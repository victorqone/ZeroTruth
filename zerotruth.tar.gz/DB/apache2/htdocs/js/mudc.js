/****View table user mudc cron**********/
function redcron(obj, c){
	var row = document.getElementById(c);
	if(obj != ""){
		row.style.display="";
	    var splcl = obj.split("|");
		var email = splcl[1];
		var phone = splcl[2];
	    document.getElementById('valueemail').value=email ;
	    document.getElementById('valuephone').value=phone ;
	}else{
		row.style.display="none";
	}
}

function showSCP() {
  if (document.getElementById('RC').checked) 
  {
      vis="block";
  } else {
       vis="none";
  }
  document.getElementById('ftpdiv').style.display = vis;
}


function showSCP() {
  if (document.getElementById('RC').checked) 
  {
      vis="block";
  } else {
       vis="none";
  }
  document.getElementById('ftpdiv').style.display = vis;
}

function showSMS() {
  if (document.getElementById('RSMS').checked) 
  {
      vis="";
  } else {
       vis="none";
  }
  document.getElementById('smsdiv').style.display = vis;
}

function showCAM() {
  if (document.getElementById('RCAM').checked) 
  {
      vis="";
      vis1="none"
  } else {
       vis="none";
       vis1=""
  }
  document.getElementById('camdiv').style.display = vis;
  document.getElementById('camdiv1').style.display = vis;
  document.getElementById('camdiv2').style.display = vis;
  document.getElementById('camdiv3').style.display = vis1;
  document.getElementById('camdiv4').style.display = vis;

}

function showCAM3() {
  if (document.getElementById('RCAM3').checked) 
  {
      vis="";
      vis1="none"
  } else {
       vis="none";
       vis1=""
  }
  document.getElementById('camdiv5').style.display = vis;
  document.getElementById('camdiv6').style.display = vis;
  document.getElementById('camdiv7').style.display = vis;
}

function showCAM4() {
  if (document.getElementById('RCAM4').checked) 
  {
      vis="";
      vis1="none"
  } else {
       vis="none";
       vis1=""
  }
  document.getElementById('camdiv8').style.display = vis;
  document.getElementById('camdiv9').style.display = vis;
}



function BaseURL(protocol,port) {
  var host = location.hostname;
  if (protocol == 'https:') { port = port + 1000 };
  return protocol+"//"+host+":"+port;
}

function snapshot() {
   var url = BaseURL(location.protocol,8088);
   var newwin=window.open(url+"/cgi-bin/snapshot.sh","snapshot","top=200,left=300,width=550,height=520,scrollbars=yes,menubar=no,toolbar=no,statusbar=no");
   newwin.focus();
}

function BaseURLVPN(portv) {
  var protocol = location.protocol;
  var host = location.hostname;
  return protocol+"//"+host+":"+portv;
}

function snapshotvpn(portvpn) {
   var url = BaseURLVPN(portvpn);
   var newwin=window.open(url+"/cgi-bin/snapshot.sh","snapshot","top=200,left=300,width=550,height=520,scrollbars=yes,menubar=no,toolbar=no,statusbar=no");
   newwin.focus();
}

function ipc() {
  var host = location.hostname;
  return host;
}
