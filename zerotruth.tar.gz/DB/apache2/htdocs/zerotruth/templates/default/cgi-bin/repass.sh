#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh
if [ -n "$CLOSE" ];then
	echo "<script>setTimeout('window.close()', 4)</script>"
fi


CR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote' | awk '{print $2}')
if [ -z $(cat $C_SYSTEM/cp/Connected/*/User | grep $USERNAME) ] && [ "$CR" == "?" ];then
	echo "<script language=\"javascript\">
	location.replace(\"http://www.zerotruth.net\");
	</script>"
fi
cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
<script>
function Controlla() {
	var OLDPASS = document.getElementById("OLDPASS").value;
	var NEWPASS = document.getElementById("NEWPASS").value;
	var NEWPASS1 = document.getElementById("NEWPASS1").value;
	var myregexp = /^[A-Za-z0-9]+$/;
	if (myregexp.test(NEWPASS) == false){
		alert("$L_DISALLOWED_CHAR");
		document.register.NEWPASS.focus();
		return false;
	}
	else if (NEWPASS != NEWPASS1) {
		alert("$L_WRONG_PASS");
		document.register.NEWPASS1.focus();
		return false;
	}
	else
	{

		document.register.action = "repass.sh";
		document.register.method = "POST";
		document.register.submit();
	}
}
</script>
EOF
echo "</head><body>"
echo "</head><body onload=\"DrawCaptcha();\">
<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>"

if [ -z "$C_EMAIL_ABIL" ];then
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p><font color=\"red\">$L_NO_SERVICE</font><p>
	<form action=\"repass.sh\" method=\"post\">
	<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$L_CHANGE_PASS</div>
	</body></html>"
	exit
fi

avviso () {
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p><font color=\"$1\">$2</font><p>
	<form action=\"repass.sh\" method=\"post\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$3\">
	<input type=\"submit\" name=\"$4\" class=\"bottone\" value=\"$5\"></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$6</div>
	</body></html>"
}
if [ -n "$CONTROL" ];then
	if [ -n "$CONTROLCODICE" ];then
		if [ -z "CODICE1" ];then
			avviso "red" "$L_WRONG_COD" "$USERNAME"  "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
			exit
		fi
		if [ "$CODICE" != "$CODICE1" ];then
			avviso "red" "$L_WRONG_COD" "$USERNAME" "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
			exit
		fi
		CONTROLN=$(echo "$NEWPASS" | wc -m | awk '{print $1}')
		if [ "$CONTROLN" -lt "$C_LENGH_PASSWORD" ];then
			  avviso "red" "$L_PASSWORD_SHORT" "$USERNAME"  "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
			  exit
		else
			FILE="dn: cn=$USERNAME,ou=Radius,$C_LDAPBASE\nsn: $NEWPASS"
			echo -e "$FILE" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 2>/dev/null >/dev/null|| CONTROLMOD="NO"
			if [ -n "$CONTROLMOD" ]; then
				avviso "red" "$L_PROBLEM_INSERTING" "$USERNAME" "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
			else
				$C_ZT_BIN_DIR/zt "UpdateK5" ": $NEWPASS" "$USERNAME"
				avviso "blue" "$L_TEXT_NEW_PASS" "$USERNAME" "CLOSE" "$L_CLOSE" "$L_CHANGE_PASS"
			fi
			exit
		fi
	fi
	LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME givenname sn )
	NAME=$(echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g')
	LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g')
	RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn)
	OLDPASS1=$( echo $RADIUS | awk '{print $NF}')
	if [ "$OLDPASS1" != "$OLDPASS" ];then
		avviso "red" "$L_MISS_PASSWORD" "$USERNAME" "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
		exit
	fi
	if [ "$NEWPASS" != "$NEWPASS1" ] || [ -z "$NEWPASS" ] || [ -z "$NEWPASS1" ];then
		avviso "red" "$L_WRONG_PASS" "$USERNAME" "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
		exit
	fi
	if [ $(echo "$NEWPASS" | grep '-') ];then
		avviso "red" "$L_DISALLOWED_CHAR_PASS" "$USERNAME" "GO_BACK" "$L_GO_BACK" "$L_CHANGE_PASS"
		exit
	fi
	MATRICE="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz"
	while [ "${A:=1}" -le 12 ]
	do
		CODICE="$CODICE${MATRICE:$(($RANDOM%${#MATRICE})):1}"
		let A+=1
	done
	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n$L_USERNAME: $USERNAME\n$L_NAME: $NAME\n$L_LAST_NAME: $LAST_NAME\n$L_COD_ACT: $CODICE\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	$C_ZT_BIN_DIR/zt "Email" "$L_CHANGE_PASS" "$TEXT_EMAIL" "$EMAIL" 2>/dev/null >/dev/null
	echo "<div id=\"paginareg\">
	<table class=\"tabellareg\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"blue\" size=\"3\">$L_TXT_COD</font><p>
	<font color=\"blue\" size=\"3\">$L_INSERT_DATA</font><br>
	<form name=\"controlcod\" method=\"POST\" action=\"repass.sh\">
	<center><input type=\"text\" style=\"text-align: center\" name=\"CODICE\" value=\"\">
	<input type=\"hidden\" name=\"CODICE1\" value=\"$CODICE\">
	<input type=\"hidden\" name=\"CONTROLCODICE\" value=\"ok\">
	<input type=\"hidden\" name=\"NEWPASS\" value=\"$NEWPASS\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"CONTROL\" value=\"OK\">
	<p><input type=\"submit\" class=\"bottone\" name=\"SALVA\" value=\"$L_SENDS\"></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$L_CHANGE_PASS</div>
	</body></html>"
	exit
fi
LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME uid givenName sn mail)
NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g')
LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g')
EMAIL=$( echo "$LINE" | grep -e '^mail: ' | sed 's/^mail: //g')
LP=$(echo $EMAIL | wc -m)
[ "$EMAIL" == "?" ] && CONTROLEMAIL="no"
echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">
<div id=\"tabella\">"
echo "<form name=\"register\" method=\"POST\">
<font color=\"blue\" size=\"3\">$L_INSERT_DATA</font><br>
($L_LENGTH_PASSWORD: $L_MIN_CHARS $C_LENGH_PASSWORD)<p>
<table width=\"350\">
	<tr><td>$L_OLD_PASS:</td>
	<td><input style=\"width:170px\" type=password id=\"OLDPASS\" name=\"OLDPASS\" value=\"\"></td></tr>
	<tr><td>$L_NEW_PASS:</td>
	<td><input style=\"width:170px\" type=password id=\"NEWPASS\" name=\"NEWPASS\" value=\"\"></td></tr>
	<tr><td>$L_NEW_PASS:</td>
	<td><input style=\"width:170px\" type=password id=\"NEWPASS1\" name=\"NEWPASS1\" value=\"\"></td></tr>"
	if [ -n "$CONTROLEMAIL" ];then
		echo "<tr><td>$L_EMAIL:</td>
		<td><input type=text name=\"EMAIL\" value=\"\"></td></tr>"
	else
		echo "<input type=\"hidden\" name=\"EMAIL\" value=\"$EMAIL\">"
	fi
	echo "<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"CONTROL\" value=\"OK\">
</table></div>
<p><input type=\"button\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\" onclick=\"Controlla()\"></form>"
echo "</td></tr></table>
</div>
<div id=\"scritta\">$L_CHANGE_PASS</div>
</body>
</html>"
