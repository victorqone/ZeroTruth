#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#**********************************************************************

echo "Content-type: text/html"
echo ""


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
		[ "$NOMEVAR" == "USERNAME" ] && USERNAME=$(echo "$USERNAME" | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
<script type="text/javascript">
	function Modulo()
	{
		var a = Math.ceil(Math.random() * 10)+ '';
		var b = Math.ceil(Math.random() * 10)+ '';
		var c = Math.ceil(Math.random() * 10)+ '';
		var d = Math.ceil(Math.random() * 10)+ '';
		var e = Math.ceil(Math.random() * 10)+ '';
		var f = Math.ceil(Math.random() * 10)+ '';
		var g = Math.ceil(Math.random() * 10)+ '';
		var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
		document.getElementById("txtCaptcha").value = code
//		var controlemail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

	}
	function Control(){
		var USERNAME = document.getElementById("USERNAME").value;
		var NAME = document.getElementById("NAME").value;
		var LAST_NAME = document.getElementById("LAST_NAME").value;
		var EMAIL = document.getElementById("EMAIL").value;
		var PREFIX = document.getElementById("PREFIX").value;
		var PHONE = document.getElementById("PHONE").value;
		var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
		var str2 = removeSpaces(document.getElementById('txtInput').value);
		var controlemail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var controlprefix = /^[1-9][0-9]{0,2}$/;
		if ((NAME == "") || (NAME == "undefined")) {
			alert("$L_NAME: $L_MISSING_DATA");
			document.register.NAME.focus();
			return false;
		}
		else if ((LAST_NAME == "") || (LAST_NAME == "undefined")) {
			alert("$L_LAST_NAME: $L_MISSING_DATA");
			document.register.LAST_NAME.focus();
			return false;
		}
		else if (((!controlemail.test(EMAIL)) || (EMAIL == "") || (EMAIL == "undefined")) && (EMAIL != "30091960")) {
			alert("$L_WRONG_EMAIL");
			document.register.EMAIL.focus();
			return false;
		}
		else if ((isNaN(PREFIX)) || (PREFIX.length < 2) || (PREFIX == "") || (PREFIX == "undefined") ||  (!controlprefix.test(PREFIX))) {
			alert("$L_WRONG_PREFIX");
			document.register.PREFIX.focus();
			return false;
		}
		else if ((isNaN(PHONE)) || (PHONE.length < 8) || (PHONE == "") || (PHONE == "undefined")) {
			alert("$L_WRONG_TELEPHONE");
			document.register.PHONE.focus();
			return false;
		}
		else if (str1 != str2)	{
			alert("$L_CAPTCHA_ERROR");
			document.register.txtInput.value = "";
			document.register.txtInput.focus();
			return false;
		}
		else
		{

			document.register.action = "register.sh";
			document.register.method = "POST";
			document.register.submit();
		}
	}
	function removeSpaces(string)
	{
		return string.split(' ').join('');
	}
</script>

</head><body onload="Modulo()">
EOF

if [ -z "$C_AUTO_REGISTER" ];then
	exit
fi

echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>
<div id=\"scritta\">$L_SELF_REGISTER</div>"
date2stamp () {
  date --utc --date "$1" +%s
}

stamp2date (){
  date --utc --date "1970-01-01 $1 sec" "+%Y-%m-%d %T"
}
dateDiff (){
  case $1 in
		-s)  sec=1;   shift;;
		-m)  sec=60;   shift;;
		-h)  sec=3600;  shift;;
		-d)  sec=86400; shift;;
		*)  sec=86400;;
	esac
	dte1=$(date2stamp $1)
	dte2=$(date2stamp $2)
	diffSec=$((dte2-dte1))
	if ((diffSec < 0)); then abs=-1; else abs=1; fi
	echo $((diffSec/sec*abs))
}
error () {
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\"><font color=\"red\" size=\"3\">$1</font><p>
	<p><form action=\"register.sh\" method=\"post\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$2\">
	<input type=\"hidden\" name=\"NAME\" value=\"$3\">
	<input type=\"hidden\" name=\"LAST_NAME\" value=\"$4\">
	<input type=\"hidden\" name=\"EMAIL\" value=\"$5\">
	<input type=\"hidden\" name=\"PREFIX\" value=\"$6\">
	<input type=\"hidden\" name=\"PHONE\" value=\"$7\">
	<input type=\"submit\" name=\"$L_GO_BACK\"
	class=\"bottone\" value=\"$L_GO_BACK\"></form>
	</td></tr></table>
	</div>
	</body></html>"
	exit
}
if [ -n "$CLOSE" ];then
	if [ -z "$NG" ];then
		if [ "$CPP" == "yes" ];then
			USERNAME="$( echo "$USERNAME" | $C_ZT_BIN_DIR/base64)"
			PASSWORD="$( echo "$PASSWORD" | $C_ZT_BIN_DIR/base64)"
			echo "<script>window.opener.location = \"http://zerotruth.net/?LoginUser=$USERNAME&pass=$PASSWORD\";</script>"
		fi
		echo "<script>setTimeout('window.close()', 500);</script>"
	else
		echo "<script>window.location = \"http://www.google.com\"</script>"
	fi
	exit
fi
if [ -n "$QUERY_STRING" ];then
	if [ "$(echo "$QUERY_STRING" | cut -d'=' -f3 | cut -d'&' -f1)" == "Completed" ];then
		CONTROL_PAY="Completed"
		ID_PAY=$(echo "$QUERY_STRING" | cut -d'=' -f2 | cut -d'&' -f1 )
		CM=$(echo "$QUERY_STRING" | cut -d'=' -f6 | cut -d'&' -f1 )
		if [[ -n "$(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep CHARGE)" || -n "$(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep CHAR_IN)" ]];then
			for pr in $(seq 1 60);do
				if [ $(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep "TXN_ID" | cut -d' ' -f2) == "$ID_PAY" ];then
					[ -n "$(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep CHARGE)" ] && PAGEC="chargepaypal.sh"
					[ -n "$(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep CHAR_IN)" ] && PAGEC="chargepaypalin.sh"
					echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"0; URL=$PAGEC?st=Completed&id=$ID_PAY&cm=$CM\">"
					exit
				fi
				sleep 2
			done
			exit
		else
			for pr in $(seq 1 60);do
				if [ $(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep "TXN_ID" | cut -d' ' -f2) == "$ID_PAY" ];then
					USER_LOCK=$(cat $C_ZT_DIR/tmp/lock_pay_$CM | grep USER | cut -d' ' -f2)
					CONTROL_UL="ok"
					break
				fi
				sleep 2
			done
		fi
	fi
fi
if [[ -n "$QUERY_STRING" && -z "$CONTROL_UL" ]];then
	exit
fi
MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
MAC=$(echo "$MAC" | tr '[:lower:]' '[:upper:]')
if [ -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ];then
	CONTROL="ok"
	BLOCK_MAC="$MAC"
fi
if [ -n "$C_WAIT_REGISTER" ];then
	if [[ -n "$(cat $C_ZT_CONF_DIR/banmac | grep $MAC)" || -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ]];then
		CONTROL="ok"
		BLOCK_MAC="$MAC"
	fi
fi
DAYS=$(date +%w)
ORAS=$(date +%H)
MINS=$(date +%M)
ORAMIN=$ORAS$MINS
ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
if [[ -n "$CONTROL" || -n "$NEW_REG" ]];then
	 if [ -n "$BLOCK_MAC" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p><font color=\"red\">$L_BLOCK_MAC<p>$BLOCK_MAC</font><p>
		<form action=\"register.sh\" method=\"post\">
		<input type=\"hidden\" name=\"NG\" value=\"$NEW_REG\">
		<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
		</td></tr></table>
		</div>
		</body></html>"
		exit
	fi
	USERNAME_REG="$USERNAME"
	EMAIL_REG="$EMAIL"
	PREFIXC="$PREFIX"
	PHONEC="$PHONE"
	PHONE_REG="$PREFIX$PHONE"
	NAME_REG="$NAME"
	LAST_NAME_REG="$LAST_NAME"
	ldap_search_people "mail=$EMAIL"
	CEMAIL="$EMAIL"
	ldap_search_people "telephoneNumber=$PHONE_REG"
	CPHONE="$PHONE"

#	if [ "$C_SMS_PROVIDER" != "Gammu" ];then
		USERNAME="$USERNAME_REG"
#	else
#		USERNAME="$PHONE_REG"
#	fi
	NAME="$NAME_REG"
	LAST_NAME="$LAST_NAME_REG"
	PHONE="$PHONE_REG"
	EMAIL="$EMAIL_REG"
	if [ -n "$CEMAIL" ] && [ -z "$NEW_REG" ] && [ -z "$C_AR_NOT_EMAIL" ];then
		error "$L_EMAIL_PRE" "$USERNAME" "$NAME" "$LAST_NAME" "" "$PREFIXC" "$PHONEC"
		exit
	fi
	if [ -n "$CPHONE" ] && [ -z "$NEW_REG" ];then
		error "$L_TEL_PRE" "$USERNAME" "$NAME" "$LAST_NAME" "$EMAIL" "" ""
		exit
	fi
	[[ -n "$C_AR_FROM_TICKET" && -z "$USERNAME" ]] && USERNAME="$RANDOM$RANDOM$RANDOM"
	if [ -n "$USERNAME" ] && [ -z "$NEW_REG" ];then
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME uid )
		CUSER=$( echo "$LINE" | grep -e '^uid: ' | sed 's/^uid: //g')
		if [ -n "$C_AR_FROM_TICKET" ];then
			CONTROLFT="$(cat $C_ZT_CONF_DIR/userswait | grep "^$USERNAME")"
		else
			CONTROLFT="yes"
		fi
		if [ -z "$CONTROLFT" ];then
			error "$L_USER_NOT_WAIT" "" "$NAME" "$LAST_NAME" "$EMAIL" "" ""
			exit
		fi
		if [ -n "$CUSER" ];then
			error "$L_USER_PRE" "" "$NAME" "$LAST_NAME" "$EMAIL" "" ""
			exit
		fi
	else
		if [ -z "$NEW_REG" ];then
			if [[ "$C_USER_AS_PHONE" != "on" || -z "$PHONE" ]];then
				MATRICE="abcdefghijklmnopqrstuvwxyz"
				while [ "${n:=1}" -le "$C_LENGH_USERNAME" ];do
					USERNAME="$USERNAME${MATRICE:$(($RANDOM%${#MATRICE})):1}"
					let n+=1
				done
			else
				USERNAME="$PHONE"
			fi
		fi
	fi
	if [ -n "$(cat $C_ZT_CONF_DIR/privacy)" ];then
		TEXT_PRIVACY=$(cat $C_ZT_CONF_DIR/privacy )
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p class=\"privacy\">$TEXT_PRIVACY</p>
		<form method=\"POST\" action=\"register.sh\">
		$L_AGREE <input name=\"ACCEPT\" type=\"checkbox\"><p>
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"NAME\" value=\"$NAME\">
		<input type=\"hidden\" name=\"LAST_NAME\" value=\"$LAST_NAME\">
		<input type=\"hidden\" name=\"EMAIL\" value=\"$EMAIL\">
		<input type=\"hidden\" name=\"PREFIXC\" value=\"$PREFIXC\">
		<input type=\"hidden\" name=\"PHONEC\" value=\"$PHONEC\">
		<input type=\"hidden\" name=\"PHONE\" value=\"$PREFIXC$PHONEC\">
		<input type=\"hidden\" name=\"CONTROL_ACCEPT\" value=\"OK\">
		<input type=\"hidden\" name=\"CONTROL_NEW\" value=\"$NEW_REG\">
		<input type=\"hidden\" name=\"PASSWORD\" value=\"$PASSWORD\">
		<input type=\"submit\" name=\"INTERFACE\" class=\"bottone\" value=\"$L_CONTINUE\"></form>
		</td></tr></table>
		</div>
		</body></html>"
		exit
	else
		CONTROL_ACCEPT="OK"
		CONTROL_NEW="$NEW_REG"
		ACCEPT="on"
	fi
fi
if [ -n "$CONTROL_ACCEPT" ] && [ -z "$ACCEPT"];then
	error "$L_NOT_AGREE" "$USERNAME" "$NAME" "$LAST_NAME" "$EMAIL" "$PREFIXC" "$PHONEC"
	exit
fi

if [[ -n "$CONTROL_ACCEPT" && "$ACCEPT" == "on" ]] || [ -n "$CONTROL_PAY" ];then
	CHARGE_TYPE=$(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType)
	if [[ "$CHARGE_TYPE" == "pre" && -z "$CONTROL_PAY"  && -n "$C_ACTIVE_PP" ]];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">"
		$C_ZT_BIN_DIR/zt "Salva" "USER $USERNAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "NAME $NAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "LAST_N $LAST_NAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "EMAIL $EMAIL" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "PHONE $PHONE" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "yes"
		cat $C_ZT_CONF_DIR/ppbutton | sed "s/<input type=\"image/<input type=\"hidden\" name=\"custom\" value=\"$USERNAME\"> <input type=\"image/g"
		echo "</td></tr></table>
		</div>
		</body></html>"
		exit
	fi
	if [ -n "$CONTROL_PAY" ];then
		USERNAME=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep USER | awk '{print $2}')
		NAME="$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep NAME | awk '{print $2,$3}' | sed 's/ $//g')"
		LAST_NAME="$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep LAST_N | awk '{print $2,$3}' | sed 's/ $//g')"
		EMAIL=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep EMAIL | awk '{print $2}')
		PHONE=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PHONE | awk '{print $2}')
		if [[ "$CONTROL_PAY" == "Completed" && "$ID_PAY" == $(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}') ]];then
			[ ! -f $C_ZT_LOG_DIR/pp/payments ] && touch $C_ZT_LOG_DIR/pp/payments
			DATAD=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_DATE | sed "s/PAYMENT_DATE //g")
			DATAH=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_HOUR | awk '{print $2}')
			CREDIT=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep AMMOUNT | awk '{print $2}')
			TID=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}')
			$C_ZT_BIN_DIR/zt "Aggiungi"	"$USER_LOCK+$DATAD+$DATAH+$CREDIT+$TID" "$C_ZT_LOG_DIR/pp/payments"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
			CPP="yes"
		else
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
			error "NOT APPROVED"
			exit
		fi
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "no"
		$C_ZT_BIN_DIR/zt "KillCP" "$REMOTE_ADDR"
	fi

	if [ -z "$CONTROL_NEW" ];then
		MATRICE=$(gen_pass ${C_PASS_CHARS:-7})
		while [ "${a:=1}" -le "$C_LENGH_PASSWORD" ];do
			PASSWORD="$PASSWORD${MATRICE:$(($RANDOM%${#MATRICE})):1}"
			let a+=1
		done

		UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uidNumber | sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n | tail -1 )
		UIDNUMBER=$(($UIDN+1))
	fi
	TODAY=$(dateDiff -d "1970-01-01" "$(date +%Y)-$(date +%m)-$(date +%d)")
	if [ -z "$C_AR_EXPIRE" ];then
		C_AR_EXPIRE=24836
	else
		SHADOWEXPIRE=$C_AR_EXPIRE
		DIFF_DATE=$(($SHADOWEXPIRE-$TODAY))
		AR_YEAR=$(date +%Y --date="+$DIFF_DATE days")
		AR_MONTH=$(date +%m --date="+$DIFF_DATE days")
		AR_DAY=$(date +%d --date="+$DIFF_DATE days")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	if [ -n "$C_AR_EXPIRE_DAYS" ];then
	 	AR_YEAR=$(date +%Y --date="+$C_AR_EXPIRE_DAYS days")
		AR_MONTH=$(date +%m --date="+$C_AR_EXPIRE_DAYS days")
		AR_DAY=$(date +%d --date="+$C_AR_EXPIRE_DAYS days")
		SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$AR_YEAR-$AR_MONTH-$AR_DAY")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	PASSWORD_ORI="$PASSWORD"
	CLASS="$C_AR_CLASS"
	UTENTEC="$C_ADMIN"
	INFO="autoregister"
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_people
	else
		ldap_modify_people "shadowExpire"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		error "$L_PROBLEM_INSERTING"
		exit
	fi
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_radius
	else
		ldap_modify_radius "sn radiusUserCategory"
	fi
	if [[ -z "$CONTROLMODIFY" && -z "$CONTROLADD" ]]; then
		$C_ZT_BIN_DIR/zt "RimuoviRiga" "$USERNAME" "$C_ZT_CONF_DIR/userswait"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
		error "$L_PROBLEM_INSERTING"
		exit
	fi
	if [ -n "$CREDIT" ];then
		if [ $(cat $C_ACCT_DIR/credits/$USERNAME/Credit) ];then
			CREDITES=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
		else
			CREDITES=0
		fi
		CREDIT=$(echo "$CREDITES+$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		if [ ! -d "$C_ACCT_DIR/credits/$USERNAME" ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USERNAME"
		fi
			$C_ZT_BIN_DIR/zt "Salva" "$CREDIT" "$C_ACCT_DIR/credits/$USERNAME/Credit"
	fi
	$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	if [ -z "$CONTROL_NEW" ];then
		$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
		$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$DATEK5"
	else
		$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME" "NEWREG"
		$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USERNAME" "$DATEK5"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_ACCT_DIR/entries/$USERNAME/MB"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_ACCT_DIR/entries/$USERNAME/Time"
	fi
	if [ $SHADOWEXPIRE == 24836 ];then
		EXPIRE=$L_NO_LIMIT
	else
		if [ "$C_FORM_DATE" == "ita" ];then
			EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%d/%m/%Y)
		else
			EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y/%m/%d)
		fi
	fi
	if [ "$C_FORM_DATE" == "ita" ];then
		DATE_CREATED=$(date +%d/%m/%Y)
	else
		DATE_CREATED=$(date +%Y/%m/%d)
	fi
	if [ "$C_AUTO_PASS_EMAIL" == "on" ];then
		PASS_EMAIL="$PASSWORD_ORI"
	else
		PASS_EMAIL="$L_SENT_BY_SMS"
	fi
	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n"
	TEXT_EMAIL="$TEXT_EMAIL\n$L_USERNAME: $USERNAME\n$L_PASSWORD: $PASS_EMAIL\n$L_NAME: $NAME\n$L_LAST_NAME: $LAST_NAME\n$L_TELEPHONE: $PHONE"
	if [ -n "$CREDIT" ];then
		TEXT_EMAIL="$TEXT_EMAIL\n$L_CREDIT: $CREDIT"
	fi
	TEXT_EMAIL="$TEXT_EMAIL\n$L_CLASS: $C_AR_CLASS\n$L_CREATED: $DATE_CREATED\n$L_EXPIRY: $EXPIRE"
	limituser "$USERNAME"
	limituseremail
	TEXT_EMAIL="$TEXT_EMAIL\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	if [ -z "$C_AR_NOT_EMAIL" ];then
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME" "$TEXT_EMAIL" "$EMAIL" 2>/dev/null >/dev/null
	fi
	if [ "$C_SMS_PROVIDER" != "Gammu" ] || [[ "$C_SMS_PROVIDER" == "Gammu" && -n "$C_SEND_SMS_GAMMU" ]];then
		TEXT_SMS="$C_HOTSPOT_NAME $L_USERNAME $USERNAME - $L_PASSWORD $PASSWORD_ORI - $L_NAME $NAME - $L_LAST_NAME $LAST_NAME"
		if [ -z "$C_AR_NOT_EMAIL" ];then
			TEXT_SMS="$TEXT_SMS - $L_FOOTER_SMS"
		fi
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$PHONE" "$TEXT_SMS" "" "credit"
	fi
	if [ -n "$C_WAIT_REGISTER" ];then
		if ! [ -d $C_ZT_LOG_DIR/controlregister ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_LOG_DIR/controlregister"
		fi
		 $C_ZT_BIN_DIR/zt "Aggiungi" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4) $(date +%s)" "$C_ZT_LOG_DIR/controlregister/control"
	fi
	POST_REGISTRATION="$(cat /Database/var/register/system/cp/Auth/Custom/PostRegistration | sed '/\\/s///g')"
	if [ "$C_SMS_PROVIDER" == "Gammu" ];then
		POST_REGISTRATION="$(echo "$POST_REGISTRATION" | sed "s/MY_NUMBER/\+$C_MY_NUMBER/g" | sed "s/USER_NUMBER/\+$USERNAME/g")"
	fi
	if [ "$CPP" == "yes" ];then
		POST_REGISTRATION="USERNAME: $USERNAME PASSWORD: $PASSWORD<br>$POST_REGISTRATION"
	fi
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p class=\"privacy\">$POST_REGISTRATION</p>
	<form action=\"register.sh\" method=\"post\">
	<input type=\"hidden\" name=\"NG\" value=\"$CONTROL_NEW\">"
	if [ "$CPP" == "yes" ];then
		echo "<input type=\"hidden\" name=\"CPP\" value=\"yes\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"PASSWORD\" value=\"$PASSWORD\">"
	fi
	echo "<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
	</td></tr></table>
	</div>
	</body></html>"
	MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
	$C_ZT_BIN_DIR/zt "RimuoviRiga" "$MAC" "$C_ZT_CONF_DIR/tmp_banmac"
	CHARGE_TYPE=$(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType)
	if [ "$CHARGE_TYPE" == "pre" ];then
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "no"
		$C_ZT_BIN_DIR/zt "KillCP" "$REMOTE_ADDR"
	fi
	if [ -n "$C_NOT_EMAIL_ADD_USER" ] && [ -n "$C_ADMIN_EMAIL" ];then
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL" "$C_ADMIN_EMAIL"
	fi
	if [ "$C_NOT_SMS_ADD_USER" == "on" ] && [ -n "$C_ADMIN_PHONE" ];then
		TEXT_SMS="$C_HOTSPOT_NAME: $L_USERADD $USERNAME $NAME $LAST_NAME ($L_SELF_REGISTER)"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS" "" "credit"
	fi
	exit
fi
echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">"
if [ -n "$C_WAIT_REGISTER" ];then
	LINE=$(cat $C_ZT_LOG_DIR/controlregister/control | grep $(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4) | tail -1)
	if [ -n "$LINE" ];then
		TIME_LAST=$(echo -e "$LINE" | cut -d' ' -f2)
		TIME_NOW=$(date +%s)
		TIME_PAST=$(($TIME_NOW-$TIME_LAST))
		TIME_WAITING=$(($C_WAIT_REGISTER*60))
		if [ "$TIME_WAITING" -gt "$TIME_PAST" ];then
			WAIT=$(($TIME_WAITING-$TIME_PAST))
			WAITM=$(($WAIT/60))
			[ "$WAITM" == 0 ] && WAITM="$L_LESS_MIN"
			echo "<p>&nbsp;<p>
			<font color=\"blue\">MAC address: $(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)</font> <p>
			<font color=\"red\" size=\"4\">$L_NO_SERVICE<br>$L_FOR_MINUTES: $WAITM</font>
			<form action=\"register.sh\" method=\"post\">
			<input type=\"hidden\" name=\"NG\" value=\"$NEW_REG\">
			<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>"
			NEW_REG="no"
			exit
		fi
	fi
fi

if [ -z "$CONTROL_NEW_REGISTER" ];then
	echo "<form name=\"register\">
	<font size=\"2\" color=\"blue\">"
	echo "$L_PHONE: $L_WITH_PREFIX</font>
	<table>"
#	if [ "$C_SMS_PROVIDER" != "Gammu" ];then
		if [ -z "$C_USER_AS_PHONE" ];then
			echo "<tr><td>$L_USER_NAME:</td>
			<td colspan=\"2\"><input class=\"input\" id=\"USERNAME\" type=\"text\" name=\"USERNAME\" value=\"$USERNAME\"></td></tr>"
		else
			echo "<input type=\"hidden\"  id=\"USERNAME\" type=\"text\" name=\"USERNAME\" value=\"\">"
		fi
#	else
#		echo "<input type=\"hidden\"  id=\"USERNAME\" type=\"text\" name=\"USERNAME\" value=\"$USERNAME\">"
#	fi
	echo "<tr><td>$L_NAME:</td>
	<td colspan=\"2\"><input class=\"input\" id=\"NAME\" name=\"NAME\" type=\"text\"  value=\"$NAME\"></td></tr>
	<tr><td>$L_LAST_NAME:</td>
	<td colspan=\"2\"><input class=\"input\" id=\"LAST_NAME\" type=\"text\" name=\"LAST_NAME\" value=\"$LAST_NAME\"></td></tr>"
	if [ -z "$C_AR_NOT_EMAIL" ];then
		echo "<tr><td>$L_EMAIL:</td>
		<td colspan=\"2\"><input class=\"input\" id=\"EMAIL\" type=\"text\" name=\"EMAIL\" value=\"$EMAIL\"></td></tr>"
	else
		echo "<input type=\"hidden\" id=\"EMAIL\" name=\"EMAIL\" value=\"30091960\">"
	fi
	echo "<tr><td>$L_PHONE:</td>"
	[ -z "$PREFIX" ] && PREFIX=$C_PREFIX
	echo "<td><input class=\"inputprefix\" id=\"PREFIX\" type=\"tel\" size=\"2\" name=\"PREFIX\" value=\"$PREFIX\"></td>
	<td><input class=\"inputphone\" id=\"PHONE\" type=\"tel\" size=\"12\" name=\"PHONE\" value=\"$PHONE\"></td>
	</tr>
	</table>
	<input type=\"hidden\" name=\"CONTROL\" value=\"OK\">
	$L_COPY_CATPCHA<br>
	<input readonly type=\"text\" id=\"txtCaptcha\"
	style=\"background-image:url(/images/template/imgcaptcha.png); text-align:center; border:none;
	font-weight:bold; font-size: 16px;\"><br>
	<input type=\"tel\" style=\"text-align: center\" id=\"txtInput\">
	<p><input type=\"button\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\" onclick=\"Control();\"></form>"
else
	ldap_search_people "uid=$USERNAME_LOGIN"
	ldap_search_radius "$USERNAME_LOGIN"
	PREFIX="${PHONE:0:2}"
	PHONE="${PHONE:2}"
	echo "<form name=\"registernew\" action=\"register.sh\" method=\"POST\">
	<table>
	<tr><td>$L_USER_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"USERNAME\" value=\"$USERNAME\"></td></tr>
	<tr><td>$L_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly name=\"NAME\" type=\"text\"  value=\"$NAME\"></td></tr>
	<tr><td>$L_LAST_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"LAST_NAME\" value=\"$LAST_NAME\"></td></tr>"
	if [ -z "$C_AR_NOT_EMAIL" ];then
		echo "<tr><td>$L_EMAIL:</td>
		<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"EMAIL\" value=\"$EMAIL\"></td></tr>"
	else
		echo "<input type=\"hidden\" name=\"EMAIL\" value=\"30091960\">"
	fi
	echo "<tr><td>$L_PHONE:</td>
	<td><input class=\"inputprefix\"  type=\"tel\" readonly size=\"2\" name=\"PREFIX\" value=\"$PREFIX\"></td>
	<td><input class=\"inputphone\" type=\"tel\"  readonly size=\"2\" name=\"PHONE\" value=\"$PHONE\"></td>
	</tr>
	</table>
	<input type=\"hidden\" name=\"PASSWORD\" value=\"$PASSWORD\">
	<input type=\"hidden\" name=\"NEW_REG\" value=\"OK\">
	<p><input type=\"submit\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\"></form>"
fi
echo "</td></tr>
</table>
</div>
</body>
</html>"
