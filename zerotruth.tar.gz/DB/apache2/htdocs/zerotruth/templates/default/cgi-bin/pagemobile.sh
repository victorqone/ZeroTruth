#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
[ -z "$REDIRECT" ] && REDIRECT="http://www.google.com"
if [ -n "$CLOSE" ];then
	$C_ZT_BIN_DIR/zt "Disconnetti" "$IPCON" "$USERNAME"
	echo "<script language=\"javascript\">
	location.replace(\"http://www.google.com\");
	</script>"
	exit
fi

if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh

CR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote' | awk '{print $2}')
if [ -z $(cat $C_SYSTEM/cp/Connected/$IPCON/User | grep $USERNAME) ] && [ "$CR" == "?" ];then
	echo "<script language=\"javascript\">
	location.replace(\"http://www.zerotruth.net\");
	</script>"
fi
if [ ! -f $C_CP_DIR/Connected/$IPCON/Renew ];then
	RENEW=0
else
	RENEWEX="$(cat $C_CP_DIR/Connected/$IPCON/Renew)"
	RENEW=$((RENEWEX+1))
fi
NOW=$(date +%s)
$C_ZT_BIN_DIR/zt "Salva" "$NOW" "$C_CP_DIR/Connected/$IPCON/Now"
$C_ZT_BIN_DIR/zt "Salva" "$RENEW" "$C_CP_DIR/Connected/$IPCON/Renew"
CLASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME radiusUserCategory | grep '^radiusUserCategory' | awk '{print $2}')
EMAIL=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME mail  | grep '^mail: ' | awk '{print $2}')
LP=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn | grep '^sn: ' | awk '{print $2}' | wc -m )
TYPE_CLASS=$(cat $C_CLASSES_DIR/$CLASS/ChargeType)
echo "<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">"
cat <<EOF
<script src="/js/zt.js" type="text/javascript"></script>
<script>
function AutoRefresh( t ) {
	setTimeout("location.reload(true);", t);
}
</script>
<style type="text/css">
body {
	font: 10px "Trebuchet MS",Arial,sans-serif;
	text-align: center;
}
input {
	color: #201561;
	background: #feffc5;
	border: 1px solid #c15959;
}
input.bottoneconf {
	display: block;width: 138px;height: 20px;
	border: 0px;
	display: inline-block;
	text-decoration: none;
	text-align: center;
	font: bold 14px/18px "Trebuchet MS",Arial,sans-serif;
	background: url(/images/template/bottone.png);
	color: #286C98
}
input.bottone:hover {
	color: #0D4B72
}
#logouser{
	position:absolute;
	top: 15px;
	left:50%;
	margin-left: -229px;
	z-index:10;
}

.interna {
	width: 90%;
	border: 2px solid #cfcfcf;
	background-color: #f3f3f3;
	margin:0 auto;
	font: 16px "Trebuchet MS",Arial,sans-serif;
}

.esterna {
	table-layout: fixed;
	width: 90%;
	border: 2px solid #cfcfcf;
	background-color: #ffffff;
	margin:0 auto;
}

table {
	 border-collapse: collapse ;
	 border-color: #a0a0f0 ;
}

</style>

</script>
</head><body <body onload="JavaScript:AutoRefresh(120000);">
EOF


if [ "$C_FORM_DATE" == "ita" ];then
	TODAY=$(date +%d/%m/%Y)
else
	TODAY=$(date +%Y/%m/%d)
fi
if [ "$LP" -gt 15 ];then
	NAMEUSER="$EMAIL"
else
	NAMEUSER="$USERNAME"
fi
echo "<table class=\"esterna\"></tr><td align=\"center\">
<img src=\"/images/template/imguser.png\" WIDTH=\"100%\"  border=\"0\">
<br>&nbsp;<br><font color=\"#0000FF\" size=\"5\"><center>$(cat $C_HTDOCS_ZT_DIR/msg/$LANGUAGE/WELCOME) $NAMEUSER</font><br>&nbsp;<br>
<font color=\"#0000FF\" size=\"2\">$TODAY $(date +%H:%M:%S)</font>
<p>
<table class=\"interna\" border=\"1\">
	<tr>
		<td align=\"center\" background=\"/images/template/imgtable.png\">Client</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">Start</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">RX</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">TX</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">$L_TRAFFIC</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">$L_TIME</td>
	</tr>"
if [ -z "$STARTC" ];then
	if [ "$C_CP_LOCAL_TYPE" == "Client" ];then
		STARTC="$NOW"
	else
		STARTC=$(cat $C_CP_DIR/Connected/$IPCON/Started)
	fi
fi
DTIME=$(($NOW-$STARTC))
TIME=$(oraconv $DTIME)
if [ "$C_FORM_DATE" == "ita" ];then
	START="$(date -d "1970-01-01 $STARTC sec GMT " +%d/%m/%Y-%H:%M:%S)"
else
	START="$(date -d "1970-01-01 $STARTC sec GMT" +%Y/%m/%d-%H:%M:%S)"
fi

MAC=$(cat $C_CP_DIR/Connected/$IPCON/MAC)
RX=$(cat $C_CP_DIR/Connected/$IPCON/RX-Octets)
TX=$(cat $C_CP_DIR/Connected/$IPCON/TX-Octets)
TRAFFIC=$(($RX+TX))
RX=$( echo "$RX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
TX=$( echo "$TX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
echo "<tr><td align=\"center\">$IPCON/$MAC</td>
<td align=\"center\">$START</td>
<td align=\"center\">$RX</td>
<td align=\"center\">$TX</td>
<td align=\"center\">$TRAFFIC</td>
<td align=\"center\">$TIME</td></tr>	
</table>
<p>
<table><tr>
<td align=\"center\"><a href=\"pagemobile.sh?IPCON=$IPCON&USERNAME=$USERNAME&CLOSE=yes\"><img src=\"/images/template/disconnetti.png\"
onClick=\"javascript:return confirm('$(cat $C_HTDOCS_ZT_DIR/msg/$LANGUAGE/DisconnectionAlert)');\"></a></td>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td align=\"center\"><a href=\"$REDIRECT\" target=\"_blank\"><img src=\"/images/template/continua.png\"</a></td></tr>
<tr><td align=\"center\"><a href=\"pagemobile.sh?IPCON=$IPCON&USERNAME=$USERNAME&CLOSE=yes\">$L_DISCONNECT1</a></td>
<td></td>
<td align=\"center\"><a href=\"$REDIRECT\" target=\"_blank\">$L_CONTINUE</a></td></tr>
<tr><td>&nbsp;</td><td></td><td></td></tr>
<tr><td>
<form action=\"detailsol.sh\" target=\"_blank\" method=\"GET\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
	<input type=\"submit\" name=\"DET\" class=\"bottoneconf\" value=\"$L_USER_DETAILS1\">
</form>
</td><td></td><td>
<form action=\"detailsolcon.sh\" target=\"_blank\" method=\"GET\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
	<input type=\"submit\" name=\"CON\" class=\"bottoneconf\" value=\"$L_SESSIONS\">
</form>
</td></tr>"
if [[ "$(cat $C_CP_DIR/Auth/Custom/CpFree)" == "no" && "$LP" -lt 15 ]];then
	echo "<tr><td><form action=\"repass.sh\" target=\"_blank\" method=\"GET\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
		<input type=\"submit\" name=\"CP\" class=\"bottoneconf\" value=\"$L_CHANGE_PASS\">
	</form>
	<td></td>"
	CHANGEP="yes"
fi
if [ "$TYPE_CLASS" == "pre" ];then
	echo "<td><form action=\"chargepaypalin.sh\" target=\"_blank\" method=\"GET\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
		<input type=\"submit\" name=\"CP\" class=\"bottoneconf\" value=\"$(cat $C_HTDOCS_ZT_DIR/msg/$LANGUAGE/ChargePayPal)\">
	</form>
	<td></td></tr>"
	CHARGE="yes"
fi
if [[ -n "$CHANGEP" && -n "$CHARGE" ]];then
	echo "</table>"
fi
if [[ -n "$CHANGEP" && -z "$CHARGE" ]];then
	echo "<td>"
fi
if [[ -z "$CHANGEP" && -z "$CHARGE" ]];then
	echo "</table>"
fi
echo "<form action=\"pagemobile.sh\" method=\"GET\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
	<input type=\"hidden\" name=\"STARTC\" value=\"$STARTC\">
	<input type=\"submit\" name=\"CON\" class=\"bottoneconf\" value=\"$L_MODIFY\">
	</form>"
if [[ -n "$CHANGEP" && -z "$CHARGE" ]];then
	echo "</td></tr></table>"
fi
echo "<p><font color=\"red\">$(cat $C_HTDOCS_ZT_DIR/msg/$LANGUAGE/DoNotClose)</font><p>"
if [ "$RENEW" -gt 0 ] ;then
	echo "<font color=\"blue\">$(cat $C_HTDOCS_ZT_DIR/msg/$LANGUAGE/RenewAuth): $RENEW</font>"
fi
echo "</table>
<p><b>Powered by Zeroshell &amp; Zerotruth</b>
</body>
</html>"
