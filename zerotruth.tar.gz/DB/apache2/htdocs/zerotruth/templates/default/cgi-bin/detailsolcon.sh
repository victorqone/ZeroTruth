#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
USERNAME=$(echo "$USERNAME" | sed 's/\%3A/\:/g')


CR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote' | awk '{print $2}')
if [ -z $(cat $C_SYSTEM/cp/Connected/$IPCON/User | grep $USERNAME) ] && [ "$CR" == "?" ];then
	echo "<script language=\"javascript\">
	location.replace(\"http://www.zerotruth.net\");
	</script>"
fi

echo "<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">"

cat <<EOF
<script src="/js/zt.js" type="text/javascript"></script>
<style type="text/css">
body {
	font: 14px/18px "Trebuchet MS",Arial,sans-serif;
	text-align: center;
}
input {
	color: #201561;
	background: #feffc5;
	border: 1px solid #c15959;
}
input.bottoneconf {
	display: block;width: 138px;height: 20px;
	border: 0px;
	display: inline-block;
	text-decoration: none;
	text-align: center;
	font: bold 14px/18px "Trebuchet MS",Arial,sans-serif;
	background: url(/images/template/bottone.png);
	color: #286C98
}
input.bottone:hover {
	color: #0D4B72
}
#logouser{
	position:absolute;
	top: 15px;
	left:50%;
	margin-left: -229px;
	z-index:10;
}
#dett {
	margin:0 auto;
}

.interna {
	width: 655px;
	border: 2px solid #cfcfcf;
	background-color: #f3f3f3;
	margin:0 auto;
	font: 10px/12px "Trebuchet MS",Arial,sans-serif;
}

.esterna {
	table-layout: fixed;
	width: 659px;
	border: 2px solid #cfcfcf;
	background-color: #ffffff;
	margin:0 auto;
}
.range {
	table-layout: fixed;
	width: 300px;
	border-collapse: collapse;
	background-color: #ffffff;
	margin:0 auto;
}

span.linea{
	float: left;
	margin: 0 auto;
	padding: 2;
}
table {
	 border-collapse: collapse ;
	 border-color: #a0a0f0 ;
}

.content { padding: 20px; display: inline-block; font-size: 1em; }

.ccal { width: 18em; font-size: 0.8em; margin-bottom: 5px;}
.ccal ul { margin: 0; padding: 0!important; text-align: center; }
.ccal li { list-style-type: none; display: inline-block; width: 13.2%; cursor: pointer; text-align: center; margin:0; }
.ccal li span { display: inline-block; line-height: 1.8em; }
.ccal li.calmonth { width: 66%; }
.ccal li span { padding: 0.1em 0.05em; display: block; }
.ccal li.calprev span, .ccal li.calnext span { color: #aaa; }
.ccal .calbody li.selected span { background: #666; color: white; }
.ccal .calbody li.preselected span { background: #f0f0f0; }
.ccal * { -moz-user-select: -moz-none; -khtml-user-select: none; -webkit-user-select: none; -ms-user-select: none; user-select: none; }
.today { font-weight: bold; }
.calendar-canvas {
	text-align: center;
	background: white;
	v-moz-box-shadow: 0 3px 4px #999999;
	-moz-box-shadow: 0 3px 4px #999999;
	-webkit-box-shadow: 0 3px 4px #999999;
	box-shadow: 0 1px 2px #999999;
}

#popitmenu{
	position: absolute;
	display: block;
	width: 15px;
	background-color: white;
	font: 14px/18px "Trebuchet MS",Arial,sans-serif;
	line-height: 18px;
	v-moz-box-shadow: 0 3px 4px #999999;
	-moz-box-shadow: 0 3px 4px #999999;
	-webkit-box-shadow: 0 3px 4px #999999;
	box-shadow: 0 1px 2px #999999;
	z-index: 500;
	visibility: hidden;
}

#popitmenu a{
	text-decoration: none;
	padding-left: 6px;
	color: blue;
	display: block;
}

#popitmenu a:hover{
	background-color: #cfcfcf;
}

</style>

<script type="text/javascript">
function calender() {
	setCibulCalendar("datespan");
	setCibulCalendar("datespan1");
}
</script>
</head><body onLoad="calender()">
EOF

if [ $(echo "$QUERY_STRING" | cut -sd'=' -f6) == "Range" ];then
	RANGE=$(echo "$QUERY_STRING" | cut -d'=' -f6)
	DATA_IN=$(echo "$QUERY_STRING" | cut -sd'=' -f4 | cut -d'&' -f1 )
	DATA_OUT=$(echo "$QUERY_STRING" | cut -sd'=' -f5 | cut -d'&' -f1 )
fi
if [ -n "$RANGE" ];then
	DATAIN=$(echo "$DATA_IN" | sed 's/\%2F/-/g')
	DATAOUT=$(echo "$DATA_OUT" | sed 's/\%2F/-/g')
	[[ -n "$DATA_IN" && -z "$DATA_OUT" ]] && DATAOUT="$(date +%d-%m-%Y)"
	[[ -n "$DATA_OUT" && -z "$DATA_IN" ]] && DATAIN="01-01-1970"
	DAYIN=$(echo "$DATAIN" | cut -d'-' -f1)
	MONTHIN=$(echo "$DATAIN" | cut -d'-' -f2)
	YEARIN=$(echo "$DATAIN" | cut -d'-' -f3)
	DATAINSEC=$(date -d "$YEARIN-$MONTHIN-$DAYIN" +%s)
	DAYOUT=$(echo "$DATAOUT" | cut -d'-' -f1)
	MONTHOUT=$(echo "$DATAOUT" | cut -d'-' -f2)
	YEAROUT=$(echo "$DATAOUT" | cut -d'-' -f3)
	DATAOUTSEC=$(date -d "$YEAROUT-$MONTHOUT-$DAYOUT 1 day" +%s)
	if [ "$DATAIN" == "01-01-1970" ];then
		DATA_IN=""
	else
		DATA_IN="$DAYIN/$MONTHIN/$YEARIN"
	fi
	DATA_OUT="$DAYOUT/$MONTHOUT/$YEAROUT"
else
	if [ -z "$DET_ALL" ];then
		DATA_IN="$(date +%d/%m/%Y)"
		DATA_OUT="$DATA_IN"
		DAYIN=$(echo "$DATA_IN" | cut -d'/' -f1)
		MONTHIN=$(echo "$DATA_IN" | cut -d'/' -f2)
		YEARIN=$(echo "$DATA_IN" | cut -d'/' -f3)
		DATAINSEC=$(date -d "$YEARIN-$MONTHIN-$DAYIN" +%s)
		DATAOUTSEC=$(date +%s)
	fi
fi
ldap_search_people "uid=$USERNAME"
echo "<table class=\"esterna\"></tr><td align=\"center\">
<img src=\"/images/template/imguser.png\" WIDTH=\"650\"  border=\"0\"><p>
	<font color=\"blue\" size=\"4\">$L_USER_DETAILS $USERNAME</font><br>
	<font color=\"blue\" size=\"3\">( $NAME $LAST_NAME"
	if [ -n "$ROOM" ] && [ "$C_ROOM" == "on" ];then
		echo "- $L_ROOM: $ROOM"
	fi
	echo ")</font>
	<br><img src=\"/images/template/barra.png\"><br><br>

	<table class=\"range\" width=\"300px\"><tr><td align=\"center\">
	<form action=\"detailsolcon.sh\" method=\"get\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
		<input type=\"text\" size=\"8\" name=\"DATA_IN\" id=\"datespan\" value=\"$DATA_IN\">
		<input type=\"text\" size=\"8\" name=\"DATA_OUT\" id=\"datespan1\" value=\"$DATA_OUT\"><p>
		<span class=\"linea\"><input type=\"submit\" name=\"RANGE\" class=\"bottoneconf\" value=\"Range\"></span>
	</form>
		<span class=\"linea\">&nbsp;&nbsp;</span>
		<form action=\"detailsolcon.sh\" method=\"get\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
		<span class=\"linea\"><input type=\"submit\" name=\"DET_ALL\" class=\"bottoneconf\" value=\"$L_ALL\"></span>
	</form>
	</td></tr>
</table><p>
	<table class=\"interna\" border=\"1\">
	<tr>
		<td align=\"center\" background=\"/images/template/imgtable.png\">N.</td>
		<td align=\"center\" background=\"/images/template/imgtable.png\">Client</td>"
		if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
			echo "<td class=\"intesta\"><center>NAS</td>"
		fi
		echo "<td align=\"center\" background=\"/images/template/imgtable.png\">Start</td>
		<td align=\"center\" background=\"/images/imgtable\">Stop</td>
		<td align=\"center\" background=\"/images/imgtable\">RX</td>
		<td align=\"center\" background=\"/images/imgtable\">TX</td>
		<td align=\"center\" background=\"/images/imgtable\">$L_TRAFFIC</td>
		<td align=\"center\" background=\"/images/imgtable\">$L_TIME</td>
		<td align=\"center\" background=\"/images/imgtable\">$L_COST $valuta</td>
	</tr>"
	N=1
	COST_TOT=0
	RX_TOT=0
	TX_TOT=0
	TRAFFIC_TOT=0
	TIME_TOT=0
	for SESSION in $(ls -t $C_ACCT_DIR/entries/$USERNAME/sessions/ | tac);do
		DATE_SESSION=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/start)
		[ -z "$DATAINSEC" ] && DATAINSEC="0"
		[ -z "$DATAOUTSEC" ] && DATAOUTSEC="$(date +%s)"
		if [[ "$DATE_SESSION" -ge "$DATAINSEC" &&  "$DATE_SESSION" -le "$DATAOUTSEC" ]];then
			IP=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/IP)
			MAC=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/MAC)
			NAS=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/NAS)
			START=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/start)
			if [ "$C_FORM_DATE" == "ita" ];then
				START="$(date -d "1970-01-01 $START sec GMT " +%d/%m/%Y-%H:%M:%S)"
			else
				START="$(date -d "1970-01-01 $START sec GMT" +%Y/%m/%d-%H:%M:%S)"
			fi
			STOP=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/stop)
			if [ -n "$STOP" ];then
				if [ "$C_FORM_DATE" == "ita" ];then
					STOP="$(date -d "1970-01-01 $STOP sec GMT" +%d/%m/%Y-%H:%M:%S)"
				else
					STOP="$(date -d "1970-01-01 $STOP sec GMT" +%Y/%m/%d-%H:%M:%S)"
				fi
			else
				STOP="$L_ACTIVE"
			fi
			RX=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/RX)
			RX_TOT=$(($RX_TOT+$RX))
			RX=$( echo "$RX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TX=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/TX)
			TX_TOT=$(($TX_TOT+$TX))
			TX=$( echo "$TX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TRAFFIC=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Traffic)
			TRAFFIC_TOT=$(($TRAFFIC_TOT+$TRAFFIC))
			TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TIME=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Time)
			TIME_TOT=$(($TIME_TOT+$TIME))
			TIME=$( oraconv $TIME)
			COST=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Cost | awk '{printf("%.2f\n", $0)}')
			COST_TOT=$(echo "$COST_TOT+$COST" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
			echo "<tr><td align=\"center\">$N</td><td>$IP/$MAC</td>"
			if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
				echo "<td><center>$NAS</td>"
			fi
			echo "<td>$START</td><td>$STOP</td>
			<td align=\"center\">$RX</td><td align=\"center\">$TX</td><td align=\"center\">$TRAFFIC</td><td align=\"center\">$TIME</td><td align=\"right\">$COST</td></tr>"
			let N=N+1
		fi
	done
	TIME_TOT=$( oraconv $TIME_TOT)
	RX_TOT=$( echo "$RX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	TX_TOT=$( echo "$TX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	TRAFFIC_TOT=$( echo "$TRAFFIC_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>"
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		echo "<tr><td>&nbsp;</td>"
	fi
	echo "<td align=\"center\" bgcolor=\"#8cc7f1\">$RX_TOT</td><td align=\"center\" bgcolor=\"#8cc7f1\">$TX_TOT</td><td align=\"center\" bgcolor=\"#8cc7f1\">
	$TRAFFIC_TOT</td><td align=\"center\" bgcolor=\"#8cc7f1\">$TIME_TOT</td><td align=\"right\" bgcolor=\"#8cc7f1\">$COST_TOT</td></tr>
	</table>
	<br>
	</td></tr><table>
</body>
</html>"
