#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#***************t*******************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi

POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
		[ "$NOMEVAR" == "USERNAME" ] && USERNAME=$(echo "$USERNAME" | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
	done
fi
if [ -n "$LANG" ];then
	echo "<script>document.cookie=\"ZtLang=$LANG;path=/\";
	window.location = \"registerfree.sh\"
	</script>"
fi

if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2 )"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

if [ "$C_AUTO_REGISTER" != "on" ];then
	AVVIOL="$(cat $C_SYSTEM/cp/Auth/Custom/msg/$LANGUAGE/InfoOffLine)"
fi

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
	var zt_login = document.createElement("link");
	zt_login.setAttribute("rel", "stylesheet");
	zt_login.setAttribute("type", "text/css");
	zt_login.setAttribute("href", "/css/template/zt_login.css");
	if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
		zt_login.setAttribute("media", "all");
	} else {
		zt_login.setAttribute("media", "only screen and (min-width: 769px)");
	}
	document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>

</head><body>
EOF

if [ "$(cat $C_CP_DIR/Auth/Custom/LoginML)" == "yes" ];then

cat << EOF
<script>
		document.write("<a id='italyflag' href='registerfree.sh?LANG=italiano'></a>");
		document.write("<a id='englishflag' href='registerfree.sh?LANG=english'></a>");
		document.write("<a id='germanflag' href='registerfree.sh?LANG=deutsch'></a>");
		document.write("<a id='frenchflag' href='registerfree.sh?LANG=francais'></a>");
		document.write("<a id='spainflag' href='registerfree.sh?LANG=espanol'></a>");
		document.write("<a id='pourtogalflag' href='registerfree.sh?LANG=portugues'></a>");
		document.write("<a id='polishflag' href='registerfree.sh?LANG=polski'></a>");
</script>
EOF

fi

echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>"

date2stamp () {
  date --utc --date "$1" +%s
}

stamp2date (){
  date --utc --date "1970-01-01 $1 sec" "+%Y-%m-%d %T"
}

dateDiff (){
  case $1 in
		-s)  sec=1;   shift;;
		-m)  sec=60;   shift;;
		-h)  sec=3600;  shift;;
		-d)  sec=86400; shift;;
		*)  sec=86400;;
	esac
	dte1=$(date2stamp $1)
	dte2=$(date2stamp $2)
	diffSec=$((dte2-dte1))
	if ((diffSec < 0)); then abs=-1; else abs=1; fi
	echo $((diffSec/sec*abs))
}

avviso () {
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"$1\">$2</font><p>
	<input type=\"submit\" name=\"$3\"
	class=\"bottone\" value=\"$4\"></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$5</div>
	</body></html>"
	exit
}

if [ -n "$DELETE" ];then
	USERDEL="$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')"
	if [ -z "USERDEL" ];then
		avviso "red" "ERROR" "GO_BACK" "$L_GO_BACK" "$L_USERDELETE"
		exit
	fi
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERDEL,ou=People,$C_LDAPBASE"
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERDEL,ou=Radius,$C_LDAPBASE" > /dev/null
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in "$CONNECTED";do
		if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERDEL" ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		fi
	done
	if [ -d $C_ACCT_DIR/entries/$USERDEL ];then
		TODAY=$(date +%d%m%Y)
		$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERDEL" "$C_ZT_DIR/deleted/$USERDEL-$L_ANONYMOUS-$L_ANONYMOUS-$TODAY"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
		if [ -d $C_ZT_DIR/expired/$USERDEL ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$USERDEL-$L_ANONYMOUS-$L_ANONYMOUS-$TODAY/EXPIRED"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USERDEL"
		fi
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERDEL"
	$C_ZT_BIN_DIR/zt "DelK5" "$USERDEL"
	$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETED user $USERDEL"
	if [ "$C_NOT_SMS_DELETE_USER" == "on" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_DELETED_USER $USERDEL $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN"
	fi
	if [ -n "$C_NOT_EMAIL_DELETE_USER" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_DELETED_USER $USERDEL\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"blue\">$L_USER_DELETED</font>
	</td></tr>
	</table>
	</div>
	<div id=\"scritta\">$L_USERDELETE</div>
	</body></html>"

	exit
fi

if [ -n "$DELETEUSER" ];then
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\" colspan=\"2\" valign=\"bottom\"><font color=\"blue\" >$L_ALERT_DELETE_USER_FREE<p></font>
	</td></tr>
	<tr><td align=\"right\" valign=\"top\">
	<form action=\"registerfree.sh\" method=\"post\">
	<input type=\"hidden\" name=\"DELETE\" value=\"yes\">
	<input type=\"submit\" name=\"CONTINUE\"
	class=\"bottone\" value=\"$L_CONTINUE\"></form>
	</td><td valign=\"top\">
	<form action=\"registerfree.sh\" method=\"post\">
	<input type=\"submit\" name=\"GO_BACK\"
	class=\"bottone\" value=\"$L_GO_BACK\"></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$L_USERDELETE</div>
	</body></html>"
	exit
fi

DAYS=$(date +%w)
ORAS=$(date +%H)
MINS=$(date +%M)
ORAMIN=$ORAS$MINS
ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$MAC)
USERNAME=$( echo "$LINE" | grep -e '^uid: ' | sed 's/^uid: //g')
if [ -n "$REGISTRATION" ];then
	USERNAME="$MAC"
	MATRICE="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz"
	while [ "${a:=1}" -le "$C_LENGH_PASSWORD" ];do
		PASSWORD="$PASSWORD${MATRICE:$(($RANDOM%${#MATRICE})):1}"
		let a+=1
	done
	TODAY=$(dateDiff -d "1970-01-01" "$(date +%Y)-$(date +%m)-$(date +%d)")
	if [ -z "$C_AR_EXPIRE" ];then
		C_AR_EXPIRE=24836
	else
		SHADOWEXPIRE=$C_AR_EXPIRE
		DIFF_DATE=$(($SHADOWEXPIRE-$TODAY))
		AR_YEAR=$(date +%Y --date="+$DIFF_DATE days")
		AR_MONTH=$(date +%m --date="+$DIFF_DATE days")
		AR_DAY=$(date +%d --date="+$DIFF_DATE days")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	if [ -n "$C_AR_EXPIRE_DAYS" ];then
	 	AR_YEAR=$(date +%Y --date="+$C_AR_EXPIRE_DAYS days")
		AR_MONTH=$(date +%m --date="+$C_AR_EXPIRE_DAYS days")
		AR_DAY=$(date +%d --date="+$C_AR_EXPIRE_DAYS days")
		SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$AR_YEAR-$AR_MONTH-$AR_DAY")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	CLASS="$C_AR_CLASS"
	UTENTEC="$C_ADMIN"
	INFO="autoregister"
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_people
	else
		ldap_modify_people "validity shadowExpire"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		avviso "red" "ERROR" "GO_BACK" "$L_GO_BACK" "$L_PROBLEM_INSERT"
		exit
	fi
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_radius
	else
		ldap_modify_radius "sn radiusUserCategory"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
		avviso "red" "ERROR" "GO_BACK" "$L_GO_BACK" "$L_PROBLEM_INSERTING"
		exit
	fi
	if [ -n "$CONTROLNO" ]; then
		avviso "red" "ERROR" "GO_BACK" "$L_GO_BACK" "$L_PROBLEM_INSERTING"
		exit
	fi
	$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
	$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	if [ -z "$CONTROL_NEW" ];then
		$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$DATEK5"
	fi
	echo "<script language=\"JavaScript\" type=\"text/javascript\">
	setTimeout('top.location.href=(window.location.href=\"registerfree.sh\")',\"50\")
	</script>"
	exit
fi
if [ -z "$USERNAME" ];then
	if [ "$C_AUTO_REGISTER" != "on" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr>
		<td align=\"center\">
		<img src=\"/images/offline\">
		<br><font color=\"blue\">$AVVIOL</font>
		</td>
		</tr>
		</table>
		</div>"
		exit
	fi
	if [ $C_AR_EXPIRE == 24836 ];then
		EXPIRE=$L_NO_LIMIT
	else
		if [ "$C_FORM_DATE" == "ita" ];then
			EXPIRE=$(date -d "1970-01-01 $C_AR_EXPIRE days" +%d/%m/%Y)
		else
			EXPIRE=$(date -d "1970-01-01 $C_AR_EXPIRE days" +%Y/%m/%d)
		fi
	fi
	if [ "$C_FORM_DATE" == "ita" ];then
		DATE_CREATED=$(date +%d/%m/%Y)
	else
		DATE_CREATED=$(date +%Y/%m/%d)
	fi
	POST_REGISTRATION=$(cat /Database/var/register/system/cp/Auth/Custom/PostRegistration | sed '/\\/s///g')
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p class=\"privacy\">$POST_REGISTRATION<br>
	<font color=\"blue\">MAC address: $MAC<br>
	$L_REGISTRATION: $DATE_CREATED<br>
	$L_ENDS: $EXPIRE<br>"
	limitclass "$C_AR_CLASS"
	[ "$RANGE" == "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp"  ] && RANGE="$L_ALL"
	echo "$L_DAYS: $DC <br>	$L_TIME: $RANGE<br>"
	if [ -n "$HDC" ];then
		echo "$L_DMAX_HOURS: $HDC <br>"
	fi
	if [ -n "$HMC" ];then
		echo "$L_MMAX_HOURS: $HMC<br>"
	fi
	if [ -n "$MDC" ];then
		echo "$L_DMAX_MB: $MDC <br>"
	fi
	if [ -n "$MMC" ];then
		echo "$L_MMAX_MB: $MMC<br>"
	fi
	echo "</font><p>
	<form action=\"registerfree.sh\" method=\"post\">
	<input type=\"hidden\" name=\"REGISTRATION\" value=\"yes\">
	<p><input type=\"submit\" name=\"CONTINUE\" class=\"bottone\" value=\"$L_AGREE\"><p></form>
	</td></tr></table>
	</div>
	<div id=\"scritta\">$L_SELF_REGISTER</div>
	</body></html>"
	exit
else
	RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn radiusUserCategory)
	PASSWORD=$( echo "$RADIUS" | grep -e '^sn: ' | sed 's/^sn: //g')
	CONTROL_LOCK=$(echo "$PASSWORD" | cut -sd'-' -f2)
	if [ -n "$CONTROL_LOCK" ];then
		USER_BLOCKED=$(cat /Database/var/register/system/cp/Auth/Custom/UserBlocked | sed '/\\/s///g')
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p><font color=\"red\">$USER_BLOCKED</font><p>
		</td></tr></table>
		</div>
		<div id=\"scritta\">$L_NOTICE</div>
		</body></html>"
		exit
	else
		if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
			LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
		else
			LANGUAGE="$C_LANGUAGE"
		fi
		echo "<script>document.cookie=\"ZtLang=$LANGUAGE;path=/\";</script>"

		RED_URL=$(cat $C_CP_DIR/Auth/Custom/RedirectFree)
		echo "<script type=\"text/javascript\">
		location.href=\"http://$RED_URL?user=$USERNAME&pass=$PASSWORD&control=zerozero\";
		</script>"
		exit
	fi
fi

