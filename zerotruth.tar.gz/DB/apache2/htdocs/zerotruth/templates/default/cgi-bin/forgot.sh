#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
<script type="text/javascript">
	function Modulo()
	{
		var a = Math.ceil(Math.random() * 10)+ '';
		var b = Math.ceil(Math.random() * 10)+ '';
		var c = Math.ceil(Math.random() * 10)+ '';
		var d = Math.ceil(Math.random() * 10)+ '';
		var e = Math.ceil(Math.random() * 10)+ '';
		var f = Math.ceil(Math.random() * 10)+ '';
		var g = Math.ceil(Math.random() * 10)+ '';
		var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
		document.getElementById("txtCaptcha").value = code
//		var controlemail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

	}
	function Control(){
		var USERNAME = document.getElementById("USERNAME").value;
		var EMAIL = document.getElementById("EMAIL").value;
		var PHONE = document.getElementById("PHONE").value;
		var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
		var str2 = removeSpaces(document.getElementById('txtInput').value);
		var controlemail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if ((USERNAME == "") || (USERNAME == "undefined")) {
			alert("$L_USERNAME: $L_MISSING_DATA");
			document.register.USERNAME.focus();
			return false;
		}
		else if (((!controlemail.test(EMAIL)) || (EMAIL == "") || (EMAIL == "undefined")) && (EMAIL != "30091960")) {
			alert("$L_WRONG_EMAIL");
			document.register.EMAIL.focus();
			return false;
		}
		else if ((isNaN(PHONE)) || (PHONE.length < 8) || (PHONE == "") || (PHONE == "undefined")) {
			alert("$L_WRONG_TELEPHONE");
			document.register.PHONE.focus();
			return false;
		}
		else if (str1 != str2)	{
			alert("$L_CAPTCHA_ERROR");
			var a = Math.ceil(Math.random() * 10)+ '';
			var b = Math.ceil(Math.random() * 10)+ '';
			var c = Math.ceil(Math.random() * 10)+ '';
			var d = Math.ceil(Math.random() * 10)+ '';
			var e = Math.ceil(Math.random() * 10)+ '';
			var f = Math.ceil(Math.random() * 10)+ '';
			var g = Math.ceil(Math.random() * 10)+ '';
			var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
			document.getElementById("txtCaptcha").value = code
			document.register.txtInput.value = "";
			document.register.txtInput.focus();
			return false;
		}
		else
		{

			document.register.action = "forgot.sh";
			document.register.method = "POST";
			document.register.submit();
		}
	}
	function removeSpaces(string)
	{
		return string.split(' ').join('');
	}
</script>

</head><body onload="Modulo()">
EOF

echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>"

if [ -n "$CLOSE" ];then
	echo "<script>setTimeout('window.close()', 4)</script>"
fi

if [ -n "$POST" ];then
	if [ -z "$USERNAME" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<font color=\"red\">$L_MISSING_DATA</font><p>
		<p><form action=\"forgot.sh\" method=\"get\">
		<input type=\"submit\" name=\"$L_GO_BACK\" class=\"bottone\" value=\"$L_GO_BACK\"></form>
		</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	CONTROLEMAIL=$(echo $EMAIL | grep -E "^(([-a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~]+|(\"([][,:;<>\&@a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~-]|(\\\\[\\ \"]))+\"))\.)*([-a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~]+|(\"([][,:;<>\&@a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~-]|(\\\\[\\ \"]))+\"))@\w((-|\w)*\w)*\.(\w((-|\w)*\w)*\.)*\w{2,4}$")
	if [ -z "$CONTROLEMAIL" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<font color=\"red\">$L_WRONG_EMAIL</font><p>
		<p><form action=\"forgot.sh\" method=\"get\">
		<input type=\"submit\" name=\"$L_GO_BACK\" class=\"bottone\" value=\"$L_GO_BACK\"></form>
		</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "( & (uid=$USERNAME) (mail=$EMAIL) (telephoneNumber=$PHONE))" uid givenName sn)
	USERNAME_EX=$( echo "$LINE" |  grep -e '^uid: ' | sed 's/^uid: //g')
	NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g')
	LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g')
	if [ "$USERNAME_EX" == "$USERNAME" ];then
		RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn)
		PASSWORD=$(echo "$RADIUS" | grep -e '^sn: ' | sed 's/^sn: //g')
		PASSWORD=$(echo "$PASSWORD" | cut -d'-' -f1)
	else
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<font color=\"red\">$L_MISSING_USER</font><p>
		<p><form action=\"forgot.sh\" method=\"get\">
		<input type=\"submit\" name=\"$L_GO_BACK\" class=\"bottone\" value=\"$L_GO_BACK\"></form>
		</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	if [ "$C_AUTO_PASS_EMAIL" == "on" ];then
		PASS_EMAIL="$PASSWORD"
	else
		PASS_EMAIL="$L_SENT_BY_SMS"
	fi
	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n$L_USERNAME: $USERNAME\n$L_NAME: "$NAME"\n$L_LAST_NAME: "$LAST_NAME"\n$L_PASSWORD: $PASS_EMAIL\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	TEXT_SMS="$C_HOTSPOT_NAME: $L_USERNAME: $USERNAME - $L_PASSWORD: $PASSWORD"
	$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME" "$TEXT_EMAIL" "$EMAIL" 2>/dev/null >/dev/null
	$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$PHONE" "$TEXT_SMS"
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"blue\" size=\"4\">$L_SEND_DATA</font>
	<p><form action=\"forgot.sh\" method=\"post\">
	<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
	</td></tr>
	</table>

	</div>
	<div id=\"scritta\">$L_REC_PASSWORD</div>
	</body></html>"
	exit
fi
MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
MAC=$(echo "$MAC" | tr '[:lower:]' '[:upper:]')
if [ -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p><font color=\"red\">$L_BLOCK_MAC<p>$BLOCK_MAC<p>$MAC</font>
		<form action=\"register.sh\" method=\"post\">
		<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
		</td></tr></table>
		</div>
		</body></html>"
		exit
fi
echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">
<form name=\"register\">
<table>
<tr><td>$L_USER</td>
<td><input type=\"text\" id=\"USERNAME\" name=\"USERNAME\" value=\"\"></td></tr>
<tr><td>$L_EMAIL</td>
<td><input type=\"text\" id=\"EMAIL\" name=\"EMAIL\" value=\"\"></td></tr>
<tr><td>$L_PHONE*</td>
<td><input type=\"tel\" id=\"PHONE\" name=\"PHONE\" value=\"$C_PREFIX\"></td></tr>
</table>
<br>$L_COPY_CATPCHA<br>
<input readonly type=\"text\" id=\"txtCaptcha\"
style=\"background-image:url(/images/template/imgcaptcha.png); text-align:center; border:none;
font-weight:bold; font-size: 16px;\"><br>
<input type=\"tel\" style=\"text-align: center\" id=\"txtInput\">
<p><input type=\"button\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\" onclick=\"Control();\"></form>
</td></tr></table>
</td></tr></table>
</div>
<div id=\"prefisso\">* $L_WITH_PREFIX (es. <font color=\"red\">39</font>3393467765)</div>
<div id=\"scritta\">$L_REC_PASSWORD</div>
</body>
</html>"
