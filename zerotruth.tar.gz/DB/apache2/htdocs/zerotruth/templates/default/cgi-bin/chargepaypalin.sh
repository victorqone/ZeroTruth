#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#***************t*******************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
</head><body>
EOF
echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>
<div id=\"scritta\">$(cat $C_CP_DIR/msg/custom/ChargePayPal)</div>"

POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$(echo $VALVAR | sed '/\+/s// /g' | sed '/%2F/s//\//g' | \
		sed '/%A3/s//L./g' | sed '/%0D%0A/s//\+/g' | sed '/%27/s//%5C%27/g' | \
		sed '/%40/s//@/g' | sed '/%3C/s//\\</g' | sed '/%3E/s//\\>/g' | \
		perl -pe 's|%([0-9a-f]{2})|pack('C',hex($1))|segi;')\"
	done
fi

avviso () {
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p><font color=\"$1\">$2</font><p>
	<form action=\"chargepaypalin.sh\" method=\"post\">
	<input type=\"submit\" name=\"$3\" class=\"bottone\" value=\"$4\"></form>
	</td></tr></table>
	</div>
	</body></html>"
}

if [ -n "$CLOSE" ];then
	echo "<script>setTimeout('window.close()', 4)</script>"
fi

if [ -n "$QUERY_STRING" ];then
	if [ "$(echo "$QUERY_STRING" | cut -d'=' -f1)" == "USERNAME" ];then
		USER_CON=$(echo "$QUERY_STRING" | cut -d'=' -f2 | cut -d'&' -f1 )
		IP_CON=$(echo "$QUERY_STRING" | cut -sd'=' -f3)
		if [ -z $(cat $C_SYSTEM/cp/Connected/$IP_CON/User | grep $USER_CON) ] && [ -z $(cat $C_ZT_DIR/remote/remotelogin | grep $IP_CON) ];then
			echo "<script language=\"javascript\">
			location.replace(\"http://www.zerotruth.net\");
			</script>"
			exit
		fi
		CLASS_U=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER_CON radiusUserCategory | grep -e '^radiusUserCategory: ' | cut -d":" -f2 | sed 's/.\(.*\)/\1/')
		if [[ $(cat $C_CLASSES_DIR/$CLASS_U/ChargeType) != "pre" || -z $(cat $C_CLASSES_DIR/$CLASS_U/ChargeType) ]];then
			avviso "red" "$L_NO_PAYMENT" "CLOSE" "$L_CLOSE" "$L_GO_BACK" "$SCRITTA"
			echo "<div id=\"avviso\"><center><font color=\"red\" size=\"4\">$L_NO_PAYMENT</font></center><p>
			<p><center><form action=\"chargepaypalin.sh\" method=\"post\"><input type=\"submit\" name=\"CLOSE\"
			class=\"bottone\" value=\"$L_CLOSE\"></form></div>
			</body></html>"
			exit
		fi
	fi
	if [ "$(echo "$QUERY_STRING" | cut -d'=' -f2 | cut -d'&' -f1)" == "Completed" ];then
		CONTROL_PAY="Completed"
		ID_PAY=$(echo "$QUERY_STRING" | cut -d'=' -f3 | cut -d'&' -f1 )
		USER_LOCK=$(echo "$QUERY_STRING" | cut -d'=' -f4)
	fi
fi

if [ -n "$USER_CON" ];then
	$C_ZT_BIN_DIR/zt "Salva" "USER $USER_CON" "$C_ZT_DIR/tmp/lock_pay_$USER_CON"
	$C_ZT_BIN_DIR/zt "Aggiungi" "CHAR_IN yes" "$C_ZT_DIR/tmp/lock_pay_$USER_CON"
	echo "<div id=\"paginareg\">
	<table class=\"tabellareg\" align=\"center\">
	<tr><td align=\"center\">"
	cat $C_ZT_CONF_DIR/ppbutton | sed "s/<input type=\"image/<input type=\"hidden\" name=\"custom\" value=\"$USER_CON\"> <input type=\"image/g"
	echo  "</td></tr>
	</table>
	</div>"
	exit
fi

if [ -n "$CONTROL_PAY" ];then
	USER=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep USER | awk '{print $2}')
	if [[ "$CONTROL_PAY" == "Completed" && "$ID_PAY" == $(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}') ]];then
		[ ! -f $C_ZT_LOG_DIR/pp/payments ] && touch $C_ZT_LOG_DIR/pp/payments
		DATAD=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_DATE | sed "s/PAYMENT_DATE //g")
		DATAH=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_HOUR | awk '{print $2}')
		CREDIT=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep AMMOUNT | awk '{print $2}')
		TID=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}')
		$C_ZT_BIN_DIR/zt "Aggiungi"	"$USER_LOCK+$DATAD+$DATAH+$CREDIT+$TID" "$C_ZT_LOG_DIR/pp/payments"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
	else
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
		avviso "red" "NOT APPROVED" "CLOSE" "$L_CLOSE"
		exit
	fi
	if [ -n $CREDIT ];then
		if [ $(cat $C_ACCT_DIR/credits/$USER_LOCK/Credit) ];then
			CREDITES=$(cat $C_ACCT_DIR/credits/$USER_LOCK/Credit | awk '{printf("%.2f\n", $0)}')
		else
			CREDITES=0
		fi
		CREDIT=$(echo "$CREDITES+$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		if [ ! -d "$C_ACCT_DIR/credits/$USER_LOCK" ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USER_LOCK"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$CREDIT" "$C_ACCT_DIR/credits/$USER_LOCK/Credit"
	fi
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p class=\"privacy\">$(cat $C_ZT_CONF_DIR/ppnotice | sed '/\\/s///g')<p>
	<form action=\"chargepaypalin.sh\" method=\"post\">
	<p><input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"><p></form>
	</td></tr></table>
	</div>
	</body></html>"
	exit
fi

echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">
<form name=\"chargepaypal\" method=\"POST\" action=\"chargepaypalin.sh\">
<p><br><br><table><tr><td>$L_USER_NAME: </td>
	<td><input type=\"text\" name=\"USERL\" value=\"\" size=\"20\" maxlength=\"20\"></td></tr>
	<tr><td>$L_PASSWORD: </td>
	<td>
	<input name=\"PASSL\" type=\"password\" value=\"\" size=\"20\" maxlength=\"20\">
	</td></tr>
	</table>
	<input type=\"hidden\" name=\"CONTROL\" value=\"OK\">
	<br>$L_COPY_CATPCHA<br>
	<input type=\"text\" id=\"txtCaptcha\"
	style=\"background-image:url(../images/imgcaptcha); text-align:center; border:none;
	font-weight:bold; font-family:Modern\" ><br>
	<input type=\"text\" id=\"txtInput\">
	<p><input type=\"button\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\" onclick=\"Control();\"></form>
	<p>
</td></tr>
</table>
</div>
</body>
</html>"

