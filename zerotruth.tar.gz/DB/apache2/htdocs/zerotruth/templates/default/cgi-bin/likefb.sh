#!/bin/bash
#*******************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# /DB/apache2/cgi-bin/zerotruth/likefb.sh
#*******************************************************


echo "Content-type: text/html"
echo ""

cat << EOF
<html><head><title>Fabebook Like</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<style type="text/css">
   body {background: white; text-align: center;}
   img {display: block; margin-left: auto;  margin-right: auto; width: 75%;}z
</style>
</head><body>
EOF


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh

echo "<p><font color=\"blue\">Facebook Like</font><p>
<p><img src=\"/images/template/fb/ztlike.png\"><p>"

POST=$(</dev/stdin)
if [ $POST != "" ];then
	USERNAME=$(echo $POST | cut -d'=' -f2)
	UL=$(cat $C_ZT_CONF_DIR/UsersLike | sed 's/\-/ /g')
	NEWUL="$UL $USERNAME"
	NEWUL=$(echo "$NEWUL" | sed 's/^ //g' | sed 's/ /\-/g' | sed 's/^/\-/g' | sed 's/$/\-/g')
	$C_ZT_BIN_DIR/zt "Salva" "$NEWUL" "$C_ZT_CONF_DIR/UsersLike"
	echo "<table width=\"300\" align=\"center\"><tr><td>"
	echo "<p><font color=\"blue\">$(cat $C_ZT_CONF_DIR/ThanksFb)</font>"
	echo "</td></tr></table>"
	echo "<script>setTimeout('window.close()', 5000)</script>"
	exit
fi

if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi

echo "<div id=\"fb-root\"></div>
<script>
  window.fbAsyncInit = function() {
  FB.init({
  // ########### *change appId ##############
    appId      : \"421227637994450\",
    status     : true,
    xfbml      : true,
    version    : 'v2.0'
  });
  FB.Event.subscribe('edge.create',
    function(response) {
		var Form, Ni;
		Form = document.createElement('form');
		Form.action = 'likefb.sh';
		Form.method = 'post';
		Ni = document.createElement('input');
		Ni.type = 'hidden';
		Ni.name = 'user';
		Ni.value = \"$user\";
		Form.appendChild(Ni);
		document.getElementById('hidden_form').appendChild(Form);
		Form.submit();
    }
  );
};

(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  // ##################   change js.src and appId ###########################################
  js.src = \"//connect.facebook.net/it_IT/sdk.js#xfbml=1&appId=421227637994450&version=v2.0\";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>"

##### change data-href #######################
echo "<div  class=\"fb-like\"
   data-href=\"https://www.facebook.com/cpzerotruth\"
   data-layout=\"button\"
   data-action=\"like\"
   data-show-faces=\"false\"
   data-width=\"400\"
   data-stream=\"true\">
   </div>
</body>
</html>"
