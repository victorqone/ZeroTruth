#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#***************t*******************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
<script>
/*author Philip M. 2010*/

var timeInSecs;
var ticker;

function startTimer(secs){
timeInSecs = parseInt(secs)-1;
ticker = setInterval("tick()",1000);
}

function tick() {
var secs = timeInSecs;
if (secs>0) {
timeInSecs--;
}
else {
clearInterval(ticker);
}

document.getElementById("countdown").innerHTML = secs;
}

startTimer(61);
</script>
</head><body>
EOF
echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>
<div id=\"scritta\">$L_GENERAL_INFO</div>"
INFO=$(cat $C_CP_DIR/Auth/Custom/GeneralInfo | sed '/\\/s///g')
INFONOINTERNET=$(cat $C_ZT_CONF_DIR/NoInternet | sed '/\\/s///g')
echo "<div id=\"paginaprivacy\">
<table class=\"tabella\" align=\"center\">
<tr><td align=\"center\">"
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
POST=$(</dev/stdin)
if [[ $POST != "" || -n "$RENEW" ]];then
	if [ -n "$RENEW"  ];then
		VAL=$(echo "$RENEW" | cut -d'=' -f1)
	else
		VAL=$(echo "$POST" | cut -d'=' -f1)
	fi
	if [ "$VAL" == "CLOSE" ];then
		echo "<script>setTimeout('window.close()', 4);</script>"
	else
		waitinternet
		return_page "showinfo.sh?RENEW=yes"
	fi
	exit
fi
echo "<p class=\"privacy\">"
if [ "$INTERNET" == "no" ];then
	echo "$INFONOINTERNET<p><form action=\"showinfo.sh\" method=\"post\">
	<input type=\"submit\" name=\"TRY_AGAIN\" class=\"bottone\" value=\"$L_TRY_AGAIN\"></form>"
else
	echo "$INFO<p><form action=\"showinfo.sh\" method=\"post\">
	<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>"
fi


echo "</td></tr></table>
</div>
</body></html>"


