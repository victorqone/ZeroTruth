#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$(cat $C_ZT_CONF_DIR/Manager/$UTENTEC/USERS_FROM_TICKET 2>/dev/null)" && "$UTENTEC" != "$C_ADMIN" ]];then
	return_page "index.sh"
	exit
fi

if [ -n "$ADDUSERS" ];then
	if [ -n "$NUM_USERS" ] && [ "$NUM_USERS" -eq "$NUM_USERS" ];then
		CONTROL_NUM="yes"
	else
		echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"0; URL=adduserstickets.sh\">"
		exit
	fi
	echo "<div id=\"ticket\">"
	NC=1
	NS=1
	if [[ -n "$(cat $C_ZT_CONF_DIR/Manager/$UTENTEC/LOG_USER 2>/dev/null)" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_ADDUSERS(tickets) $NUM_USERS $L_CLASS $CLASS"
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "/tmp/userswait"
	for NUSER in $(seq 1 $NUM_USERS);do
		source $C_ZT_DIR/language/$LANGUAGE/$LANGUAGE.sh
		USERNAME=""
		MATRICE="abcdefghijklmnopqrstuvwxyz"
		b=""
		while [ "${b:=1}" -le $C_LENGH_USERNAME ];do
			USERNAME="$USERNAME${MATRICE:$(($RANDOM%${#MATRICE})):1}"
			let b+=1
		done
		$C_ZT_BIN_DIR/zt "Aggiungi" "$USERNAME" "/tmp/userswait"
	done
	$C_ZT_BIN_DIR/zt "DeleteBlankLine" "/tmp/userswait"
	$C_ZT_BIN_DIR/zt "SortUsersWait" "/tmp/userswait"
	$C_ZT_BIN_DIR/zt "Aggiungi" "$(cat /tmp/userswait)" "$C_ZT_CONF_DIR/userswait"
	$C_ZT_BIN_DIR/zt "SortUsersWait" "$C_ZT_CONF_DIR/userswait"
	if [ -z "$C_TICKETS_PAGE" ];then
		N_TICKETS_PAGE=4
	else
		N_TICKETS_PAGE=$(($C_TICKETS_PAGE/2+1))
	fi
	RIGHE=$(cat /tmp/userswait | wc -l | awk '{print $1}' )
	[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
	[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
	for NUSER in $(seq 1 $RIGHE);do
		USERNAME="$(cat /tmp/userswait | /bin/sed -n "${NUSER}p")"
		if [ $NUSER == 1 ];then
			source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
			echo "<table align=\"center\"><tr><td align=\"center\"><font color=\"blue\" size=\"5\"><br>$L_USER_TICKET</font></td></tr>
			<tr><td align=\"center\"><p><img src=\"/images/barra.png\" alt=\"barra\"></td></tr></table><br>&nbsp;<br>
			<table width=\"920\" border=\"0\" align=\"center\">"
		fi
		source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
		INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
		if [ $NC == 2 ];then
			echo "</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;<br>"
		else
			echo "<tr><td>&nbsp;<br>"
		fi
		echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\" align=\"center\">
		<tr>
		<td colspan=\"2\"><img src=\"/images/imguser.png\" WIDTH=\"350px\" alt=\"imguser\"></td>
		</tr>
		<tr><td>
		<table width=\"350\" style=\"font: ${C_FONT_TICKET}px "Trebuchet MS",Arial,sans-serif;\">
		<tr><td width=\"130px\">&nbsp;</td><td></td></tr>
		<tr><td colspan=\"2\" align=\"center\">$L_USERNAME:<br><b>$USERNAME</b></td></tr>
		<tr><td width=\"130px\">&nbsp;</td><td></td></tr>
		</table>"
		if [ -n "$INFO_TICKET" ];then
			echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
			<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
		fi
		echo "</table>"
		if [ $NC == 1 ];then
			NC=2
		else
			echo "</td></tr>"
			NC=1
			NS=$(($NS+1))
			if [ $NS == $N_TICKETS_PAGE ];then
				echo "</table><p><hr style=\"page-break-after:always\"><p><table width=\"920\" border=\"0\">"
				NS=1
			fi
			if [ $NUSER == $NUM_USERS ];then
				echo "</table><p>"
			fi
		fi
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
	done
	echo "</div><br>&nbsp;<br>"
	source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
	if [ $(expr $NUM_USERS % 2) -eq 0 ];then
		echo ""
	else
		echo "</table>"
	fi
	echo "<p><input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_TICKETS\" onClick=\"StampaTicket()\">
	<br>&nbsp;<br>"
	./footer.sh
	if [ -n "$C_NOT_SMS_MULTI_USERS" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_CREATED_MULTI $NUM_USERS $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN" "credito"
	fi
	if [ -n "$C_NOT_EMAIL_MULTI_USERS" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_CREATED_MULTI $NUM_USERS\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_CREATED_MULTI" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
	exit
fi
echo "<br><font color=\"#0000FF\" size=\"5\">$L_ADDUSERS</font><br>
<p><img src=\"/images/barra.png\" alt=\"barra\"></p>
<form name=\"ADD_USERS\" action=\"adduserstickets.sh\" method=\"POST\">
$L_NUM_USERS: <input type=text size=\"1\" name=\"NUM_USERS\" value=\"\">
<p><input type=\"hidden\" name=\"ADDUSERS\" value=\"ok\">
<p><input type=\"submit\" name=\"SAVE\" class=\"bottone\" value=\"$L_SAVE\"><p>&nbsp;<p>
</form>"
./footer.sh
