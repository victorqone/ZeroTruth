#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2014 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************


date2stamp () {
	date --utc --date "$1" +%s
}

stamp2date (){
	date --utc --date "1970-01-01 $1 sec" "+%Y-%m-%d %T"
}

dateDiff (){
	case $1 in
		-s)		sec=1;		shift;;
		-m)		sec=60;		shift;;
		-h)		sec=3600;	shift;;
		-d)		sec=86400;	shift;;
		*)		sec=86400;;
	esac
	dte1=$(date2stamp $1)
	dte2=$(date2stamp $2)
	diffSec=$((dte2-dte1))
	if ((diffSec < 0)); then abs=-1; else abs=1; fi
	echo $((diffSec/sec*abs))
}

oraconv () {
TIME=$1
if [ $TIME -ge 3600 ];then
	ORE=$(($TIME/3600))
	TIME1=$(($ORE*3600))
	TIME=$(($TIME-$TIME1))
	if [ $ORE -lt 10 ];then
		ORE=0$ORE
	fi
else
	ORE="00"
fi
if [ $TIME -ge 60 ];then
	MINUTI=$(($TIME/60))
	TIME1=$(($MINUTI*60))
	TIME=$(($TIME-$TIME1))
	if [ $MINUTI -lt 10 ];then
		MINUTI=0$MINUTI
	fi
else
	MINUTI="00"
fi
if [ $TIME -ge 0 ];then
	SECONDI=$TIME
	if [ $SECONDI -lt 10 ];then
		SECONDI=0$SECONDI
	fi
else
	SECONDI="00"
fi
echo "$ORE:$MINUTI:$SECONDI"
}

formdatesec () {
	if [ "$C_FORM_DATE" == "ita" ];then
		echo "$(date -d "1970-01-01 $1 sec GMT " +%d/%m/%Y-%H:%M:%S)"
	else
		echo "$(date -d "1970-01-01 $1 sec GMT " +%Y/%m/%d-%H:%M:%S)"
	fi
}

SecNow () {
	TMP="$(date +'%F %X')"
	echo "$(date -u +%s -d "$TMP")"
}

formdateday () {
	if [ "$C_FORM_DATE" == "ita" ];then
		echo "$(date -d "1970-01-01 $1 days" +%d/%m/%Y)"
	else
		echo "$(date -d "1970-01-01 $1 days" +%Y/%m/%d)"
	fi
}

search () {
	CONTROLLDAP="&(!(uid=admin))"
	if [ -n "$1" ];then
		URIC="$1"
		CONTROLLDAP="$CONTROLLDAP(uid=$1*)"
	else
		URIC="$L_ALL"
	fi
	if [ -n "$2" ];then
		NRIC="$2"
		CONTROLLDAP="$CONTROLLDAP(givenName=$2*)"
	else
		NRIC="$L_ALL"
	fi
	if [ -n "$3" ];then
		CRIC="$3"
		CONTROLLDAP="$CONTROLLDAP(sn=$3*)"
	else
		CRIC="$L_ALL"
	fi
	if [ -n "$4" ];then
		PRIC="$4"
		CONTROLLDAP="$CONTROLLDAP(class=$4*)"
	else
		PRIC="$L_ALL"
	fi
	if [ -n "$5" ];then
		SRIC="$5"
		CONTROLLDAP="$CONTROLLDAP(roomName=$5)"
	else
		SRIC="$L_ALL"
	fi
	if [ -n "$6" ];then
		PHRIC="$6"
		CONTROLLDAP="$CONTROLLDAP(telephoneNumber=$6*)"
	else
		PHRIC="$L_ALL"
	fi
	if [ -n "$7" ];then
		ERIC="$7"
		CONTROLLDAP="$CONTROLLDAP(mail=$7*)"
	else
		ERIC="$L_ALL"
	fi
	if [[ -n "$C_THEIR_USERS" && "$UTENTEC" != "$C_ADMIN" ]];then
		CONTROLLDAP="$CONTROLLDAP(ownerUser=$UTENTEC)"
	fi
	if [ "$8" ];then
		if [ "$8" == "yes" ];then
			SCRIC="$L_YES"
			CONTROLLDAP="$CONTROLLDAP(validity=yes)"
		else
			SCRIC="$L_NO"
			CONTROLLDAP="$CONTROLLDAP(!(validity=yes))"
		fi
	else
		SCRIC="$L_ALL"
	fi
	if [ -n "$9" ];then
		OWRIC="$9"
		CONTROLLDAP="$CONTROLLDAP(ownerUser=$9)"
	else
		OWRIC="$L_ALL"
	fi

	if [ -n "${10}" ];then
		if [ "${10}" == "yes" ];then
			BLOCKEDRIC="$L_YES"
		else
			BLOCKEDRIC="$L_NO"
		fi
	else
		BLOCKEDRIC="$L_ALL"
	fi

	if [ -n "${11}" ];then
		if [ "${11}" == "yes" ];then
			CONNECTRIC="$L_YES"
		else
			CONNECTRIC="$L_NO"
		fi
	else
		CONNECTRIC="$L_ALL"
	fi

	CONTROLLDAP="($CONTROLLDAP)"
}

wait () {
	./footer.sh
	echo "<w style=\"margin:0 auto;display: inline-block;width: 380px;height: 200px;border: 0px;text-decoration: none;position:relative;top:-$1;color:blue;text-align:center;z-index:1000;\">"
	if [ -n "$2" ];then
		echo "<font color=\"#0000FF\" size=\"3\">$2</font><br>&nbsp;<br>"
	fi
	echo "<img src=\"/images/wait.gif\" alt=\"wait\"><w>"
}

waitmail () {
	echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
}

waitinternet () {
	echo "<w style=\"margin:0 auto;display: inline-block;width: 380px;height: 200px;border: 0px;text-decoration: none;position:relative;top:33;color:blue;text-align:center;z-index:1000;\">"
	echo "<img src=\"/images/wait\" alt=\"wait\"><w>"
	echo "<ww style=\"margin:0 auto;display: inline-block;width: 380px;height: 200px;border: 0px;text-decoration: none;position:relative;top:-89;color:blue;text-align:center;z-index:1001;\">"
	for i in $(seq 1 61);do
		if [ "$(cat $C_CP_DIR/Auth/Custom/NoInternet)" != "yes" ];then
			sleep 2
			echo "<script>location.href = \"http://www.google.com/\";</script>"
			exit
		fi
		echo "<br>&nbsp;<br><span id=\"countdown\" style=\"font-weight: bold;\"></span>"
		sleep 1
	done
	echo "<ww>"
}

footerwait () {
	echo "<fw style=\"display: inline-block;position:absolute;top:$1;left:50%;margin-left:-500px;z-index:1000;\">"
	VERSION=$(cat /DB/apache2/cgi-bin/zerotruth/conf/version)
	YEARNOW=$(date +%Y)
	echo "<img class=\"imgfoot\" src=\"/images/foot.png\" alt=\"footer\">
	<script language=\"javascript\" type=\"text/javascript\" src=\"/js/license.js\"></script>
	<table class=\"tacchino\">
		<tr>
			<td width=\"100\" align=\"right\"><a href=\"javascript:apri('/license.html')\">&copy; 2012-$YEARNOW</a> </td>
		<td width=\"50\" align=\"center\"><img src=\"/images/tacchino.png\" border=\"0\" alt=\"tacchino\"></td>
		<td width=\"100\" align=\"left\"><a target=\"_blank\" href=\"http://www.zerotruth.net/\">ver. $VERSION </a></td>
		</tr>
	</table></fw>"
}

getvarqs () {
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
}

getvarp () {
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
		[ "$NOMEVAR" == "USERNAME" ] && USERNAME=$(echo "$USERNAME" | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
	done
}

return_page () {
	echo "<script language=\"JavaScript\" type=\"text/javascript\">
	setTimeout('top.location.href=(window.location.href=\"$1\")',\"1000\")
	</script>"
}

reload_search () {
	echo "<script language=\"JavaScript\" type=\"text/javascript\">
	setTimeout('top.location.href=(window.location.href=\"users.sh?USERNAME_RIC="$1"&NAME_RIC="$2"&LAST_NAME_RIC="$3"&CLASS_RIC="$4"&ROOM_RIC="$5"&PHONE_RIC="$6"&EMAIL_RIC="$7"&EXPIRE_RIC="$8"&OWNER_RIC="$9"\")',\"50\")
	</script>"
}

controlemail (){
	CONTROLEMAIL=$(echo $1 | grep -E "^(([-a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~]+|(\"([][,:;<>\&@a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~-]|(\\\\[\\ \"]))+\"))\.)*([-a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~]+|(\"([][,:;<>\&@a-zA-Z0-9\!#\$%\&\'*+/=?^_\`{\|}~-]|(\\\\[\\ \"]))+\"))@\w((-|\w)*\w)*\.(\w((-|\w)*\w)*\.)*\w{2,15}$")
	if [ -z "$CONTROLEMAIL" ];then
		echo "<p>&nbsp;<p><center><font color=\"red\" size=\"4\">$L_WRONG_EMAIL</font></center><p>"
		echo "<form action=\"$2\" method=\"POST\"><center>
		<input type=\"hidden\" name=\"$3\" value=\"$4\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
		</form>"
		./footer.sh
		exit
	fi
}

controltelefono () {
	if ! [ $1 -eq $1 ];then
		echo "<p>&nbsp;<p><center><font color=\"red\" size=\"4\">$L_WRONG_TELEPHONE</font></center><p>"
		echo "<form action=\"$2\" method=\"POST\"><center>
		<input type=\"hidden\" name=\"$3\" value=\"$4\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
		</form>"
		./footer.sh
		exit
	fi
}

controlprefix () {
	CONTROLPREFIX=$(echo $1 | grep -E "^[1-9][0-9]{0,2}$")
	if [ -z "$CONTROLPREFIX" ];then
		echo "<p>&nbsp;<p><center><font color=\"red\" size=\"4\">$L_WRONG_PREFIX</font></center><p>"
		echo "<form action=\"$2\" method=\"POST\"><center>
		<input type=\"hidden\" name=\"$3\" value=\"$4\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
		</form>"
		./footer.sh
		exit
	fi
}

controlquery (){
	n=$(echo $QUERY_STRING | grep -o '=' | wc -l)
	for i in $(seq 1 $n);do
		eval $NAME_VAR=\"$(echo "$QUERY_STRING" | cut -d'=' -f$i | cut -d'&' -f1 )\"
	done

}

valid_ip (){
	ip=$1
	ipcontrol=$(echo "$ip" | sed 's/\.//g')
	ip1=$(echo $ip | cut -sd'.' -f1)
	ip2=$(echo $ip | cut -sd'.' -f2)
	ip3=$(echo $ip | cut -sd'.' -f3)
	ip4=$(echo $ip | cut -sd'.' -f4)
	if [[ -n "$ip1" && -n "$ip2" && -n "$ip3" && -n "$ip4" && "$ipcontrol" -eq "$ipcontrol" ]] && [[ $ip1 -le 255 && $ip2 -le 255 && $ip3 -le 255 && $ip4 -le 255 ]];then
		CONTROL_IP="yes"
	else
		CONTROL_IP="no"
	fi
}

valid_mac_address () {
	ERROR=0
	oldIFS=$IFS
	IFS=:
	set -f
	set -- $1
	if [ $# -eq 6 ]; then
		for seg; do
			case $seg in
				""|*[!0-9a-fA-F]*)
				ERROR=1
				break
				;;
				??)
				;;
				*)
				ERROR=1
				break
				;;
			esac
		done
	else
		ERROR=2 ## Not 6 segments
	fi
	IFS=$oldIFS
	set +f
	return $ERROR
}

gen_pass () {
	MATRICE=""
	PASS_CHARS="$1"
	if [ ${PASS_CHARS:-0} -eq 0 ];then
		PASS_CHARS=7
	fi

	if [ $(( $PASS_CHARS & 1 )) -gt 0 ];then
		MATRICE=$MATRICE"0123456789"
	fi
	if [ $(( $PASS_CHARS & 2 )) -gt 0 ];then
		MATRICE=$MATRICE"abcdefghijklmnopqrstuvwxyz"
	fi
	if [ $(( $PASS_CHARS & 4 )) -gt 0 ];then
		MATRICE=$MATRICE"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	fi
#	if [ $(( $PASS_CHARS & 8 )) -gt 0 ];then
#		MATRICE=$MATRICE"!\$_.,;:%&()?"
#	fi
	if [ -z "$MATRICE" ];then
		MATRICE="23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz"
	fi
	echo $MATRICE
}

ldap_add_people () {
	CONTROLADD=""
	for VAR in "EMAIL" "PHONE" "DESCRIPTION" "DISPLAYNAME" "ORGANIZATION" "INFO" "ROOM" "MCPI" "MAXDAYS" "CN" "LOGINREMOTE" "MUDC";do
		if [ -z ${!VAR} ];then
			eval $VAR="?"
		fi
	done
	USERNAME="$(echo "$USERNAME" | sed 's/ //g')"
	NAME="$(echo "$NAME" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
	LAST_NAME="$(echo "$LAST_NAME" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
	EMAIL="$(echo "$EMAIL" | sed 's/ //g')"
	PHONE="$(echo "$PHONE" | sed 's/ //g')"
	[ -z "$NAME" ] && NAME="$L_ANONYMOUS"
	[ -z "$LAST_NAME" ] && LAST_NAME="$L_ANONYMOUS"
	[ -z "$HIDDEN" ] && HIDDEN="no"
	[ -z "$VALIDITY" ] && VALIDITY="yes"
	[ -z "$SHADOWEXPIRE" ] && SHADOWEXPIRE="24836"
	[ -z "$GIDNUMBER" ] && GIDNUMBER="65534"
	[ -z "$UTENTEC" ] && UTENTEC="admin"
	[ "$EMAIL" == "30091960" ] && EMAIL="?"
	if [ -z "$UIDNUMBER" ];then
		UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uidNumber | sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n | tail -1 )
		UIDNUMBER=$(($UIDN+1))
	fi
	DATA="dn: uid=$USERNAME,ou=People,$C_LDAPBASE\nobjectClass: inetOrgPerson\nobjectClass: posixAccount\nobjectClass: top"
	DATA="$DATA\nobjectClass: shadowAccount\nobjectClass: organizationalPerson\nuid: $USERNAME\ncn: $CN"
	DATA="$DATA\ndescription: $DESCRIPTION\ndisplayName: $DISPLAYNAME\no: $ORGANIZATION\nmail: $EMAIL\ngivenName: $NAME"
	DATA="$DATA\nsn: $LAST_NAME\ntelephoneNumber: $PHONE\nuidNumber: $UIDNUMBER\ngidNumber: $GIDNUMBER\ngecos: $INFO"
	DATA="$DATA\nhomeDirectory: /home/$USERNAME\nloginShell: /bin/sh\nshadowExpire: $SHADOWEXPIRE"
	DATA="$DATA\nvalidity: $VALIDITY\nroomName: $ROOM\nhidden: $HIDDEN\\nmudc: $MUDC"
	DATA="$DATA\nownerUser: $UTENTEC\nMCpInterfaces: $MCPI\nmaxDays: $MAXDAYS\nsessions: 0\nclass: $CLASS\nloginRemote: $LOGINREMOTE"
	echo -e "$DATA" | /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLADD="no"
	for VAR in "EMAIL" "PHONE" "DESCRIPTION" "DISPLAYNAME" "ORGANIZATION" "INFO" "ROOM" "MCPI" "MAXDAYS" "CN";do
		if [ ${!VAR} == "?" ];then
			eval $VAR=""
		fi
	done
}

ldap_add_radius () {
	CONTROLADD=""
	[ -z "$CLASS" ] && CLASS="DEFAULT"
	USERNAME="$(echo "$USERNAME" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
	PASSWORD="$(echo "$PASSWORD" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
	DATA="dn: cn=$USERNAME,ou=Radius,$C_LDAPBASE\nobjectClass: organizationalPerson\nobjectClass: top\nobjectClass: radiusprofile"
	DATA="$DATA\nobjectClass: radiusExtension\ncn: $USERNAME\nsn: $PASSWORD\ndialupAccess: yes\nradiusUserCategory: $CLASS"
	echo -e "$DATA" | /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLADD="no"
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		$C_ZT_BIN_DIR/zt "TgzUser" "$USERNAME"
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
				CONTROL_NC=$( `nc -z -w 8 $IP_REMOTE 8088 2> /dev/null` || echo "down")
				if [ -z "$CONTROL_NC" ];then
					curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&USER=$USERNAME&ACTION=AddUser" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				fi
			else
				$C_ZT_BIN_DIR/zt "RemoteSyncDef" "AddUser" "$CLIENT" "$IP_REMOTE" "$PASSWORD" "$USERNAME"
			fi	
		done
	fi
}

ldap_search_people () {
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$1" "$2" "$3" uid uidNumber  givenName sn mail telephoneNumber gecos shadowExpire roomName hidden validity ownerUser MCpInterfaces maxDays createTimestamp displayName description mudc)
	USERNAME=$( echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
	UID_NUMBER=$( echo "$QUERY" | grep -e '^uidNumber: ' | sed 's/^uidNumber: //g')
	NAME=$( echo "$QUERY" | grep -e '^givenName: ' | sed 's/^givenName: //g')
	LAST_NAME=$( echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
	EMAIL=$( echo "$QUERY" | grep -e '^mail: ' | sed 's/^mail: //g')
	PHONE=$( echo "$QUERY" | grep -e '^telephoneNumber: ' | sed 's/^telephoneNumber: //g')
	INFO=$( echo "$QUERY" | grep -e '^gecos: ' | sed 's/^gecos: //g')
	EXPIRE=$( echo "$QUERY" | grep -e '^shadowExpire: ' | sed 's/^shadowExpire: //g')
	ROOM=$( echo "$QUERY" | grep -e '^roomName: ' | sed 's/^roomName: //g')
	HIDDEN=$( echo "$QUERY" | grep -e '^hidden: ' | sed 's/^hidden: //g')
	VALIDITY=$( echo "$QUERY" | grep -e '^validity: ' | sed 's/^validity: //g')
	OWNER=$( echo "$QUERY" | grep -e '^ownerUser: ' | sed 's/^ownerUser: //g')
	MCPI=$( echo "$QUERY" | grep -e '^MCpInterfaces: ' | sed 's/^MCpInterfaces: //g')
	MAXDAYS=$( echo "$QUERY" | grep -e '^maxDays: ' | sed 's/^maxDays: //g')
	CREATED=$( echo "$QUERY" | grep -e '^createTimestamp: ' | sed 's/^createTimestamp: //g')
	DESCRIPTION=$( echo "$QUERY" | grep -e '^description: ' | sed 's/^description: //g')
	DISPLAYNAME=$( echo "$QUERY" | grep -e '^displayName: ' | sed 's/^displayName: //g')
	ORGANIZATION=$( echo "$QUERY" | grep -e '^o: ' | sed 's/^o: //g')
	MUDC=$( echo "$QUERY" | grep -e '^mudc: ' | sed 's/^mudc: //g')
	[ "$INFO" == "?" ] && INFO=""
	[ "$ROOM" == "?" ] && ROOM=""
	[ "$EMAIL" == "?" ] && EMAIL=""
	[ "$HOURSDAY" == "?" ] && HOURSDAY=""
	[ "$HOURSMONTH" == "?" ] && HOURSMONTH=""
	[ "$MBDAY" == "?" ] && MBDAY=""
	[ "$MBMONTH" == "?" ] && MBMONTH=""
	[ "$MAXDAYS" == "?" ] && MAXDAYS=""
	[ "$MCPI" == "?" ] && MCPI=""
	[ "$MUDC" == "?" ] && MUDC=""
	if [ $EXPIRE -eq 24836 ];then
		DAY_EXPIRE=""
		MONTH_EXPIRE=""
		YEAR_EXPIRE=""
	else
		DAY_EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%d)
		MONTH_EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%m)
		YEAR_EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%Y)
	fi
	if [ $PHONE != "?" ];then
		PHONE1=$(echo $PHONE | sed -e 's/^../''/g')
		PREFIX=$(echo $PHONE | sed '/'${PHONE1}'/s///g')
	else
		PHONE=""
		PREFIX=""
	fi
}

ldap_search_radius () {
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$1 sn radiusUserCategory)
	CLASS=$(echo "$QUERY" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
	PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
	[ -z "$CLASS" ] && class="DEFAULT"
}

ldap_modify_people () {
	DATA="dn: uid=$USERNAME,ou=People,$C_LDAPBASE\nuid: $USERNAME"
	for ATT in $1;do
		if [ "$ATT" == "givenName" ];then
			NAME="$(echo "$NAME" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
			DATA="$DATA\n$ATT: $NAME"
		fi
		if [ "$ATT" == "sn" ];then
			LAST_NAME="$(echo "$LAST_NAME" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
			DATA="$DATA\n$ATT: $LAST_NAME"
		fi
		if [ "$ATT" == "mail" ];then
			EMAIL="$(echo "$EMAIL" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
			DATA="$DATA\n$ATT: $EMAIL"
		fi
		[ "$ATT" == "gecos" ] && DATA="$DATA\n$ATT: $INFO"
		[ "$ATT" == "hidden" ] && DATA="$DATA\n$ATT: $HIDDEN"
		if [ "$ATT" == "telephoneNumber" ];then
			PHONE="$(echo "$PHONE" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
			DATA="$DATA\n$ATT: $PHONE"
		fi
		[ "$ATT" == "maxDays" ] && DATA="$DATA\n$ATT: $MAXDAYS"
		[ "$ATT" == "validity" ] && DATA="$DATA\n$ATT: $VALIDITY"
		[ "$ATT" == "roomName" ] && DATA="$DATA\n$ATT: $ROOM"
		[ "$ATT" == "MCpInterfaces" ] && DATA="$DATA\n$ATT: $MCPI"
		[ "$ATT" == "ownerUser" ] && DATA="$DATA\n$ATT: $OWNER"
		[ "$ATT" == "shadowExpire" ] && DATA="$DATA\n$ATT: $SHADOWEXPIRE"
		[ "$ATT" == "class" ] && DATA="$DATA\n$ATT: $CLASS"
		[ "$ATT" == "sessions" ] && DATA="$DATA\n$ATT: $SESSIONS"
		[ "$ATT" == "mudc" ] && DATA="$DATA\n$ATT: $MUDC"
	done
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
}

ldap_modify_radius () {
	DATA="dn: cn=$USERNAME,ou=Radius,$C_LDAPBASE\ncn: $USERNAME"
	for ATT in $1;do
		if [ "$ATT" == "sn" ];then
			PASSWORD="$(echo "$PASSWORD" | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')"
			DATA="$DATA\n$ATT: $PASSWORD"
		fi
		[ "$ATT" == "radiusUserCategory" ] && DATA="$DATA\n$ATT: $CLASS"
	done
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		$C_ZT_BIN_DIR/zt "TgzUser" "$USERNAME"
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
				CONTROL_NC=$( `nc -z -w 8 $IP_REMOTE 8088 2> /dev/null` || echo "down")
				if [ -z "$CONTROL_NC" ];then
					curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&USER=$USERNAME&ACTION=UpdateUser" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				fi
			else
				$C_ZT_BIN_DIR/zt "RemoteSyncDef" "UpdateUser" "$CLIENT" "$IP_REMOTE" "$PASSWORD" "$USERNAME" 
			fi	
		done

	fi
}

rawurlencode() {
  local string="${1}"
  local strlen=${#string}
  local encoded=""

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded+="${o}"
  done
  echo "${encoded}"
  REPLY="${encoded}"
}

urlencode () {
	echo "${1}" | sed -f $C_ZT_CONF_DIR/url_escape
}

urlencodehtml () {
	echo "${1}" | sed -f $C_ZT_CONF_DIR/urlencodehtml
}

addressprefix () {
	echo "${1}" | sed -f $C_ZT_CONF_DIR/addressprefix
}

error () {
	echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">$1</font><p>
	<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form action=\"$2\" method=\"POST\">
	<input type=\"hidden\" name=\"$3\" value=\"$4\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	echo "<p>&nbsp;<p>"
	./footer.sh
}

controlok () {
	echo "<font color=\"blue\" size=\"4\">$1</font><p>
	<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form action=\"$2\" method=\"POST\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	echo "<p>&nbsp;<p>"
	./footer.sh
}

namelan () {
	NAME_LAN="$(ls $C_SYSTEM/net/interfaces)"
	for INT_LAN in $NAME_LAN;do
		N_VLAN="$(ls $C_SYSTEM/net/interfaces/$INT_LAN/VLAN)"
		if [ -n "$N_VLAN" ];then
			MULTI_VLAN=""
			for M_VLAN in $N_VLAN;do
				MULTI_VLAN="$MULTI_VLAN $INT_LAN.$M_VLAN"
			done
			NAME_VLAN="$NAME_VLAN $MULTI_VLAN"
		fi
	done
	NAME_LAN="$NAME_LAN $NAME_VLAN"
	NAME_LAN="$(echo "$NAME_LAN" | sed 's/ /\n/g' | sort )"
}

addusercron () {
	for CRON_DAYS in "LUN 1" "MAR 2" "MER 3" "GIO 4" "VEN 5" "SAB 6" "DOM 0";do
		set -- $CRON_DAYS
		eval CRON_DAY=\$$1
		if [ "$CRON_DAY" == "on" ];then
			DAYS_CRON="$DAYS_CRON+$2"
			[ $2 == $DAYS ] && CONTROLGS="ok"
		fi
	done
	if [ -n "$DAYS_CRON" ] || [[ -n "$HOUR_START" && -n "$HOUR_STOP" && -n "$MINUTES_START" && -n "$MINUTES_STOP" ]];then
		if [ -n "$DAYS_CRON" ];then
			DAYS_CRON=$(echo $DAYS_CRON | sed 's/+//' | sed '/+/s//,/g')
		else
			DAYS_CRON="ALL"
		fi
		if [[ -z $HOUR_START || -z $MINUTES_START || -z $HOUR_STOP || -z $MINUTES_STOP ]];then
			HOUR_START=0
			MINUTES_START=0
			HOUR_STOP=23
			MINUTES_STOP=59
			HOUR_START_SEC=""
			MINUTES_START_SEC=""
			HOUR_STOP_SEC=""
			MINUTES_STOP_SEC=""
		else
			if [[ -z $HOUR_START_SEC || -z $MINUTES_START_SEC || -z $HOUR_STOP_SEC || -z $MINUTES_STOP_SEC ]];then
				HOUR_START_SEC=""
				MINUTES_START_SEC=""
				HOUR_STOP_SEC=""
				MINUTES_STOP_SEC=""
			else
				SEC_TIME_CRON="yes"
			fi
		fi
		MINUTES_START=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_START" )
		MINUTES_STOP=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_STOP" )
		$C_ZT_BIN_DIR/zt "AggiornaCron" "$USERNAME" "$DAYS_CRON" "$HOUR_START" "$MINUTES_START" "$HOUR_STOP" "$MINUTES_STOP"
		if [ -n "$SEC_TIME_CRON" ];then
			MINUTES_START_SEC=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_START_SEC" )
			MINUTES_STOP_SEC=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_STOP_SEC" )
			$C_ZT_BIN_DIR/zt "AggiornaCronSec" "$USERNAME" "$DAYS_CRON" "$HOUR_START_SEC" "$MINUTES_START_SEC" "$HOUR_STOP_SEC" "$MINUTES_STOP_SEC"
		fi
		$C_ZT_BIN_DIR/zt "RestartCron"
		[ $MINUTES_START -lt 10 ] && MINUTES_START=0$MINUTES_START
		[ $MINUTES_STOP -lt 10 ] && MINUTES_STOP=0$MINUTES_STOP
		CONTROLSTART=$HOUR_START$MINUTES_START
		CONTROLSTOP=$HOUR_STOP$MINUTES_STOP
		if [ -n "$HOUR_START_SEC" ];then
			[ $MINUTES_START_SEC -lt 10 ] && MINUTES_START_SEC=0$MINUTES_START_SEC
			[ $MINUTES_STOP_SEC -lt 10 ] && MINUTES_STOP_SEC=0$MINUTES_STOP_SEC
			CONTROLSTART_SEC=$HOUR_START_SEC$MINUTES_START_SEC
			CONTROLSTOP_SEC=$HOUR_STOP_SEC$MINUTES_STOP_SEC
		fi
		if [ -z "$HOUR_START_SEC" ];then
			[ "$DAYS_CRON" == "ALL" ] && [[ $ORAMIN -lt $CONTROLSTART || $ORAMIN -gt $CONTROLSTOP ]] && CONTROLTIME="no"
		else
			[[ $ORAMIN -gt $CONTROLSTOP && $ORAMIN -lt $CONTROLSTART_SEC ]] && CT="yes"
			[ "$DAYS_CRON" == "ALL" ] && [[ $ORAMIN -lt $CONTROLSTART || -n "$CT" || $ORAMIN -gt $CONTROLSTOP_SEC ]] && CONTROLTIME="no"
		fi
		[[ "$DAYS_CRON" != "ALL" && -z "$CONTROLGS" ]] && CONTROLTIME="no"

		if [ -z "$HOUR_START_SEC" ];then
			[ -n "$CONTROLGS" ] && [[ $ORAMIN -lt $CONTROLSTART || $ORAMIN -gt $CONTROLSTOP ]] && CONTROLTIME="no"
		else
			[[ $ORAMIN -gt $CONTROLSTOP && $ORAMIN -lt $CONTROLSTART_SEC ]] && CT="yes"
			[ -n "$CONTROLGS" ] && [[ $ORAMIN -lt $CONTROLSTART || -n "$CT" || $ORAMIN -gt $CONTROLSTOP_SEC ]] && CONTROLTIME="no"
		fi
		if [ "$CONTROLTIME" == "no" ];then
			PASSWORD="$PASSWORD-$RANDOM"
		fi
	else
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}START-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}STARTSEC-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}START-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}STOP-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}STOPSEC-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
}

cronpopup () {
	if [[ -n "$HOUR_START" && -n "$HOUR_STOP" && -n "$MINUTES_START" && -n "$MINUTES_STOP" ]];then
		ORAS=$(date +%H)
		MINS=$(date +%M)
		ORAMIN=$ORAS$MINS
		ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
		DAYS_CRON="ALL"
		MINUTES_START=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_START" )
		MINUTES_STOP=$($C_ZT_BIN_DIR/zt "DeleteFirstZero" "$MINUTES_STOP" )
		$C_ZT_BIN_DIR/zt "AggiornaCronPopup" "POPUP" "$DAYS_CRON" "$HOUR_START" "$MINUTES_START" "$HOUR_STOP" "$MINUTES_STOP"
		$C_ZT_BIN_DIR/zt "RestartCron"
		[ $MINUTES_START -lt 10 ] && MINUTES_START=0$MINUTES_START
		[ $MINUTES_STOP -lt 10 ] && MINUTES_STOP=0$MINUTES_STOP
		CONTROLSTART=$HOUR_START$MINUTES_START
		CONTROLSTOP=$HOUR_STOP$MINUTES_STOP
		[ "$DAYS_CRON" == "ALL" ] && [[ $ORAMIN -lt $CONTROLSTART || $ORAMIN -gt $CONTROLSTOP ]] && CONTROLTIME="no"

		if [ "$CONTROLTIME" == "no" ];then
			$C_ZT_BIN_DIR/zt "Salva" "no" "$C_CP_DIR/Auth/Custom/PopupActive"
		else
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/PopupActive"
		fi
	else
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron" 2>/dev/null
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
}

disconnectuser () {
	USERDIS="$1"
	if [ "$C_CP_LOCAL_TYPE" != "Server" ];then
		for SC in $(ls $C_CP_DIR/Connected);do
			USERLDAP=$(cat $C_CP_DIR/Connected/$SC/User | cut -sd'@' -f1)
			if [ "$USERLDAP" == "$USERDIS" ];then
				IP=$SC
				$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDIS"
			fi
		done
	else
		IP=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERDIS loginRemote | grep '^loginRemote:' | awk '{print $2}' | cut -d'-' -f2)
		$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDIS"
	fi
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DISCONNECTED $USERDIS $IP"
	fi
}

disconnectuserfd () {
	USERDIS="$1"
	if [ "$C_CP_LOCAL_TYPE" != "Server" ];then
		for SC in $(ls $C_CP_DIR/Connected);do
			USERLDAP=$(cat $C_CP_DIR/Connected/$SC/User | cut -sd'@' -f1)
			if [ "$USERLDAP" == "$USERDIS" ];then
				IP=$SC
			fi
		done
	else
		IP=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERDIS loginRemote | grep '^loginRemote:' | awk '{print $2}' | cut -d'-' -f2)
	fi
	$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDIS"
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DISCONNECTED $USERDIS $IP"
	fi
}

disconnectall () {
	LETTER="$1"
	if [ -n "$LETTER" ];then
		LETTERD=$(echo "$LETTER" | tr A-Z a-z)
	fi
	NAME_CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -d'@' -f1)
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in $CONNECTED;do
		if [ -n $(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1 | grep "^$LETTERD") ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		fi
	done
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DISCONNECT_ALL LETTER $LETTER"
	fi
}

lockuser () {
	USERLOCK="$1"
	LOCK="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERLOCK sn)
	PASS=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1)
	if [ "$LOCK" != "no" ];then
		PASS="$PASS-$RANDOM"
		BLOCKED="yes"
		ACTION="LockUser"
	else
		BLOCKED="no"
		ACTION="UnlockUser"
	fi
	WAIT_ASTERISK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERLOCK gecos | sed -n '/gecos:/p' | awk '{ print $2 }')
	if [ "$WAIT_ASTERISK" != "wait_asterisk" ];then
		DATA="dn: cn=$USERLOCK,ou=Radius,$C_LDAPBASE\nsn: $PASS"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		DATA="dn: uid=$USERLOCK,ou=PEOPLE,$C_LDAPBASE\nlocked: $BLOCKED"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		CONNECTED=$(ls $C_CP_DIR/Connected )
		for IP in $CONNECTED;do
			if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERLOCK" ];then
				$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERLOCK"
			fi
		done
		if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
			for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
				IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
				PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
				if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
					CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
					if [ "$CONTROL_NC" != "down" ];then
						curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=$ACTION&USER=$USERLOCK" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
					fi
				else
					$C_ZT_BIN_DIR/zt "RemoteSyncDef" "$ACTION" "$CLIENT" "$IP_REMOTE" "$PASSWORD" "$USERLOCK"
				fi
			done
		fi
		if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
			if [ "$LOCK" != "no" ];then
				$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_LOCK user $USERLOCK"
			else
				$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UNLOCK user $USERLOCK"
			fi
		fi
	fi

}

lockall () {
	LETTER="$1"
	if [[ -n "$LETTER" && "$LETTER" != "$L_ALL" ]];then
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" "(&(cn=$LETTER*))" '(!(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	else
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(!(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	fi
	[ -z "$USERLOCK" ] && exit
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
				CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
				if [ "$CONTROL_NC" != "down" ];then
					curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=LockAll" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				fi
			else
				$C_ZT_BIN_DIR/zt "RemoteSyncDef" "LockAll" "$CLIENT" "$IP_REMOTE" "$PASSWORD"
			fi
		done
	fi
	for USERL in $USERLOCK;do
		if [ "$USERL" != "admin" ];then
			OWNER=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERL ownerUser | sed -n '/ownerUser:/p' | awk '{ print $2 }')
			if [[ "$UTENTEC" == "$C_ADMIN" || -z "$C_THEIR_USERS" ]] || [[ -n "$C_THEIR_USERS" && "$OWNER" == "$UTENTEC" ]];then
				CONNECTED=$(ls $C_CP_DIR/Connected )
				for IP in $CONNECTED;do
					if [ $(cat $C_CP_DIR/Connected/$IP/User | cut -d"@" -f1) == "$USERL" ];then
						$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERL"
					fi
				done
				RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERL sn)
				PASS=$( echo $RADIUS | awk '{print $NF}')
				PASSLOCK="$PASS-$RANDOM"
				DATA="dn: cn=$USERL,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
				echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
				DATA="dn: uid=$USERL,ou=PEOPLE,$C_LDAPBASE\nlocked: yes"
				echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			fi
		fi
	done
	if [[ -n "$C_LOG_USER" && -n "$USERLOCK" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_LOCK_ALL"
	fi
}

unlockall () {
	LETTER="$1"
	if [[ -n "$LETTER" && "$LETTER" != "$L_ALL" ]];then
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" "(&(cn=$LETTER*))" '(&(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	else
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(&(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	fi
	[ -z "$USERLOCK" ] && exit
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
				CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
				if [ "$CONTROL_NC" != "down" ];then
					curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=UnlockAll" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				fi
			else
				$C_ZT_BIN_DIR/zt "RemoteSyncDef" "UnlockAll" "$CLIENT" "$IP_REMOTE" "$PASSWORD"
			fi	
		done
	fi
	for USERL in $USERLOCK;do
		OWNER=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERL ownerUser | sed -n '/ownerUser:/p' | awk '{ print $2 }')
		WAIT_ASTERISK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERL gecos | sed -n '/gecos:/p' | awk '{ print $2 }')
		if [[ "$UTENTEC" == "$C_ADMIN" || -z "$C_THEIR_USERS" ]] || [[ -n "$C_THEIR_USERS" && "$OWNER" == "$UTENTEC" ]];then
			if [ "$USERL" != "admin" ] && [ "$WAIT_ASTERISK" != "wait_asterisk" ];then
				RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERL sn)
				PASS=$( echo $RADIUS | awk '{print $NF}')
				PASS=$(echo "$PASS" | cut -d'-' -f1)
				DATA="dn: cn=$USERL,ou=Radius,$C_LDAPBASE\nsn: $PASS"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
				DATA="dn: uid=$USERL,ou=PEOPLE,$C_LDAPBASE\nlocked: no"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			fi
		fi
	done
	if [[ -n "$C_LOG_USER" && -n "$USERLOCK" ]] && [ "$WAIT_ASTERISK" != "wait_asterisk" ];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UNLOCK_ALL"
	fi
}

deleteexpired () {
	LETTER="$1"
	if [ -n "$LETTER" ];then
		FILTERD="(&(uid=$LETTER*)(!(validity=yes)))"
	else
		FILTERD="(!(validity=yes))"
	fi
	EXPIRED=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$FILTERD" uid)
	USEREXPIRED=$(echo "$EXPIRED" | sed -n '/uid:/p' | awk '{ print $2 }')
	if [ -n "$USEREXPIRED" ];then
		for USER_EX in $USEREXPIRED;do
			if [ "$USER_EX" != "admin" ];then
				LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USER_EX givenName sn)
				NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g' | sed 's/ /_/g')
				LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g' | sed 's/ /_/g')
				TODAY=$(date +%d%m%Y)
				if [ -d $C_ACCT_DIR/entries/$USER_EX/sessions ];then
					if ! [ -d $C_ZT_DIR/deleted ];then
						$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted"
					fi
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
					$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USER_EX" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USER_EX"
					if [ -f $C_ACCT_DIR/credits/$USER_EX/Credit ];then
						$C_ZT_BIN_DIR/zt "Copia" "$C_ACCT_DIR/credits/$USER_EX/Credit" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY/Credit"
					fi
				fi
				if [ -d $C_ZT_DIR/expired/$USER_EX ];then
					if ! [ -d $C_ZT_DIR/deleted/$USER_EX_$NAME_$LAST_NAME_$TODAY ];then
						$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
					fi
					$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ZT_DIR/expired/$USER_EX" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY/EXPIRED"
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USER_EX"
				fi
				$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USER_EX"
				/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USER_EX,ou=People,$C_LDAPBASE" > /dev/null
				/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USER_EX,ou=Radius,$C_LDAPBASE" > /dev/null
				$C_ZT_BIN_DIR/zt "DelK5" "$USER_EX"
			fi
		done
		if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETE_EXPIRED"
		fi
	fi
}

deleteuser () {
	USERDEL="$1"
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}START-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOPSEC-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOPSEC-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STARTSEC-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -n "$CONTROL_CRON" ];then
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in "$CONNECTED";do
		if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERDEL" ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDEL"
		fi
	done	
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		LR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERDEL loginRemote | grep '^loginRemote:' | awk '{print $2}')
		if [ "$LR" != "?" ];then
			NAS=$(echo "$LR" | cut -d'-' -f1)
			IP=$(echo "$LR" | cut -d'-' -f2)
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$NAS/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$NAS/PASSWORD)
			CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
			if [ "$CONTROL_NC" != "down" ];then
				/usr/local/bin/curl -G -d "CLIENT=$NAS&PASS=$PASSWORD&ACTION=DisconnectUser&USER=$USERDEL&IP=$IP" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
			fi
		fi
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
				CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
				if [ "$CONTROL_NC" != "down" ];then
					/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=DeleteUser&USER=$USERDEL" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				fi
			else
				$C_ZT_BIN_DIR/zt "RemoteSyncDef" "DeleteUser" "$CLIENT" "$IP_REMOTE" "$PASSWORD" "$USERDEL"
			fi	
		done
	fi
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERDEL,ou=People,$C_LDAPBASE" > /dev/null
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERDEL,ou=Radius,$C_LDAPBASE" > /dev/null
	if [ -d $C_ACCT_DIR/entries/$USERDEL ];then
		NAME=$(echo "$NAME" | sed '/ /s///g' | sed 's/ /_/g')
		LAST_NAME=$(echo "$LAST_NAME" | sed '/ /s///g' | sed 's/ /_/g')
		TODAY=$(date +%d%m%Y)
		$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERDEL" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-$TODAY"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
		if [ -d $C_ZT_DIR/expired/$USERDEL ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY/EXPIRED"
			$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ZT_DIR/expired/$USERDEL" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-CREDIT-$TODAY/EXPIRED"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USERDEL"
		fi
		if [ -f $C_ACCT_DIR/credits/$USERDEL/Credit ];then
			$C_ZT_BIN_DIR/zt "Salva" "$(cat $C_ACCT_DIR/credits/$USERDEL/Credit)" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-$TODAY/Credit"
		fi
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERDEL"
	$C_ZT_BIN_DIR/zt "DelK5" "$USERDEL"
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETED user $USERDEL"
	fi
	if [ "$C_NOT_SMS_DELETE_USER" == "on" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_DELETED_USER $USERDEL $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN"
	fi
	if [ -n "$C_NOT_EMAIL_DELETE_USER" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_DELETED_USER $USERDEL\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
}

remoteclient () {
	IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
	PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
	CONTROL_NC=$( `nc -z -w 8 $IP_REMOTE 8088 2> /dev/null` || echo "down")
	if [ -z "$CONTROL_NC" ];then
		if [ -z "$2" ];then
			curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=$1" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
		else
			CONTROL=$(curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=$1" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh)
			CONTROL_UP=$(echo "$CONTROL" | awk '{print $1}')
			CONTROL_ACTIVE=$(echo "$CONTROL" | awk '{print $2}')
			CONTROL_AR=$(echo "$CONTROL" | awk '{print $3}')
			CONTROL_SHAPER=$(echo "$CONTROL" | awk '{print $4}')
			CONTROL_HAVP=$(echo "$CONTROL" | awk '{print $5}')
			CONTROL_SQUID=$(echo "$CONTROL" | awk '{print $6}')
			CONTROL_DS=$(echo "$CONTROL" | awk '{print $7}')
			CONTROL_AUTO=$(echo "$CONTROL" | awk '{print $8}')
			CONTROL_REMOTE_SYNC=$(echo "$CONTROL" | awk '{print $9}')
			[ "$CONTROL_REMOTE_SYNC" == "no" ] && CONTROL_REMOTE_SYNC=""
			CONTROL_KEY=$(echo "$CONTROL" | awk '{print $10}')
		fi
	else
		CONTROL=""
		CONTROL_CON_CLIENT="down"
		echo ""
	fi
}

putprivkey () {
	if [ -f $C_ZT_CONF_DIR/RemoteKey/privatekey.pem ];then
		IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
		PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
		curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=DeleteKey" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh
		LINEKEY=$(cat $C_ZT_CONF_DIR/RemoteKey/privatekey.pem | wc -l | awk '{print $1}')
		for I in $(seq 1 $LINEKEY);do
			LINE="$(cat $C_ZT_CONF_DIR/RemoteKey/privatekey.pem | sed -n "${I}p" | sed 's/ /+++++/g')"
			curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=GetKey&LINE=$LINE" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh
		done
		curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=ModifyKey" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh
		CONTROLKEY="$(cat $C_ZT_CONF_DIR/RemoteKey/controlkey)"
		curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=GetControlKey&CONTROLKEY=$CONTROLKEY" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh
		$C_ZT_BIN_DIR/zt "ProFile" "root:root" "$C_ZT_CONF_DIR/RemoteKey/privatekey.pem"
	fi
}

remoteserverlink () {
	CONTROL_NC=$( `nc -z -w 4 $C_CP_REMOTE_IP 8088 2> /dev/null` || echo "down")
	if [ -z "$CONTROL_NC" ];then
		CONTROL_LINK=$(curl -G -d "CLIENT=$C_CP_LOCAL_NAME&PASS=$C_CP_REMOTE_PASSWORD&ACTION=ControlLink" http://$C_CP_REMOTE_IP:8088/cgi-bin/remotecp.sh)
	fi
}

UpdateClassRemote (){
	$C_ZT_BIN_DIR/zt "TgzClasses"
	for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
		IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
		PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
		if [ ! -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
			CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $IP_REMOTE 8088  2> /dev/null` || echo "down")
			if [ "$CONTROL_NC" != "down" ];then
				curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=GetClass" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
			fi
		else
			$C_ZT_BIN_DIR/zt "RemoteSyncDef" "GetClass" "$CLIENT" "$IP_REMOTE" "$PASSWORD"
		fi	
	done
}

varmanager () {
	for CONF in "CLASS" "CLASS_USER" "CREDIT" "DAYS" "DELETE_EXPIRED" "DELETE_USER" "DELETE_USERS" \
		"DISCONNECT_ALL" "DISCONNECT_USER" "EDIT_USERS" "EXPIRE" "EXPIRECLASS" "GES_CLASS" \
		"HOURS" "LIMIT" "LOCK_ALL" "LOG_USER" "MULTI_USERS" "PREFIX_MULTI" "PRINT_TICKET" \
		"REGISTER_INFO" "REGISTER_USERS" "ROOM" "SEND_EMAIL" "SEND_SMS" "THEIR_USERS" \
		"UNLOCK_ALL" "UNLOCK_LOCK_USERS" "USER_EXPIRE" "USERS_FROM_TICKET" "VIEW_DETAILS" \
		"VIEW_HIDDEN" "VIEW_RANGE" "VIEW_SMS_CREDIT" "USER_MUDC" "USER_MUDCCCTV";do
		eval C_$CONF="$(cat $C_ZT_CONF_DIR/Manager/$MANAGER/$CONF)"
	done
	C_CLASS_USER="$(cat $C_ZT_CONF_DIR/Manager/$MANAGER/CLASS_USER)"
}

ldap_repair () {
	ACTION="$1"
	QUERYP=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" '(!(uid=admin))' uid )
	USERS=$(echo "$QUERYP" |  grep -e '^uid: ' | awk '{print $2}')
	NR=1
	for USER in $USERS;do
		BG="$C_BG"
		[ $(expr $NR % 2 ) -eq 0 ] && BG="$C_BG1"
		NORADIUS=""
		ERROR=""
		CONTROLMODIFY=""
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USER uid givenName sn mail telephoneNumber shadowExpire roomName hidden validity ownerUser MCpInterfaces maxDays loginRemote class sessions)
		USERNAME=$(echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
		QUERYR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER)
		[ -z "$QUERYR" ] && NORADIUS="yes"
		NAME=$(echo "$QUERY" | grep -e '^givenName:')
		[[ -z "$NAME" || -n "$(echo $NAME | grep '\:\:')" ]] && ERROR="NAME"
		[ -z "$NAME" ] && ERROR="NAME"
		LAST_NAME=$(echo "$QUERY" | grep -e '^sn:')
		[[ -z "$LAST_NAME" || -n "$(echo $LAST_NAME | grep '\:\:')" ]] && ERROR="$ERROR LAST_NAME"
		EMAIL=$(echo "$QUERY" | grep -e '^mail:')
		[[ -z "$EMAIL" || -n "$(echo $EMAIL | grep '\:\:')" ]] && ERROR="$ERROR EMAIL"
		PHONE=$(echo "$QUERY" | grep -e '^telephoneNumber:')
		[[ -z "$PHONE" || -n "$(echo $PHONE | grep '\:\:')" ]] && ERROR="$ERROR PHONE"
		EXPIRE=$(echo "$QUERY" | grep -e '^shadowExpire:')
		[[ -z "$EXPIRE" || -n "$(echo $EXPIRE | grep '\:\:')" ]] && ERROR="$ERROR EXPIRE"
		ROOM=$(echo "$QUERY" | grep -e '^roomName:')
		[[ -z "$ROOM" || -n "$(echo $ROOM | grep '\:\:')" ]] && ERROR="$ERROR ROOM"
		HIDDEN=$(echo "$QUERY" | grep -e '^hidden:')
		[[ -z "$HIDDEN" || -n "$(echo $HIDDEN | grep '\:\:')" ]] || [[ "$(echo -e "$QUERY" | grep -e '^hidden:' | awk '{print $2}')" != "yes" && "$(echo "$QUERY" | grep -e '^hidden:' | awk '{print $2}')" != "no" ]] && ERROR="$ERROR HIDDEN"
		VALIDITY=$(echo "$QUERY" | grep -e '^validity:')
		[[ -z "$VALIDITY" || -n "$(echo $VALIDITY | grep '\:\:')" ]] || [[ "$(echo -e "$QUERY" | grep -e '^validity:' | awk '{print $2}')" != "yes" && "$(echo "$QUERY" | grep -e '^validity:' | awk '{print $2}')" != "no" ]] && ERROR="$ERROR VALIDITY"
		OWNER=$(echo "$QUERY" | grep -e '^ownerUser:')
		[[ -z "$OWNER" || -n "$(echo $OWNER | grep '\:\:')" ]] || [ "$(echo -e "$QUERY" | grep -e '^ownerUser:' | awk '{print $2}')" == "?" ] && ERROR="$ERROR OWNER"
		MCPI=$(echo "$QUERY" | grep -e '^MCpInterfaces:')
		[[ -z "$MCPI" || -n "$(echo $MCPI | grep '\:\:')" ]] && ERROR="$ERROR MCPI"
		MAXDAYS=$(echo "$QUERY" | grep -e '^maxDays:')
		[[ -z "$MAXDAYS" || -n "$(echo $MAXDAYS | grep '\:\:')" ]] && ERROR="$ERROR MAXDAYS"
		LOGINREMOTE=$(echo "$QUERY" | grep -e '^loginRemote:')
		[[ -z "$LOGINREMOTE" || -n "$(echo $LOGINREMOTE | grep '\:\:')" ]] && ERROR="$ERROR LOGINREMOTE"
		EXPIRE=$(echo "$QUERY" | grep -e '^shadowExpire:')
		[[ -z "$EXPIRE" || -n "$(echo $EXPIRE | grep '\:\:')" ]] && ERROR="$ERROR EXPIRE"
		CLASS=$(echo "$QUERY" | grep -e '^class:')
		[[ -z "$CLASS" || -n "$(echo $CLASS | grep '\:\:')" ]] && ERROR="$ERROR CLASS"
		SESSIONS=$(echo "$QUERY" | grep -e '^sessions:')
		[[ -z "$SESSIONS" || -n "$(echo $SESSIONS | grep '\:\:')" ]] && ERROR="$ERROR SESSIONS"
		if [[ -n "$NORADIUS" || -n "$ERROR" ]];then
			if [ "$ACTION" == "view" ];then
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td>&nbsp;<img src=\"/images/disabilita.png\">&nbsp;$ERROR</td></tr>"
			fi
			if [ "$ACTION" == "repair" ];then
				DATA="dn: uid=$USER,ou=People,$C_LDAPBASE"
				for ATT in $ERROR;do
					[ "$ATT" == "NAME" ] && DATA="$DATA\ngivenName: $L_ANONYMOUS"
					[ "$ATT" == "LAST_NAME" ] && DATA="$DATA\nsn: $L_ANONYMOUS"
					[ "$ATT" == "EMAIL" ] && DATA="$DATA\nmail: ?"
					[ "$ATT" == "INFO" ] && DATA="$DATA\ngecos: ?"
					[ "$ATT" == "HIDDEN" ] && DATA="$DATA\nhidden: no"
					[ "$ATT" == "PHONE" ] && DATA="$DATA\ntelephoneNumber: ?"
					[ "$ATT" == "MAXDAYS" ] && DATA="$DATA\nmaxDays: ?"
					[ "$ATT" == "VALIDITY" ] && DATA="$DATA\nvalidity: yes"
					[ "$ATT" == "HOURSDAY" ] && DATA="$DATA\nhoursDay: ?"
					[ "$ATT" == "HOURSMONTH" ] && DATA="$DATA\nhoursMonth: ?"
					[ "$ATT" == "MBDAY" ] && DATA="$DATA\nmbDay: ?"
					[ "$ATT" == "MBMONTH" ] && DATA="$DATA\nmbMonth: ?"
					[ "$ATT" == "ROOM" ] && DATA="$DATA\nroomName: ?"
					[ "$ATT" == "MCPI" ] && DATA="$DATA\nMCpInterfaces: ?"
					[ "$ATT" == "OWNER" ] && DATA="$DATA\nownerUser: $C_ADMIN"
					[ "$ATT" == "EXPIRE" ] && DATA="$DATA\nshadowExpire: 24836"
					[ "$ATT" == "CLASS" ] && DATA="$DATA\nclass: DEFAULT"
					[ "$ATT" == "SESSIONS" ] && DATA="$DATA\nsessions: 0"
					[ "$ATT" == "LOGINREMOTE" ] && DATA="$DATA\nloginRemote: ?"
				done
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
				if [ "$2" == "view" ];then
					if [ -z "$CONTROLMODIFY" ];then
						echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td align=\"center\"><img src=\"/images/disabilita.png\"> --> <img src=\"/images/abilita.png\"></td></tr>"
					fi
					if [[ -n "$CONTROLMODIFY" || -n "$NORADIUS" ]];then
						echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td align=\"center\"><img src=\"/images/disabilita.png\"> --> <img src=\"/images/disabilita.png\"></td></tr>"
					fi
				fi

			fi
		else
			echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td align=\"center\"><img src=\"/images/abilita.png\"></td></tr>"
		fi
		NR=$(($NR+1))
	done
}

limituser () {
	USERLIMIT="$1"
	USERCLASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERLIMIT radiusUserCategory | grep -e '^radiusUserCategory: ' | awk '{print $2}')
	if [ -n "$(cat $C_CLASSES_DIR/$USERCLASS/Days)" ];then
		for CRON_DAYS in "$L_MONDAY 1" "$L_TUESDAY 2" "$L_WEDNESDAY 3" "$L_THURSDAY 4" "$L_FRIDAY 5" "$L_SATURDAY 6" "$L_SUNDAY 0";do
		set -- $CRON_DAYS
			if [ -n "$(cat $C_CLASSES_DIR/$USERCLASS/Days | grep "$2")" ];then
				USERDAYS="$USERDAYS $1, "
			fi
		done
		USERDAYS=$(echo -e "$USERDAYS" | sed 's/, $//' | sed 's/\\//g')
	else
		USERDAYS="$L_ALL"
	fi
	if [ -n "$(cat $C_CLASSES_DIR/$USERCLASS/Range1)" ];then
		USERTIME="$(cat $C_CLASSES_DIR/$USERCLASS/Range1)"
			if [ -n "$(cat $C_CLASSES_DIR/$USERCLASS/Range2)" ];then
				USERTIME="$USERTIME $(cat $C_CLASSES_DIR/$USERCLASS/Range2)"
			fi
	else
		USERTIME="$L_ALL"
	fi
	USERHOURSDAY="$(cat $C_CLASSES_DIR/$USERCLASS/HoursDay)"
	USERHOURSMONTH="$(cat $C_CLASSES_DIR/$USERCLASS/HoursMonth)"
	USERMBDAY="$(cat $C_CLASSES_DIR/$USERCLASS/MBDay)"
	USERMBMONTH="$(cat $C_CLASSES_DIR/$USERCLASS/MBMonth)"	
}

limituseremail () {
	[ "$USERDAYS" != "$L_ALL" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_DAYS: $USERDAYS"
	[ "$USERTIME" != "$L_ALL" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_LIMIT $L_HOURS: $USERTIME"
	[ -n "$USERHOURSDAY" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_DMAX_HOURS: $USERHOURSDAY"
	[ -n "$USERHOURSMONTH" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_MMAX_HOURS: $USERHOURSMONTH"
	[ -n "$USERMBDAY" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_DMAX_MB: $USERMBDAY"
	[ -n "$MBMONTH" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_MMAX_MB: $MBMONTH"
}

limitclassjs () {
	for CL in $(ls $C_CLASSES_DIR);do
		if [ -n "$(cat $C_CLASSES_DIR/$CL/Days)" ];then
			for CRON_DAYS in "$L_MONDAY 1" "$L_TUESDAY 2" "$L_WEDNESDAY 3" "$L_THURSDAY 4" "$L_FRIDAY 5" "$L_SATURDAY 6" "$L_SUNDAY 0";do
			set -- $CRON_DAYS
				if [ -n "$(cat $C_CLASSES_DIR/$CL/Days | grep "$2")" ];then
					DAYS_CLASS="$DAYS_CLASS $1, "
				fi
			done
			DAYS_CLASS=$(echo -e "$DAYS_CLASS" | sed 's/, $//' | sed 's/\\//g' | sed 's/^[ \t]*//' | sed  's/[ \t]*$//' | sed 's/,  /+/g' )
		else
			DAYS_CLASS="ALL"
		fi
		MB_DAY_CLASS="$(cat $C_CLASSES_DIR/$CL/MBDay)"
		[ -z "$MB_DAY_CLASS" ] && MB_DAY_CLASS="ALL"
		MB_MONTH_CLASS="$(cat $C_CLASSES_DIR/$CL/MBMonth)"
		[ -z "$MB_MONTH_CLASS" ] && MB_MONTH_CLASS="ALL"
		HOURS_DAY_CLASS="$(cat $C_CLASSES_DIR/$CL/HoursDay)"
		[ -z "$HOURS_DAY_CLASS" ] && HOURS_DAY_CLASS="ALL"
		HOURS_MONTH_CLASS="$(cat $C_CLASSES_DIR/$CL/HoursMonth)"
		[ -z "$HOURS_MONTH_CLASS" ] && HOURS_MONTH_CLASS="ALL"
		RANGE1_CLASS="$(cat $C_CLASSES_DIR/$CL/Range1)"
		if [ -n "$RANGE1_CLASS" ];then
			HOUR_START_CLASS="$(echo "$RANGE1_CLASS" | cut -d':' -f1 )"
			MINUTES_START_CLASS="$(echo "$RANGE1_CLASS" | cut -d':' -f2 | cut -d'-' -f1)"
			HOUR_STOP_CLASS="$(echo "$RANGE1_CLASS" | cut -d'-' -f2 | cut -d':' -f1 )"
			MINUTES_STOP_CLASS="$(echo "$RANGE1_CLASS" | cut -d':' -f3 )"
		else
			HOUR_START_CLASS="ALL"
			MINUTES_START_CLASS="ALL"
			HOUR_STOP_CLASS="ALL"
			MINUTES_STOP_CLASS="ALL"
		fi
		RANGE2_CLASS="$(cat $C_CLASSES_DIR/$CL/Range2)"
		if [ -n "$RANGE2_CLASS" ];then
			HOUR_START_SEC_CLASS="$(echo "$RANGE2_CLASS" | cut -d':' -f1 )"
			MINUTES_START_SEC_CLASS="$(echo "$RANGE2_CLASS" | cut -d':' -f2 | cut -d'-' -f1 )"
			HOUR_STOP_SEC_CLASS="$(echo "$RANGE2_CLASS" | cut -d'-' -f2 | cut -d':' -f1 )"
			MINUTES_STOP_SEC_CLASS="$(echo "$RANGE2_CLASS" | cut -d':' -f3 )"
		else
			HOUR_START_SEC_CLASS="ALL"
			MINUTES_START_SEC_CLASS="ALL"
			HOUR_STOP_SEC_CLASS="ALL"
			MINUTES_STOP_SEC_CLASS="ALL"
		
		fi
		LIMITCLASS="$CL-$DAYS_CLASS-$HOUR_START_CLASS-$MINUTES_START_CLASS-$HOUR_STOP_CLASS-$MINUTES_STOP_CLASS"
		LIMITCLASS="$LIMITCLASS-$HOUR_START_SEC_CLASS-$MINUTES_START_SEC_CLASS-$HOUR_STOP_SEC_CLASS-$MINUTES_STOP_SEC_CLASS"
		LIMITCLASS="$LIMITCLASS-$HOURS_DAY_CLASS-$HOURS_MONTH_CLASS-$MB_DAY_CLASS-$MB_MONTH_CLASS-$L_ALL"
		eval LIMITCLASS$CL="\$LIMITCLASS"
		DAYS_CLASS=""
		MB_DAY_CLASS=""
		MB_MONTH_CLASS=""
		HOURS_DAY_CLASS=""
		HOURS_MONTH_CLASS=""
		HOUR_START_CLASS=""
		MINUTES_START_CLASS=""
		HOUR_STOP_CLASS=""
		MINUTES_STOP_CLASS=""
		HOUR_START_SEC_CLASS=""
		MINUTES_START_SEC_CLASS=""
		HOUR_STOP_SEC_CLASS=""
		MINUTES_STOP_SEC_CLASS=""
	done
}

limitclass () {
	CL="$1"
	if [ -n "$(cat $C_CLASSES_DIR/$CL/Days)" ];then
		for CRON_DAYS in "$L_MONDAY 1" "$L_TUESDAY 2" "$L_WEDNESDAY 3" "$L_THURSDAY 4" "$L_FRIDAY 5" "$L_SATURDAY 6" "$L_SUNDAY 0";do
		set -- $CRON_DAYS
			if [ -n "$(cat $C_CLASSES_DIR/$CL/Days | grep "$2")" ];then
				DC="$DC $1, "
			fi
		done
		DC=$(echo -e "$DC" | sed 's/, $//' | sed 's/\\//g' | sed 's/^[ \t]*//' | sed  's/[ \t]*$//')
	else
		DC="$L_ALL"
	fi
	MDC="$(cat $C_CLASSES_DIR/$CL/MBDay)"
	MMC="$(cat $C_CLASSES_DIR/$CL/MBMonth)"
	HDC="$(cat $C_CLASSES_DIR/$CL/HoursDay)"
	HMC="$(cat $C_CLASSES_DIR/$CL/HoursMonth)"
	RANGE1_CLASS="$(cat $C_CLASSES_DIR/$CL/Range1)"
	if [ -n "$RANGE1_CLASS" ];then
		RANGE=$(echo "$RANGE1_CLASS")
		RANGE2_CLASS="$(cat $C_CLASSES_DIR/$CL/Range2)"
		if [ -n "$RANGE2_CLASS" ];then
			RANGE="$RANGE&nbsp;&nbsp;&nbsp;$(cat $C_CLASSES_DIR/$CL/Range2)"			
		fi
	else
		RANGE="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp"
	fi
}

valrandom () {
	MATRICE="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	VALRANDOM=""
	while [ "${nvar:=1}" -le "$1" ];do
		VALRANDOM="$VALRANDOM${MATRICE:$(($RANDOM%${#MATRICE})):1}"
		let nvar+=1
	done
}



