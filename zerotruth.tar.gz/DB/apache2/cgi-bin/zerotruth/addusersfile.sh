#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$C_MULTI_USERS" && "$UTENTEC" != "$C_ADMIN" ]];then
	return_page "index.sh"
	exit
fi
if [ -n "$DELETE_FILE" ];then
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/fileusers.txt"
fi
if [ -n "$ADDUSERS" ];then
	NUM_USERS=$(cat $C_ZT_DIR/tmp/fileusers.txt | sed '/^$/d' | wc -l)
	CONTROL_NUM="yes"
	DAYS=$(date +%w)
	ORAS=$(date +%H)
	MINS=$(date +%M)
	ORAMIN=$ORAS$MINS
	ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
	echo "<div id=\"ticket\">"
	NC=1
	NS=1
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_ADDUSERS($L_FROM_FILE) $NUM_USERS $L_CLASS $CLASS"zzz
	fi
	for NUSER in $(seq 1 $NUM_USERS);do
		CONTROLERROR=""
		CONTROLADD=""
		USERDAYS=""
		RIGA="$(cat $C_ZT_DIR/tmp/fileusers.txt | sed -n "${NUSER}p")"
		source $C_ZT_DIR/language/$LANGUAGE/$LANGUAGE.sh
		USERNAME="$(echo "$RIGA" | cut -d',' -f1 | sed 's/[^[:alnum:]]//g' | tr A-Z a-z)"
		if [ -z "$USERNAME" ];then
			MATRICE="abcdefghijklmnopqrstuvwxyz"
			while [ "${b:=1}" -le $C_LENGH_USERNAME ]
			do
				USERNAME="$USERNAME${MATRICE:$(($RANDOM%${#MATRICE})):1}"
				let b+=1
			done
		fi
		b=1
		PASSWORD="$(echo "$RIGA" | cut -d',' -f2 | sed 's/[^[:alnum:]]//g')"
		if [ -z "$PASSWORD" ];then
			MATRICE="abcdefghijkmnpqrstuvwxyzABCDEFGHIJKMNPQRSTUVWXYZ23456789"
			while [ "${a:=1}" -le $C_LENGH_PASSWORD ]
			do
				PASSWORD="$PASSWORD${MATRICE:$(($RANDOM%${#MATRICE})):1}"
				let a+=1
			done
		fi
		a=1
		NAME="$(echo "$RIGA" | cut -d',' -f3)"
		NAME_PRINT="$NAME"
		LAST_NAME="$(echo "$RIGA" | cut -d',' -f4)"
		LAST_NAME_PRINT="$LAST_NAME"
		EMAIL="$(echo "$RIGA" | cut -d',' -f5)"
		PHONE="$(echo "$RIGA" | cut -d',' -f6)"
		ROOM="$(echo "$RIGA" | cut -d',' -f7)"
		PASSWORD_ORI="$PASSWORD"
		if [ -z "$MAXDAYS" ];then
			if [[ -z $DAY_EXPIRE || -z $MONTH_EXPIRE || -z $YEAR_EXPIRE ]];then
				DAY_EXPIRE="31"
				MONTH_EXPIRE="12"
				YEAR_EXPIRE="2037"
			else
				[ $DAY_EXPIRE -lt 10 ] && DAY_EXPIRE="0$DAY_EXPIRE"
				[ $MONTH_EXPIRE -lt 10 ] && MONTH_EXPIRE="0$MONTH_EXPIRE"
			fi
		else
			YEAR_EXPIRE=$(date +%Y --date="+$MAXDAYS days")
			MONTH_EXPIRE=$(date +%m --date="+$MAXDAYS days")
			DAY_EXPIRE=$(date +%d --date="+$MAXDAYS days")
			MAXDAYS=""
		fi
		SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
		TODAY=$(dateDiff -d "1970-01-01" "$(date +%Y)-$(date +%m)-$(date +%d)")
		ldap_add_people
		if [ "$CONTROLADD" != "no" ];then
			ldap_add_radius
			if [ "$CONTROLADD" == "no" ]; then
				/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
				$C_ZT_BIN_DIR/zt "Aggiungi" "$USERNAME" "$C_ZT_DIR/tmp/errorusersfile"
				NUMUSERERROR=$(($NUMUSERERROR+1))
			fi
		else
			$C_ZT_BIN_DIR/zt "Aggiungi" "$USERNAME" "$C_ZT_DIR/tmp/errorusersfile"
			NUMUSERERROR=$(($NUMUSERERROR+1))
		fi
		if [ -z "$CONTROLNO" ];then
			if [ -n "$CONTROLPASSLOCK" ];then
				DATA="dn: cn=$USERNAME,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			fi
			$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
			$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
			$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE"
			source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
			limituser "$USERNAME"
			if [ -n "$MAXDAYS" ];then
				EXP="$MAXDAYS $L_DAYS"
			else
				if [ $SHADOWEXPIRE == 24836 ];then
					EXP=$L_NO_LIMIT
				else
					if [ "$C_FORM_DATE" == "ita" ];then
						EXP=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%d/%m/%Y)
					else
						EXP=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y/%m/%d)
					fi
				fi
			fi
			if [ "$C_FORM_DATE" == "ita" ];then
				DATE_CREATED=$(date +%d/%m/%Y)
			else
				DATE_CREATED=$(date +%Y/%m/%d)
			fi
			FREETIME=$(cat $C_ACCT_DIR/classes/$CLASS/FreeTime)
			if [[ -n "$CREDITO" || -n "$FREETIME" ]];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USERNAME"
				[[ -z "$CREDITO" && -n "$FREETIME" ]] && CREDITO="freetime"
				$C_ZT_BIN_DIR/zt "Salva" "$CREDITO" "$C_ACCT_DIR/credits/$USERNAME/Credit"
				if [ -z "$FREETIME" ];then
					CREDITO=$(echo "$CREDITO" | awk '{printf("%.2f\n", $0)}')
					$C_ZT_BIN_DIR/zt "Aggiungi" "$USERNAME+$(date '+%b %d, %Y')+$( date '+%T')+$CREDITO+cash" "$C_ZT_LOG_DIR/pp/payments"
				fi
			fi
		fi
		if [ -z "$C_TICKETS_PAGE" ];then
			N_TICKETS_PAGE=4
		else
			N_TICKETS_PAGE=$(($C_TICKETS_PAGE/2+1))
		fi
		if [ -n "$PRINT" ];then
			[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
			[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
			if [ $NUSER == 1 ];then
				source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
				echo "<table align=\"center\"><tr><td align=\"center\"><font color=\"blue\" size=\"5\">$L_USER_TICKET</font></td></tr>
				<tr><td align=\"center\"><p><img src=\"/images/barra.png\" alt=\"barra\"></td></tr></table><br>&nbsp;<br>"
				echo "<table width=\"920\" border=\"0\" align=\"center\">"
			fi
			source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
			INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
			if [ $NC == 2 ];then
				echo "</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;<br>"
			else
				echo "<tr><td>&nbsp;<br>"
			fi
			echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\" align=\"center\">
			<tr>
			<td colspan=\"2\"><img src=\"/images/imguser.png\" WIDTH=\"350px\" alt=\"imguser\"></td>
			</tr>
			<tr><td>
			<table width=\"350\" style=\"font: ${C_FONT_TICKET}px "Trebuchet MS",Arial,sans-serif;\">"
			if [ -n "$C_PRINT_QR" ];then
				$C_ZT_BIN_DIR/zt "QrCode" "$USERNAME" "$PASSWORD_ORI"
				echo "<tr><td colspan =\"2\" align=\"center\"><img src=\"$APACHE_BASEDIR/images/qrcode/${USERNAME}.png\"></td></tr>
				<tr><td colspan =\"2\">&nbsp;</td></tr>"
			fi
			echo "<tr><td width=\"130px\"><b>&nbsp;$L_USERNAME: </b></td>
			<td><b>$USERNAME</b></td></tr>
			<tr><td><b>&nbsp;$L_PASSWORD: </b></td>
			<td><b>$PASSWORD_ORI</b></td></tr>"
			if [ -n "$C_PRINT_NAME" ];then
				if [ -n "$NAME_PRINT" ];then
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME_PRINT | sed '/\\/s///g')</td></tr>"
				else
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$L_ANONYMOUS</td></tr>"
				
				fi
				if [ -n "$LAST_NAME_PRINT" ];then
					echo "<tr><td>&nbsp;$L_LAST_NAME: </td><td>$( echo $LAST_NAME_PRINT | sed '/\\/s///g')</td></tr>"
				else
					echo "<tr><td>&nbsp;$L_LAST_NAME: </td><td>$L_ANONYMOUS</td></tr>"
				fi
			else
				if [ -n "$NAME_PRINT" ];then
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME_PRINT | sed '/\\/s///g')</td></tr>"
				fi
				if [ -n "$LAST_NAME_PRINT" ];then
					echo "<tr><td>&nbsp;$L_LAST_NAME: </td><td>$(echo $LAST_NAME_PRINT | sed '/\\/s///g')</td></tr>"
				fi
			fi
			if [ -z "$CONTROLADD" ];then
				if [ -n "$ROOM" ];then
					echo "<tr><td>&nbsp;$C_ROOM_NAME: </td><td>$ROOM</td></tr>"
				fi
				if [ -n "$C_PRINT_CLASS" ];then
					echo "<tr><td>&nbsp;$L_CLASS: </td><td>$CLASS</td></tr>"
				fi
				if [ -n "$C_PRINT_CREATED" ];then
					echo "<tr><td>&nbsp;$L_CREATED: </td><td>$DATE_CREATED</td></tr>"
				fi
				if [ -n "$C_PRINT_EXP" ];then
					echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXP</td></tr>"
				else
					if [ "$EXP" != "$L_NO_LIMIT" ];then
						echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXP</td></tr>"
					fi
				fi
				if [[ -n "$USERDAYS" && "$USERDAYS" != "$L_ALL" ]];then
					echo "<tr><td>&nbsp;$L_DAYS: </td><td>$USERDAYS</td></tr>"
				fi
				if [ "$USERTIME" != "$L_ALL" ];then
					echo "<tr><td>&nbsp;$L_TIME: </td><td>$USERTIME</td></tr>"
				fi
				if [ -n "$USERHOURSDAY" ];then
					echo "<tr><td>&nbsp;$L_DMAX_HOURS: </td><td>$USERHOURSDAY</td></tr>"
				fi
				if [ -n "$USERHOURSMONTH" ];then
					echo "<tr><td>&nbsp;$L_MMAX_HOURS: </td><td>$USERHOURSMONTH</td></tr>"
				fi
				if [ -n "$USERMBDAY" ];then
					echo "<tr><td>&nbsp;$L_DMAX_MB: </td><td>$USERMBDAY</td></tr>"
				fi
				if [ -n "$MBMONTH" ];then
					echo "<tr><td>&nbsp;$L_MMAX_MB: </td><td>$MBMONTH</td></tr>"
				fi
				echo "</table>"
				if [ -n "$INFO_TICKET" ];then
					echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
					<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
				fi
			else
				echo "<tr><td colspan=\"2\"><br>&nbsp;<font color=\"red\">$L_PROBLEM_INSERTING</font></td></tr></table>"
			fi
			echo "</table><br>&nbsp;<br>"
			if [ $NC == 1 ];then
				NC=2
			else
				echo "</td></tr>"
				NC=1
				NS=$(($NS+1))
				if [ $NS == $N_TICKETS_PAGE ];then
					echo "</table><p><hr style=\"page-break-after:always\"><p><table width=\"920\" border=\"0\">"
					NS=1
				fi
			fi
			if [ $NUSER == $NUM_USERS ];then
				echo "</table><p>"
			fi
			source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		fi
	done
	if [ -n "$PRINT" ];then
		echo "</div><p>&nbsp;<br>&nbsp;<br>"
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<p><input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_TICKETS\" onClick=\"StampaTicket()\">
		<br>&nbsp;<br>"
	fi
	[ -z "$NUMUSERERROR" ] && NUMUSERERROR=0
	NUM_USERS=$(($NUSER-$NUMUSERERROR))
	if [ -n "$C_NOT_SMS_MULTI_USERS" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_CREATED_MULTI $NUM_USERS $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN" "credito"
	fi
	if [ -n "$C_NOT_EMAIL_MULTI_USERS" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_CREATED_MULTI $NUM_USERS\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_CREATED_MULTI" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
	if [ -z "$PRINT" ];then
		echo "<br>&nbsp;<br>"
		if [ -f $C_ZT_DIR/tmp/errorusersfile ];then
			RIGHE=$(cat $C_ZT_DIR/tmp/errorusersfile | wc -l )
				for I in $(seq 1 $RIGHE);do
					USERERR="$(cat $C_ZT_DIR/tmp/errorusersfile | /bin/sed -n "${I}p")"
					echo "<font color=\"blue\">User $USERERR</font>&nbsp;&nbsp;<font color=\"red\">$L_PROBLEM_INSERTING</font><br>"
				done
			echo "<br>&nbsp;<br>"
		fi
		$C_ZT_BIN_DIR/zt "ControlOk" "$L_REGISTERED_USERS: $NUM_USERS" "addusersfile.sh"
		./footer.sh
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/fileusers.txt"
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/errorusersfile"
	exit
fi
limitclassjs
echo "<br><font color=\"#0000FF\" size=\"5\">$L_ADDUSERS</font><br>
<p><img src=\"/images/barra.png\" alt=\"barra\"></p>"
if ! [ -f $C_ZT_DIR/tmp/fileusers.txt ];then
	$C_ZT_BIN_DIR/zt "PermCartella" "777" "$ZT_DIR/tmp"
	echo "<p><font color=\"#0000FF\" size=\"3\">$L_INFO_FILE</font><p>
	<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
	<input type=\"hidden\" name=\"config\" value=\"Fileusers\">
	<input type=\"hidden\" name=FileName value=\"fileusers.txt\">
	<input type=\"file\" name=\"file\" size=\"40\">
	<p><img src=\"/images/barra.png\" alt=\"barra\" alt=\"barra\"><p>
	<input type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_FILE\">
	</form>"
	./footer.sh
	exit
else
	N_USERS=$(cat $C_ZT_DIR/tmp/fileusers.txt | sed '/^$/d' | wc -l)
	echo "<font color=\"blue\">N. users: $N_USERS</font>"
fi

echo "<form name=\"ADD_USERS\" action=\"addusersfile.sh\" method=\"POST\">
<br>&nbsp;<br><p><table WIDTH=\"790px\" border=\"0\" cellpadding=\"0px\">
<tr><td with=\"\100px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\">
</td><td width=\"100px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td></tr>"
if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || [[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td height=\"30\">$C_ROOM_NAME:</td><td><input type=\"text\" class=\"room1\" name=\"ROOM\" value=\"\"></td>"
	CONTROLROOM="yes"
fi
if [ -n "$C_CLASS" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$CONTROLROOM" ];then
		echo "<td height=\"30\">$L_CLASS:</td><td colspan=\"3\">"
	else
		echo "<td colspan=\"2\" align=\"right\" cellpadding=\"0\">$L_CLASS:"
	fi
	echo "<select name=\"CLASS\" onchange=\"limitclass(this.options[this.selectedIndex].value, this.options[this.selectedIndex].id)\">"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		for CL in $(ls $C_CLASSES_DIR);do
			if [ $CL != "DEFAULT" ];then
				INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
				[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
				eval LIMITCLASS="\$LIMITCLASS$CL"
				echo "<option id=\"$LIMITCLASS-$INTCL\" name=\"NCLASS\" value=\"$CL\">$CL</option>"
			fi
		done
		CL="DEFAULT"
		eval LIMITCLASS="\$LIMITCLASS$CL"
		INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
		[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
		echo "<option id=\"$LIMITCLASS-$INTCL\" value=\"DEFAULT\" selected>DEFAULT</option></select>"
	else
		for CL in $(ls $C_CLASSES_DIR);do
			if [ -n "$(echo $C_CLASS_USER | grep "$CL")" ];then
				if [ $CL != "DEFAULT" ];then
				INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
				[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
					echo "<option id=\"$INTCL\" value=\"$CL\" selected>$CL</option>"
				else
					CONTROL_DEFAULT="ok"
				fi
			fi
		done
		if [ -n "$CONTROL_DEFAULT" ];then
			INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
			[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
			echo "<option id=\"$INTCL\" value=\"DEFAULT\" selected>DEFAULT</option>"
		fi
	fi
	echo "</select>
	</td><td>&nbsp;&nbsp;</td>"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<td height=\"30\" align=\"left\" colspan=\"2>\">"
	else
		echo "<td height=\"30\" align=\"left\" colspan=\"4>\">"
	fi
	echo "<div id=\"intclass\">Int: <font size=\"2\">$(cat $C_CLASSES_DIR/DEFAULT/InterfacesClass)</font></div>"
fi
if [ "$UTENTEC" == "$C_ADMIN" ];then
	echo "</td><td align=\"right\" colspan=\"2\" height=\"30\">$L_HIDDEN:
	<select name=\"HIDDEN\">
	<option value=\"yes\" selected>$L_YES</option>
	<option value=\"no\" selected>$L_NO</option>
	</select>"
else
	echo "<input type=\"hidden\" name=\"HIDDEN\" value=\"no\">"
fi
echo "</td></tr>"
YNOW=$(date +%Y)
YEND=$(($YNOW+10))
if [ -n "$C_EXPIRE" ] || [ "$UTENTEC" == "$C_ADMIN" ] ;then
	if [ "$C_FORM_DATE" == "ita" ];then
		echo "<tr><td height=\"30\">$L_EXPIRY:</td>
		<td><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\" selected>$L_DAY</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"YEAR_EXPIRE\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>"
	else
		echo "<tr><td height=\"30\">$L_EXPIRY:</td>
		<td><select name=\"YEAR_EXPIRE\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\" selected>$L_DAY</option></select></td>"
	fi
	echo "<td>&nbsp;&nbsp;</td>
	<td>$L_OR_DAYS:</td><td>
	<select name=\"MAXDAYS\">"
	for MD in $(seq 1 100);do
		echo "<option value=\"$MD\" selected>$MD</option>"
	done
	echo "<option value=\"\" selected></option></select>"
	CVAL="yes"
fi
if 	[ -n "$C_CREDIT" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$C_EXPIRE" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		echo "<tr><td height=\"30\">$L_CREDIT:</td><td colspan=\"8\">"
	else
		echo "<td height=\"30\" colspan=\"2\" align=\"right\">$L_CREDIT: "
	fi
	echo "<input type=\"text\" class=\"credit\" name=\"CREDITO\" value=\"\"></td>"
	CVAL="yes"
fi
[ -n "$CVAL" ] && echo "</td></tr>"
limitclass "DEFAULT"
echo "<tr><td height=\"30\">$L_LIMIT: </td><td colspan=\"4\">
$L_HOURS $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limithoursday\">"$HDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$L_HOURS $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limithoursmonth\">"$HMC"</div></td>
<td colspan=\"4\" align=\"right\">
MB $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limitmbday\">"$MDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	MB $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limitmbmonth\">"$MMC"</div></td>
</tr><tr>
<td height=\"30\">$L_DAYS:</td><td colspan=\"4\">
<div style=\"display: inline-block;\" id=\"limitdays\">"$DC"</div>
</td>
<td colspan=\"4\" align=\"right\">$L_TIME:
<div style=\"display: inline-block;\" id=\"limitrange\">"$RANGE"</div>
</td></tr>"
if [[ -n "$C_PRINT_TICKET" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<tr><td height=\"30\">$L_TICKET:</td><td colspan=\"4\">"
	echo "<input name=\"PRINT\" type=\"checkbox\" checked=\"checked\">
	<select name=\"LANGUAGE_PRINT\">"
	for LANG in $(ls -A ./language/);do
		if [ "$LANG" != "$C_LANGUAGE" ] && [ "$LANG" != "index.html" ];then
			LANG1=$LANG
			[ "$LANG" == "espanol" ] && LANG1="espa&ntilde;ol"
			[ "$LANG" == "portugues" ] && LANG1="portugu&ecirc;s"
			[ "$LANG" == "francais" ] && LANG1="fran&ccedil;ais"
			echo "<option value=\"$LANG\">$LANG1</option>"
		fi
	done
	LANGUAGE1=$C_LANGUAGE
	[ "$C_LANGUAGE" == "espanol" ] && LANGUAGE1="espa&ntilde;ol"
	[ "$C_LANGUAGE" == "portugues" ] && LANGUAGE1="portugu&ecirc;s"
	[ "$C_LANGUAGE" == "francais" ] && LANGUAGE1="fran&ccedil;ais"
	echo "<option value=\"$C_LANGUAGE\" selected=\"selected\">$LANGUAGE1</option></select></td>"
	CONTROLTICKET="ok"
fi
if [ -n "$CONTROLTICKET" ];then
	echo "<td colspan=\"4\" align=\"right\">$L_CREDIT_AS_PAYMENT:<input name=\"PAYMENT\" type=\"checkbox\">"
else
	echo "<tr><td height=\"30\">$L_CREDIT:</td><td colspan=\"5\">
	$L_CREDIT_AS_PAYMENT: <input name=\"PAYMENT\" type=\"checkbox\">"
fi
echo "</td></tr>"

echo "<tr><td>$L_INFO:</td><td colspan=\"8\">
<input type=text class=\"info\" name=\"INFO\" value=\"\"><br>&nbsp;<br></td></tr>
</table>
<img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
<input type=\"hidden\" name=\"ADDUSERS\" value=\"ok\">
<p><input type=\"submit\" name=\"SAVE\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
<form method=\"POST\" action=\"addusersfile.sh\">
<input type=\"submit\" name=\"DELETE_FILE\" class=\"bottonelineadue\" value=\"$L_DELETE_FILE\"></form>"
./footer
