#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$C_AR_FROM_TICKET" || -z "$C_USERS_FROM_TICKET" ]] && [ "$UTENTEC" != "$C_ADMIN" ];then
	return_page "index.sh"
	exit
fi

if [ -z "$PRINT" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_USERS_WAIT</font>"
	echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
fi
if [ -n "$LOCK" ];then
		wait 750
		RIGHE=$(cat $C_ZT_CONF_DIR/userswait | wc -l | awk '{print $1}' )
		for I in $(seq 1 $RIGHE);do
			USERSW="$(cat $C_ZT_CONF_DIR/userswait | /bin/sed -n "${I}p")"
			eval USERLOCK="\$$USERSW"
			if [ -n "$USERLOCK" ];then
				$C_ZT_BIN_DIR/zt "LockUserWait" "$USERSW" "$C_ZT_CONF_DIR/userswait"
			fi
		done
		return_page "userswait.sh"
		exit
	fi
	if [ -n "$UNLOCK" ];then
		wait 750
		RIGHE=$(cat $C_ZT_CONF_DIR/userswait | wc -l | awk '{print $1}')
		for I in $(seq 1 $RIGHE);do
			USERSW="$(cat $C_ZT_CONF_DIR/userswait | /bin/sed -n "${I}p" | cut -d'-' -f1)"
			eval USERLOCK="\$$USERSW"
			if [ -n "$USERLOCK" ];then
				$C_ZT_BIN_DIR/zt "UnlockUserWait" "$USERSW" "$C_ZT_CONF_DIR/userswait"
			fi
		done
		return_page "userswait.sh"
		exit
	fi
	if [ -n "$DELETE" ];then
		wait 750
		RIGHE=$(cat $C_ZT_CONF_DIR/userswait | wc -l | awk '{print $1}')
		for I in $(seq 1 $RIGHE);do
			USERSW="$(cat $C_ZT_CONF_DIR/userswait | /bin/sed -n "${I}p" | cut -d'-' -f1)"
			eval USERDEL="\$$USERSW"
			if [ -n "$USERDEL" ];then
				$C_ZT_BIN_DIR/zt "DeleteUserWait" "$USERSW" "$C_ZT_CONF_DIR/userswait"
			fi
		done
		$C_ZT_BIN_DIR/zt "DeleteUserWait" "END" "$C_ZT_CONF_DIR/userswait"
		return_page "userswait.sh"
		exit
	fi

if [ -n "$PRINT" ];then
	echo "<div id=\"ticket\">"
	NC=1
	NS=1
	NUM_USERS=$(cat $C_ZT_CONF_DIR/userswait | wc -l | awk '{print $1}')
	for NUSER in $(seq 1 $NUM_USERS);do
		USERSW="$(cat $C_ZT_CONF_DIR/userswait | /bin/sed -n "${NUSER}p" | cut -d'-' -f1)"
		eval USERPRINT="\$$USERSW"
		if [ -n "$USERPRINT" ];then
			if [ $NUSER == 1 ];then
				source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
				echo "<table align=\"center\"><tr><td align=\"center\"><font color=\"blue\" size=\"5\"><br>$L_USER_TICKET</font></td></tr>
				<tr><td align=\"center\"><p><img src=\"/images/barra.png\" alt=\"barra\"></td></tr></table><br>&nbsp;<br>"
				echo "<table width=\"920\" border=\"0\" align=\"center\">"
			fi
			if [ $NC == 2 ];then
				echo "</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;<br>"
			else
				echo "<tr><td>&nbsp;<br>"
			fi
			echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\" align=\"center\">
			<tr>
			<td><img src=\"/images/imguser.png\" WIDTH=\"350px\" alt=\"imguser\"></td>
			</tr>
			<tr><td>
			<table width=\"350\">"
			echo "<tr><td>&nbsp;</td></tr>"
			echo "<tr><td align=\"center\">$L_USERNAME:<br><b>$USERSW</b></td></tr>"
			echo "<tr><td >&nbsp;</td></tr>"
			if [ -n "$INFO_TICKET" ];then
				echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
				<tr><td style=\"font: 11px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
			fi
			echo "</table></table>"

			if [ $NC == 1 ];then
				NC=2
			else
				echo "</td></tr>"
				NC=1
				NS=$(($NS+1))
				if [ $NS == 8 ];then
					echo "</table><p><hr style=\"page-break-after:always\"><p><table width=\"920\" border=\"0\">"
					NS=1
				fi
			fi

		fi
	done
	echo "</table><p>"
	if [ $(expr $NUM_USERS % 2) -eq 0 ];then
		echo ""
	else
		echo "</table>"
	fi
	echo "</div><p>&nbsp;<br>&nbsp;<br>"
	source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
	echo "<p><input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_TICKETS\" onClick=\"StampaTicket()\">
	<br>&nbsp;<br>"
	./footer.sh
	exit
fi

SEL='ALL'
[[ -z "$SELECT" || "$SELECT" == "ALL" ]] && SEL='NONE'
echo "<table class=\"tabellain\" width=\"960\" border=\"1\">
<tr>
<td width=\"20\" class=\"intesta\">N.</td>
<td width=\"20\" class=\"intesta\"><a href=\"userswait.sh?SELECT=$SEL\">C.</a></td>
<td width=\"200\" class=\"intesta\">$L_USERNAME</td>
<td width=\"20\" class=\"intesta\">N.</td>
<td width=\"20\" class=\"intesta\"><a href=\"userswait.sh?SELECT=$SEL\">C.</a></td>
<td width=\"200\" class=\"intesta\">$L_USERNAME</td>
<td width=\"20\" class=\"intesta\">N.</td>
<td width=\"20\" class=\"intesta\"><a href=\"userswait.sh?SELECT=$SEL\">C.</a></td>
<td width=\"200\" class=\"intesta\">$L_USERNAME</td>
<td width=\"20\" class=\"intesta\">N.</td>
<td width=\"20\" class=\"intesta\"><a href=\"userswait.sh?SELECT=$SEL\">C.</a></td>
<td width=\"200\" class=\"intesta\">$L_USERNAME</td>
</tr><tr>"
RIGHE=$(cat $C_ZT_CONF_DIR/userswait | wc -l | awk '{print $1}')
if [ "$RIGHE" -gt 0 ];then
	NR=0
	NG=1
	echo "<form method=\"POST\" action=\"userswait.sh\">"
	for I in $(seq 1 $RIGHE);do
		USERSW="$(cat $C_ZT_CONF_DIR/userswait | /bin/sed -n "${I}p")"
		if [ -n "$(echo $USERSW | cut -sd'-' -f2)" ];then
			USERSW="$(echo $USERSW | cut -d'-' -f1)"
			BLOCK="YES"
		else
			BLOCK="no"
		fi
		echo "<td>$I</td><td>"
		if [[ "$SELECT" == "ALL" || -z "$SELECT" ]];then
			echo "<input name=\"$USERSW\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"$USERSW\" type=\"checkbox\">"
		fi
		echo "</td><td>"
		if [ "$BLOCK" == "YES" ];then
			echo "&nbsp;<img src=\"/images/lock.png\">&nbsp;&nbsp;"
		fi
		echo "$USERSW</td>"
		NR=$(($NR+1))
		if [ "$NR" == 4 ];then
			NG=$(($NG+1))
			if [ "$NG" == "2" ];then
				BGC="white"
				NG=0
			else
				BGC="#f3f3f3"
			fi
			echo "</tr><tr bgcolor=\"$BGC\">"
			NR=0
		fi
	done
	if [[ "$NR" != "4" && "$NR" != "0" ]];then
		NRR=$((4 - $NR))
		for I in $(seq 1 $NRR);do
			echo "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>"
		done
		echo "</tr>"
	fi
fi
echo "</table>"
echo "<br>&nbsp;<br>
<table width=\"450px\"><tr>
	<td><input type=\"submit\" name=\"LOCK\" class=\"bottone\" value=\"$L_LOCK\"></td>
	<td><input type=\"submit\" name=\"UNLOCK\" class=\"bottone\" value=\"$L_UNLOCK\"></td>
	<td><input type=\"submit\" name=\"DELETE\" class=\"bottone\" value=\"$L_DELETE\"
	onClick=\"javascript:return confirm('$L_ALERT_SURE?');\"></td>
	<td><input type=\"submit\" name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT\"></form></td>
	<td><form action=\"adduserstickets.sh\" method=\"POST\">
	<input type=\"submit\"  class=\"bottone\" value=\"$L_ADDUSERS\"></form></td>
</tr></table>
<br>&nbsp;<br>"
./footer.sh
