#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

echo "Content-type: text/html"
echo ""


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh


if [ -z "$QUERY_STRING" ];then
	exit
else
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi


if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
	[ ! -d $C_ZT_CONF_DIR/RemoteClients/$CLIENT ] && exit
	PASS_CLIENT=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
	[ "$PASS" != "$PASS_CLIENT" ] && exit
	if [ "$ACTION" == "ControlLink" ];then
		echo "ok"
		exit
	fi
	if [ "$ACTION" == "ConnectUser" ];then
		if [ -n "$USERNAME" ];then
			if [ "$CONNECT" == "yes" ];then
				VAL="$CLIENT-$IP"
				SESSIONS=$(ls $C_ACCT_DIR/entries/$USERNAME/sessions/ | wc -l | awk '{print $1}')
				SESSIONS=$(($SESSIONS+1))
				DATA="dn: uid=$USERNAME,ou=People,$C_LDAPBASE\nloginRemote: $CLIENT-$IP\nsessions: $SESSIONS"
			else
				DATA="dn: uid=$USERNAME,ou=People,$C_LDAPBASE\nloginRemote: ?"
			fi
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		fi
		exit
	fi
	if [ "$ACTION" == "ControlClass" ];then
		RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$OPTION radiusUserCategory)
		CLASS=$( echo "$RADIUS" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
		[ "$CLASS" == "" ] && CLASS="DEFAULT"
		echo "$CLASS"
		exit
	fi
fi

if [[ "$C_CP_LOCAL_TYPE" == "Client" && "$CLIENT" == "$C_CP_LOCAL_NAME" ]];then
	[[ -z "$PASS" || -z "$C_CP_REMOTE_PASSWORD" || "$PASS" != "$C_CP_REMOTE_PASSWORD" || "$C_CP_LOCAL_NAME" != "$CLIENT" ]] && exit

	if [ "$ACTION" == "ControlAll" ];then
			if [ "$C_ACTIVE_CP" == "on" ];then
			CONTROL="ok ok"
		else
			CONTROL="ok no"
		fi
		if [ "$C_AUTO_REGISTER" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ "$C_SHAPER" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ "$C_HAVP" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ "$C_SQUID" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ "$C_DANSGUARDIAN" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ "$C_CP_LOCAL_AUTO" == "on" ];then
			CONTROL="$CONTROL ok"
		else
			CONTROL="$CONTROL no"
		fi
		if [ -f $C_ZT_CONF_DIR/RemoteSync ];then
			CONTROL="$CONTROL $(cat $C_ZT_CONF_DIR/RemoteSync)"
		else
			CONTROL="$CONTROL no"
		fi
		if [ -f $C_ZT_CONF_DIR/RemoteKey/controlkey ];then
			CONTROLKEY=$(cat $C_ZT_CONF_DIR/RemoteKey/controlkey)
			CONTROL="$CONTROL $CONTROLKEY"
		else
			CONTROL="$CONTROL $RANDOM"
		fi
		echo "$CONTROL"
		exit
	fi
	if [ "$ACTION" == "LockUser" ];then
		$C_ZT_BIN_DIR/zt "LockUserClient" "$USER"
		exit
	fi
	if [ "$ACTION" == "UnlockUser" ];then
		$C_ZT_BIN_DIR/zt "UnlockUserClient" "$USER"
		exit
	fi

	if [ "$ACTION" == "LockAll" ];then
		$C_ZT_BIN_DIR/zt "LockAllClient"
		exit
	fi
	if [ "$ACTION" == "UnlockAll" ];then
		$C_ZT_BIN_DIR/zt "UnlockAllClient"
		exit
	fi

	if [ "$ACTION" == "DisconnectUser" ];then
		$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "NOREMOTE"
		exit
	fi
	if [ "$ACTION" == "ActiveCp" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_ACTIVE_CP" "on"
		$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-on" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
		exit
	fi
	if [ "$ACTION" == "DisactiveCp" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_ACTIVE_CP" ""
		$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-off" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
		exit
	fi
	if [ "$ACTION" == "DisactiveAr" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AUTO_REGISTER" ""
		$C_ZT_BIN_DIR/zt "Salva" "no" "$C_CP_DIR/Auth/Custom/Registered"
		echo "ok"
		exit
	fi
	if [ "$ACTION" == "ActiveAr" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AUTO_REGISTER" "on"
		$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Registered"
		echo "ok"
		exit
	fi
	if [ "$ACTION" == "ActiveShaper" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SHAPER" "on"
		$C_ZT_BIN_DIR/zt "Shaper" "on"
#		fi
#		NAME_CLASS=$(echo $OPTION | cut -d'-' -f1)
	#	MBITS=$(echo $OPTION | cut -d'-' -f2)
	#	$C_ZT_BIN_DIR/zt "RemoteClass" "$NAME_CLASS" "$MBITS" "no"
		echo "ok"
		exit
	fi

	if [ "$ACTION" == "DisactiveShaper" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SHAPER" ""
		$C_ZT_BIN_DIR/zt "Shaper" "off"
		echo "ok"
		exit
	fi

	if [ "$ACTION" == "ActiveAuto" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_AUTO" "on"
		exit
	fi

	if [ "$ACTION" == "DisactiveAuto" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_AUTO" ""
		exit
	fi

	if [ "$ACTION" == "ActiveHAVP" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_HAVP" "on"
		if [ -n "$C_SQUID" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "on-on"
		else
			$C_ZT_BIN_DIR/zt "Proxy" "-on"
		fi
		echo "ok"
		exit
	fi
	if [ "$ACTION" == "DisactiveHAVP" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_HAVP" ""
		if [ -n "$C_SQUID" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "on-"
		else
			$C_ZT_BIN_DIR/zt "Proxy"
		fi
		echo "ok"
		exit
	fi

	if [ "$ACTION" == "ActiveSquid" ];then
		if [ -f $C_ZT_PROXY_DIR/sbin/squid ];then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SQUID" "on"
			if [ -n "$C_HAVP" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "on-on"
			else
				$C_ZT_BIN_DIR/zt "Proxy" "on-"
			fi
			echo "ok"
			exit
		fi
	fi
	if [ "$ACTION" == "DisactiveSquid" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SQUID" ""
		if [ -n "$C_HAVP" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "-on"
		else
			$C_ZT_BIN_DIR/zt "Proxy"
		fi
		echo "ok"
		exit
	fi

	if [ "$ACTION" == "ActiveDS" ];then
		if [ -f $C_ZT_PROXY_DIR/sbin/dansguardian ];then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_DANSGUARDIAN" "on"
			[ -n "$C_SQUID" ] && VAL="on-"
			[ -n "$C_HAVP" ] && VAL="${VAL}-on"
			VAL="$(echo "$VAL" | sed 's/--/-/g')"
			$C_ZT_BIN_DIR/zt "Proxy" "$VAL"
		fi
		echo "ok"
		exit
	fi
	if [ "$ACTION" == "DisactiveDS" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_DANSGUARDIAN" ""
		[ -n "$C_SQUID" ] && VAL="on-"
		[ -n "$C_HAVP" ] && VAL="${VAL}-on"
		VAL="$(echo "$VAL" | sed 's/--/-/g')"
		$C_ZT_BIN_DIR/zt "Proxy" "$VAL"
		echo "ok"
		exit
	fi

	if [ "$ACTION" == "UpdateLDAP" ];then
		$C_ZT_BIN_DIR/zt "GetRemoteLDAP"
		exit
	fi

	if [ "$ACTION" == "AddUser" ];then
		$C_ZT_BIN_DIR/zt "GetRemoteUser" "$USER"
		exit
	fi

	if [ "$ACTION" == "UpdateUser" ];then
		$C_ZT_BIN_DIR/zt "GetRemoteUser" "$USER"
		exit
	fi
	if [ "$ACTION" == "DeleteUser" ];then
		deleteuser "$USER"
		exit
	fi

	if [ "$ACTION" == "GetCredit" ];then
		if [ ! -d $C_ACCT_DIR/credits ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits"
		fi
		$C_ZT_BIN_DIR/zt "GetRemoteCredits"
		exit
	fi

	if [ "$ACTION" == "DeleteUserLdap" ];then
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" > /dev/null
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERNAME,ou=Radius,$C_LDAPBASE" > /dev/null
		$C_ZT_BIN_DIR/zt "DelK5" "$USERP"
		exit
	fi

	if [ "$ACTION" == "DataSync" ];then
		if [ "$C_FORM_DATE" == "ita" ];then
			TODAY=$(date +%d/%m/%Y-%H:%M:%S)
		else
			TODAY=$(date +%Y/%m/%d-%H:%M:%S)
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$TODAY" "$C_ZT_CONF_DIR/RemoteSync"
		exit
	fi

	if [ "$ACTION" == "DeleteKey" ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/RemoteKey/*"
		exit
	fi

	if [ "$ACTION" == "ControlKey" ];then
		if [ -f $C_ZT_CONF_DIR/RemoteKey/ControlKey ];then
			echo "$(cat $C_ZT_CONF_DIR/RemoteKey/controlkey)"
		else
			echo "$RANDOM"
		fi
		exit
	fi

	if [ "$ACTION" == "GetKey" ];then
		if [ ! -d $C_ZT_CONF_DIR/RemoteKey ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/RemoteKey"
		fi
		$C_ZT_BIN_DIR/zt "Aggiungi" "$LINE" "$C_ZT_CONF_DIR/RemoteKey/privatekey.pem"
		exit
	fi

	if [ "$ACTION" == "ModifyKey" ];then
		$C_ZT_BIN_DIR/zt "ModifyKey"
		exit
	fi

	if [ "$ACTION" == "GetControlKey" ];then
		$C_ZT_BIN_DIR/zt "Salva" "$CONTROLKEY" "$C_ZT_CONF_DIR/RemoteKey/controlkey"
		exit
	fi
	if [ "$ACTION" == "GetClass" ];then
		$C_ZT_BIN_DIR/zt "GetRemoteClass"
		if [ -n "$C_SHAPER" ];then
			$C_ZT_BIN_DIR/zt "Shaper" "off"
			$C_ZT_BIN_DIR/zt "Shaper" "on"
		fi
		exit
	fi
fi

exit

