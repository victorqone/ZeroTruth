#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [ "$C_FORM_DATE" == "ita" ];then
	TODAYN=$(date +%d/%m/%Y)
else
	TODAYN=$(date +%Y/%m/%d)
fi
ldap_search_people "uid=$USERNAME"
ldap_search_radius "$USERNAME"
[ -z "$EMAIL" ] && EMAIL="$L_NOT_ADDED"
[ -z "$PHONE" ] && PHONE="$L_NOT_ADDED"
CREATED_YEAR=$(echo "$CREATED" | cut -c 1-4 )
CREATED_MONTH=$(echo "$CREATED" | cut -c 5-6 )
CREATED_DAY=$(echo "$CREATED" | cut -c 7-8 )
if [ "$C_FORM_DATE" == "ita" ];then
	DATE_CREATED="$CREATED_DAY/$CREATED_MONTH/$CREATED_YEAR"
else
	DATE_CREATED="$CREATED_YEAR/$CREATED_MONTH/$CREATED_DAY"
fi
if [ "$VALIDITY" == "yes" ];then
	EXPIRED="$L_NO"
else
	EXPIRED="$L_YES"
fi
if [ -n "$MAXDAYS" ];then
		EXPIRE="$MAXDAYS $L_DAYS"
else
	if [ "$EXPIRE" == "24836" ];then
		EXPIRE="$L_NO_LIMIT"
	else
		if [ "$C_FORM_DATE" == "ita" ];then
			EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%d/%m/%Y)
		else
			EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%Y/%m/%d)
		fi
	fi
fi
if [ -n "$(echo $PASSWORD | cut -sd"-" -f2)" ];then
	BLOCKED="$L_YES"
else
	BLOCKED="$L_NO"
fi
PASSWORD=$( echo $PASSWORD | cut -d'-' -f1)
if [ -z $(cat $C_CLASSES_DIR/$CLASS/CostH) ];then
	COST_HOUR="$L_NOPAID"
else
	COST_HOUR=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/CostH)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	[ -z $(echo $COST_HOUR | cut -sd'.' -f1) ] && COST_HOUR="0$COST_HOUR"
	COST_HOUR="$COST_HOUR $C_CURRENCY"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/CostM) ];then
	COST_MB="$L_NOPAID"
else
	COST_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/CostM)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	[ -z $(echo $COST_MB | cut -sd'.' -f1) ] && COST_MB="0$COST_MB"
	COST_MB="$COST_MB $C_CURRENCY"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/MB) ];then
	LIMIT_MB="$L_NO_LIMIT"
else
	LIMIT_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/MB)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	LIMIT_MB="$LIMIT_MB MB"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/Hours) ];then
	LIMIT_HOUR="$L_NO_LIMIT"
else
	LIMIT_HOUR="$(cat $C_CLASSES_DIR/$CLASS/Hours) $L_HOURS"
fi

if [ -z $(cat $C_CLASSES_DIR/$CLASS/HoursDay) ];then
	HOURSDAY="$L_NO_LIMIT"
else
	HOURSDAY=$(cat $C_CLASSES_DIR/$CLASS/HoursDay)
	[ "$HOURSDAY" -lt 10 ] && HOURSDAY="0$HOURSDAY"
	HOURSDAY="$HOURSDAY:00"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/HoursMonth) ];then
	HOURSMONTH="$L_NO_LIMIT"
else
	HOURSMONTH=$(cat $C_CLASSES_DIR/$CLASS/HoursMonth)
	[ "$HOURSMONTH" -lt 10 ] && HOURSMONTH="0$HOURSMONTH"
	HOURSMONTH="$HOURSMONTH:00"
fi

if [ -z $(cat $C_CLASSES_DIR/$CLASS/MBDay) ];then
	MBDAY="$L_NO_LIMIT"
else
	MBDAY=$(cat $C_CLASSES_DIR/$CLASS/MBDay)
	MBDAY="$MBDAY.00"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/MBMonth) ];then
	MBMONTH="$L_NO_LIMIT"
else
	MBMONTH=$(cat $C_CLASSES_DIR/$CLASS/MBMonth)
	MBMONTH="$MBMONTH.00"
fi
BW=$(cat $C_CLASSES_DIR/$CLASS/Mbits)
if [[ -z $BW || -z "$C_SHAPER" ]];then
	BW="$L_NO_LIMIT"
else
	BW=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/Mbits)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	BW="$BW Mbit/s"
fi
BWU=$(cat $C_CLASSES_DIR/$CLASS/MbitsUp)
if [[ -z $BWU || -z "$C_SHAPER" ]];then
	BWU="$L_NO_LIMIT"
else
	BWU=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/MbitsUp)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	BWU="$BWU Mbit/s"
fi
TYPE=$(cat $C_CLASSES_DIR/$CLASS/ChargeType)
[ "$TYPE" == "pre" ] &&	PAYMENT="$L_PREPAID"
[ "$TYPE" == "post" ] && PAYMENT="$L_POSTPAID"
[ -z "$TYPE" ] && PAYMENT="$L_NOPAID"
CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
if [ -z "$CREDIT" ];then
	CREDIT="$L_NOPAID"
else
	CREDIT="$CREDIT $C_CURRENCY"
fi
CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -sd'@' -f1)
CONTROL_CON=$(echo "$CONNECTED" | grep "^$USERNAME$")
if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
	CONTROL_CON_REM=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote:' | awk '{print $2}')
	[ "$CONTROL_CON_REM" == "?" ] && CONTROL_CON_REM=""
fi
if [[ -n "$CONTROL_CON" || -n "$CONTROL_CON_REM" ]];then
	CONTROL_CON="$L_YES"
else
	CONTROL_CON="$L_NO"
fi
YEAR=$(date +%Y)
MONTH=$(echo $(date +%m) | sed 's/^0//g')
TODAY=$(echo $(date +%d) | sed 's/^0//g')
if [ -f  $C_ACCT_DIR/entries/$USERNAME/TimeD$TODAY ];then
	TIME_TODAY=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeD$TODAY))
else
	TIME_TODAY="00:00:00"
fi
if [ -f  $C_ACCT_DIR/entries/$USERNAME/MBD$TODAY ];then
	TRAFFIC_TODAY=$(cat $C_ACCT_DIR/entries/$USERNAME/MBD$TODAY)
	TRAFFIC_TODAY=$( echo "$TRAFFIC_TODAY/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_TODAY="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/TimeM$MONTH ];then
	TIME_MONTH=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeM$MONTH))
else
	TIME_MONTH="00:00:00"
fi
if [ -f  $C_ACCT_DIR/entries/$USERNAME/MBM$MONTH ];then
	TRAFFIC_MONTH=$(cat $C_ACCT_DIR/entries/$USERNAME/MBM$MONTH)
	TRAFFIC_MONTH=$( echo "$TRAFFIC_MONTH/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_MONTH="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/TimeY$YEAR ];then
	TIME_YEAR=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeY$YEAR))
else
	TIME_YEAR="00:00:00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/MB ];then
	TRAFFIC_YEAR=$(cat $C_ACCT_DIR/entries/$USERNAME/MBY$YEAR)
	TRAFFIC_YEAR=$( echo "$TRAFFIC_YEAR/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_YEAR="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/Time ];then
	TIME_TOT=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/Time))
else
	TIME_TOT="00:00:00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/MB ];then
	TRAFFIC_TOT=$(cat $C_ACCT_DIR/entries/$USERNAME/MB)
	TRAFFIC_TOT=$(echo "$TRAFFIC_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_TOT="0.00"
fi

echo "<script language=\"javascript\" src=\"$APACHE_BASEDIR/js/stampalog.js\"></script>
<div id=\"ticket\">
<br><font color=\"#0000FF\" size=\"5\"><center>$L_USER_DETAILS1: $USERNAME</font><p>
<font color=\"#0000FF\">$TODAYN $(date +%H:%M:%S)</font>
<p><img src=\"$APACHE_BASEDIR/images/barra.png\">
</div>"
if [ -d $C_ACCT_DIR/entries/$USERNAME ];then
	echo "<br>
	<form action=\"detailscon.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"submit\" name=\"CON\" class=\"bottone\" value=\"$L_SESSIONS\">
	</form>
	<br>"
fi
echo "<div id=\"ticketa\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/zerotruth/css/zt.css\">
<p>
<table class=\"tabellain\" width=\"800\" border=\"1\">
	<tr>
		<td class=\"intesta\" colspan=\"2\">User</td><td class=\"intesta\" colspan=\"2\">$L_CLASS: $CLASS"
		CT=$(cat $C_CLASSES_DIR/$CLASS/ChargeType)
		if [ "$CT" == "pre" ];then
			FREETIME=$(cat $C_CLASSES_DIR/$CLASS/FreeTime)
			if [ -n "$FREETIME" ];then
				echo " - $L_FREE_FOR $FREETIME"
			fi
		fi
		echo "</td>
	</tr>
	<tr>
		<td width=\"250px\">&nbsp;Username:</td>
		<td width=\"150px\">&nbsp;$USERNAME</td>
		<td width=\"250px\">&nbsp;$L_PAYMENT:</td>
		<td width=\"150px\">&nbsp;$PAYMENT</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_PASSWORD:</td>
		<td><div id=\"pwd1\"><a href=\"#\" onclick=\"hidden_passwordline('pwd1','$PASSWORD','show','hide', '1');\" id=\"showhide1\">&nbsp;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</a></div></td>
		<td>&nbsp;$L_CREDIT:</td>
		<td>&nbsp;$CREDIT</td>
	</tr>
	<tr>
		<td>&nbsp;$L_NAME:</td>
		<td>&nbsp;$NAME</td>
		<td>&nbsp;$L_COSTMB:</td>
		<td>&nbsp;$COST_MB</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_LAST_NAME:</td>
		<td>&nbsp;$LAST_NAME</td>
		<td>&nbsp;$L_COSTH::</td>
		<td>&nbsp;$COST_HOUR</td>
	</tr>
	<tr>
		<td>&nbsp;$L_EMAIL:</td>
		<td>&nbsp;$EMAIL</td>
		<td>&nbsp;$L_TRAFFIC:</td>
		<td>&nbsp;$LIMIT_MB</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_PHONE:</td>
		<td>&nbsp;$PHONE</td>
		<td>&nbsp;$L_TIME:</td>
		<td>&nbsp;$LIMIT_HOUR</td>
	</tr>
	<tr>
		<td>&nbsp;$L_CREATED:</td>
		<td>&nbsp;$DATE_CREATED</td>
		<td>&nbsp;$L_BANDWIDTH Down.:</td>
		<td>&nbsp;$BW</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_EXPIRY:</td>
		<td>&nbsp;$EXPIRE</td>
		<td>&nbsp;$L_BANDWIDTH Up.:</td>
		<td>&nbsp;$BWU</td>
	</tr>
</table>
<br>
<table class=\"tabellain\" width=\"800\" border=\"1\">
	<tr>
		<td width=\"250px\">&nbsp;$L_LIMIT_HOURS $L_FOR_DAY: </td>
		<td width=\"150px\">&nbsp;$HOURSDAY</td>
		<td width=\"250px\">&nbsp;$L_LIMIT_HOURS $L_FOR_MONTH:</td>
		<td  width=\"150px\">&nbsp;$HOURSMONTH</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_HOURS ($L_TODAY):</td>
		<td>&nbsp;$TIME_TODAY</td>
		<td>&nbsp;$L_HOURS ($L_THIS_MONTH):</td>
		<td>&nbsp;$TIME_MONTH</td>
	</tr>
	<tr>
		<td>&nbsp;$L_HOURS ($L_THIS_YEAR):</td>
		<td>&nbsp;$TIME_YEAR</td>
		<td>&nbsp;$L_HOURS ($L_TOTAL):</td>
		<td>&nbsp;$TIME_TOT</td>
	</tr>
	<tr>
		<td>&nbsp;$L_LIMIT_MB $L_FOR_DAY: </td>
		<td>&nbsp;$MBDAY</td>
		<td>&nbsp;$L_LIMIT_MB $L_FOR_MONTH:</td>
		<td>&nbsp;$MBMONTH</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_TRAFFIC ($L_TODAY):</td>
		<td>&nbsp;$TRAFFIC_TODAY MB</td>
		<td>&nbsp;$L_TRAFFIC ($L_THIS_MONTH):</td>
		<td>&nbsp;$TRAFFIC_MONTH MB</td>
	</tr>
	<tr>
		<td>&nbsp;$L_TRAFFIC ($L_THIS_YEAR):</td>
		<td>&nbsp;$TRAFFIC_YEAR MB</td>
		<td>&nbsp;$L_TRAFFIC ($L_TOTAL):</td>
		<td>&nbsp;$TRAFFIC_TOT MB</td>
	</tr>
	<tr  BGCOLOR=\"white\">
		<td>&nbsp;$L_CONNECTED:</td>
		<td>&nbsp;$CONTROL_CON</td>
		<td>&nbsp;$L_EXPIRED:</td>
		<td>&nbsp;$EXPIRED</td>
	</tr>
	<tr>
		<td>&nbsp;$L_BLOCKED:</td>
		<td>&nbsp;$BLOCKED</td>
		<td>&nbsp;$L_INFO:</td>
		<td>&nbsp;$INFO</td>
	</tr>
</table>
</div>
<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
<form action=\"details.sh\" method=\"GET\">
<input type=\"hidden\" name=\"PRINT\" value=\"PRINT\">
<input type=button  class=\"bottone\" value=\"$L_PRINT_DETAILS\" onClick=\"StampaLog()\"></form><p><br>"

#echo "<script language=\"JavaScript\" type=\"text/javascript\">
#setTimeout('top.location.href=(window.location.href=\"details.sh?USERNAME=$USERNAME\")',\"8000\")
#</script>"
./footer.sh
