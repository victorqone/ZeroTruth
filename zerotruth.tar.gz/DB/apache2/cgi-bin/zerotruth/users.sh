#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

RU="$(echo "$REQUEST_URI" | sed 's/\// /g' | awk '{print $NF}' | cut -d'?' -f1)"
if [ -n "$ONLY_CONNECT" ];then
	[ "$ONLY_CONNECT" == "off" ] && ONLY_CONNECT=""
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_ONLY_CONNECT" "$ONLY_CONNECT"
	source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
fi

if [ -n $(ls $C_HTDOCS_DIR/*.tgz) ];then
	$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_DIR/*.tgz"
fi

echo "<br><font color=\"blue\" size=\"5\">$L_REGISTERED_USERS</font><br>&nbsp;<br>"
if [ -n "$C_AR_FROM_TICKET" ]  &&  [[ -n "$C_USERS_FROM_TICKET" || "$UTENTEC" == "$C_ADMIN" ]] ;then
	echo "<font color=\"blue\">(<a href=\"userswait.sh\">$L_USERS_WAIT</a>)</font>"
fi
if  [[ -n "$C_VIEW_RANGE" || "$UTENTEC" == "$C_ADMIN" ]];then
	if [ -z "$LETTER" ];then
		LETTERVIEW="$L_ALL"
		LETTERPRE="Z"
		LETTERPOS="A"
	else
		LETTERVIEW="$LETTER"
		EL="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
		LETTERPRE=$(echo "$EL" | cut -d"$LETTERVIEW" -f1 | awk '{print $NF}')
		LETTERPOS=$(echo "$EL" | cut -d"$LETTERVIEW" -f2 | awk '{print $1}')
		[ "$LETTERVIEW" == "A" ] && LETTERPRE=""
		[ "$LETTERVIEW" == "Z" ] && LETTERPOS=""
	fi
	echo "<form action=\"$RU\" method=\"POST\">
	<table width=\"140px\" ><tr>
	<td width=\"40px\" align=\"center\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTERPRE\">
	<input type=\"submit\" class=\"frecciasx\" value=\"\">
	</form></td>
	<td width=\"60px\" align=\"center\" valign=\"middle\"><font color=\"blue\">
	<a href=\"#\" onMouseover=\"showmenu(event,linkset[0])\" onMouseout=\"delayhidemenu()\">$LETTERVIEW</a>
	</font>
	</td>
	<form action=\"$RU\" method=\"POST\">
	<td width=\"40px\" align=\"center\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTERPOS\">
	<input type=\"submit\" class=\"frecciadx\" value=\"\">
	</form></td>
	</tr></table></p>"
fi
echo "<table  border=\"0\" align=\"center\"><tr>
<td align=\"center\">
<form action=\"$RU\" method=\"POST\">
<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
<input type=\"submit\" class=\"bottone\" value=\"$L_REFRESH\">
</form></td>"
if [[ -n "$C_DISCONNECT_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td><form action=\"$RU\" method=\"POST\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"DISCONNECT_ALL\" value=\"$L_DISCONNECT_ALL\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_DISCONNECT_ALL\"
	onClick=\"javascript:return confirm('$L_ALERT_DISCONNECT_ALL');\">
	</form></td>"
fi
if [[ -n "$C_LOCK_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td><form action=\"$RU\" method=\"POST\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"LOCKTUTTI\" value=\"$L_LOCK_ALL\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_LOCK_ALL\"
	onClick=\"javascript:return confirm('$L_ALERT_ALL_LOCKED');\">
	</form></td>"
fi
if [[ -n "$C_UNLOCK_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td><form action=\"$RU\" method=\"POST\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"UNLOCKTUTTI\" value=\"$L_UNLOCK_ALL\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_UNLOCK_ALL\"
	onClick=\"javascript:return confirm('$L_ALERT_UNLOCK_ALL');\">
	</form></td>"
fi
if [[ -n "$C_DELETE_EXPIRED" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td><form action=\"$NAME_SCRIPT\" method=\"POST\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"DELETEEXP\" value=\"$L_DELETE_EXPIRED\">
	<input type=\"hidden\" name=\"CONTROLLDAP\" value=\"$CONTROLLDAP\">
	<input type=\"hidden\" name=\"CLASS_RIC\" value=\"$CLASS_RIC\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_DELETE_EXPIRED\"
	onClick=\"javascript:return confirm('$L_ALERT_DELETE_EXPIRED');\">
	</form></td>"
fi
echo "<td><form action=\"$RU\" method=\"POST\">"
if [ -n "$C_ONLY_CONNECT" ];then
	echo "<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"ONLY_CONNECT\" value=\"off\">
	<input type=\"submit\" class=\"bottoner\" value=\"$L_ALL\">"
else
	echo "<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"hidden\" name=\"ONLY_CONNECT\" value=\"on\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_CONNECT\">"
fi
echo "</form></td>"
echo "<td><form action=\"search.sh\" method=\"POST\">
<input type=\"submit\" class=\"bottone\" value=\"$L_SEARCH\">
</form></td></tr></table><p>"
if [[ "$C_CP_LOCAL_TYPE" == "Client" && -f $C_ZT_CONF_DIR/RemoteSync ]];then
	echo "<font color=\"blue\">$L_LAST_SYNC: $(cat $C_ZT_CONF_DIR/RemoteSync)</font><p>"
fi

if [ -n "$DISCONNECT_ALL" ];then
	wait 650
	disconnectall "$LETTER"
	return_page "$RU"
	exit
fi

if [ -n "$USERDEL" ];then
	wait 650
	deleteuser "$USERDEL"
	return_page "$RU"
	exit
fi
if [ -n "$USERDIS" ];then
	wait 650
	disconnectuser "$USERDIS"
	return_page "$RU?LETTER=$LETTERVIEW"
	exit
fi
if [ -n "$USERLOCK" ];then
	wait 650
	lockuser "$USERLOCK" "$LOCK"
	return_page "$RU?LETTER=$LETTERVIEW"
	exit
fi
if [ -n "$LOCKTUTTI" ];then
	wait 650
	lockall "$LETTER"
	return_page "$RU?LETTER=$LETTERVIEW"
	exit
fi
if [ -n "$UNLOCKTUTTI" ];then
	wait 650
	unlockall "$LETTER"
	return_page "$RU?LETTER=$LETTERVIEW"
	exit
fi
if [ -n "$DELETEEXP" ];then
	wait 650
	deleteexpired "$LETTER"
	EXPIRED=""
	USEREXPIRED=""
	USER_EX=""
	return_page "$RU"
	exit
fi
px="px"
echo "<table class=\"tabellauser\" style=\"font: $C_FONT_USERS$px Trebuchet MS,Arial,sans-serif;\" border=\"1\">
<tr>
<td class=\"intesta\" align=\"center\">N.</td>"
echo "<td class=\"intesta\"><a href=\"./$RU?SORT=sessions&amp;LETTER=$LETTERVIEW\">S."
[ "$SORT" == "sessions" ] && echo "<font color=\"red\">&#149;</font>"
echo "</a></td>"
if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
	CROOM="yes"
	echo "<td class=\"intesta\"><a href=\"./$RU?SORT=roomName&amp;LETTER=$LETTERVIEW\">$C_ROOM_NAME"
	[ "$SORT" == "roomName" ] && echo "<font color=\"red\">&#149;</font>"
	echo "</a></td>"
fi
if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
	CREMOTE="yes"
	HOSTLOC=$(echo $HOSTNAME | cut -d'.' -f1)
	CCONR="$(cat $C_ZT_DIR/remote/remotelogin)"
	echo "<td class=\"intesta\">NAS</td>"
fi
echo "<td class=\"intesta\"><a href=\"./$RU?SORT=uid&amp;LETTER=$LETTERVIEW\">$L_USERNAME"
[ "$SORT" == "uid" ] && echo "<font color=\"red\">&#149;</font>"
echo "</a></td>
<td class=\"intesta\"><a href=\"./$RU?SORT=givenName&amp;LETTER=$LETTERVIEW\">$L_NAME"
[ "$SORT" == "givenName" ] && echo "<font color=\"red\">&#149;</font>"
echo "</a></td>
<td class=\"intesta\"dd><a href=\"./$RU?SORT=sn&amp;LETTER=$LETTERVIEW\">$L_LAST_NAME"
[ "$SORT" == "sn" ] && echo "<font color=\"red\">&#149;</font>"
echo "</a></td>"
if [ -n "$C_VIEW_EMAIL" ];then
	echo "<td class=\"intesta\"><a href=\"./$RU?SORT=mail&amp;LETTER=$LETTERVIEW\">$L_EMAIL"
	[ "$SORT" == "mail" ] && echo "<font color=\"red\">&#149;</font>"
	echo "</a></td>"
fi
if [ -n "$C_VIEW_PHONE" ];then
	echo "<td class=\"intesta\"><a href=\"./$RU?SORT=telephoneNumber&amp;LETTER=$LETTERVIEW\">$L_TELEPHONE"
	[ "$SORT" == "telephoneNumber" ] && echo "<font color=\"red\">&#149;</font>"
	echo "</a></td>"
fi
if [ -n "$C_VIEW_CLASS" ];then
	echo "<td class=\"intesta\"><a href=\"./$RU?SORT=class&amp;LETTER=$LETTERVIEW\">$L_CLASS"
	[ "$SORT" == "class" ] && echo "<font color=\"red\">&#149;</font>"
	echo "</a></td>"
fi
if [ -n "$C_VIEW_EXPIRY" ];then
	echo "<td class=\"intesta\"><a href=\"./$RU?SORT=shadowExpire&amp;LETTER=$LETTERVIEW\">$L_EXPIRY"
	[ "$SORT" == "shadowExpire" ] && echo "<font color=\"red\">&#149;</font>"
	echo "</a></td>"
fi
echo "<td class=\"intesta\"><a href=\"./$RU?SORT=validity&amp;LETTER=$LETTERVIEW\">S."
[ "$SORT" == "validity" ] && echo "<font color=\"red\">&#149;</font>"
echo "</td><td class=\"intesta\">I.</td>"
if [ "$UTENTEC" == "$C_ADMIN" ];then
	COLSPAN=4
else
	COLSPAN=2
	[ -n "$C_DELETE_USER" ] && COLSPAN=$(($COLSPAN+1))
	[ -n "$C_EDIT_USERS" ] && COLSPAN=$(($COLSPAN+1))
fi
echo "<td colspan=\"$COLSPAN\" class=\"intesta\">$L_ACTIONS</td></tr>"
N=1
NR=0
FILTER="&(!(uid=admin))"
if [[ -n "$LETTERVIEW" && "$LETTERVIEW" != "$L_ALL" ]];then
	FILTER="$FILTER(uid=$LETTERVIEW*)"
fi
if [[ -n "$C_THEIR_USERS" && "$UTENTEC" != "$C_ADMIN" ]];then
	FILTER="$FILTER(ownerUser=$UTENTEC)"
fi
if [[ -z "$C_VIEW_HIDDEN" && "$UTENTEC" != "$C_ADMIN" ]];then
	FILTER="$FILTER(hidden=no)"
fi
now=$(date +%s)
PASSBLOCKED=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn=*-* cn | sed -n '/cn:/p' | awk '{ print $2 }' |  sed 's/^/-/g' | sed 's/ /-/g' | sed 's/$/-/g')
if [ "$(ls $C_CP_DIR/Connected/)" ];then
	CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -sd'@' -f1)
	CONNECTED=$(echo $CONNECTED |  sed 's/^/--/g' | sed 's/ /--/g' | sed 's/$/--/g')
fi
CONNECTREMOTE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE" '(&(!(loginRemote=?))(!(uid=admin)))' uid | sed -n '/uid:/p' | awk '{ print $2 }' |  sed 's/^/-/g' | sed 's/ /-/g' | sed 's/$/-/g')
if [ "$C_ONLY_CONNECT" == "on" ];then
	if [[ -z "$CONNECTED" && -z "$CONNECTREMOTE" ]];then
		CONNECTEDS="LkiujNMHG6543DFRTgbgfvcfJHXX"
	else
		CONNECTEDS="$(echo "$CONNECTED$CONNECTREMOTE" | sed 's/\-/ /g')"
	fi
	FILTERCON="(|"
	for NCON in $CONNECTEDS;do
		FILTERCON="$FILTERCON(uid=$NCON)"
	done
	FILTER="$FILTER $FILTERCON)"
fi
[ -z "$C_SORT_TABLE" ] && $C_SORT_TABLE="uid"
[ -z "$SORT" ] && SORT="$C_SORT_TABLE"
PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "($FILTER)" -S $SORT uid hidden givenName sn mail telephoneNumber shadowExpire validity gecos sessions class roomName loginRemote)
if [ -n "$(echo "$PEOPLE" | grep '^uid:')" ];then
	PEOPLE=$(echo "$PEOPLE" | sed '/^dn:/d'  | sed 's/^$/XXXXX/g')
	PEOPLE=$(echo "$PEOPLE" | \
	sed 's/sessions: /01--/g' | \
	sed 's/uid: /02--/g' | \
	sed 's/hidden: /03--/g' | \
	sed 's/givenName: /04--/g' | \
	sed 's/sn: /05--/g' | \
	sed 's/mail: /06--/g' | \
	sed 's/telephoneNumber: /07--/g' | \
	sed 's/shadowExpire: /08--/g' | \
	sed 's/validity: /09--/g' | \
	sed 's/gecos: /10--/g' | \
	sed 's/class: /11--/g' | \
	sed 's/roomName: /12--/g' | \
	sed 's/loginRemote: /13--/g' | \
	sed 's/ /+/g' )
	PEOPLE=$(echo $PEOPLE | sed 's/XXXXX/\n/g' | sed '/^dn/d' | sed 's/^ //g' | sed '/^$/d')
	PEOPLE="$(echo "$PEOPLE" | $C_ZT_SCRIPTS_DIR/split.sh| sed 's/[0-9][0-9]--//g' | sed 's/\?/\&nbsp;/g' | sed 's/+/\&nbsp;/g')"
	if [ "$SORT" == "sessions" ];then
		PEOPLE="$(echo "$PEOPLE" | sort -n)"
	fi
	if [ "$SORT" == "roomName" ];then
		PEOPLE="$(echo "$PEOPLE" | sed 's/\&nbsp;/11111111111111/g' | sort -k 12)"
		PEOPLE="$(echo "$PEOPLE" | sed 's/11111111111111/\&nbsp;/g')"
	fi
	echo "$PEOPLE" | awk -v NOLIMIT="$L_NO_LIMIT" -v LETTER="$LETTERVIEW" -v DELETE="$L_DELETE" \
	-v LOCK="$L_LOCK" -v UNLOCK="$L_UNLOCK" -v EDIT="$L_MODIFY" -v AVVLOCK="$L_ALERT_LOCKED" -v AVVDELETE="$L_ALERT_REMOVE" \
	-v AVVUNLOCK="$L_ALERT_UNLOCK" -v DISCONNECT="$L_DISCONNECT1"  -v AVVDISCONNECT="$L_ALERT_DISCONNECT" \
	-v LOCKED="$PASSBLOCKED" -v CONNECTED="$CONNECTED" -v CROOM="$CROOM" -v CREMOTE="$CREMOTE" -v HOSTLOC="$HOSTLOC" \
	-v CCONR="$CCONR" -v UC="$UTENTEC" -v ADMIN="$C_ADMIN" -v EDITUSERS="$C_EDIT_USERS"  -v UNLOCKLOCK="$C_UNLOCK_LOCK_USERS" \
	-v DELETEUSER="$C_DELETE_USER" -v DISCONNECTUSER="$C_DISCONNECT_USER" -v MBLIMITREACHED="$L_MB_LIMIT_REACHED" -v HOURLIMITREACHED="$L_HOUR_LIMIT_REACHED" \
	-v EXCEEDEDEXPIRYDATE="$L_EXCEEDED_EXPIRY_DATE" -v CREDITNOTAVAILABLE="$L_CREDIT_NOT_AVAILABLE" -v RU="$RU" -v NOT_ACTIVE="$L_NOT_ACTIVE"\
	-v VIEWEMAIL="$C_VIEW_EMAIL" -v VIEWEMAIL="$C_VIEW_EMAIL"  -v VIEWPHONE="$C_VIEW_PHONE"  -v VIEWEXPIRY="$C_VIEW_EXPIRY" -v VIEWCLASS="$C_VIEW_CLASS" \
	-f $C_ZT_SCRIPTS_DIR/table.awk
	echo "</table></table>"
else
	echo "</table><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<p><font color=\"red\">$L_NO_RESULT</font><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<p>"
fi
./footer.sh

