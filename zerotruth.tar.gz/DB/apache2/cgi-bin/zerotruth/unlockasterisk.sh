#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published b205:8089/y
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

echo "Content-type: text/html"
echo ""


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh

PHONE=$(echo "$QUERY_STRING" | cut -d"=" -f2 | cut -d"+" -f1 )
PHONE=$(echo "$PHONE" | sed 's/^\+//g' | sed 's/^0//g' | sed 's/^0//g' )
CONTROL=$(echo "$QUERY_STRING" | cut -d"=" -f2 | cut -d"+" -f2)
[ "$CONTROL" != "$C_PASS_ASTERISK" ] && exit
QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "(&(telephoneNumber=*$PHONE)(&(gecos=wait_asterisk)))" uid gecos)
USERNAME=$(echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
INFO=$(echo "$QUERY" | grep -e '^gecos: ' | sed 's/^gecos: //g')
if [[ -n "$USERNAME" && "$INFO" == "wait_asterisk" ]];then
	$C_ZT_BIN_DIR/zt "UnlockAsterisk" "$USERNAME"
	echo "yes"
else
	echo "no"
fi
exit
