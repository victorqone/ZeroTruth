#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/mudc/conf/mudc.config
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">
<link rel=\"shortcut icon\" href=\"/images/tacchino.ico\">
<link href=\"/zerotruth/css/zt.css\" rel=\"stylesheet\" type=\"text/css\" >
<script type=\"text/javascript\" src=\"/js/zt.js\"></script>
<script type=\"text/javascript\" src=\"/js/mudc.js\"></script>
<script type=\"text/javascript\">
function calender() {
	setCibulCalendar(\"datespan\");
	setCibulCalendar(\"datespan1\");
}
</script>"

echo "</head><body onLoad=\"show_clock(), calender()\">"
source /DB/apache2/cgi-bin/zerotruth/functions.sh
POST=$(</dev/stdin)
if [ $POST != "" ];then
	CONTROL_PLAIN=$(echo "$POST" | grep "CONF_SCRIPT")
	n=$(($(echo $POST | grep -o "&" | wc -l)+1))
	for i in $(seq 1 $n);do
		NV=$(echo $POST | awk '{split ($0, a, "&*&");print a['$i']}')
		NAME_VAR=$(echo $NV | cut -d'=' -f1)
		VAL_VAR=$(echo $NV | sed '/'$NAME_VAR='/s///g')
		if [[ -n "$CONTROL_PLAIN" || -n $(echo "$NAME_VAR" | grep PASS) ]];then
			VAL_VAR=$($C_ZT_BIN_DIR/convplain "$VAL_VAR")
			for SCRIPT in "ACCOUNT_INFO $C_CP_DIR/Auth/Custom/AccountInfo" \
				"CONF_EXTENSIONS /opt/asterisk/etc/asterisk/extensions.conf" \
				"CONF_OPENDOOR /opt/asterisk/var/lib/asterisk/agi-bin/openDoor.sh" \
				"CONF_SIP /opt/asterisk/etc/asterisk/sip.conf" \
				"CONF_ZEROTRUTH /opt/asterisk/var/lib/asterisk/agi-bin/zerotruth.sh" \
				"DESCRIPTION $C_CP_DIR/Auth/Custom/Image/Description" \
				"EMAILALLARM $CM_MUDC_DIR/conf/EmailAllarm" \
				"EMAILFOOTER  $CM_MUDC_DIR/conf/EmailFooter" \
				"EMAIL_FOOTER_NOT $C_ZT_CONF_DIR/emailf" \
				"EMAILMOTION $CM_MUDC_DIR/conf/EmailMotion" \
				"EMAILTEXT  $CM_MUDC_DIR/conf/EmailText" \
				"EMAIL_TEXT_NOT $C_ZT_CONF_DIR/emailh" \
				"EXEC_MY_SCRIPT $C_ZT_SCRIPTS_DIR/esec_from_sms.sh" \
				"FBLIKE $C_HTDOCS_ZT_DIR/cgi-bin/template/likefb.sh" \
				"GENERAL_INFO $C_CP_DIR/Auth/Custom/GeneralInfo" \
				"HEADING $C_CP_DIR/Auth/Custom/NetDescription" \
				"INFO_OFF_LINE $C_CP_DIR/Auth/Custom/InfoOffLine" \
				"INFOTICKET $CM_MUDC_DIR/conf/InfoTicket" \
				"INFO_TICKET $C_ZT_CONF_DIR/infoTicket" \
				"MOTIONCONF $CM_MUDC_DIR/conf/motion.conf" \
				"NO_INTERNET $C_ZT_CONF_DIR/NoInternet" \
				"POPUP_HTML $C_HTDOCS_ZT_DIR/template/popup.html" \
				"POST_REGISTRATION $C_CP_DIR/Auth/Custom/PostRegistration" \
				"PP_BUTTON $C_ZT_CONF_DIR/ppbutton" \
				"PP_NOTICE $C_ZT_CONF_DIR/ppnotice" \
				"REDIRECT_FREE $C_CP_DIR/Auth/Custom/RedirectFree" \
				"SCRIPTKEY $CM_MUDC_DIR/scripts/scriptkeypad.sh" \
				"SMSALLARM $CM_MUDC_DIR/conf/SMSAllarm" \
				"SMSMOTION $CM_MUDC_DIR/conf/SMSMotion" \
				"SMSTEXT  $CM_MUDC_DIR/conf/SMSText" \
				"TEXT_MY_SCRIPT $C_ZT_SCRIPTS_DIR/my_SMS_script.sh" \
				"TEXT_PRIVACY $C_ZT_CONF_DIR/privacy" \
				"THANKS_FB $C_HTDOCS_ZT_DIR/cgi-bin/template/ThanksFb" \
				"THREAD1CONF $CM_MUDC_DIR/conf/thread1.conf" \
				"THREAD2CONF $CM_MUDC_DIR/conf/thread2.conf" \
				"THREAD3CONF $CM_MUDC_DIR/conf/thread3.conf" \
				"THREAD4CONF $CM_MUDC_DIR/conf/thread4.conf" \
				"USER_BLOCKED $C_CP_DIR/Auth/Custom/UserBlocked" \
				"CONF_LANGUAGE $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh" \
				"CONF_LANGUAGEMUDC $C_ZT_DIR/mudc/language/$C_LANGUAGE/$C_LANGUAGE.sh" \
				"WALLED_GARDEN $C_HTDOCS_ZT_DIR/template/walledgarden.html";do
				set -- $SCRIPT
				if [ "$NAME_VAR" == "$1" ];then
					$C_ZT_BIN_DIR/zt "Salva" "$VAL_VAR" "$2"
				fi
				
			done
			eval $NAME_VAR=\"$VAL_VAR\"
		else
			eval $NAME_VAR=\"$($C_ZT_BIN_DIR/convnum "$VAL_VAR" | sed 's/%3A/:/g')\"
		fi
	done
fi
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi

HC=$(echo $HTTP_COOKIE | sed '/\;/s// /g')
NOMEC=$(echo $HC | awk '{split ($0, a, "nome=");print a['2']}' | awk '{print $1}')
VALOREC=$(echo $HC | awk '{split ($0, a, "VALORE=");print a['2']}' | awk '{print $1}')
UTENTEC=$(echo $HC | awk '{split ($0, a, "UTENTEC=");print a['2']}' | awk '{print $1}')

if [[ "$VALOREC" != "$C_ADMIN_COOKIE" && "$VALOREC" != "$C_USER_COOKIE" ]];then
	echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"0; URL=index.sh?ooo=ooo\">"
	exit
fi

if [ "$UTENTEC" != "$C_ADMIN" ];then
	MANAGER="$UTENTEC"
	varmanager
fi


source ./language/$C_LANGUAGE/$C_LANGUAGE.sh
source ./mudc/language/$C_LANGUAGE/$C_LANGUAGE.sh

echo "<div id=\"containertest\">
<div id=\"orologio\">
	<script type=\"text/javascript\" src=\"/js/liveclock.js\"></script>
</div>"
if [ -n "$REFRESHIMG" ];then
	RN="$RANDOM"
	echo "<div id=\"testata\"><img src=\"/images/testata.png?$RN\" alt=\"testata\"></div>
	<div id=\"imgbase\"><img src=\"/images/base.png?$RN\" alt=\"base\"></div>
	<div id=\"imguser\"><img src=\"/images/imguser.png?$RN\" alt=\"imguser\"></div>"
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_IMG_RANDOM" "$RN"
else
	echo "<div id=\"testata\"><img src=\"/images/testata.png?$C_IMG_RANDOM\" alt=\"testata\"></div>
	<div id=\"imgbase\"><img src=\"/images/base.png?$C_IMG_RANDOM\" alt=\"base\"></div>
	<div id=\"imguser\"><img src=\"/images/imguser.png?$C_IMG_RANDOM\" alt=\"imguser\"></div>"
fi

echo "<div id=\"bottonitestata\">
<table width=\"70%\" align=\"center\">
	<tr>
		<td WIDTH=\"1%\" align=\"center\">
			<form action=\"users.sh\" method=\"POST\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_USERLIST\">
			</form>
		</td>"
		if [[ -n "$C_REGISTER_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			NB=1
			echo "<td WIDTH=\"1%\" align=\"center\">
				<form action=\"adduser.sh\" method=\"POST\">
				<input type=\"submit\"  class=\"bottone\" value=\"$L_ADDUSER\">
				</form>
			</td>"
		fi
		if [[ -n "$C_GES_CLASS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<td WIDTH=\"1%\" align=\"center\">
				<form action=\"classes.sh\" method=\"POST\">
				<input type=\"submit\"  class=\"bottone\" value=\"$L_CLASSES\">
				</form>
			</td>"
		fi
		if [[ -n "$C_MUDC" && -n "$C_USER_MUDC" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_MUDC" ]];then
			NB=$(($NB+1))
			echo "<td WIDTH=\"1%\" align=\"center\">
			<form action=\"./mudc/switches.sh\" method=\"POST\">
			<input type=\"submit\"  class=\"bottone\" value=\"Mudc\">
			</form>
			</td>"
		fi
		if [[ -n "$C_EMAIL_ABIL" && -n "$C_SEND_EMAIL" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_EMAIL_ABIL" ]];then
			NB=$(($NB+2))
			echo "<td WIDTH=\"1%\" align=\"center\">
				<form action=\"email.sh\" method=\"POST\">
				<input type=\"submit\"  class=\"bottone\" value=\"$L_EMAIL\">
				</form>
			</td>"
		fi
		if [[ -n "$C_SMS_ABIL" && -n "$C_SEND_SMS" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_SMS_ABIL" ]] ;then
			if [ "$C_SMS_PROVIDER" != "Gammu" ] || [[ "$C_SMS_PROVIDER" == "Gammu" && -n "$C_SEND_SMS_GAMMU" ]];then
				NB=$(($NB+1))
				echo "<td WIDTH=\"1%\" align=\"center\">
				<form action=\"sms.sh\" method=\"POST\">
				<input type=\"submit\"  class=\"bottone\" value=\"$L_SMS\">
				</form>
				</td>"
			fi
		fi
		if [ "$UTENTEC" == "$C_ADMIN" ];then
			NB=$(($NB+1))
			echo "<td WIDTH=\"1%\" align=\"center\">
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\""
			if [[ -n "$C_FIX"  && "$SCRIPT_NAME" != "/cgi-bin/zerotruth/config.sh" ]];then
				echo "class=\"bottonev\""
			else
				echo "class=\"bottone\""
			fi
			echo "value=\"$L_CONFIG\">
			</form>
			</td>"
		else
			if [[ "$UTENTEC" != "$C_ADMIN" && -n "$C_LOG_USER" ]];then
				echo "<td WIDTH=\"1%\" align=\"center\">
				<form action=\"userlog.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"user\" class=\"bottone\" value=\"$UTENTEC\">
				<input type=\"submit\"  class=\"bottone\" value=\"Log\">
				</form>
				</td>"
			fi
		fi
		if [ "$NB" == 6 ];then
			echo "<td WIDTH=\"1%\" align=\"center\">
			<form action=\"./index.sh?EXIT=yes&USER=$UTENTEC\" method=\"POST\">
			<input type=\"submit\"  class=\"bottonelogout\" value=\"\"></form>"
		else
			echo "<td WIDTH=\"1%\" align=\"center\">
			<form action=\"./index.sh?EXIT=yes&USER=$UTENTEC\" method=\"POST\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_EXIT\"></form>"
		fi
		echo "</td>
	</tr>
</table>
</div>"
if [[ "$(cat $C_CP_DIR/Auth/Custom/NoInternet)" == "yes" && -n "$C_INTERNET_DOWN" ]];then
	echo "<script>alert (\"$L_INTERNET_DOWN\");</script>"
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_INTERNET_DOWN" ""
fi
echo "<div id=\"pagina\">
<p><table class=\"tabellaint\">
	<tr>
		<td align=\"center\" valign=\"top\">"

