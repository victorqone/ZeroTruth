#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

echo "Content-type: text/html"
echo ""


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh

getvarqs

NR=1
for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep 'cbq-4[0-9]');do
	USERNAME=$(echo $SHAP | cut -d'-' -f2 | cut -d'.' -f2 )
	CLASS=$(echo $SHAP | cut -d'-' -f4 )
	DEVICE=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep 'DEVICE' | cut -d'=' -f2 | cut -d',' -f1 )
	RATE=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep RATE | cut -d'=' -f2 | cut -d'K' -f1)
	RATE=$(echo "scale=$C_DECIMAL;$(echo $RATE)/1024" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./')
	WEIGHT=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep WEIGHT | cut -d'=' -f2 | cut -d'K' -f1)
	WEIGHT=$(echo "scale=$C_DECIMAL;$(echo $WEIGHT)/1024" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./')
	NUM=$(echo $SHAP | cut -d'-' -f2 | cut -d'.' -f1 )
	T_SHAPER=$(tc -s qdisc show dev "$DEVICE")
	T_SHAPER=$(echo $T_SHAPER | sed 's/qdisc tbf /\n/g' | sed '/^qdisc/d')
	RIGA_SHAPER=$( echo -e "$T_SHAPER" | grep "^$NUM:")
	SENT=$(echo "$RIGA_SHAPER" | cut -d' ' -f11)
	SENT=$( echo "$SENT/1024" | $C_ZT_BIN_DIR/bc )
	PKT=$(echo "$RIGA_SHAPER" | cut -d' ' -f13)
	DROP=$(echo "$RIGA_SHAPER" | cut -d' ' -f16 | sed '/\,/s///g')
	OVER=$(echo "$RIGA_SHAPER" | cut -d' ' -f18 | sed '/\,/s///g')
	DATA="$DATA\n$NR-$USERNAME-$CLASS-$DEVICE-$RATE-$SENT-$PKT-$DROP-$OVER"
	NR=$(($NR+1))
done
echo "$(echo -e "$DATA" |  grep "^$line")"
