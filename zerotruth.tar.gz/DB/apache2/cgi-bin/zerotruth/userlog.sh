#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [ -z "$UTENTEC" ];then
	return_page "index.sh"
	exit
fi
source ./conf/zt.config
source ./language/$C_LANGUAGE/$C_LANGUAGE.sh

if [ -n "$QUERY_STRING" ];then
	USER_LOG=$(echo "$QUERY_STRING" | cut -d'=' -f2 | cut -d'&' -f1)
	if [ $(echo "$QUERY_STRING" | cut -d'=' -f4 )  == "$L_DELETE" ];then
		log="_log"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_LOG_DIR/users/$USER_LOG/$USER_LOG$log"
	fi

	if [ $(echo "$QUERY_STRING" | cut -d'&' -f2  | cut -d'=' -f1)  == "EDIT_USER" ];then
		NUSER=$(echo "$QUERY_STRING" | cut -d'=' -f3 | cut -d'&' -f1 )
	fi
	if [ $(echo "$QUERY_STRING" | cut -d'&' -f3 | cut -d'=' -f1 ) == "N_DAY_SEARCH" ];then
		N_DAY_SEARCH=$(echo "$QUERY_STRING" | cut -d'=' -f3 | cut -d'&' -f1)
	fi
fi
if [[ -z "$QUERY_STRING" || -n "$V_ALL" ]] && [ "$UTENTEC" != "$C_ADMIN" ];then
	USER_LOG="$UTENTEC"
fi
if [ -n "$RANGE" ];then
	DATAIN=$(echo "$DATA_IN" | sed 's/\%2F/-/g')
	DATAOUT=$(echo "$DATA_OUT" | sed 's/\%2F/-/g')
	[[ -n "$DATA_IN" && -z "$DATA_OUT" ]] && DATAOUT="$(date +%d-%m-%Y)"
	[[ -n "$DATA_OUT" && -z "$DATA_IN" ]] && DATAIN="01-01-1970"
	if [[ -z "$DATA_IN" && -z "$DATA_OUT" ]];then
		DATAIN="01-01-1970"
		DATAOUT="$(date +%d-%m-%Y)"
	fi
	DAYIN=$(echo "$DATAIN" | cut -d'-' -f1)
	MONTHIN=$(echo "$DATAIN" | cut -d'-' -f2)
	YEARIN=$(echo "$DATAIN" | cut -d'-' -f3)
	DATAINSEC=$(date -d "$YEARIN-$MONTHIN-$DAYIN" +%s)
	DAYOUT=$(echo "$DATAOUT" | cut -d'-' -f1)
	MONTHOUT=$(echo "$DATAOUT" | cut -d'-' -f2)
	YEAROUT=$(echo "$DATAOUT" | cut -d'-' -f3)
	DATAOUTSEC=$(date -d "$YEAROUT-$MONTHOUT-$DAYOUT 1 day" +%s)
	DATA_IN="$DAYIN/$MONTHIN/$YEARIN"
	DATA_OUT="$DAYOUT/$MONTHOUT/$YEAROUT"
else
	DATAINSEC="0"
	DATAOUTSEC="$(date +%s)"
fi
echo "<script language=\"javascript\" src=\"/js/stampalog.js\"></script>
<div id=\"ticket\">
<br>&nbsp;<br><center><font color=\"#0000FF\" size=\"5\">$USER_LOG Log</font><p>
<p><center><img src=\"/images/barra.png\"><p>

</div>
	<form action=\"userlog.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"USER_LOG\" value=\"$USER_LOG\">
		<input type=\"hidden\" name=\"NUSER\" value=\"$NUSER\">
		<input type=\"text\" size=\"8\" name=\"DATA_IN\" id=\"datespan\" value=\"$DATA_IN\">
		<input type=\"text\" size=\"8\" name=\"DATA_OUT\" id=\"datespan1\" value=\"$DATA_OUT\"><p>
		<input type=\"submit\" name=\"RANGE\" class=\"bottonelinea\" value=\"Range\">
	</form>
	<form action=\"userlog.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"USER_LOG\" value=\"$USER_LOG\">
		<input type=\"hidden\" name=\"NUSER\" value=\"$NUSER\">
		<input type=\"submit\" name=\"V_ALL\" class=\"bottonelineadue\" value=\"$L_ALL\">
	</form>
	<p><br>

<div id=\"ticketa\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/zerotruth/css/zt.css\">
<table  width=\"700\" BGCOLOR=\"#f3f3f3\" border=\"1\" align=\"center\">
	<tr>
		<td class=\"intesta\" align=\"center\">N.</td>
		<td class=\"intesta\" align=\"center\">$L_DATE</td>
		<td class=\"intesta\" align=\"center\">$L_HOUR</td>
		<td class=\"intesta\" align=\"center\">$L_ACTIONS</td>
	</tr>"
	N=1
	log="_log"
	RIGHE=$(cat $C_ZT_LOG_DIR/users/$USER_LOG/$USER_LOG$log | wc -l )
	for I in $(seq 1 $RIGHE);do
		RIGA=$(cat $C_ZT_LOG_DIR/users/$USER_LOG/$USER_LOG$log | /bin/sed -n "${I}p")
		DATESEC=$(echo "$RIGA" | cut -d'-' -f1)

		if [ "$C_FORM_DATE" == "ita" ];then
			DATE=$( date -d "1970-01-01 $DATESEC sec" +%d/%m/%Y)
		else
			DATE=$( date -d "1970-01-01 $DATESEC sec" +%Y/%m/%d)
		fi
		HOUR=$( date -d "1970-01-01 $DATESEC sec" +%H:%M:%S)
		ACTION=$(echo "$RIGA" | cut -d'-' -f2)
		if [[ -n "$ACTION" && "$DATESEC" -gt "$DATAINSEC" && "$DATESEC" -lt "$DATAOUTSEC"  ]];then
			echo "<tr><td align=\"center\">$N</td><td align=\"center\">$DATE</td><td align=\"center\">$HOUR</td><td>$ACTION</td></tr>"
			let N=N+1
		fi
	done
	echo "
</table>
</div><p>
<img src=\"$APACHE_BASEDIR/images/barra.png\"><p>
<table><tr><td>
<input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_DETAILS\" onClick=\"StampaLog()\"></td>"
if [ "$UTENTEC" == "$C_ADMIN" ];then
	echo "<td><form method=\"GET\" action=\"config.sh\">
	<input type=\"hidden\" name=\"EDIT_USER\" value=\"$NUSER\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form></td>
	<td><form action=\"userlog.sh\" method=\"GET\">
	<input type=\"hidden\" name=\"user\" value=\"$USER_LOG\">
	<input type=\"hidden\" name=\"EDIT_USER\" value=\"$NUSER\">
	<input type=\"submit\" name=\"delete\" class=\"bottone\" value=\"$L_DELETE\"
	onClick=\"javascript:return confirm('$L_ALERT_DELETE_LOG');\"></form>"
fi
echo "</td></tr></table><p>&nbsp;"
./footer.sh


