#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
if [ -n "$USERDIS" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\"><center>$L_USER_DETAILS: $USERDIS</font><br>"
	wait 750
	disconnectuserfd "$USERDIS"
	return_page "detailscon.sh?USERNAME=$USERDIS"
	exit
fi 

ldap_search_people "uid=$USERNAME"
echo "<script language=\"javascript\" src=\"$APACHE_BASEDIR/js/stampalog.js\"></script>
<div id=\"ticket\">
<br><font color=\"#0000FF\" size=\"5\"><center>$L_USER_DETAILS: $USERNAME</font><br>
<font color=\"#0000FF\" size=\"3\">( $NAME $LAST_NAME"


if [ -n "$RANGE" ];then
	DATAIN=$(echo "$DATA_IN" | sed 's/\%2F/-/g')
	DATAOUT=$(echo "$DATA_OUT" | sed 's/\%2F/-/g')
	[[ -n "$DATA_IN" && -z "$DATA_OUT" ]] && DATAOUT="$(date +%d-%m-%Y)"
	[[ -n "$DATA_OUT" && -z "$DATA_IN" ]] && DATAIN="01-01-1970"
	DAYIN=$(echo "$DATAIN" | cut -d'-' -f1)
	MONTHIN=$(echo "$DATAIN" | cut -d'-' -f2)
	YEARIN=$(echo "$DATAIN" | cut -d'-' -f3)
	DATAINSEC=$(date -d "$YEARIN-$MONTHIN-$DAYIN" +%s)
	DAYOUT=$(echo "$DATAOUT" | cut -d'-' -f1)
	MONTHOUT=$(echo "$DATAOUT" | cut -d'-' -f2)
	YEAROUT=$(echo "$DATAOUT" | cut -d'-' -f3)
	DATAOUTSEC=$(date -d "$YEAROUT-$MONTHOUT-$DAYOUT 1 day" +%s)
	if [ "$DATAIN" == "01-01-1970" ];then
		DATA_IN=""
	else
		DATA_IN="$DAYIN/$MONTHIN/$YEARIN"
	fi
	DATA_OUT="$DAYOUT/$MONTHOUT/$YEAROUT"
else
	if [ -z "$DET_ALL" ];then
		DATA_IN="$(date +%d/%m/%Y)"
		DATA_OUT="$DATA_IN"
		DAYIN=$(echo "$DATA_IN" | cut -d'/' -f1)
		MONTHIN=$(echo "$DATA_IN" | cut -d'/' -f2)
		YEARIN=$(echo "$DATA_IN" | cut -d'/' -f3)
		DATAINSEC=$(date -d "$YEARIN-$MONTHIN-$DAYIN" +%s)
		DATAOUTSEC=$(date +%s)
	fi
fi

if [ -n "$ROOM" ] && [ "$C_ROOM" == "on" ];then
	echo "- $C_ROOM_NAME: $ROOM"
fi
echo ")</font>
<br><img src=\"$APACHE_BASEDIR/images/barra.png\"><p>
</div>
<br>
<table width=\"284px\"><tr><td align=\"center\">
	<form action=\"detailscon.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"text\" size=\"8\" name=\"DATA_IN\" id=\"datespan\" value=\"$DATA_IN\">
		<input type=\"text\" size=\"8\" name=\"DATA_OUT\" id=\"datespan1\" value=\"$DATA_OUT\"><p>
</td></tr>
</table>
	<input type=\"submit\" name=\"RANGE\" class=\"bottonelinea\" value=\"Range\">
	</form>
	<form action=\"detailscon.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
		<input type=\"submit\" name=\"DET_ALL\" class=\"bottonelineadue\" value=\"$L_ALL\">
	</form>
	<br>
<div id=\"ticketa\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/zerotruth/css/zt.css\">
<p><table class=\"tabellain\" width=\"970\" border=\"1\" >
	<tr>
		<td class=\"intesta\"><center>N.</td>
		<td class=\"intesta\"><center>Client</td>"
		if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
			echo "<td class=\"intesta\"><center>NAS</td>"
		fi
		echo "<td class=\"intesta\"><center>Start</td>
		<td class=\"intesta\"><center>Stop</td>
		<td class=\"intesta\"><center>RX</td>
		<td class=\"intesta\"><center>TX</td>
		<td class=\"intesta\"><center>$L_TRAFFIC</td>
		<td class=\"intesta\"><center>$L_TIME</td>
		<td class=\"intesta\"><center>$L_COST $valuta</td>
	</tr>"
	N=1
	COST_TOT=0
	RX_TOT=0
	TX_TOT=0
	TRAFFIC_TOT=0
	TIME_TOT=0
	for SESSION in $(ls -t $C_ACCT_DIR/entries/$USERNAME/sessions/ | tac);do
		BG="#f3f3f3"
		[ $(expr $N % 2 ) -eq 0 ] && BG="white"
		DATE_SESSION=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/start)
		[ -z "$DATAINSEC" ] && DATAINSEC="0"
		[ -z "$DATAOUTSEC" ] && DATAOUTSEC="$(date +%s)"
		if [[ "$DATE_SESSION" -ge "$DATAINSEC" &&  "$DATE_SESSION" -le "$DATAOUTSEC" ]];then
			IP=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/IP)
			MAC=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/MAC)
			NAS=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/NAS)
			START=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/start)
			if [ "$C_FORM_DATE" == "ita" ];then
				START="$(date -d "1970-01-01 $START sec GMT " +%d/%m/%Y-%H:%M:%S)"
			else
				START="$(date -d "1970-01-01 $START sec GMT " +%Y/%m/%d-%H:%M:%S)"
			fi
			STOP=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/stop)
			if [ -n "$STOP" ];then
				if [ "$C_FORM_DATE" == "ita" ];then
					STOP="$(date -d "1970-01-01 $STOP sec GMT " +%d/%m/%Y-%H:%M:%S)"
				else
					STOP="$(date -d "1970-01-01 $STOP sec GMT " +%Y/%m/%d-%H:%M:%S)"
				fi
			else
				STOP="<a href=\"detailscon.sh?USERDIS=$USERNAME\"
				onClick=\"javascript:return confirm('$L_ALERT_DISCONNECT $USERNAME (IP $IP)');\">$L_ACTIVE</a>"
			fi
			RX=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/RX)
			RX_TOT=$(($RX_TOT+$RX))
			RX=$( echo "$RX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TX=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/TX)
			TX_TOT=$(($TX_TOT+$TX))
			TX=$( echo "$TX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TRAFFIC=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Traffic)
			TRAFFIC_TOT=$(($TRAFFIC_TOT+$TRAFFIC))
			TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TIME=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Time)
			TIME_TOT=$(($TIME_TOT+$TIME))
			TIME=$( oraconv $TIME)
			COST=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/$SESSION/Cost | awk '{printf("%.2f\n", $0)}')
			COST_TOT=$(echo "$COST_TOT+$COST" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
			echo "<tr BGCOLOR=\"$BG\"><td><center>$N</td><td><center>$IP/$MAC</td>"
			if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
				echo "<td><center>$NAS</td>"
			fi
			echo "<td><center>$START</td><td><center>$STOP</td>
			<td><center>$RX</td><td><center>$TX</td><td><center>$TRAFFIC</td><td><center>$TIME</td><td><center>$COST</td></tr>"
			let N=N+1
		fi
	done
	TIME_TOT=$( oraconv $TIME_TOT)
	RX_TOT=$( echo "$RX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	TX_TOT=$( echo "$TX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	TRAFFIC_TOT=$( echo "$TRAFFIC_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
	echo "<tr><td>&nbsp;</td><td><center>&nbsp;</td><td><center>&nbsp;</td><td><center>&nbsp;</td>"
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		echo "<tr><td>&nbsp;</td>"
	fi
	echo "<td bgcolor=\"#8cc7f1\"><center>$RX_TOT</td><td bgcolor=\"#8cc7f1\"><center>$TX_TOT</td><td bgcolor=\"#8cc7f1\">
	<center>$TRAFFIC_TOT</td><td bgcolor=\"#8cc7f1\"><center>$TIME_TOT</td><td bgcolor=\"#8cc7f1\"><center>$COST_TOT</td></tr>
</table>
</div>
<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
<form action=\"detailscon.sh\" method=\"GET\">
<input type=\"hidden\" name=\"PRINT\" value=\"PRINT\">
<input type=button  class=\"bottone\" value=\"$L_PRINT_DETAILS\" onClick=\"StampaLog()\"></form><p><br>"
if [ -d $C_ZT_DIR/expired/$USERNAME ];then
	echo "<center><img src=\"$APACHE_BASEDIR/images/barra.png\"><p>$L_CONNECTIONS_EXPIRED
	<table class=\"tabellain\" width=\"970\" border=\"1\" >
		<tr>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>N.</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>Client</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>NAS</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>Start</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>Stop</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>RX</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>TX</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>$L_TRAFFIC</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>$L_TIME</td>
			<td background=\"$APACHE_BASEDIR/images/imgtable.png\"><center>$L_COST $valuta</td>
		</tr>"
		N=1
		COST_TOT=0
		RX_TOT=0
		TX_TOT=0
		TRAFFIC_TOT=0
		TIME_TOT=0
		for SESSION in $(ls -t $C_ZT_DIR/expired/$USERNAME/sessions/ | tac);do
			BG="#f3f3f3"
			[ $(expr $N % 2 ) -eq 0 ] && BG="white"
			IP=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/IP)
			MAC=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/MAC)
			NAS=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/NAS)
			START=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/start)
			if [ "$C_FORM_DATE" == "ita" ];then
				START="$(date -d "1970-01-01 $START sec GMT " +%d/%m/%Y-%H:%M:%S)"
			else
				START="$(date -d "1970-01-01 $START sec GMT " +%Y/%m/%d-%H:%M:%S)"
			fi
			STOP=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/stop)
			if [ -n "$STOP" ];then
				if [ "$C_FORM_DATE" == "ita" ];then
					STOP="$(date -d "1970-01-01 $STOP sec GMT " +%d/%m/%Y-%H:%M:%S)"
				else
					STOP="$(date -d "1970-01-01 $STOP sec GMT " +%Y/%m/%d-%H:%M:%S)"
				fi
			else
				STOP="$L_ACTIVE"
			fi
			RX=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/RX)
			RX_TOT=$(($RX_TOT+$RX))
			RX=$( echo "$RX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TX=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/TX)
			TX_TOT=$(($TX_TOT+$TX))
			TX=$( echo "$TX/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TRAFFIC=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/Traffic)
			TRAFFIC_TOT=$(($TRAFFIC_TOT+$TRAFFIC))
			TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
			TIME=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/Time)
			TIME_TOT=$(($TIME_TOT+$TIME))
			TIME=$( oraconv $TIME)
			COST=$(cat $C_ZT_DIR/expired/$USERNAME/sessions/$SESSION/Cost | awk '{printf("%.2f\n", $0)}')
			COST_TOT=$(echo "$COST_TOT+$COST" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
			echo "<tr BGCOLOR=\"$BG\"><td><center>$N</td><td><center>$IP/$MAC</td><td><center>$NAS</td><td><center>$START</td><td><center>$STOP</td>
			<td><center>$RX</td><td><center>$TX</td><td><center>$TRAFFIC</td><td><center>$TIME</td><td><center>$COST</td></tr>"
			let N=N+1
		done
		TIME_TOT=$( oraconv $TIME_TOT)
		RX_TOT=$( echo "$RX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
		TX_TOT=$( echo "$TX_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
		TRAFFIC_TOT=$( echo "$TRAFFIC_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
		echo "<tr ><td>&nbsp;</td><td>&nbsp;</td><td><center>&nbsp;</td><td><center>&nbsp;</td><td><center>&nbsp;</td>
		<td bgcolor=\"#8cc7f1\"><center>$RX_TOT</td><td bgcolor=\"#8cc7f1\"><center>$TX_TOT</td><td bgcolor=\"#8cc7f1\">
		<center>$TRAFFIC_TOT</td><td bgcolor=\"#8cc7f1\"><center>$TIME_TOT</td><td bgcolor=\"#8cc7f1\"><center>$COST_TOT</td></tr>
	</table>"
fi
./footer.sh
