#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#***************t*******************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
<script>
function BaseURL(protocol,port) {
  var host = location.hostname;
  if (protocol == 'https:') { port = port + 1000 };
  return protocol+"//"+host+":"+port;
}
</script>
</head><body>
EOF

if [ -n "$QUERY_STRING" ];then
	USERNAME="$(echo $QUERY_STRING | awk '{split ($0, a, "OjoK");print a['2']}')"
	PASSWORD="$(echo $QUERY_STRING | awk '{split ($0, a, "OjoK");print a['3']}')"
else
	exit
fi
DOMAIN="$(echo $HOSTNAME | cut -d'.' -f2,3,4)"
if [ -z "$C_REDIRECT_QR" ];then
	C_REDIRECT_QR="www.zerotruth.net"
fi

RED_URL=$(cat $C_CP_DIR/Auth/Custom/RedirectFree)
echo "<script type=\"text/javascript\">
location.href=\"http://$C_REDIRECT_QR?OjoKcXJyZXR1cm4KOjoK${USERNAME}OjoK${PASSWORD}OjoK${DOMAIN}\";
</script>"

echo "</body></html>"




