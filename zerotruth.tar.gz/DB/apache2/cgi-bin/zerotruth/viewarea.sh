#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/mudc/conf/mudc.config

if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
IPM="$( echo $HTTP_REFERER | cut -d'/' -f3 | cut -d'/' -f1 | cut -d':' -f1)"
CONTROLV="$( echo $HTTP_REFERER | cut -d'/' -f3 | cut -d'/' -f1 | cut -s -d':' -f2)"
if [[ -n "$CONTROLV" &&  "$CONTROLV" == "$CM_PORTSERVERVPN" ]];then
	$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_CONNECTVPN" "on"
	PORTCONTROL="$CM_PORTCONTROLVPN"
	PORT=CM_PORTVPN$cam
	eval PORT=\$$PORT
else
	PORTCONTROL="$CM_PORTCONTROL"
	PORT=CM_PORT$cam
	eval PORT=\$$PORT
fi
W="$(cat $CM_MUDC_DIR/conf/motion.conf | grep '^width' | cut -d' ' -f2)"
H="$(cat $CM_MUDC_DIR/conf/motion.conf | grep '^height' | cut -d' ' -f5)"
echo "<img src=\"http://$IPM:$PORT\" style=\"position:absolute;top:0;left:0;width:498px;height:336px;border:1px solid blue;\">"
sleep 2
for N in $(seq 1 9);do
	AREA=CM_AREA$cam$N
	eval AREA$N=\$$AREA
done
if [ -z "$AREA1" ];then
	echo "<div style=\"position:absolute;top:0;left:0;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA2" ];then
	echo "<div style=\"position:absolute;top:0;left:166;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA3" ];then
	echo "<div style=\"position:absolute;top:0;left:332;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA4" ];then
	echo "<div style=\"position:absolute;top:112;left:0;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA5" ];then
	echo "<div style=\"position:absolute;top:112;left:166;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA6" ];then
	echo "<div style=\"position:absolute;top:112;left:332;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA7" ];then
	echo "<div style=\"position:absolute;top:224;left:0;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi
if [ -z "$AREA8" ];then
	echo "<div style=\"position:absolute;top:224;left:166;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi	
if [ -z "$AREA9" ];then
	echo "<div style=\"position:absolute;top:224;left:332;width:166px;height:112px;background-color:blue;border:1px solid red;opacity: 0.5;\"></div>"
fi




