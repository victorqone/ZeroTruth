#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [ "$UTENTEC" != "$C_ADMIN" ];then
	return_page "index.sh"
	exit
fi
if [ -n "$QUERY_STRING" ];then
	getvarqs
fi

if [ -n "$REBOOT" ];then
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_REBOOT" ""
	return_page "index.sh"
	$C_ZT_BIN_DIR/zt "Reboot"
	exit
fi
if [ -n "$SHUTDOWN" ];then
	return_page "index.sh"
	$C_ZT_BIN_DIR/zt "Shutdown"
fi
#if [ -n "$(ls -d  $C_HTDOCS_DIR/BK_*)" ];then
#	$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_DIR/BK_*"
#fi

echo "<br><font color=\"#0000FF\" size=\"5\">$L_CONFIG1</font>
<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
<table   cellpadding=\"3\">
<tr>
<td valign=\"middle\"><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
<input type=\"submit\" class=\"bottoneconf\" value=\"Zerotruth\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
<input type=\"submit\" class=\"bottoneconf\" value=\"Captive Portal\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
<input type=\"submit\" class=\"bottoneconf\" value=\"Proxy\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"SHAPER\">
<input type=\"submit\" class=\"bottoneconf\" value=\"Shaper\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_BLOCKER\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"EMAIL\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_EMAIL\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
<input type=\"submit\" class=\"bottoneconf\" value=\"SMS\"></form></td>
</tr>
<tr>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
<input type=\"submit\" class=\"bottoneconf\" value=\"MultiCP\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_BACKUP\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"DISK\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_DISK\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_GRAPHS\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_ZT\">
<input type=\"submit\""
if [ "$C_FIX" == "on" ];then
	echo "class=\"bottoneconfv\""
else
	echo "class=\"bottoneconf\""
fi
echo "value=\"$L_MODIFY\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"REBOOT\" value=\"REBOOTOK\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_REBOOT\"
onClick=\"javascript:return confirm('$L_ALERT_REBOOT');\"></form></td>
<td><form action=\"config.sh\" method=\"POST\">
<input type=\"hidden\" name=\"SHUTDOWN\" value=\"SHUTDOWNOK\">
<input type=\"submit\" class=\"bottoneconf\" value=\"$L_SHUTDOWN\"
onClick=\"javascript:return confirm('$L_ALERT_SHUTDOWN');\">
</form>
</td></tr>
</table><br>"
if [[ "$SECTION" == "ZEROTRUTH" || -z "$SECTION" ]];then
	echo "<font color=\"#0000FF\" size=\"3\">Zerotruth</font><p>
	<table border=\"0\" align=\"center\" cellpadding=\"3\">
	<tr><td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Zerotruth\"></form></td>
	<td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ADMIN\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Admin\"></form></td>
	<td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Users\"></form></td>
	<td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"IMAGE\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"$L_IMAGES\"></form></td>
	<td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Asterisk\"></form></td>
	<td>
	<form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"LOG\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Log\"></form></td>
	</tr>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"MUDC\" class=\"bottoneconf\" value=\"Mudc\"></form></td>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CHECKLDAP\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"CHECK_LDAP\" class=\"bottoneconf\" value=\"LDAP\"></form></td>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"VSBS\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"CHECK_LDAP_REPAIR\" class=\"bottoneconf\" value=\"VSBS\"></form></td>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"EXPORT\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"EXPORT\" class=\"bottoneconf\" value=\"Export\"></form></td>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FONT\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"FONT\" class=\"bottoneconf\" value=\"$L_LANGUAGE/Font\"></form></td>
	<td>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TEST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
	<input type=\"submit\" name=\"FONT\" class=\"bottoneconf\" value=\"Test\"></form></td>
	</tr></table>"
	if [ -z "$SUB_SECTION" ];then
		if [ -n "$CONF_ZEROTRUTH" ];then
			wait "550"
			for CONF in "HOTSPOT_NAME"  "LANGUAGE";do
				if [ $(echo "${!CONF}" | grep '&') ];then
					$C_ZT_BIN_DIR/zt "Errore" "$L_DISALLOWED_CHAR" "config.sh?SECTION=ZEROTRUTH"
					exit
				fi
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
			done
			$C_ZT_BIN_DIR/zt "HttpdConf" "$HTTP_PORT" "$HTTPS_PORT"
			$C_ZT_BIN_DIR/zt "AggOrologio"
			$C_ZT_BIN_DIR/zt "AggCalendario"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_CP_DIR/msg/custom/*"
			$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_ZT_DIR/msg/$LANGUAGE/*" "$C_CP_DIR/msg/custom/"
			$C_ZT_BIN_DIR/zt "ConfigProxy"
			if [ -n "$($C_ZT_BIN_DIR/zt ControlActive dansguardian)" ]; then
				$C_ZT_PROXY_DIR/sbin/dansguardian -g
			fi
			return_page "config.sh?SECTION=ZEROTRUTH"
			exit
		fi
		if [ -n "$DELETE_REG" ];then
			$C_ZT_BIN_DIR/zt "DeleteCode"
			source $C_ZT_CONF_DIR/zt.config
		fi
		echo "<br><table border=\"1\"><tr><td align=\"center\">"
		$C_ZT_BIN_DIR/zt "InfoZT"
		echo "</td></tr></table>"
		echo "<p><form method=\"POST\" action=\"config.sh\">
		<table>
		<tr>
		<td>$L_NAME: </td>
		<td><input type=\"text\" style=\"width:100px\" name=\"HOTSPOT_NAME\" value=\"$C_HOTSPOT_NAME\"></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_LANGUAGE: </td>
		<td><select name=\"LANGUAGE\" style=\"width:100px\">"
		for LANG in $(ls -A ./language/);do
			if [ "$LANG" != "$C_LANGUAGE" ] && [ "$LANG" != "index.html" ];then
				LANG1=$LANG
				[ "$LANG" == "espanol" ] && LANG1="espa&ntilde;ol"
				[ "$LANG" == "portugues" ] && LANG1="portugu&ecirc;s"
				[ "$LANG" == "francais" ] && LANG1="fran&ccedil;ais"
				echo "<option value=\"$LANG\">$LANG1</option>"
			fi
		done
		LANGUAGE1=$C_LANGUAGE
		[ "$C_LANGUAGE" == "espanol" ] && LANGUAGE1="espa&ntilde;ol"
		[ "$C_LANGUAGE" == "portugues" ] && LANGUAGE1="portugu&ecirc;s"
		[ "$C_LANGUAGE" == "francais" ] && LANGUAGE1="fran&ccedil;ais"
		echo "<option value=\"$C_LANGUAGE\" selected>$LANGUAGE1</option></select>
		<br>&nbsp;</td></tr>
		<tr>
		<td>HTTP Port: </td>
		<td><input type=\"text\" style=\"width:100px\" name=\"HTTP_PORT\" value=\"$(cat $C_SYSTEM/httpd/HTTP)\"></td>
		<td>&nbsp;&nbsp;</td>
		<td>HTTPS Port: </td>
		<td><input type=\"text\" style=\"width:100px\" name=\"HTTPS_PORT\" value=\"$(cat $C_SYSTEM/httpd/HTTPS)\"></td></tr>
		</table>
		<font size=\"2\">($L_PORT_CHANGES)</font><br>
		<br><input type=\"submit\" name=\"CONF_ZEROTRUTH\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		if [ -n "$REG_CODE" ];then
			$C_ZT_BIN_DIR/zt "RegisterCode" "$CODE"
		else
			$C_ZT_BIN_DIR/zt "ControlCode"
		fi
		if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)"  ];then
			source $C_ZT_CONF_DIR/zt.config
			echo "<font color=\"blue\">Reg.: $C_CODE</font><br>
			<form method=\"POST\" action=\"config.sh\">
			<input type=\"submit\" name=\"DELETE_REG\" class=\"bottone\" value=\"$L_DELETE\"
			onClick=\"javascript:return confirm('$L_ALERT_DELETE_REG?');\"></form><br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "ADMIN" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">Admin</font><p>"
		if [ -n "$CONF_ZEROTRUTH" ];then
			wait "550"
			for CONF in "ADMIN" "ADMIN_PASSWORD" "ADMIN_EMAIL" "ADMIN_PHONE" "ADMIN_LOCK" "ADMIN_LOG";do
				if [ $(echo "${!CONF}" | grep '&') ];then
					$C_ZT_BIN_DIR/zt "Errore" "$L_DISALLOWED_CHAR" "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ADMIN"
					exit
				fi
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
			done
			if [ -n "$ADMIN_LOG" ];then
				if [ ! -d $C_ZT_LOG_DIR/users/admin ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_LOG_DIR/users/admin"
					$C_ZT_BIN_DIR/zt "Salva"  "" "$C_ZT_LOG_DIR/users/admin/admin_log"
				fi
			else
				$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_LOG_DIR/users/admin"
			fi
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ADMIN"
			exit
		fi
		if [ -n "$CONF_NOT_ADMIN" ];then
			wait "550"
			for CONF in "NOT_EMAIL_ADD_USER" "NOT_SMS_ADD_USER" "NOT_EMAIL_UPDATE_USER" "NOT_SMS_UPDATE_USER" "NOT_EMAIL_ADD_CLASS" \
				"NOT_SMS_ADD_CLASS" "NOT_EMAIL_UPDATE_CLASS" "NOT_SMS_UPDATE_CLASS" "NOT_EMAIL_MULTI_USERS" "NOT_SMS_MULTI_USERS" \
				"NOT_EMAIL_DELETE_USER" "NOT_SMS_DELETE_USER" "NOT_EMAIL_DELETE_CLASS" "NOT_SMS_DELETE_CLASS" "NOT_EMAIL_START_ZT" "NOT_SMS_START_ZT";do
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
			done
			if [ -d $C_ZT_DIR/mudc ];then
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_EMAIL_NOTUSED" "$EMAIL_NOTUSED"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_SMS_NOTUSED" "$SMS_NOTUSED"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_EMAIL_PTHERM" "$EMAIL_PTHERM"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_SMS_PTHERM" "$SMS_PTHERM"
			fi
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ADMIN"
			exit
		fi
		echo "<p><form method=\"POST\" action=\"config.sh\">
		<table class=\"naked\">
		<tr><td>$L_USERNAME: </td>
		<td><input type=\"text\" name=\"ADMIN\" value=\"$C_ADMIN\"></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_PASSWORD: </td>
		<td><input type=\"password\"  name=\"ADMIN_PASSWORD\" value=\"$C_ADMIN_PASSWORD\" id=\"pwd1\">
		&nbsp;<a href=\"#\" onclick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></td></tr>
		<tr><td>$L_EMAIL: </td>
		<td><input type=\"text\" name=\"ADMIN_EMAIL\" value=\"$C_ADMIN_EMAIL\"></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_PHONE: </td>
		<td><input type=\"text\" name=\"ADMIN_PHONE\" value=\"$C_ADMIN_PHONE\"></td></tr>
		<tr><td>$L_BLOCK_USERS: </td><td>"
		if [ -n "$C_ADMIN_LOCK" ];then
			echo "<input name=\"ADMIN_LOCK\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"ADMIN_LOCK\" type=\"checkbox\">"
		fi
		echo "</td>
		<td>&nbsp;&nbsp;</td>
		<td>Log:</td><td>"
		if [ -n "$C_ADMIN_LOG" ];then
			echo "<input name=\"ADMIN_LOG\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"ADMIN_LOG\" type=\"checkbox\">"
		fi
		echo "</td></tr></table><br>"
		if [ -n "$C_ADMIN_LOG" ];then
			echo "<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ADMIN\">
			<input type=\"submit\" name=\"CONF_ZEROTRUTH\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
			<form method=\"POST\" action=\"adminlog.sh\">
			<input type=\"submit\" name=\"ADMINLOG\" class=\"bottonelineadue\" value=\"Log\"></form><br>"
		else
			echo "<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ADMIN\">
			<input type=\"submit\" name=\"CONF_ZEROTRUTH\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		fi
		echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		echo "<font color=\"#0000FF\" size=\"3\">$L_NOTIFICATION_ADMIN</font><br>"
		if [[ -n "$C_EMAIL_ABIL" && -n "$C_ADMIN_EMAIL" ]] || [[ -n "$C_SMS_ABIL" && -n "$C_ADMIN_PHONE" ]];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<table WIDTH=\"350\">
				<tr>
					<td></td><td align=\"center\">"
					[[ -n "$C_EMAIL_ABIL" && -n "$C_ADMIN_EMAIL" ]] && EM="Email"
					[[ -n "$C_SMS_ABIL" && -n "$C_ADMIN_PHONE" ]] && SM="SMS"
					echo "$EM</td><td align=\"center\">
					$SM</td></tr>"
					echo "<tr><td height=\"30\">$L_USERADD: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_ADD_USER" == "on" ];then
							echo "<input name=\"NOT_EMAIL_ADD_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_ADD_USER\" type=\"checkbox\">";
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_ADD_USER" == "on" ];then
							echo "<input name=\"NOT_SMS_ADD_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_ADD_USER\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_USERMULTI: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_MULTI_USERS" == "on" ];then
							echo "<input name=\"NOT_EMAIL_MULTI_USERS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_MULTI_USERS\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_MULTI_USERS" == "on" ];then
							echo "<input name=\"NOT_SMS_MULTI_USERS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_MULTI_USERS\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_USERUPDATE: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_UPDATE_USER" == "on" ];then
							echo "<input name=\"NOT_EMAIL_UPDATE_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_UPDATE_USER\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_UPDATE_USER" == "on" ];then
							echo "<input name=\"NOT_SMS_UPDATE_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_UPDATE_USER\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_USERDELETE: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_DELETE_USER" == "on" ];then
							echo "<input name=\"NOT_EMAIL_DELETE_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_DELETE_USER\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_DELETE_USER" == "on" ];then
							echo "<input name=\"NOT_SMS_DELETE_USER\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_DELETE_USER\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_CLASSADD: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_ADD_CLASS" == "on" ];then
							echo "<input name=\"NOT_EMAIL_ADD_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_ADD_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_ADD_CLASS" == "on" ];then
							echo "<input name=\"NOT_SMS_ADD_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_ADD_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_CLASS_UPDATE: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_UPDATE_CLASS" == "on" ];then
							echo "<input name=\"NOT_EMAIL_UPDATE_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_UPDATE_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_UPDATE_CLASS" == "on" ];then
							echo "<input name=\"NOT_SMS_UPDATE_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_UPDATE_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_CLASSDELETE: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_DELETE_CLASS" == "on" ];then
							echo "<input name=\"NOT_EMAIL_DELETE_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_DELETE_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_DELETE_CLASS" == "on" ];then
							echo "<input name=\"NOT_SMS_DELETE_CLASS\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_DELETE_CLASS\" type=\"checkbox\">"
						fi
					fi
					echo "</td>
				</tr><tr>
					<td height=\"30\">$L_START_ZT: </td><td align=\"center\">"
					if [ "$C_EMAIL_ABIL" == "on" ];then
						if [ "$C_NOT_EMAIL_START_ZT" == "on" ];then
							echo "<input name=\"NOT_EMAIL_START_ZT\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_EMAIL_START_ZT\" type=\"checkbox\">"
						fi
					fi
					echo "</td><td align=\"center\">"
					if [ "$C_SMS_ABIL" == "on" ];then
						if [ "$C_NOT_SMS_START_ZT" == "on" ];then
							echo "<input name=\"NOT_SMS_START_ZT\" type=\"checkbox\" checked=\"checked\">"
						else
							echo "<input name=\"NOT_SMS_START_ZT\" type=\"checkbox\">"
						fi
					fi
						echo "</td></tr>"
					if [ -d $C_ZT_DIR/mudc ];then	
						echo "<tr>
						<td height=\"30\">$LM_PROGNOTUSED: </td><td align=\"center\">"
						if [ "$C_EMAIL_ABIL" == "on" ];then
							if [ "$CM_EMAIL_NOTUSED" == "on" ];then
								echo "<input name=\"EMAIL_NOTUSED\" type=\"checkbox\" checked=\"checked\">"
							else
								echo "<input name=\"EMAIL_NOTUSED\" type=\"checkbox\">"
							fi
						fi
						echo "</td><td align=\"center\">"
						if [ "$C_SMS_ABIL" == "on" ];then
							if [ "$CM_SMS_NOTUSED" == "on" ];then
								echo "<input name=\"SMS_NOTUSED\" type=\"checkbox\" checked=\"checked\">"
							else
								echo "<input name=\"SMS_NOTUSED\" type=\"checkbox\">"
							fi
						fi
							echo "</td></tr>"
						echo "<tr>
						<td height=\"30\">$LM_THERMP: </td><td align=\"center\">"
						if [ "$C_EMAIL_ABIL" == "on" ];then
							if [ "$CM_EMAIL_PTHERM" == "on" ];then
								echo "<input name=\"EMAIL_PTHERM\" type=\"checkbox\" checked=\"checked\">"
							else
								echo "<input name=\"EMAIL_PTHERM\" type=\"checkbox\">"
							fi
						fi
						echo "</td><td align=\"center\">"
						if [ "$C_SMS_ABIL" == "on" ];then
							if [ "$CM_SMS_PTHERM" == "on" ];then
								echo "<input name=\"SMS_PTHERM\" type=\"checkbox\" checked=\"checked\">"
							else
								echo "<input name=\"SMS_PTHERM\" type=\"checkbox\">"
							fi
						fi
							
					fi	
						
					
					echo "</tr>
			</table>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ADMIN\">
			<p><input type=\"submit\" name=\"CONF_NOT_ADMIN\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		else
			[ -z "$C_EMAIL_ABIL" ] && ALERTND="$L_NO_SERVICE_EMAIL <br> "
			[ -z "$C_ADMIN_EMAIL" ] && ALERTND="$ALERTND $L_NO_EMAIL_ADMIN <br>"
			[ -z "$C_SMS_ABIL" ] && ALERTND="$ALERTND $L_NO_SERVICE_SMS <br> "
			[ -z "$C_ADMIN_PHONE" ] && ALERTND="$ALERTND $L_NO_PHONE_ADMIN"
			echo "<br><font color=\"red\" size=\"3\">$ALERTND</font><p>"
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;<br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "USERS" ];then
		echo "<p><font color=\"blue\" size=\"3\">Users</font><p>"
		if [ -n "$CONF_USER" ];then
			if [ "$CONF_USER" == "$L_ADDUSER" ];then
				echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<p><font color=\"blue\" size=\"3\">$L_ADDUSER</font><p>
				<p><form method=\"POST\" action=\"config.sh\">
				<table class=\"naked\">
				<tr><td>$L_USERNAME: </td><td><input type=\"text\" name=\"USER\" value=\"\"></td>
				<td>&nbsp;&nbsp;</td>
				<td>$L_PASSWORD: </td>
				<td><input type=\"password\" name=\"PASSWORD\" value=\"\" id=\"pwd1\">
				&nbsp;<a href=\"#\" onclick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a>
				</td></tr></table>
				<p><form method=\"POST\" action=\"config.sh\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
				<input type=\"submit\" name=\"CONF_USER\" class=\"bottone\" value=\"$L_SAVE\"></form><br>&nbsp;"
				./footer.sh
				exit
			fi
			if [ "$CONF_USER" == "$L_SAVE" ];then
				if [[ -n "$(echo "$USER" | grep '%26')" || -n "$(echo "$PASSWORD" | grep '%26')" ]];then
					$C_ZT_BIN_DIR/zt "Errore" "$L_DISALLOWED_CHAR" "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=USERS"
					exit
				fi
				wait "550"
				if [ ! -d $C_ZT_CONF_DIR/Manager ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/Manager"
				fi
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/Manager/$USER"
				$C_ZT_BIN_DIR/zt "Salva" "$PASSWORD" "$C_ZT_CONF_DIR/Manager/$USER/PASSWORD"
				$C_ZT_BIN_DIR/zt "Salva" "DEFAULT" "$C_ZT_CONF_DIR/Manager/$USER/CLASS_USER"
				$C_ZT_BIN_DIR/zt "Salva" "24836" "$C_ZT_CONF_DIR/Manager/$USER/USER_EXPIRE"
				for CONF in  "DELETE_EXPIRED" "DISCONNECT_ALL" "DISCONNECT_USER" "EDIT_USERS" "GES_CLASS" "USER_EXPIRE"\
					"LOCK_ALL" "LOG_USER" "MULTI_USERS" "PREFIX_MULTI" "REGISTER_INFO" "REGISTER_USERS" "ROOM" "SEND_EMAIL" "PRINT_TICKET"\
					"SEND_SMS" "THEIR_USERS" "UNLOCK_ALL" "VIEW_RANGE" "VIEW_SMS_CREDIT" "UNLOCK_LOCK_USERS" "VIEW_HIDDEN" "USERS_FROM_TICKET";do
					$C_ZT_BIN_DIR/zt "Salva" "" "$C_ZT_CONF_DIR/Manager/$USER/$CONF"
				done
				for CONF in "CLASS" "DAYS" "HOURS" "LIMIT" "DELETE_USER" "CREDIT" "VIEW_DETAILS" "EXPIRE";do
					$C_ZT_BIN_DIR/zt "Salva" "on" "$C_ZT_CONF_DIR/Manager/$USER/$CONF"
				done
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=USERS"
				exit
			fi
			if [ -n "$DELUSER" ];then
				wait "550"
				$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/Manager/$DELUSER"
				if [ -z "$(ls $C_ZT_CONF_DIR/Manager 2>/dev/null)" ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/Manager"
				fi
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=USERS"
				exit
			fi
			if [ -n "$INTERFACE_USER" ];then
				wait "550"
				for CL in $(ls $C_CLASSES_DIR);do
					USER_CLASS="USER$CL"
					eval USER_CLASS="\$$USER_CLASS"
					if [ "$USER_CLASS" == "on" ];then
						USER_CLASSES="$USER_CLASSES $CL"
					fi
				done
				USER_CLASSES="$(echo $USER_CLASSES | sed 's/^ *//g')"
				$C_ZT_BIN_DIR/zt "Salva" "$USER_CLASSES" "$C_ZT_CONF_DIR/Manager/$USER/CLASS_USER"
				for CONF in "PASSWORD" "DELETE_EXPIRED" "DISCONNECT_ALL" "DISCONNECT_USER" "EDIT_USERS" "GES_CLASS" \
					"LOCK_ALL" "LOG_USER" "MULTI_USERS" "PREFIX_MULTI" "REGISTER_INFO" "REGISTER_USERS" "ROOM" "SEND_EMAIL" \
					"SEND_SMS" "THEIR_USERS" "UNLOCK_ALL" "VIEW_RANGE" "VIEW_SMS_CREDIT" "CLASS" "DAYS" "HOURS" "LIMIT" \
					"DELETE_USER" "CREDIT" "VIEW_DETAILS" "EXPIRE""CLASS" "DAYS" "HOURS" "LIMIT" "DELETE_USERS" "CREDIT" \
					"VIEW_DETAILS" "EXPIRE" "USER_EXPIRE" "UNLOCK_LOCK_USERS" "VIEW_HIDDEN" "USERS_FROM_TICKET" "PRINT_TICKET" "USER_MUDC" "USER_MUDCCCTV";do
					$C_ZT_BIN_DIR/zt "Salva" "${!CONF}" "$C_ZT_CONF_DIR/Manager/$USER/$CONF"
				done
				if [[ -n "$YEAR_EXPIRE" && -n "$MONTH_EXPIRE" && -n "$DAY_EXPIRE" ]];then
					EXP=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
					$C_ZT_BIN_DIR/zt "Salva" "$EXP" "$C_ZT_CONF_DIR/Manager/$USER/USER_EXPIRE"
				else
					$C_ZT_BIN_DIR/zt "Salva" "24836" "$C_ZT_CONF_DIR/Manager/$USER/USER_EXPIRE"
				fi
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=USERS&CONF_USER=yes&EDITUSER=$USER"
				exit
			fi
			if [ -n "$EDITUSER" ];then
				USER="$EDITUSER"
				for CONF in "PASSWORD" "DELETE_EXPIRED" "DISCONNECT_ALL" "DISCONNECT_USER" "EDIT_USERS" "GES_CLASS" \
					"LOCK_ALL" "LOG_USER" "MULTI_USERS" "PREFIX_MULTI" "REGISTER_INFO" "REGISTER_USERS" "ROOM" "SEND_EMAIL" \
					"SEND_SMS" "THEIR_USERS" "UNLOCK_ALL" "VIEW_RANGE" "VIEW_SMS_CREDIT" "CLASS"  "USER_MUDC" "USER_MUDCCCTV"\
					"DELETE_USER" "CREDIT" "VIEW_DETAILS" "EXPIRE" "CLASS" "DELETE_USERS" "CREDIT" \
					"VIEW_DETAILS" "EXPIRE" "USER_EXPIRE" "UNLOCK_LOCK_USERS" "VIEW_HIDDEN" "USERS_FROM_TICKET" "PRINT_TICKET";do
					eval "$CONF"="$(cat $C_ZT_CONF_DIR/Manager/$USER/$CONF)"
				done
				CLASS_USER="$(cat $C_ZT_CONF_DIR/Manager/$USER/CLASS_USER)"
				if [ -n "$LOG_USER" ];then
					if ! [ -f $C_ZT_LOG_DIR/users/$USER/$USER_log ];then
						$C_ZT_BIN_DIR/zt "CreaLog" "$USER"
					fi
				fi
				echo "<p><font color=\"#0000FF\" size=\"3\">$L_INTERFACE $USER</font><p>
				<form method=\"POST\" action=\"config.sh\">
				$L_PASSWORD: <input id=\"pwd1\" size=\"15\" type=\"password\" name=\"PASSWORD\" value=\"$PASSWORD\">&nbsp;
				<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\">
				<img src=\"/images/show.png\" alt=\"show\"></a><p>
				<table class=\"naked\"><tr>
				<td>$L_USER_PERM_EXP:&nbsp;</td><td>"
				if [ "$EXPIRE" == "on" ];then
					echo "<input name=\"EXPIRE\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"EXPIRE\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_USER_PERM_CLASS:&nbsp;</td><td>"
				if [ "$CLASS" == "on" ];then
					echo "<input name=\"CLASS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"CLASS\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_VIEW_DETAILS:&nbsp;</td><td>"
				if [ "$VIEW_DETAILS" == "on" ];then
					echo "<input name=\"VIEW_DETAILS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"VIEW_DETAILS\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_DELETE_USER:&nbsp;</td><td>"
				if [ "$DELETE_USER" == "on" ];then
					echo "<input name=\"DELETE_USER\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DELETE_USER\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_ALLOW_DELETE_EXPIRED:&nbsp;</td><td>"
				if [ "$DELETE_EXPIRED" == "on" ];then
					echo "<input name=\"DELETE_EXPIRED\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DELETE_EXPIRED\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_LOCK_ALL:&nbsp;</td><td>"
				if [ "$LOCK_ALL" == "on" ];then
					echo "<input name=\"LOCK_ALL\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"LOCK_ALL\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_ALLOW_UNLOCK_ALL:&nbsp;</td><td>"
				if [ "$UNLOCK_ALL" == "on" ];then
					echo "<input name=\"UNLOCK_ALL\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"UNLOCK_ALL\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_DISCONNECT_ALL:&nbsp;</td><td>"
				if [ "$DISCONNECT_ALL" == "on" ];then
					echo "<input name=\"DISCONNECT_ALL\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DISCONNECT_ALL\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_ALLOW_LOCK_USER:&nbsp;</td><td>"
				if [ "$UNLOCK_LOCK_USERS" == "on" ];then
					echo "<input name=\"UNLOCK_LOCK_USERS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"UNLOCK_LOCK_USERS\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_DISCONNECT_USER:&nbsp;</td><td>"
				if [ "$DISCONNECT_USER" == "on" ];then
					echo "<input name=\"DISCONNECT_USER\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DISCONNECT_USER\" type=\"checkbox\">"
				fi

				echo "</td></tr><tr>
				<td>$L_ALLOW_REGISTER_USER:&nbsp;</td><td>"
				if [ "$REGISTER_USERS" == "on" ];then
					echo "<input name=\"REGISTER_USERS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"REGISTER_USERS\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_EDIT_USERS:&nbsp;</td><td>"
				if [ "$EDIT_USERS" == "on" ];then
					echo "<input name=\"EDIT_USERS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"EDIT_USERS\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_ALLOW_REGISTER_INFO:&nbsp;</td><td>"
				if [ "$REGISTER_INFO" == "on" ];then
					echo "<input name=\"REGISTER_INFO\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"REGISTER_INFO\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_ALLOW_VIEW_HIDDEN:&nbsp;</td><td>"
				if [ "$VIEW_HIDDEN" == "on" ];then
					echo "<input name=\"VIEW_HIDDEN\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"VIEW_HIDDEN\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_GES_CLASS:&nbsp;</td><td>"
				if [ "$GES_CLASS" == "on" ];then
					echo "<input name=\"GES_CLASS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"GES_CLASS\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_MULTI_USERS:&nbsp;</td><td>"
				if [ "$MULTI_USERS" == "on" ];then
					echo "<input name=\"MULTI_USERS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"MULTI_USERS\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				<td>$L_USER_PERM_PREFIX:&nbsp;</td><td>"
				if [ "$PREFIX_MULTI" == "on" ];then
					echo "<input name=\"PREFIX_MULTI\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"PREFIX_MULTI\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>"
				if [ "$C_CP_LOCAL_TYPE" != "Server" ];then
					echo "$L_USER_ROOMS:&nbsp;</td><td>"
					if [ "$ROOM" == "on" ];then
						echo "<input name=\"ROOM\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"ROOM\" type=\"checkbox\">"
					fi
				else
					echo "$L_ALLOW_USE_USERS:&nbsp;</td><td>"
					if [ "$THEIR_USERS" == "on" ];then
						echo "<input name=\"THEIR_USERS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"THEIR_USERS\" type=\"checkbox\">"
					fi
				fi
				echo "</td></tr><tr>
				<td>$L_USER_PERM_EMAIL:&nbsp;</td><td>"
				if [ "$SEND_EMAIL" == "on" ];then
					echo "<input name=\"SEND_EMAIL\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"SEND_EMAIL\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_USER_PERM_SMS:&nbsp;</td><td>"
				if [ "$SEND_SMS" == "on" ];then
					echo "<input name=\"SEND_SMS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"SEND_SMS\" type=\"checkbox\">"
				fi
				echo "</td><tr></tr><tr>
				<td>$L_USER_PERM_RANGE:&nbsp;</td><td>"
				if [ "$VIEW_RANGE" == "on" ];then
					echo "<input name=\"VIEW_RANGE\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"VIEW_RANGE\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_USER_PERM_VIEW_CREDIT:&nbsp;</td><td>"
				if [ "$VIEW_SMS_CREDIT" == "on" ];then
					echo "<input name=\"VIEW_SMS_CREDIT\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"VIEW_SMS_CREDIT\" type=\"checkbox\">"
				fi
				echo "</td><tr></tr><tr>"
				if [ "$C_CP_LOCAL_TYPE" != "Server" ];then
					echo "<td>$L_ALLOW_USE_USERS:&nbsp;</td><td>"
					if [ -n "$THEIR_USERS" ];then
						echo "<input name=\"THEIR_USERS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"THEIR_USERS\" type=\"checkbox\">"
					fi
					echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td>$L_USER_PERM_PRINT_TICKET:&nbsp;</td><td>"
					if [ -n "$PRINT_TICKET" ];then
						echo "<input name=\"PRINT_TICKET\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"PRINT_TICKET\" type=\"checkbox\">"
					fi
					echo "</td></tr><tr>"
				fi
				echo "<td>$L_USERS_FROM_TICKET:&nbsp;</td><td>"
				if [ "$USERS_FROM_TICKET" == "on" ];then
					echo "<input name=\"USERS_FROM_TICKET\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"USERS_FROM_TICKET\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>$L_USER_PERM_CREDIT:&nbsp;</td><td>"
				if [ "$CREDIT" == "on" ];then
					echo "<input name=\"CREDIT\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"CREDIT\" type=\"checkbox\">"
				fi
				echo "</td><tr></tr><tr>"
				
				if [ -n "$C_MUDC" ];then
					echo "<td>$L_USER_MUDC:&nbsp;</td><td>"
					if [ "$USER_MUDC" == "on" ];then
						echo "<input name=\"USER_MUDC\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"USER_MUDC\" type=\"checkbox\">"
					fi
					echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
					
					echo "<td>$L_USER_MUDCCCTV:&nbsp;</td><td>"
					if [ "$USER_MUDCCCTV" == "on" ];then
						echo "<input name=\"USER_MUDCCCTV\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"USER_MUDCCCTV\" type=\"checkbox\">"
					fi
					echo "</td><tr></tr><tr>"
				fi
				
				echo "<td>$L_LOG_USER:&nbsp;</td><td>"
				if [ "$LOG_USER" == "on" ];then
					echo "<input name=\"LOG_USER\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"LOG_USER\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>$L_EXPIRY:"
				YNOW=$(date +%Y)
				YEND=$(($YNOW+10))
				if [[ -z "$USER_EXPIRE" || "$USER_EXPIRE" == "24836" ]];then
					DAY_EXPIRE="$L_DAY"
					DAY_EXPIRE1=""
					MONTH_EXPIRE="$L_MONTH"
					MONTH_EXPIRE1=""
					YEAR_EXPIRE="$L_YEAR"
					YEAR_EXPIRE1=""
				else
					DAY_EXPIRE=$(date -d "1970-01-01 $USER_EXPIRE days" +%d)
					DAY_EXPIRE1="$DAY_EXPIRE"
					MONTH_EXPIRE=$(date -d "1970-01-01 $USER_EXPIRE days" +%m)
					MONTH_EXPIRE1="$MONTH_EXPIRE"
					YEAR_EXPIRE=$(date -d "1970-01-01 $USER_EXPIRE days" +%Y)
					YEAR_EXPIRE1="$YEAR_EXPIRE"
				fi
				if [ "$C_FORM_DATE" == "ita" ];then
					echo "<select name=\"DAY_EXPIRE\">"
					for G in $(seq 1 31);do
						echo "<option value=\"$G\" selected>$G</option>"
					done
					echo "<option value=\"\"></option>
					<option value=\"$DAY_EXPIRE1\" selected>$DAY_EXPIRE</option></select>
					<select name=\"MONTH_EXPIRE\">"
					for M in $(seq 1 12);do
						echo "<option value=\"$M\" selected>$M</option>"
					done
					echo "<option value=\"\" ></option>
					<option value=\"$MONTH_EXPIRE1\" selected>$MONTH_EXPIRE</option></select>
					<select name=\"YEAR_EXPIRE\">"
					for A in $(seq $YNOW $YEND);do
						echo "<option value=\"$A\" selected>$A</option>"
					done
					echo "<option value=\"\" ></option>
					<option value=\"$YEAR_EXPIRE1\" selected>$YEAR_EXPIRE</option></select>"
				else
					echo "<select name=\"YEAR_EXPIRE\">"
					for A in $(seq $YNOW $YEND);do
						echo "<option value=\"$A\" selected>$A</option>"
					done
					echo "<option value=\"\"></option>
					<option value=\"$YEAR_EXPIRE1\" selected>$YEAR_EXPIRE</option></select>
					<select name=\"MONTH_EXPIRE\">"
					for M in $(seq 1 12);do
						echo "<option value=\"$M\" selected>$M</option>"
					done
					echo "<option value=\"\"></option>
					<option value=\"$MONTH_EXPIRE1\" selected>$MONTH_EXPIRE</option></select>
					<select name=\"DAY_EXPIRE\">"
					for G in $(seq 1 31);do
						echo "<option value=\"$G\" selected>$G</option>"
					done
					echo "<option value=\"\"></option>
					<option value=\"$DAY_EXPIRE1\" selected>$DAY_EXPIRE</option></select>"
				fi
				echo "</td><td></td>
				</tr></table><p>
				<table width=\"600px\"><tr>
				<td colspan=\"4\" align=\"center\">$L_ALLOW_USE_CLASSES:<br>&nbsp;</td></tr><tr>"
				NCL=0
				CLN=1
				for CL in $(ls $C_CLASSES_DIR);do
					NCL=$(($NCL+1))
					echo "<td>$CL "
					if [ -n "$(echo $CLASS_USER  | grep "$CL")"  ];then
						echo "<input name=\"USER$CL\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"USER$CL\" type=\"checkbox\">"
					fi
					echo "</td>"
					if [ "$NCL" == "4" ];then
						echo "</tr><tr>"
					fi
					CLN=$(($CLN+1))
				done
				echo "</table>"
				if [ -f $C_ZT_LOG_DIR/users/$USER/${USER}_log ];then
					BOTT="bottonelineatre"
				else
					BOTT="bottonelinea"
				fi
				echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<input type=\"hidden\" name=\"USER\" value=\"$USER\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
				<input type=\"hidden\" name=\"CONF_USER\" value=\"yes\">
				<p><input type=\"submit\" name=\"INTERFACE_USER\" class=\"$BOTT\" value=\"$L_SAVE\"></form>"
				if [ -f $C_ZT_LOG_DIR/users/$USER/${USER}_log ];then
					echo "<form method=\"GET\" action=\"userlog.sh\">
					<input type=\"HIDDEN\" name=\"user\" value=\"$C_USER\">
					<input type=\"HIDDEN\" name=\"EDIT_USER\" value=\"$number\">
					<input type=\"submit\" class=\"bottonelineadue\" value=\"Log\"></form>"
				fi
				echo "<form method=\"POST\" action=\"config.sh\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
				<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><p><br><br><br>"
				./footer.sh
				exit
			fi
		fi
		if [ -n "$(ls $C_ZT_CONF_DIR/Manager/*)" ];then
			echo "<table class=\"tabellaldap\"  border=\"1\">"
			echo "<td class=\"intesta\" width=\"1%\">N.</td>
			<td class=\"intesta\" width=\"45%\">Username</td>
			<td class=\"intesta\" width=\"45%\">Password</td>
			<td class=\"intesta\" width=\"1%.\">S</td>
			<td class=\"intesta\" width=\"5%\" colspan=\"2\">A.</td></tr>"
			NU=1
			NOW=$(date +%s)
			for USER in $(ls $C_ZT_CONF_DIR/Manager);do
				PASSWORD="$(cat $C_ZT_CONF_DIR/Manager/$USER/PASSWORD)"
				USER_EXPIRE="$(cat $C_ZT_CONF_DIR/Manager/$USER/USER_EXPIRE)"
				EXP="no"
				if [ -n "$USER_EXPIRE" ];then
					USER_EXPIRE=$(date -d "1970-01-01 $USER_EXPIRE days" +%s)
					[ "$NOW" -gt "$USER_EXPIRE" ] && EXP="yes"
				fi
				echo "<tr><td>$NU</td>
				<td>&nbsp;$USER</td>
				<td><div id=\"pwd$NU\">
				<a href=\"#\" onclick=\"hidden_passwordline('pwd$NU','$PASSWORD','show','hide', '$NU');\" id=\"showhide$NU\">
				&nbsp;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</a>
				</div></td>"
				if [ "$EXP" != "yes" ];then
					echo "<td><img src=\"/images/abilita.png\"></td>"
				else
					echo "<td><img src=\"/images/disabilita.png\"></td>"
				fi
				echo "<td><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
				<input type=\"hidden\" name=\"CONF_USER\" value=\"yes\">
				<input type=\"hidden\" name=\"DELUSER\" value=\"$USER\">
				<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
				onClick=\"javascript:return confirm('$L_ALERT_REMOVE $USER?');\"></form></td>
				<td><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
				<input type=\"hidden\" name=\"CONF_USER\" value=\"yes\">
				<input type=\"hidden\" name=\"EDITUSER\" value=\"$USER\">
				<input type=\"image\" class=\"image\" src=\"/images/edit.png\"></form></td>
				</tr>"
				NU=$(($NU+1))
			done
			echo "</table>"
		fi
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<p><form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"USERS\">
		<input type=\"submit\" name=\"CONF_USER\" class=\"bottone\" value=\"$L_ADDUSER\"></form><br>&nbsp;"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "IMAGE" ];then
		if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
			$C_ZT_BIN_DIR/zt "PerFile" "root" "666" "$C_HTDOCS_DIR/images/base.png"
			echo "<p><font color=\"#0000FF\" size=\"3\">Logo (997 X 120 px)</font><p>
			<img src=\"/images/base.png?$RANDOM\" WIDTH=\"725\" HEIGHT=\"93\" border=\"1\" alt=\"base\">
			<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
			<input type=\"hidden\" name=\"config\" value=\"Logo\">
			<input type=\"hidden\" name=FileName value=\"base.png\">
			<input type=\"file\" name=\"imagetest\" size=\"40\"><p>
			<input  type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\">
			</form>
			<p><img src=\"/images/barra.png\" alt=\"barra\" alt=\"barra\"><p>"
			$C_ZT_BIN_DIR/zt "PerFile" "root" "666" "$C_HTDOCS_DIR/images/imguser.png"
			$C_ZT_BIN_DIR/zt "PerFile" "root" "666" "$C_HTDOCS_DIR/zerotruth/images/template/imguser.png"
			echo "<p><font color=\"#0000FF\" size=\"3\">$L_MAIN_IMAGE (725 X 97 px)</font><p>
			<img src=\"/images/imguser.png?$RANDOM\" WIDTH=\"725\" HEIGHT=\"93\" border=\"1\" alt=\"imguser\">
			<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
			<input type=\"hidden\" name=FileName value=\"imguser.png\">
			<input type=\"file\" name=\"imagetest\" size=\"40\"><p>
			<input type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\">
			</form>"
			source $C_HTDOCS_ZT_DIR/template/conf/templateconf.sh
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<p><font color=\"#0000FF\" size=\"3\">Template $L_CP_IMAGE ($PX_IMG_WIDTH X $PX_IMG_HEIGHT px)</font><p>
			<img src=\"/zerotruth/images/template/imguser.png?$RANDOM\" style=\"width:=$PX_IMG_WIDTHpx; height:$PX_IMG_HEIGHTpx;\" border=\"1\" alt=\"imguser\" id=\"tiu\">
			<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
			<input type=\"hidden\" name=\"config\" value=\"ImgLogin\">
			<input type=\"hidden\" name=FileName value=\"imguser.png\">
			<input type=\"file\" name=\"imagetest\" size=\"40\"><p>
			<input type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\">
			</form><br>"
			
			./footer.sh
			exit
		else
			echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ALERT</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
			./footer.sh
			exit
		fi
		
	fi
	if [ "$SUB_SECTION" == "ASTERISK" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">Asterisk</font><p>"
		if [ -n "$STOPASTERISK" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "AsteriskStop" 
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ASTERISK"
			exit
		fi
		if [ -n "$STARTASTERISK" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "AsteriskStart" 
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ASTERISK"
			exit
		fi
		if [ -n "$RESTARTASTERISK" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "AsteriskRestart" 
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=ASTERISK"
			exit
		fi
		if [ -f /opt/asterisk/sbin/asterisk ];then
			if [ -z "$(cat /etc/ld.so.conf | grep 'jansson')" ];then
				$C_ZT_BIN_DIR/zt "ConfLibAsterisk"
			fi
			if [ -d $C_ZT_DIR/mudc ];then
				LINKSCRIPTS="Scripts"
			else
				LINKSCRIPTS="zerotruth.net"
			fi
			echo "<table border=\"0\" align=\"center\" cellpadding=\"3\">
			<tr>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"STARTASTERISK\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"Start\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"RESTARTASTERISK\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"Restart\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"STOPASTERISK\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"Stop\"></form></td>
			</tr>
			<tr>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"SIPCONF\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"sip.conf\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"EXTENSIONSCONF\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"extensions.conf\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"ZEROTRUTHSH\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"$LINKSCRIPTS\"></form></td>
			</tr>
			</table>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			if [[ -z "$SIPCONF" && -z "$EXTENSIONSCONF" && -z "$ZEROTRUTHSH" ]];then
				PIDASTERISK="$(pidof asterisk)"
				TEL="$(cat /opt/asterisk/etc/asterisk/sip.conf | sed -n '/];/p' |  cut -d']' -f1 | sed 's/\[//g')"
				NTEL="$(echo $TEL | wc -w | awk '{print $1}')"
				echo "<table class=\"tabellain\"  border=\"1\">
				<tr><td class=\"intesta\">&nbsp;&nbsp;&nbsp;Asterisk&nbsp;&nbsp;&nbsp;</td>"
				for N in $(seq 1 $NTEL);do
					echo "<td class=\"intesta\">&nbsp;&nbsp;&nbsp;$(echo $TEL | cut -d' ' -f$N)&nbsp;&nbsp;&nbsp;</td>"
				done
				echo "<tr><td align=\"center\">"			
				if [ -n "$PIDASTERISK" ];then
					echo "<img src=\"/images/abilita.png\"></td>"
				else
					echo "<img src=\"/images/disabilita.png\"</td>"
				fi
				for N in $(seq 1 $NTEL);do
					echo "<td align=\"center\">"
					TELP="$(echo $TEL | cut -d' ' -f$N)"
					$C_ZT_BIN_DIR/zt "StatusPeer" "$TELP"
				done
				echo "</tr></table><p>
				<form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"submit\" name=\"ACT_BOOT\" class=\"bottoneconf\" value=\"$L_MODIFY\"></form>"
			fi
			
			if [ -n "$SIPCONF" ];then
				echo "<form action=\"config.sh\" method=\"POST\">
				<p>sip.conf<br><textarea name=\"CONF_SIP\" rows=\"20\" cols=\"80\">$(cat /opt/asterisk/etc/asterisk/sip.conf)</textarea><p>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
				<input type=\"hidden\" name=\"SIPCONF\" value=\"yes\">
				<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
				<form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
			fi
			if [ -n "$EXTENSIONSCONF" ];then
				echo "<form action=\"config.sh\" method=\"POST\">
				<p>extensions.conf<br><textarea name=\"CONF_EXTENSIONS\" rows=\"20\" cols=\"80\">$(cat /opt/asterisk/etc/asterisk/extensions.conf)</textarea><p>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"hidden\" name=\"EXTENSIONSCONF\" value=\"yes\">
				<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
				<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
				<form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
			fi
			if [ -n "$ZEROTRUTHSH" ];then
				echo "<form action=\"config.sh\" method=\"POST\">
				<p>zerotruth.sh<br><textarea name=\"CONF_ZEROTRUTH\" rows=\"20\" cols=\"80\">$(cat /opt/asterisk/var/lib/asterisk/agi-bin/zerotruth.sh)</textarea><p>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"hidden\" name=\"ZEROTRUTHSH\" value=\"yes\">
				<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
				<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
				<form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
				<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
				if [ -d $C_ZT_DIR/mudc ];then
					if ! [ -f /opt/asterisk/var/lib/asterisk/agi-bin/openDoor.sh ];then
						$C_ZT_BIN_DIR/zt "Salva" "$(cat $C_ZT_DIR/mudc/scripts/openDoor.sh)" "/opt/asterisk/var/lib/asterisk/agi-bin/openDoor.sh"
					fi
					echo "<form action=\"config.sh\" method=\"POST\">
					<p>openDoor.sh<br><textarea name=\"CONF_OPENDOOR\" rows=\"20\" cols=\"80\">$(cat /opt/asterisk/var/lib/asterisk/agi-bin/openDoor.sh)</textarea><p>
					<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
					<input type=\"hidden\" name=\"ZEROTRUTHSH\" value=\"yes\">
					<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
					<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
					<form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ASTERISK\">
					<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
				fi				
			fi
			./footer.sh
			exit
		else
			echo "<br>&nbsp;<br><font color=\"blue\">$L_ALERT_AST</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			./footer.sh
			exit
		fi
	fi
	if [ "$SUB_SECTION" == "FONT" ];then
		echo "<p><font color=\"blue\" size=\"3\">$L_LANGUAGE/Font</font>"
		if [ -n "$LANGUAGE" ];then
			wait "550"
			./footer
			sleep 2
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=FONT"
			exit
		fi
		if [ -n "$CONF_FONT" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FONT_USERS" "$FONT_USERS"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FONT_SEARCH" "$FONT_SEARCH"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FONT_TICKET" "$FONT_TICKET"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FONT_TICKET_INFO" "$FONT_TICKET_INFO"
			./footer
			sleep 2
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=FONT"
			exit
		fi

		echo "<br>&nbsp;<br><form method=\"POST\" action=\"config.sh\">
		<table>
		<tr>
		<td>$L_FONT_USERS (px): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><select name=\"FONT_USERS\">"
		for nu in $(seq 10 16);do
			if [ "$nu" != "$C_FONT_USERS" ];then
				echo "<option value=\"$nu\">$nu</option>"
			fi
		done
		echo "<option NAME=\"$C_FONT_USERS\" selected>$C_FONT_USERS</option>
		</select></td></tr>
		<tr>
		<td>$L_FONT_SEARCH (px): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><select name=\"FONT_SEARCH\">"
		for nu in $(seq 10 16);do
			if [ "$nu" != "$C_FONT_SEARCH" ];then
				echo "<option value=\"$nu\">$nu</option>"
			fi
		done
		echo "<option NAME=\"$C_FONT_SEARCH\" selected>$C_FONT_SEARCH</option>
		</select></td></tr>
		<tr>
		<td>Font $L_TICKET (px): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><select name=\"FONT_TICKET\">"
		for nu in $(seq 10 24);do
			if [ "$nu" != "$C_FONT_TICKET" ];then
				echo "<option value=\"$nu\">$nu</option>"
			fi
		done
		echo "<option NAME=\"$C_FONT_TICKET\" selected>$C_FONT_TICKET</option>
		</select></td></tr>
		<tr>
		<td>Font $L_TICKET info(px): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><select name=\"FONT_TICKET_INFO\">"
		for nu in $(seq 10 24);do
			if [ "$nu" != "$C_FONT_TICKET_INFO" ];then
				echo "<option value=\"$nu\">$nu</option>"
			fi
		done
		echo "<option NAME=\"$C_FONT_TICKET_INFO\" selected>$C_FONT_TICKET_INFO</option>
		</select></td></tr>
		</table><br>&nbsp;<br>
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FONT\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"CONF_FONT\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		if [ "$C_LANGUAGE" != "italiano" ];then
			echo "Please send corrections or new translations to truthahn@zerotruth.net<br>"
		fi
		echo "<form action=\"config.sh\" method=\"POST\">
		<p>Zerotruth $C_LANGUAGE.sh<br><textarea name=\"CONF_LANGUAGE\" rows=\"20\" cols=\"110\">$(cat $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh | sed 's/&/&amp/g')</textarea><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FONT\">
		<input type=\"hidden\" name=\"LANGUAGE\" value=\"yes\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<br>&nbsp;"
		if [ -d $C_ZT_DIR/mudc ];then
			echo "<img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<form action=\"config.sh\" method=\"POST\">
			<p>MUDC $C_LANGUAGE.sh<br><textarea name=\"CONF_LANGUAGEMUDC\" rows=\"20\" cols=\"110\">$(cat $C_ZT_DIR/mudc/language/$C_LANGUAGE/$C_LANGUAGE.sh | sed 's/&/&amp/g')</textarea><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FONT\">
			<input type=\"hidden\" name=\"LANGUAGE\" value=\"yes\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_SAVE\"></form>
			<br>&nbsp;"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "MUDC" ];then
		echo "<p><font color=\"blue\">MUDC</font><p>"
		if [ -n "$INSTALL_MUDC" ];then
			if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
				wait "550"
				$C_ZT_BIN_DIR/zt "installMUDC"
				sleep 1
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC"
				exit
			else
				echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ZT</font><br>
				<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<form action=\"config.sh\" method=\"POST\">
				<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
				./footer.sh
			exit
			fi
		fi
		
		if [ ! -d $C_ZT_DIR/mudc ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"submit\" name=\"INSTALL_MUDC\" class=\"bottone\" value=\"$L_INSTALL MUDC\"
			onClick=\"javascript:return confirm('$L_ALERT_INSTALL_MUDC');\"></form>"
			./footer.sh
			exit
		fi
		if [ -n "$C_REBOOT" ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;<br>$L_REBOOT_NOTICE<br>&nbsp;<br>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\" name=\"REBOOT\" class=\"bottone\" value=\"$L_REBOOT\"
			onClick=\"javascript:return confirm('$L_ALERT_REBOOT');\"></form>"
			./footer.sh
			exit
		fi
		if [ -n "$START_MUDC" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_MUDC" "$MUDC"
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_MUDC" "$MUDC"
			if [ -z "$MUDC" ];then
				$C_ZT_BIN_DIR/zt "mudc" "KillMotion"
			fi
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC"
			exit
		fi
		if [ -n "$RELCHECK" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			sleep 2
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_HEATING" "$CMHEATING"
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_DOOROPENERS" "$CMDOOROPENERS"
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_HEATINGPAUSE" "$CMHEATINGPAUSE"
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_DOOROPENERSUSER" "$DOOROPENERSUSER"
			[[ -n "$CMHEATING" && -n "$CMHEATINGPAUSE" ]] && $C_ZT_BIN_DIR/zt "mudc" "StopTherm"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=$SUBSUB_SECTION"
			exit
		fi
		if [ -n "$MUDCCONF" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			sleep 2
			VAR="$(echo $POST | cut -d'=' -f1)"
			VAL="$(echo $POST | cut -d'=' -f2 | cut -d'&' -f1 | sed 's/+/ /g')"
			[ "$VAR" != "SECTION" ] && $C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "$VAR" "$VAL"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=$SUBSUB_SECTION"
			exit
		fi
		if [ -n "$MUDCTEMPMIN" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			sleep 2
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TMIN" "$CM_TMIN"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=$SUBSUB_SECTION"
			exit
		fi
		if [ -n "$CM_MUDC" ];then
			echo "<table   cellpadding=\"3\">
			<tr><td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"Relays\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"$LM_CCTV\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"KEYPAD\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"$LM_KEYPAD\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DEVICES\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"Devices\"></form></td>
			<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"TICKET\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"$LM_TICKET\"></form></td>"

			if [[ -n "$C_EMAIL_ABIL" && -n "$C_SEND_EMAIL" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_EMAIL_ABIL" ]];then
				CEMAIL="YES"
			fi
			if [[ -n "$C_SMS_ABIL" && -n "$C_SEND_SMS" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_SMS_ABIL" ]] ;then
				if [ "$C_SMS_PROVIDER" != "Gammu" ] || [[ "$C_SMS_PROVIDER" == "Gammu" && -n "$C_SEND_SMS_GAMMU" ]];then
					CSMS="yes"
				fi
			fi
			if [[ -n "$CEMAIL" || -n "$CSMS" ]];then
				[[ -n "$CEMAIL" && -n "$CSMS" ]] && SC="$L_EMAIL/SMS"
				[[ -n "$CEMAIL" && -z "$CSMS" ]] && SC="$L_EMAIL"
				[[ -z "$CEMAIL" && -n "$CSMS" ]] && SC="SMS"
				echo "<td><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"EMAIL\">
				<input type=\"submit\" class=\"bottoneconf\" value=\"$SC\"></form></td>"
			fi
			if [ -n "$CM_DOOROPENERS" ];then
				echo "<td><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DOOROPENERS\">
				<input type=\"submit\" class=\"bottoneconf\" value=\"$LM_DOOROPENERS\"></form></td>"
			fi
			echo "</tr></table><br>"
		fi
		if [[ "$SUBSUB_SECTION" == "MUDCCONF" || -z "$SUBSUB_SECTION" ]];then
		
			echo "<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">"
			echo "$L_ACTIVE_SERVICE:&nbsp;"
			if [ -n "$C_MUDC" ];then
				echo "<input name=\"MUDC\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"MUDC\" type=\"checkbox\">"
			fi
			echo "<p><input type=\"submit\" name=\"START_MUDC\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
			if [ -n "$C_MUDC" ];then
				echo "<img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;<br>"
			fi
		fi
		if [ "$SUBSUB_SECTION" == "RELAYS" ];then
			TEMPERATURE="$($C_ZT_BIN_DIR/zt "mudc" "Temperaturedec")"
			echo "<br><font color=\"#0000FF\" size=\"5\">Relays</font><p>"
			echo "<div id=ris>
			<form name=\"RELCHECK\" action=\"./config.sh\" method=\"POST\">"
			echo "<table width=\"80%\">
			<tr><td style=\"text-align:center;\">$LM_HEATING
			<input name=\"CMHEATING\" type=\"checkbox\""
			[ "$CM_HEATING" == "on" ] && echo "checked=\"checked\""
			echo "></td>
			<td style=\"text-align:center;\">$LM_HEATINGPAUSE
			<input name=\"CMHEATINGPAUSE\" type=\"checkbox\""
			[ "$CM_HEATINGPAUSE" == "on" ] && echo "checked=\"checked\""
			echo "></td>
			<td style=\"text-align:center;\">$LM_DOOROPENERS
			<input name=\"CMDOOROPENERS\" type=\"checkbox\" id=\"DOP\" onclick=\"showDOP(this);\""
			[ "$CM_DOOROPENERS" == "on" ] && echo "checked=\"checked\""
			echo "></td>"
			if [ -n "$CM_DOOROPENERS" ];then
				OPEN=""
			else
				OPEN="none"
			fi
			echo "<td id=\"opend\" style=\"display:$OPEN;text-align:center;\">
			$LM_OPENDOORUSER <input name=\"DOOROPENERSUSER\" type=\"checkbox\""
			[ "$CM_DOOROPENERSUSER" == "on" ] && echo "checked=\"checked\""
			echo "></td></tr>"
			echo "<table width=\"80%\"><tr>
			<td style=\"text-align:center;\" colspan=\"3\"><br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"RELCHECK\" class=bottone value=\"$L_SAVE\"></form></td></tr>
			</table>"
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;"
			echo "</div>"
			echo "<div id=content1>
			<form method=\"post\" action=\"config.sh\"><p><p><center>
			<table width=\"90%\">"
			if [ "$CM_HEATING" == "on" ];then
				echo "<tr><td style=\"vertical-align:middle\">
				<strong>(R2) $CM_NAMERELAY2:</strong></td><td style=\"vertical-align:middle\"><center><img src=\"/images/mudc/lamp.jpg\"></td>
				<td style=\"vertical-align:middle\"><center>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"button\" name=\"RELAY2\" class=bottone value=\"$LM_TURNOFF\"></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style=\"vertical-align:middle;\"><strong>(R3) $CM_THERMOSTAT</strong>($TEMPERATURE&#176;)</td>
				<td style=\"vertical-align:middle;text-align:center;\">Min.</td>
				<td style=\"vertical-align:middle;\">
				<form method=\"POST\" action=\"config.sh\">
				<select name=\"CM_TMIN\" style=\"width:40px\">"
				for n in $(seq 1 25); do
					echo "<option value=\"$n\" >$n</option>"
				done
				echo "<option value=\"$CM_TMIN\" selected=\"selected\">$CM_TMIN</option></select>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"submit\" name=\"MUDCTEMPMIN\" class=\"bottone\" value=\"$L_SAVE\"></form></td>
				</tr>"
			else
				echo "<tr><td style=\"vertical-align:middle\">
				<form method=\"POST\" action=\"config.sh\">
				(R2) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY2\" value=\"$CM_NAMERELAY2\">
				</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
				<td style=\"vertical-align:middle\"><center>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td>
				<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style=\"vertical-align:middle\">
				<form method=\"POST\" action=\"config.sh\">
				(R3) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY3\" value=\"$CM_NAMERELAY3\">
				</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
				<td style=\"vertical-align:middle\"><center>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td></tr>"
			fi
			echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
			echo "<tr><td style=\"vertical-align:middle\">
			<form method=\"POST\" action=\"config.sh\">
			(R4) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY4\" value=\"$CM_NAMERELAY4\">
			</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td>
			<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style=\"vertical-align:middle\">
			<form method=\"POST\" action=\"config.sh\">
			(R5) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY5\" value=\"$CM_NAMERELAY5\">
			</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td></tr>"
			echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
			echo "<tr><td style=\"vertical-align:middle\">
			<form method=\"POST\" action=\"config.sh\">
			(R6) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY6\" value=\"$CM_NAMERELAY6\">
			</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td>
			<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style=\"vertical-align:middle\">
			<form method=\"POST\" action=\"config.sh\">
			(R7) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY7\" value=\"$CM_NAMERELAY7\">
			</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td></tr>"
			echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
			echo "<tr><td style=\"vertical-align:middle\">
			<form method=\"POST\" action=\"config.sh\">
			(R8) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY8\" value=\"$CM_NAMERELAY8\">
			</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td>
			<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style=\"vertical-align:middle\"><strong>$LM_CCTV:</strong></td><td><center><center><img src=\"/images/mudc/lamp.jpg\"></td>
			<td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"button\" name=\"MUDCCONF\" name=\"motion\" class=bottone value=\"$L_SAVE\"></td></tr>"
			echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
			if [ "$CM_DOOROPENERS" == "on" ];then
				echo "<tr><td style=\"vertical-align:middle\"><strong>(R1) $CM_NAMERELAY1: </strong></td><td><center><center><img src=\"/images/mudc/chiave.jpg\"></td>
				<td style=\"vertical-align:middle\"><center>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"button\" name=\"name=\"MUDCCONF\"\" class=bottone value=\"APRI\"></td>"
			else
				echo "<tr><td style=\"vertical-align:middle\">
				<form method=\"POST\" action=\"config.sh\">
				(R1) <input type=\"text\" style=\"width:140px\" name=\"CM_NAMERELAY1\" value=\"$CM_NAMERELAY1\">
				</td><td><center><img src=\"/images/mudc/lamp.jpg\"></td>
				<td style=\"vertical-align:middle\"><center>
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
				<input type=\"submit\" name=\"MUDCCONF\" class=bottone value=\"$L_SAVE\"></form></td>"
			fi
			echo "<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td style=\"vertical-align:middle\">
			<strong>$LM_GENERAL: </strong></td><td><center><img src=\"/images/mudc/spegni.jpg\">
			</td><td style=\"vertical-align:middle\"><center>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"RELAYS\">
			<input type=\"button\" name=\"name=\"MUDCCONF\"\" class=bottone value=\"$LM_OFFALL\"></td></tr>"
			echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table>"
			./footer.sh
			exit
		fi

		if [ "$SUBSUB_SECTION" == "DEVICES" ];then
			echo "<font color=\"#0000FF\" size=\"3\">Devices</font><p>"
			if [ -n "$CONFDEVICES" ];then
				echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
				echo "<br>&nbsp;<br>&nbsp;<br>"
				footerwait "480"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYRELAYS" "$TTYRELAYS"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYRELAYSS" "$TTYRELAYSS"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYTHERMOMETER" "$TTYTHERMOMETER"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYTHERMOMETERS" "$TTYTHERMOMETERS"
				#$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYVIDEO1" "$TTYVIDEO1"
				#$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_TTYVIDEO2" "$TTYVIDEO2"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_THERMOMETERTYPE" "$THERMOMETERTYPE"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_THERMOMETERTYPE" "$THERMOMETERTYPE"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_SENSORTEMP" "$SENSORTEMP"
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_BEEPALLARM" "$BEEPALLARM"
				$C_ZT_BIN_DIR/zt "mudc" "LinkDevice"
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=DEVICES"
				exit
			fi
			if [ -n "$SEARCHKP" ];then
				echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
				echo "<br>&nbsp;<br>&nbsp;<br>"
				footerwait "480"
				$C_ZT_BIN_DIR/zt "mudc" "SearchKP" "on"
				sleep 2
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=DEVICES"
				exit
			fi
			$C_ZT_BIN_DIR/zt "mudc" "usbdmesg"
			USBDMESG="$(cat $CM_MUDC_DIR/temp/dmesg)"
			if [[ "$($C_ZT_BIN_DIR/zt mudc relaystatus | awk '{print $1}' | cut -d':' -f2)" == "ON" || "$($C_ZT_BIN_DIR/zt mudc relaystatus | awk '{print $1}' | cut -d':' -f2)" == "OFF" ]];then
				IMGRELEYS="<img src=\"/images/abilita.png\">"
			else
				IMGRELEYS="<img src=\"/images/disabilita.png\">"
			fi
			TEMP="$($C_ZT_BIN_DIR/zt "mudc" "Temperature")"
			if [[ -n "$TEMP" && -z "$(echo "$TEMP" | grep 'Error')" ]];then
				IMGTEMP="<img src=\"/images/abilita.png\">"
			else
				IMGTEMP="<img src=\"/images/disabilita.png\">"
			fi
			echo "<font color=\"#0000FF\" size=\"3\">$L_SEARCH Devices ttyUSB $LM_OR ttyACM </font> <br>"
			echo "<textarea  rows=\"5\" cols=\"90\">$USBDMESG</textarea>"
			echo "<form method=\"POST\" action=\"config.sh\">
			<table class=\"naked\">
			<tr><td size=\"\100\">Relays grep $LM_STRING: </td>
			<td colspan=\"2\"><input type=\"text\" name=\"TTYRELAYS\" size=\"35\" value=\"$CM_TTYRELAYS\">
			&nbsp;&nbsp;&nbsp;$LM_OR: tty<input type=\"text\" name=\"TTYRELAYSS\" size=\"8\" value=\"$CM_TTYRELAYSS\">&nbsp;$IMGRELEYS</td></tr>
			<tr><td size=\"\100\" >$LM_THERMOMETER grep $LM_STRING: </td>
			<td colspan=\"2\"><input type=\"text\" name=\"TTYTHERMOMETER\" size=\"35\" value=\"$CM_TTYTHERMOMETER\">
			&nbsp;&nbsp;&nbsp;$LM_OR: tty<input type=\"text\" name=\"TTYTHERMOMETERS\" size=\"8\" value=\"$CM_TTYTHERMOMETERS\">&nbsp;$IMGTEMP</td></tr>
			<tr><td>$LM_THERMOMETER $LM_TYPE: </td><td>
			<select name=\"THERMOMETERTYPE\">"
			for TM in "DS9097" "DS9097U";do
				if [ "$CM_THERMOMETERTYPE" != "$TM" ];then
					echo "<option value=\"$TM\">$TM</option>"
				fi
			done 
			echo "<option value=\"$CM_THERMOMETERTYPE\" selected>$CM_THERMOMETERTYPE</option></select></td>
			<td style=\"text-align:right;\">Keypad Device:"
			if [ -f $CM_MUDC_DIR/conf/dev.conf ];then
				DEVK="$(cat $CM_MUDC_DIR/conf/dev.conf)"
				if [ -z  "$($C_ZT_BIN_DIR/zt "mudc" "SearchKP" )" ];then
					echo "$LM_NOTKEYCONF <img src=\"/images/disabilita.png\">"
				else
					echo "$(cat $CM_MUDC_DIR/conf/dev.conf) <img src=\"/images/abilita.png\">"
				fi
			else
				echo "$LM_NOTKEYCONF <img src=\"/images/disabilita.png\">"
			fi
			echo "</td></tr>"
			echo "<tr><td>$LM_SENSOR: </td><td>
			<select name=\"SENSORTEMP\">"
			for TM in "0" "1";do
				if [ "$CM_SENSORTEMP" != "$TM" ];then
					echo "<option value=\"$TM\">$TM</option>"
				fi
			done
			echo "<option value=\"$CM_SENSORTEMP\" selected>$CM_SENSORTEMP</option></select></td>
			<td style=\"text-align:right;\">$LM_BEEPALLARM:"
			if [ "$CM_BEEPALLARM" == "on" ];then
				echo "<input name=\"BEEPALLARM\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BEEPALLARM\" type=\"checkbox\">"
			fi
			echo "</td></tr>"
	#		echo "<tr><td>Video 1 grep $LM_STRING:</td>
	#		<td><input type=\"text\" name=\"CM_TTYVIDEO1\" size=\"70\" value=\"$CM_TTYVIDEO1\"></td></tr>
	#		<td>Video 2 grep $LM_STRING: </td>
	#		<td><input type=\"text\" name=\"CM_TTYVIDEO2\" size=\"70\" value=\"$CM_TTYVIDEO2\"></td></tr>"
			echo "</table>"
			echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DEVICES\">
			<input type=\"hidden\" name=\"CONFDEVICES\" value=\"YES\">
			<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>
			<img src=\"/images/barra.png\" alt=\"barra\"><p>"
			if ! [ -f $CM_MUDC_DIR/conf/dev.conf ];then
				echo "<form method=\"POST\" action=\"config.sh\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DEVICES\">
				<input type=\"hidden\" name=\"SEARCHKP\" value=\"YES\">
				<input type=\"submit\"  class=\"bottone\" value=\"$LM_SEARCH_KP \"></form><br>"
			fi
			if  [ -f $CM_MUDC_DIR/conf/dev.conf ];then
				echo "<form method=\"POST\" action=\"config.sh\">
				<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DEVICES\">
				<input type=\"hidden\" name=\"SEARCHKP\" value=\"YES\">
				<input type=\"submit\"  class=\"bottone\" value=\"$LM_NEW_KP \"></form><br>"
			fi
			./footer.sh
			exit
		fi
	fi
	if [ "$SUBSUB_SECTION" == "CCTV" ];then
		echo "<script>
		function viewkey() {
			var newwin=window.open(\"./viewkey.sh\",\"viewkey\",\"top=200,left=100,width=1100,height=60,scrollbars=yes,menubar=no,toolbar=no,statusbar=no\");
			newwin.focus();
		}
		</script>"
		echo "<script>
		function viewarea(cam) {
			var newwin=window.open(\"./viewarea.sh?cam=\"+cam,\"viewkey\",\"top=200,left=100,width=510,height=350,scrollbars=yes,menubar=no,toolbar=no,statusbar=no\");
			newwin.focus();
		}
		</script>"
		echo "<br><font color=\"#0000FF\" size=\"3\">$LM_CCTV</font><p>"
		if [ ! -c /dev/video0 ]  && [  ! -c /dev/video1 ];then
			$C_ZT_BIN_DIR/zt "Errore" "$LM_NOCAMERA" "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			./footer.sh
			exit
		fi
		IPM="$( echo $HTTP_REFERER | cut -d'/' -f3 | cut -d'/' -f1)"
		$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_IPM" "$IPM"
		if [ -n "$INSTALL_FFMPEG" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			$C_ZT_BIN_DIR/zt "mudc" "InstallFFMPEG"
			sleep 5
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$UPDATEKEYREMOTE" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "CREATEKEYREMOTE" "$SCPPASS"
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "RemoteConf"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$NEWKEY" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "NEWKEY"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$SPEEDTEST" ];then
			echo "<br><font color=\"#0000FF\" size=\"3\">SCP Speed Test (10000 kB file)</font><p>"
			echo "<div id=\"loading\">"
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "550"
			echo "</div>"
			TEST="$($C_ZT_BIN_DIR/zt "mudc" "SCPSpeedTest")"
			SERVER="$(echo "$TEST" | cut -d'-' -f1)"
			DOWN="$(echo "$TEST" | cut -d'-' -f3)"
			UP="$(echo "$TEST" | cut -d'-' -f2)"
			echo "<table class=\"tabellaldap\"  border=\"1\">"
			echo "<td class=\"intesta\" width=\"33%\">Server</td>
			<td class=\"intesta\" width=\"33%\">Download</td>
			<td class=\"intesta\" width=\"33%\">Upload</td></tr>
			<tr><td style=\"text-align: center\">$SERVER</td><td style=\"text-align: center\">$DOWN kB/s</td><td style=\"text-align: center\">$UP kB/s</td></tr></table>"
			echo "<br>&nbsp;<br>"
			echo "<form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form>"
			echo "<br>&nbsp;<br>"
			echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById('loading').remove();</script>"
			./footer.sh
			exit
		fi
		if [ -n "$DELETEALLVIDEO" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "DELETEALLVIDEO"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$DELETEALLIMG" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "DELETEALLIMAGES"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$CONTROLCONF" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "495"
			if [ -z "$REMOTESAVE" ];then
				for CONF in "REMOTESAVE" "TEXTVIDEO" "FORMATDATE" "MOTIONPASS" "MAKEMOVIE1" "MAKEMOVIEMIN1" "SAVEIMAGES1" "SMS1" "SMS2" "SMS3" \
					"CAM2ACTIVE" "CAM3ACTIVE" "CAM3ACTIVE" "CAMBOOTACTIVE" "OFFPROG" "ALLARM" "PORTCONTROL" "PORT1" "SENDVIDEO1" "SENDEMAIL1" "SENDSMS1" \
					"NOTICEADMINEMAIL" "NOTICEEMAIL1" "NOTICEEMAIL2" "NOTICEADMINSMS" "NOTICESMS1" "NOTICESMS2" "AREA11" "AREA12" "AREA13" "AREA14" "AREA15" \
					"AREA16" "AREA17" "AREA18" "AREA19";do
					CONFT="$(echo ${!CONF} | sed 's/\\/\\\//g' )"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "$CONFT"
				done
			else
				for CONF in "REMOTESAVE" "IPSERVERSCP" "USERSCP"  "PASSVIDEOREMOTE" "TEXTVIDEO" "FORMATDATE" "MOTIONPASS" "IPSERVERVPN" "PORTSERVERVPN" \
					"MAKEMOVIE1" "MAKEMOVIEMIN1" "SAVEIMAGES1" "CAMBOOTACTIVE" "OFFPROG" "ALLARM" "PORTCONTROL" "PORT1"  "SMS1" "SMS2" "SMS3"\
					"SAVELOCAL" "SAVESNAPLOCAL" "VIEWLOCAL" "SENDVIDEO1" "SENDEMAIL1" "SENDSMS1" "CAM2ACTIVE" "CAM3ACTIVE" "CAM4ACTIVE" \
					"NOTICEADMINEMAIL" "NOTICEEMAIL1" "NOTICEEMAIL2" "NOTICEADMINSMS" "NOTICESMS1" "NOTICESMS2" "AREA11" "AREA12" "AREA13" "AREA14" "AREA15" \
					"AREA16" "AREA17" "AREA18" "AREA19";do
					CONFT="$(echo ${!CONF} | sed 's/\\/\\\//g' )"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "$CONFT"
				done
				source /DB/apache2/cgi-bin/zerotruth/mudc/conf/mudc.config
				if [[ -n "$CM_IPSERVERVPN" && -n "$CM_PORTSERVERVPN" ]];then
					PORTCONTROLVPN=$(($CM_PORTSERVERVPN + 1))
					PORTVPN1=$(($CM_PORTSERVERVPN + 2))
					PORTVPN2=$(($CM_PORTSERVERVPN + 3))
					PORTVPN3=$(($CM_PORTSERVERVPN + 4))
					PORTVPN4=$(($CM_PORTSERVERVPN + 5))
					PORTCONTROLSNAPVPN=$(($CM_PORTSERVERVPN + 6))
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTVPN1" "$PORTVPN1"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTVPN2" "$PORTVPN2"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTVPN3" "$PORTVPN3"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTVPN4" "$PORTVPN4"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTCONTROLVPN" "$PORTCONTROLVPN"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_PORTCONTROLSNAPVPN" "$PORTCONTROLSNAPVPN"			
				fi
			fi
			if [ -n "$CAM2ACTIVE" ];then
				for CONF in "CAM2ACTIVE" "PORT2" "MAKEMOVIE2" "MAKEMOVIEMIN2" "SAVEIMAGES2" "AREA21" "AREA22" "AREA23" "AREA24" "AREA25" \
					 "AREA26" "AREA27" "AREA28" "AREA29" "SENDVIDEO2" "SENDEMAIL2" "SENDSMS2";do
					CONFT="$(echo ${!CONF} | sed 's/\\/\\\//g' )"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "$CONFT"
				done
			fi
			if [ -n "$CAM3ACTIVE" ];then
				for CONF in "CAM3ACTIVE" "PORT3" "MAKEMOVIE3" "MAKEMOVIEMIN3" "SAVEIMAGES3" "AREA31" "AREA32" "AREA33" "AREA34" "AREA35" \
					  "AREA36" "AREA37" "AREA38" "AREA39" "SENDVIDEO3" "SENDEMAIL3" "SENDSMS3";do
					CONFT="$(echo ${!CONF} | sed 's/\\/\\\//g' )"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "$CONFT"
				done
			fi
			if [ -n "$CAM4ACTIVE" ];then
				for CONF in "CAM4ACTIVE" "PORT4" "MAKEMOVIE4" "MAKEMOVIEMIN4" "SAVEIMAGES4" "AREA41" "AREA42" "AREA43" "AREA44" "AREA45" \
					 "AREA46" "AREA47" "AREA48" "AREA39" "SENDVIDEO4" "SENDEMAIL4" "SENDSMS4";do
					CONFT="$(echo ${!CONF} | sed 's/\\/\\\//g' )"
					$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "$CONFT"
				done
			fi
			$C_ZT_BIN_DIR/zt "mudc" "Motion" "RemoteConf"
			$C_ZT_BIN_DIR/zt "mudc" "ConfigMotion"
			if [ -n "$ALLARM" ];then
				$C_ZT_BIN_DIR/zt "mudc" "Language" "LM_NAMERELAY8" "$LM_ALLARM"
			fi
			if [ -n "$(pidof motion)" ];then
				$C_ZT_BIN_DIR/zt "mudc" "Motion" "Restart"
			fi
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV"
			exit
		fi
		if [ -n "$MOTIONCONF" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<textarea name=\"MOTIONCONF\" rows=\"20\" cols=\"110\">$(cat $CM_MUDC_DIR/conf/motion.conf)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE \"></form><p>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [ -n "$THREAD1CONF" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<textarea name=\"THREAD1CONF\" rows=\"20\" cols=\"110\">$(cat $CM_MUDC_DIR/conf/thread1.conf)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE \"></form><p>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [ -n "$THREAD2CONF" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<textarea name=\"THREAD2CONF\" rows=\"20\" cols=\"110\">$(cat $CM_MUDC_DIR/conf/thread2.conf)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE \"></form><p>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [ -n "$THREAD3CONF" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<textarea name=\"THREAD3CONF\" rows=\"20\" cols=\"110\">$(cat $CM_MUDC_DIR/conf/thread3.conf)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE \"></form><p>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [ -n "$THREAD4CONF" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<textarea name=\"THREAD4CONF\" rows=\"20\" cols=\"110\">$(cat $CM_MUDC_DIR/conf/thread4.conf)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE \"></form><p>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [[ -n "$CM_CREATEKEYSSH" && -n "$CM_USERSCP" && "$CM_IPSERVERSCP" ]];then
			echo "$LM_PASSSCP<br>
			<form name=\"PASSSCPF\" action=\"./config.sh\" method=\"POST\">
			<input type=\"password\" name=\"SCPPASS\" size=\"14\"  value=\"\"><br>
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<br><input type=\"submit\" name=\"UPDATEKEYREMOTE\" class=\"bottone\" value=\"$L_SAVE\"></form><br>
			<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		echo "<form name=\"VIDEOC\" action=\"./config.sh\" method=\"POST\">"
		echo "<table class=\"naked\"><tr><td>$LM_REMOTESAVE
		<input type=\"checkbox\" name=\"REMOTESAVE\" id=\"RC\" onclick=\"showSCP(this);\""
		[ "$CM_REMOTESAVE" == "on" ] && echo "checked=\"checked\""
		echo "></td></tr></table>"
		echo "<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		if [ -n "$CM_REMOTESAVE" ];then
			DIS="block"
			$C_ZT_BIN_DIR/zt "mudc" "CreateKeyScp" 
		else
			DIS="none"
		fi
		echo "<div id=\"ftpdiv\" style=\"display:$DIS\">"
		if [ "$($C_ZT_BIN_DIR/zt "mudc" "Motion" "RemoteControl")" != "yes" ];then
			echo "<font color=\"red\" size=\"3\">$LM_NOSERVERREMOTE</font><br>&nbsp;<br>"
		fi
		echo "<table  width=\"915\">
		<tr>
		<td width=\"150\">IP/URL Server SCP: </td><td width=\"145\"><input type=\"text\" name=\"IPSERVERSCP\" size=\"14\" value=\"$CM_IPSERVERSCP\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td width=\"130\">User Server SCP: </td><td width=\"130\"><input type=\"text\" name=\"USERSCP\" size=\"14\" value=\"$CM_USERSCP\"></td>
		<td>&nbsp;</td>
		<td width=\"165\">$LM_KEYSSH: </td><td>"
		if [ "$($C_ZT_BIN_DIR/zt "Checkidrsa")" == "yes" ];then
			echo "<a href=\"javascript:viewkey()\">SSH Key</a>"
		else
			echo "<font color=\"red\">$LM_NOKEYSSH</font>"
		fi
		echo "&nbsp;$LM_NEW: <input name=\"NEWKEY\" type=\"checkbox\"></td>
		</tr><tr>
		<td>IP/URL Server VPN: </td><td><input type=\"text\" name=\"IPSERVERVPN\" size=\"14\" value=\"$CM_IPSERVERVPN\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>Redir. Port to ZT: </td><td><input type=\"text\" name=\"PORTSERVERVPN\" size=\"14\"  value=\"$CM_PORTSERVERVPN\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>$LM_PASSVIDEOREM: </td><td>"
		echo "<input id=\"pwd1\" size=\"7\" type=\"password\" name=\"PASSVIDEOREMOTE\" value=\"$CM_PASSVIDEOREMOTE\" >
		&nbsp;<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></td></tr>"
		#<tr><td>$LM_SAVEVIDEOLOCAL: </td><td><input name=\"SAVELOCAL\" type=\"checkbox\""
		#[ "$CM_SAVELOCAL" == "on" ] && echo "checked=\"checked\""
		#echo "></td>
		#<td>&nbsp;&nbsp;&nbsp;</td>
		#<td>$LM_SAVESNAPLOCAL: </td><td><input name=\"SAVESNAPLOCAL\" type=\"checkbox\""
		#[ "$CM_SAVESNAPLOCAL" == "on" ] && echo "checked=\"checked\""
		#echo "></td>
		#<td>&nbsp;&nbsp;&nbsp;</td>
		#<td>$LM_VIEWLOCAL: </td><td><input name=\"VIEWLOCAL\" type=\"checkbox\""
		#[ "$CM_VIEWLOCAL" == "on" ] && echo "checked=\"checked\""
		#echo "></td></tr>
		echo "</table>
		<br>&nbsp;<br></div>"
		echo "<table  class=\"naked\"  width=\"915\">
		<tr><td width=\"150\">$LM_TEXT_ON_VIDEO: </td><td width=\"160\"><input type=\"text\" name=\"TEXTVIDEO\" size=\"14\" value=\"$CM_TEXTVIDEO\"></td>
		<td width=\"130\">$LM_PORTCONTROL: </td><td width=\"130\"><input type=\"text\" name=\"PORTCONTROL\" size=\"14\" value=\"$CM_PORTCONTROL\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>Motion User:Pass: </td><td>"
		echo "<input id=\"pwd2\" size=\"7\" type=\"password\" name=\"MOTIONPASS\" value=\"$CM_MOTIONPASS\" >
		&nbsp;<a href=\"#\" onClick=\"hidden_password('pwd2', 'show' , 'hide', '2');\" id=\"showhide2\"><img src=\"/images/show.png\" alt=\"show\"></a></td></tr>"
		echo "<tr><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>"
		
		echo "<tr><td colspan=\"7\"  style=\"text-align: center;\"><font color=\"blue\">$LM_CAMERA 1:
		
		<input type=\"checkbox\" disabled=\"disabled\" checked=\"checked\">"
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		$LM_CAMERA 2: <input type=\"checkbox\" name=\"CAM2ACTIVE\" id=\"RCAM2\" onclick=\"showCAM2(this);\""
		[ "$CM_CAM2ACTIVE" == "on" ] && echo "checked=\"checked\""
		echo ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		$LM_CAMERA 3: <input type=\"checkbox\" name=\"CAM3ACTIVE\" id=\"RCAM3\" onclick=\"showCAM3(this);\""
		[ "$CM_CAM3ACTIVE" == "on" ] && echo "checked=\"checked\""
		echo ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		$LM_CAMERA 4: <input type=\"checkbox\" name=\"CAM4ACTIVE\" id=\"RCAM4\" onclick=\"showCAM4(this);\""
		[ "$CM_CAM4ACTIVE" == "on" ] && echo "checked=\"checked\""
		echo ">
		</td></tr>
		<tr><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td><td colspan=\"2\" align=\"center\"><font color=\"blue\">$LM_CAMERA 1</font>
		</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr><td>$L_PORT Cam 1 : </td><td width=\"80\"><input type=\"text\" name=\"PORT1\" size=\"14\" value=\"$CM_PORT1\"></td>
		<td>$LM_MAKEMOVIECONF: </td><td><input name=\"MAKEMOVIE1\" type=\"checkbox\""
		[ "$CM_MAKEMOVIE1" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>$LM_MAKEMOVIEMIN: </td><td>
		<select name=\"MAKEMOVIEMIN1\" style=\"width:60px\">"
		for n in "20" "50" "100" "250" "500" "1000"; do
			if [ "$n" != "$CM_MAKEMOVIEMIN1" ];then
				echo "<option value=\"$n\" >$n</option>"
			fi
		done
		echo "<option value=\"$CM_MAKEMOVIEMIN1\" selected=\"selected\">$CM_MAKEMOVIEMIN1</option></select></td></tr>
		<tr><td>$LM_NOTEMAIL: </td><td><input name=\"SENDEMAIL1\" type=\"checkbox\""
		[ "$CM_SENDEMAIL1" == "on" ] && echo "checked=\"checked\" name=\"REMOTESAVE\" id=\"RC\" onclick=\"showSCP(this);\""
		echo "></td><td>
		$LM_NOTSMS: </td><td>
		<input name=\"SENDSMS1\" type=\"checkbox\""
		[ "$CM_SENDSMS1" == "on" ] && echo "checked=\"checked\""
		echo "></td><td></td><td>
		$LM_SENDVIDEO: </td><td>
		<input name=\"SENDVIDEO1\" type=\"checkbox\""
		[ "$CM_SENDVIDEO1" == "on" ] && echo "checked=\"checked\""
		echo "></td></tr>"
		echo "<tr><td>$LM_AREAS:<td colspan=\"6\">${LM_AREA}1:<input name=\"AREA11\" type=\"checkbox\""
		[ "$CM_AREA11" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}2:<input name=\"AREA12\" type=\"checkbox\""
		[ "$CM_AREA12" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}3:<input name=\"AREA13\" type=\"checkbox\""
		[ "$CM_AREA13" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}4:<input name=\"AREA14\" type=\"checkbox\""
		[ "$CM_AREA14" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}5:<input name=\"AREA15\" type=\"checkbox\""
		[ "$CM_AREA15" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}6:<input name=\"AREA16\" type=\"checkbox\""
		[ "$CM_AREA16" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}7:<input name=\"AREA17\" type=\"checkbox\""
		[ "$CM_AREA17" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}8:<input name=\"AREA18\" type=\"checkbox\""
		[ "$CM_AREA18" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}9:<input name=\"AREA19\" type=\"checkbox\""
		[ "$CM_AREA19" == "on" ] && echo "checked=\"checked\""
		echo ">"
		if [[ "$CM_AREA11" || "$CM_AREA12" || "$CM_AREA13" || "$CM_AREA14" || "$CM_AREA15" || "$CM_AREA16" || "$CM_AREA17" || "$CM_AREA18" || "$CM_AREA19" ]];then
			echo "<a href=\"javascript:viewarea(1)\">$L_CHECK</a></td></tr>"
		else
			echo "</td></tr>"
		fi
		echo "<tr><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>"
		## cam 2
		if [ -n "$CM_CAM2ACTIVE" ];then
			DIS2=""
		else
			DIS2="none"
		fi
		echo "<tr id=\"camdiv21\" style=\"display:$DIS2\"><td colspan=\"7\"  style=\"text-align: center;\"><font color=\"blue\">$LM_CAMERA 2</font></td></tr>"
		echo "<tr id=\"camdiv22\" style=\"display:$DIS2\"><td>$L_PORT Cam 2: </td><td width=\"80\"><input type=\"text\" name=\"PORT2\" size=\"14\" value=\"$CM_PORT2\"></td>
		<td>$LM_MAKEMOVIECONF: </td><td><input name=\"MAKEMOVIE2\" type=\"checkbox\""
		[ "$CM_MAKEMOVIE2" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>$LM_MAKEMOVIEMIN: </td><td>
		<select name=\"MAKEMOVIEMIN2\" style=\"width:60px\">"
		for n in "20" "50" "100" "250" "500" "1000"; do
			if [ "$n" != "$CM_MAKEMOVIEMIN2" ];then
				echo "<option value=\"$n\" >$n</option>"
			fi
		done
		echo "<option value=\"$CM_MAKEMOVIEMIN2\" selected=\"selected\">$CM_MAKEMOVIEMIN2</option></select></td></tr>
		<tr id=\"camdiv23\" style=\"display:$DIS2\"><td>$LM_NOTEMAIL: </td><td><input name=\"SENDEMAIL2\" type=\"checkbox\""
		[ "$CM_SENDEMAIL2" == "on" ] && echo "checked=\"checked\""
		echo "></td><td>
		$LM_NOTSMS: </td><td>
		<input name=\"SENDSMS2\" type=\"checkbox\""
		[ "$CM_SENDSMS2" == "on" ] && echo "checked=\"checked\""
		echo "></td><td></td><td>
		$LM_SENDVIDEO: </td><td>
		<input name=\"SENDVIDEO2\" type=\"checkbox\""
		[ "$CM_SENDVIDEO2" == "on" ] && echo "checked=\"checked\""
		echo "></td></tr>"
		
		echo "<tr id=\"camdiv24\" style=\"display:$DIS2\"><td>$LM_AREAS:<td colspan=\"6\">${LM_AREA}1:<input name=\"AREA21\" type=\"checkbox\""
		[ "$CM_AREA21" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}2:<input name=\"AREA22\" type=\"checkbox\""
		[ "$CM_AREA22" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}3:<input name=\"AREA23\" type=\"checkbox\""
		[ "$CM_AREA23" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}4:<input name=\"AREA24\" type=\"checkbox\""
		[ "$CM_AREA24" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}5:<input name=\"AREA25\" type=\"checkbox\""
		[ "$CM_AREA25" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}6:<input name=\"AREA26\" type=\"checkbox\""
		[ "$CM_AREA26" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}7:<input name=\"AREA27\" type=\"checkbox\""
		[ "$CM_AREA27" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}8:<input name=\"AREA28\" type=\"checkbox\""
		[ "$CM_AREA28" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}9:<input name=\"AREA29\" type=\"checkbox\""
		[ "$CM_AREA29" == "on" ] && echo "checked=\"checked\""
		echo ">"
		if [[ "$CM_AREA21" || "$CM_AREA22" || "$CM_AREA23" || "$CM_AREA24" || "$CM_AREA25" || "$CM_AREA26" || "$CM_AREA27" || "$CM_AREA28" || "$CM_AREA29" ]];then
			echo "<a href=\"javascript:viewarea(2)\">$L_CHECK</a></td></tr>"
		else
			echo "</td></tr>"
		fi
		echo "<tr id=\"camdiv25\" style=\"display:$DIS2\"><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>"
		######## CAM3
		if [ -n "$CM_CAM3ACTIVE" ];then
			DIS3=""
		else
			DIS3="none"
		fi
		echo "<tr id=\"camdiv31\" style=\"display:$DIS3\"><td colspan=\"7\"  style=\"text-align: center;\"><font color=\"blue\">$LM_CAMERA 3</font></td></tr>"
		echo "<tr id=\"camdiv32\" style=\"display:$DIS3\"><td>$L_PORT Cam 3: </td><td width=\"80\"><input type=\"text\" name=\"PORT3\" size=\"14\" value=\"$CM_PORT3\"></td>
		<td>$LM_MAKEMOVIECONF: </td><td><input name=\"MAKEMOVIE3\" type=\"checkbox\""
		[ "$CM_MAKEMOVIE3" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>$LM_MAKEMOVIEMIN: </td><td>
		<select name=\"MAKEMOVIEMIN3\" style=\"width:60px\">"
		for n in "20" "50" "100" "250" "500" "1000"; do
			if [ "$n" != "$CM_MAKEMOVIEMIN3" ];then
				echo "<option value=\"$n\" >$n</option>"
			fi
		done
		echo "<option value=\"$CM_MAKEMOVIEMIN3\" selected=\"selected\">$CM_MAKEMOVIEMIN3</option></select></td></tr>
		<tr id=\"camdiv33\" style=\"display:$DIS3\"><td>$LM_NOTEMAIL: </td><td><input name=\"SENDEMAIL3\" type=\"checkbox\""
		[ "$CM_SENDEMAIL3" == "on" ] && echo "checked=\"checked\""
		echo "></td><td>
		$LM_NOTSMS: </td><td>
		<input name=\"SENDSMS3\" type=\"checkbox\""
		[ "$CM_SENDSMS3" == "on" ] && echo "checked=\"checked\""
		echo "></td><td></td><td>
		$LM_SENDVIDEO: </td><td>
		<input name=\"SENDVIDEO3\" type=\"checkbox\""
		[ "$CM_SENDVIDEO3" == "on" ] && echo "checked=\"checked\""
		echo "></td></tr>"
		
		echo "<tr id=\"camdiv34\" style=\"display:$DIS3\"><td>$LM_AREAS:<td colspan=\"6\">${LM_AREA}1:<input name=\"AREA31\" type=\"checkbox\""
		[ "$CM_AREA31" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}2:<input name=\"AREA32\" type=\"checkbox\""
		[ "$CM_AREA32" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}3:<input name=\"AREA33\" type=\"checkbox\""
		[ "$CM_AREA33" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}4:<input name=\"AREA34\" type=\"checkbox\""
		[ "$CM_AREA34" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}5:<input name=\"AREA35\" type=\"checkbox\""
		[ "$CM_AREA35" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}6:<input name=\"AREA36\" type=\"checkbox\""
		[ "$CM_AREA36" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}7:<input name=\"AREA37\" type=\"checkbox\""
		[ "$CM_AREA37" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}8:<input name=\"AREA38\" type=\"checkbox\""
		[ "$CM_AREA38" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}9:<input name=\"AREA39\" type=\"checkbox\""
		[ "$CM_AREA39" == "on" ] && echo "checked=\"checked\""
		echo ">"
		if [[ "$CM_AREA31" || "$CM_AREA32" || "$CM_AREA33" || "$CM_AREA34" || "$CM_AREA35" || "$CM_AREA36" || "$CM_AREA37" || "$CM_AREA38" || "$CM_AREA39" ]];then
			echo "<a href=\"javascript:viewarea('3')\">$L_CHECK</a></td></tr>"
		else
			echo "</td></tr>"
		fi
		
		echo "<tr id=\"camdiv35\" style=\"display:$DIS3\"><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>"
		if [ -n "$CM_CAM4ACTIVE" ];then
			DIS4=""
		else
			DIS4="none"
		fi
		echo "<tr id=\"camdiv41\" style=\"display:$DIS4\"><td colspan=\"7\"  style=\"text-align: center;\"><font color=\"blue\">$LM_CAMERA 4</font></td></tr>"
		echo "<tr id=\"camdiv42\" style=\"display:$DIS4\"><td>$L_PORT Cam 4: </td><td width=\"80\"><input type=\"text\" name=\"PORT4\" size=\"14\" value=\"$CM_PORT4\"></td>
		<td>$LM_MAKEMOVIECONF: </td><td><input name=\"MAKEMOVIE4\" type=\"checkbox\""
		[ "$CM_MAKEMOVIE4" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td>$LM_MAKEMOVIEMIN: </td><td>
		<select name=\"MAKEMOVIEMIN4\" style=\"width:60px\">"
		for n in "20" "50" "100" "250" "500" "1000"; do
			if [ "$n" != "$CM_MAKEMOVIEMIN4" ];then
				echo "<option value=\"$n\" >$n</option>"
			fi
		done
		echo "<option value=\"$CM_MAKEMOVIEMIN4\" selected=\"selected\">$CM_MAKEMOVIEMIN4</option></select></td></tr>
		<tr id=\"camdiv43\" style=\"display:$DIS4\"><td>$LM_NOTEMAIL: </td><td><input name=\"SENDEMAIL4\" type=\"checkbox\""
		[ "$CM_SENDEMAIL4" == "on" ] && echo "checked=\"checked\""
		echo "></td><td>
		$LM_NOTSMS: </td><td>
		<input name=\"SENDSMS4\" type=\"checkbox\""
		[ "$CM_SENDSMS4" == "on" ] && echo "checked=\"checked\""
		echo "></td><td></td><td>
		$LM_SENDVIDEO: </td><td>
		<input name=\"SENDVIDEO4\" type=\"checkbox\""
		[ "$CM_SENDVIDEO4" == "on" ] && echo "checked=\"checked\""
		echo "></td></tr>"
		echo "<tr id=\"camdiv44\" style=\"display:$DIS4\"><td>$LM_AREAS:<td colspan=\"6\">${LM_AREA}1:<input name=\"AREA41\" type=\"checkbox\""
		[ "$CM_AREA41" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}2:<input name=\"AREA42\" type=\"checkbox\""
		[ "$CM_AREA42" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}3:<input name=\"AREA43\" type=\"checkbox\""
		[ "$CM_AREA43" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}4:<input name=\"AREA44\" type=\"checkbox\""
		[ "$CM_AREA44" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}5:<input name=\"AREA45\" type=\"checkbox\""
		[ "$CM_AREA45" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}6:<input name=\"AREA46\" type=\"checkbox\""
		[ "$CM_AREA46" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}7:<input name=\"AREA47\" type=\"checkbox\""
		[ "$CM_AREA47" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}8:<input name=\"AREA48\" type=\"checkbox\""
		[ "$CM_AREA48" == "on" ] && echo "checked=\"checked\""
		
		echo ">&nbsp;${LM_AREA}9:<input name=\"AREA49\" type=\"checkbox\""
		[ "$CM_AREA49" == "on" ] && echo "checked=\"checked\""
		echo ">"
		if [[ "$CM_AREA41" || "$CM_AREA42" || "$CM_AREA43" || "$CM_AREA44" || "$CM_AREA45" || "$CM_AREA46" || "$CM_AREA47" || "$CM_AREA48" || "$CM_AREA49" ]];then
			echo "<a href=\"javascript:viewkey()\">$L_CHECK</a></td></tr>"
		else
			echo "</td></tr>"
		fi
		echo "<tr id=\"camdiv45\" style=\"display:$DIS4\"><td colspan=\"7\"  style=\"text-align: center; vertical-align:middle\"><img src=\"/images/barra.png\" alt=\barra\"</td></tr>"
		
		echo "<tr><td>Email $LM_NOTICE: &nbsp;&nbsp;&nbsp;Admin</td><td><input name=\"NOTICEADMINEMAIL\" type=\"checkbox\""
		[ "$CM_NOTICEADMINEMAIL" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td align=\"right\">Email1: </td><td align=\"right\">
		<input type=\"text\" name=\"NOTICEEMAIL1\" size=\"14\" value=\"$CM_NOTICEEMAIL1\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td colspan=\"2\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email2:
		<input type=\"text\" name=\"NOTICEEMAIL2\" size=\"14\" value=\"$CM_NOTICEEMAIL2\"></td></tr>"
		echo "<tr><td>SMS $LM_NOTICE: &nbsp;&nbsp;&nbsp;Admin</td><td><input name=\"NOTICEADMINSMS\" type=\"checkbox\""
		[ "$CM_NOTICEADMINSMS" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td align=\"right\">Tel. SMS1:</td><td align=\"right\">
		<input type=\"text\" name=\"NOTICESMS1\" size=\"14\" value=\"$CM_NOTICESMS1\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td colspan=\"2\">&nbsp;&nbsp;&nbsp;&nbsp;Tel. SMS2:
		<input type=\"text\" name=\"NOTICESMS2\" size=\"14\" value=\"$CM_NOTICESMS2\"></td></tr>"
		echo "<tr><td>$LM_BOOT_ACTIVE: </td><td><input name=\"CAMBOOTACTIVE\" type=\"checkbox\""
		[ "$CM_CAMBOOTACTIVE" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td colspan=\"2\" align=\"right\">$LM_OFF_PROG:&nbsp;</td>
		<td><input name=\"OFFPROG\" type=\"checkbox\""
		[ "$CM_OFFPROG" == "on" ] && echo "checked=\"checked\""
		echo "></td>
		<td colspan=\"2\" align=\"center\">$LM_ALLARM (Relay 8):&nbsp;&nbsp;<input name=\"ALLARM\" type=\"checkbox\" id=\"RSMS\" onclick=\"showSMS(this);\""
		[ "$CM_ALLARM" == "on" ] && echo "checked=\"checked\""
		echo ">
		</td></tr>"
		if [ -n "$CM_ALLARM" ];then
			DSMS=""
		else
			DSMS="none"
		fi
		echo "<tr id=\"smsdiv\" style=\"display:$DSMS\"><td width=\"150\">$LM_TELSMSALLARM: </td><td width=\"160\">
		<input type=\"text\" name=\"SMS1\" size=\"14\" value=\"$CM_SMS1\"></td>
		<td colspan=\"2\" align=\"center\">
		<input type=\"text\" name=\"SMS2\" size=\"14\" value=\"$CM_SMS2\"></td>
		<td>&nbsp;&nbsp;&nbsp;</td>
		<td colspan=\"2\" align=\"center\">
		<input type=\"text\" name=\"SMS3\" size=\"14\" value=\"$CM_SMS3\"></td></tr>"
		echo "<tr><td>$LM_EDIT: </td><td><a href=\"config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV&MOTIONCONF=yes\">Motion.conf</a></td>
		<td align=\"left\"><a href=\"config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV&THREAD1CONF=yes\">thread1.conf</a>
		<td align=\"center\"><a href=\"config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV&THREAD2CONF=yes\">thread2.conf</a></td>
		<td colspan=\"3\" ><a href=\"config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV&THREAD3CONF=yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;thread3.conf</a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=CCTV&THREAD4CONF=yes\">thread4.conf</a></td>
		</tr></table>"
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">"
		echo "<input type=\"hidden\" name=\"CONTROLCONF\" class=\"bottone\" value=\"YES\">"
		echo "<p><input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		echo "<table   cellpadding=\"3\"><tr>
		<td valign=\"middle\"><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
		<input type=\"hidden\" name=\"DELETEALLIMG\" value=\"YES\">
		<input type=\"submit\" class=\"bottone\" value=\"$LM_DELETEALLIMG\"
		onClick=\"javascript:return confirm('$LM_ALERTREMOVEALLIMG');\"></form></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
		if [ -n "$CM_REMOTESAVE" ];then
			echo "<td><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"hidden\" name=\"SPEEDTEST\" value=\"YES\">
			<input type=\"submit\" class=\"bottone\" value=\"SCP Speed Test\"></form></td>"
		fi
		echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
		<input type=\"hidden\" name=\"DELETEALLVIDEO\" value=\"YES\">
		<input type=\"submit\" class=\"bottone\" value=\"$LM_DELETEALLVIDEO\"
		onClick=\"javascript:return confirm('$LM_ALERTREMOVEALLVIDEO');\">
		</form></td>
		</td></tr></table><br>&nbsp;<br>"
		if  [ -f $C_ZT_DIR/mudc/bin/ffmpeg ];then
			echo "<img src=\"/images/barra.png\" alt=\barra\">
			<br>&nbsp;<br>$L_ALERT_FFMPEG<br>&nbsp;<br><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"CCTV\">
			<input type=\"submit\" name=\"INSTALL_FFMPEG\" class=\"bottone\" value=\"$L_INSTALL FFMPEG\"
			onClick=\"javascript:return confirm('$L_ALERT_INSTALL_FFMPEG');\"></form><br>&nbsp;<br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUBSUB_SECTION" == "TICKET" ];then
		echo "<br><font color=\"blue\" size=\"4\">MUDC $L_USER_TICKET</font><p>
		<img src=\"/images/barra.png\" alt=\barra\"><p>"
		if [ -n "$CONTROLCONF" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "600"
			for CONF in "TICKET_ABIL" "SWOWDATECREATED" "SWOWDATESTART" "SWOWTEL" "SWOWDATESTOP" "SWOWHOURS" "SWOWPROG" "SWOWINFO" "SWOWCODEKEY";do
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_$CONF" "${!CONF}"
			done
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=TICKET"
			exit
		fi
		if [ -n "$INFOTICKET" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "600"
			sleep 2
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=TICKET"
			exit
		fi
		echo "<table style=\"width:350;\" border=\"1\" align=\"center\"><tr>
		<form method=\"POST\" action=\"config.sh\">
		<table class=\"naked\"><tr>
		<td>$L_ACTIVE_SERVICE: </td><td>"
		if [ "$CM_TICKET_ABIL" == "on" ];then
			echo "<input name=\"TICKET_ABIL\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"TICKET_ABIL\" type=\"checkbox\">"
		fi
		echo "</td><td>&nbsp;&nbsp;</td>
		<td>$LM_SWOWDATECREATED: </td><td>"
		if [ "$CM_SWOWDATECREATED" == "on" ];then
			echo "<input name=\"SWOWDATECREATED\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWDATECREATED\" type=\"checkbox\">"
		fi
		echo "</td>
		</tr><tr>
		<td>$LM_SWOWTEL: </td><td>"
		if [ "$CM_SWOWTEL" == "on" ];then
			echo "<input name=\"SWOWTEL\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWTEL\" type=\"checkbox\">"
		fi
		echo "</td><td>&nbsp;&nbsp;</td>
		<td>$LM_SWOWDATESTART: </td><td>"
		if [ "$CM_SWOWDATESTART" == "on" ];then
			echo "<input name=\"SWOWDATESTART\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWDATESTART\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		<td>$LM_SWOWDATESTOP: </td><td>"
		if [ "$CM_SWOWDATESTOP" == "on" ];then
			echo "<input name=\"SWOWDATESTOP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWDATESTOP\" type=\"checkbox\">"
		fi
		echo "</td><td>&nbsp;&nbsp;</td>
		<td>$LM_SWOWHOURS: </td><td>"
		if [ "$CM_SWOWHOURS" == "on" ];then
			echo "<input name=\"SWOWHOURS\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWHOURS\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		<td>$LM_SWOWPROG: </td><td>"
		if [ "$CM_SWOWPROG" == "on" ];then
			echo "<input name=\"SWOWPROG\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWPROG\" type=\"checkbox\">"
		fi
		echo "</td><td>&nbsp;&nbsp;</td>
		<td>$LM_SWOWINFO: </td><td>"
		if [ "$CM_SWOWINFO" == "on" ];then
			echo "<input name=\"SWOWINFO\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWINFO\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		<td>$LM_SWOWCODEKEY: </td><td>"
		if [ "$CM_SWOWCODEKEY" == "on" ];then
			echo "<input name=\"SWOWCODEKEY\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SWOWCODEKEY\" type=\"checkbox\">"
		fi
		echo "</td><td>&nbsp;&nbsp;</td></td></tr>	
		</table>
		<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"TICKET\">
		<input type=\"submit\" name=\"CONTROLCONF\" class=\"bottone\" value=\"$L_SAVE\"></form><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		INFOTICKET=$(cat $CM_MUDC_DIR/conf/InfoTicket)
		echo "<form method=\"POST\" action=\"config.sh\"><p>
		<table><tr><td align=\"center\">$LM_INFO:<br>
		<textarea name=\"INFOTICKET\" rows=\"4\" cols=\"40\">$INFOTICKET</textarea></td>
		</tr></table>
		<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"TICKET\">
		<input type=\"hidden\" name=\"CONTROLINFO\" value=\"YES\">
		<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<img src=\"/images/barra.png\" alt=\barra\"><p>	"
		[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
		[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
		echo "<div id=\"ticket\">
		<table style=\"width:350;\" border=\"1\" align=\"center\">
		<tr>
		<td colspan=\"2\"><img src=\"$APACHE_BASEDIR/images/imguser.png\" WIDTH=\"350px\"></td>
		</tr>
		<tr><td>
		<table  border=\"1\" style=\"font: ${C_FONT_TICKET}px; "Trebuchet MS",Arial,sans-serif; width:350;\">"
		echo "<tr><td style=\"width:100px;\">&nbsp;$L_NAME: </td><td>John Wayne </td></tr>"
		echo "<tr><td>&nbsp;$LM_ACTIVITY/$LM_GROUP: </td><td>Western</td></tr>"
		if [ -n "$CM_SWOWTEL" ];then
			echo "<tr><td>&nbsp;$L_TELEPHONE: </td><td>393398567009</td></tr>"
		fi
		if [ -n "$CM_SWOWCODEKEY" ];then
			echo "<tr><td>&nbsp;$LM_CODEKEY: </td><td>67143</td></tr>"
		fi
		if [ "$C_FORM_DATE" == "ita" ];then
			DATE_CREATED="$(date +%d/%m/%Y)"
			DATE_START="$(date +%d/%m/%Y -d '+ 14 day')"
			DATE_END="$(date +%d/%m/%Y -d '+ 180 day')"
		else
			DATE_CREATED=$(date +%Y/%m/%d)
			DATE_START=$(date +%Y/%m/%d -d '+ 14 day')
			DATE_END=$(date +%Y/%m/%d -d '+ 180 day')
		fi
		if [ -n "$CM_SWOWDATECREATED" ];then
			echo "<tr><td>&nbsp;$L_CREATED: </td><td>$DATE_CREATED</td></tr>"
		fi
		if [ -n "$CM_SWOWDATESTART" ];then
			echo "<tr><td>&nbsp;$LM_VALFROM: </td><td>$DATE_START</td></tr>"
		fi
		if [ -n "$CM_SWOWDATESTOP" ];then
			echo "<tr><td>&nbsp;$L_ENDS: </td><td>$DATE_END</td></tr>"
		fi
		if [ -n "$CM_SWOWHOURS" ];then
			echo "<tr><td>&nbsp;$LM_HOURTICKET: </td><td>$L_WEDNESDAY<br>18:30 - 22:30</td></tr>"
		fi
		if [ -n "$CM_SWOWPROG" ];then
			echo "<tr><td>&nbsp;$LM_PROGRAMMING: </td><td>$LM_HEATING, $LM_NAMERELAY4, $LM_NAMERELAY5</td></tr>"
		fi
		echo "</table>"
		if [ -n "$CM_SWOWINFO" ];then
			if [ -n "$INFOTICKET" ];then
				echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
				<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFOTICKET</td></tr></table>"
			fi
		fi
		echo "</table></div><p>&nbsp;<p>"
		./footer.sh
	fi
	if [ "$SUBSUB_SECTION" == "EMAIL" ];then
		if [ -n "$CONF_EMAIL" ];then
			echo "<font color=\"#0000FF\" size=\"3\">$L_EMAIL</font><br>"
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>"
			footerwait "480"
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_EMAILABIL" "$EMAILABIL"
			sleep 2
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=EMAIL"
			exit
		fi
		if [ -n "$CONF_SMS" ];then
			echo "<font color=\"#0000FF\" size=\"3\">SMS</font>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>"
			footerwait "480"
			sleep 2
			$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "CM_SMSABIL" "$SMSABIL"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=EMAIL"
			exit
		fi
		if [[ -n "$C_EMAIL_ABIL" && -n "$C_SEND_EMAIL" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_EMAIL_ABIL" ]];then
			echo "<font color=\"#0000FF\" size=\"3\">$L_EMAIL</font>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			EMAILTEXT=$(cat $CM_MUDC_DIR/conf/EmailText)
			EMAILFOOTER=$(cat $CM_MUDC_DIR/conf/EmailFooter)
			EMAILMOTION=$(cat $CM_MUDC_DIR/conf/EmailMotion)
			EMAILALLARM=$(cat $CM_MUDC_DIR/conf/EmailAllarm)
			echo "<form method=\"POST\" action=\"config.sh\">
			<table class=\"naked\" border=0><tr>
			<td style=\"text-align:center;\" colspan=\"3\">$L_ACTIVE_SERVICE:"
			if [ "$CM_EMAILABIL" == "on" ];then
				echo "<input name=\"EMAILABIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"EMAILABIL\" type=\"checkbox\">"
			fi
			echo "</td></tr><tr>
			<td align=\"center\">$L_TEXT:<br>
			<textarea name=\"EMAILTEXT\" rows=\"8\" cols=\"30\">$EMAILTEXT</textarea></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</td>
			<td align=\"center\">$L_FOOTER:<br>
			<textarea name=\"EMAILFOOTER\" rows=\"8\" cols=\"30\">$EMAILFOOTER</textarea></td>
			</tr>
			<tr><td style=\"text-align:center;\" colspan=\"3\">&nbsp;</td></tr>
			<tr>
			<td align=\"center\">$LM_NOTALERT:<br>
			<textarea name=\"EMAILMOTION\" rows=\"8\" cols=\"30\">$EMAILMOTION</textarea></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</td>
			<td align=\"center\">$LM_NOTALLARM:<br>
			<textarea name=\"EMAILALLARM\" rows=\"8\" cols=\"30\">$EMAILALLARM</textarea></td>
			</tr>
			</table>
			<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"EMAIL\">
			<input type=\"hidden\" name=\"CONF_EMAIL\" value=\"YES\">
			<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
			echo "<img src=\"/images/barra.png\" alt=\"barra\"><p>"
			fi
		if [[ -n "$C_SMS_ABIL" && -n "$C_SEND_SMS" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_SMS_ABIL" ]] ;then
			if [ "$C_SMS_PROVIDER" != "Gammu" ] || [[ "$C_SMS_PROVIDER" == "Gammu" && -n "$C_SEND_SMS_GAMMU" ]];then	
				echo "<font color=\"#0000FF\" size=\"3\">SMS</font>"
				echo "<form method=\"POST\" action=\"config.sh\">
				<table class=\"naked\" border=0><tr>
				<td style=\"text-align:center;\" colspan=\"3\">$L_ACTIVE_SERVICE:"
				if [ "$CM_SMSABIL" == "on" ];then
					echo "<input name=\"SMSABIL\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"SMSABIL\" type=\"checkbox\">"
				fi
				SMSTEXT="$(cat $CM_MUDC_DIR/conf/SMSText)"
				SMSMOTION="$(cat $CM_MUDC_DIR/conf/SMSMotion)"
				SMSALLARM="$(cat $CM_MUDC_DIR/conf/SMSAllarm)"
				echo "</td></tr><tr>
				<td align=\"center\" colspan=\"3\">$L_TEXT:<br>
				<textarea name=\"SMSTEXT\" rows=\"4\" cols=\"40\">$SMSTEXT</textarea></td></tr>
				<tr><td style=\"text-align:center;\" colspan=\"3\">&nbsp;</td></tr>
				<tr>
				<td align=\"center\">$LM_NOTALERT:<br>
				<textarea name=\"SMSMOTION\" rows=\"4\" cols=\"30\">$SMSMOTION</textarea></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</td>
				<td align=\"center\">$LM_NOTALLARM:<br>
				<textarea name=\"SMSALLARM\" rows=\"4\" cols=\"30\">$SMSALLARM</textarea></td>
				</tr></table>
				<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
				<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"EMAIL\">
				<input type=\"hidden\" name=\"CONF_SMS\" value=\"YES\">
				<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
			fi
		fi
		./footer.sh
		exit
	fi
	if [ "$SUBSUB_SECTION" == "DOOROPENERS" ];then
		echo "<font color=\"#0000FF\" size=\"3\">$LM_DOOROPENERS</font><br>&nbsp;<br>"
		if [[ -n "$CONF_FREE_TEL" || -n "$DEL_FREE_TEL" ]];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			echo "<br>&nbsp;<br>&nbsp;<br>"
			footerwait "480"
			if [ -n "$DEL_FREE_TEL" ];then
				$C_ZT_BIN_DIR/zt "mudc" "delFreeTel" "$DEL_FREE_TEL"
				return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=DOOROPENERS"
				exit	
			fi
			if [[ -n "$DAY_START" && -n "$MONTH_START" && -n "$YEAR_START" ]] && [[ -n "$DAY_EXPIRE" && -n "$MONTH_EXPIRE" && -n "$YEAR_EXPIRE" ]];then
				START=$(dateDiff -d "1970-01-01" "$YEAR_START-$MONTH_START-$DAY_START")
				EXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
				if [ "$START" -gt "$STOP" ];then
					START=""
					EXPIRE=""
				fi
			else
				START=""
				EXPIRE=""
			fi
			TEL="$(echo $TEL | sed 's/%2B//g')"
			[ "$(echo $TEL | wc -c | awk '{print $1}')" -lt 8 ] && TEL=""
			$C_ZT_BIN_DIR/zt "Aggiungi" "$TEL|$KEYPAD|$NAME|$START $EXPIRE" "$CM_MUDC_DIR/conf/FreeTel"
			$C_ZT_BIN_DIR/zt "mudc" "DelLineEmpty" "$CM_MUDC_DIR/conf/FreeTel"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=DOOROPENERS"
			exit	
		fi
		if [ -f $CM_MUDC_DIR/conf/dev.conf ];then
			DEVK="$(cat $CM_MUDC_DIR/conf/dev.conf)"
			if [ -z  "$($C_ZT_BIN_DIR/zt "mudc" "SearchKP" )" ];then
				CONTKD=""
			else
				CONTKD="YES"
			fi
		else
			CONTKD=""
		fi
		echo "$(/opt/asterisk/sbin/asterisk -r -x "sip show peer $2" | grep 'Status' | awk '{print $3}')"
		echo "<table class=\"tabellain\"  border=\"1\">
		<tr><td class=\"intesta\">&nbsp;&nbsp;&nbsp;Keypad&nbsp;&nbsp;&nbsp;</td>"
		if [ -f /opt/asterisk/etc/asterisk/sip.conf ];then
			
			PIDASTERISK="$(pidof asterisk)"
			TELAS="$(cat /opt/asterisk/etc/asterisk/sip.conf | sed -n '/];/p' |  cut -d']' -f1 | sed 's/\[//g')"
			NTEL="$(echo $TELAS | wc -w | awk '{print $1}')"
			
			echo "<td class=\"intesta\">&nbsp;&nbsp;&nbsp;Asterisk&nbsp;&nbsp;&nbsp;</td>"
			for N in $(seq 1 $NTEL);do
				if [ -z "$TELAS" ];then
					echo "<td class=\"intesta\">&nbsp;&nbsp;&nbsp;Sip N.?&nbsp;&nbsp;&nbsp;</td>"
				else 
					echo "<td class=\"intesta\">&nbsp;&nbsp;&nbsp;$(echo $TELAS | cut -d' ' -f$N)&nbsp;&nbsp;&nbsp;</td>"
				fi
			done
		fi
		echo "<tr><td align=\"center\">"
		if [ -n "$CONTKD" ];then
			echo "<img src=\"/images/abilita.png\"></td>"
		else
			echo "<img src=\"/images/disabilita.png\"</td>"
		fi
			if [ -f /opt/asterisk/etc/asterisk/sip.conf ];then		
			if [ -n "$PIDASTERISK" ];then
				echo "<td align=\"center\"><img src=\"/images/abilita.png\"></td>"
			else
				echo "<td align=\"center\"><img src=\"/images/disabilita.png\"</td>"
			fi
			for N in $(seq 1 $NTEL);do
				echo "<td align=\"center\">"
				TELP="$(echo $TELAS | cut -d' ' -f$N)"
				$C_ZT_BIN_DIR/zt "StatusPeer" "$TELP"
			done
		fi
		echo "</tr></table>"
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		YEND="$(($(date +%Y) + 10))"
		echo "<form method=\"POST\" action=\"config.sh\">"
		echo "$L_NAME: <input type=\"text\" name=\"NAME\" value=\"\">&nbsp;&nbsp;&nbsp;$L_TELEPHONE: <input type=\"text\"  name=\"TEL\" value=\"\">
		&nbsp;&nbsp;&nbsp;Keypad: <input type=\"text\" name=\"KEYPAD\" value=\"\">
		</br>&nbsp;&nbsp;<br>" 
		echo "<table WIDTH=\"550px\" border=\"0\" cellpadding=\"0px\"><tr>"
		if [ "$C_FORM_DATE" == "ita" ];then
		echo "<td height=\"30\">$LM_FROM:</td>
		<td><select name=\"DAY_START\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\" selected>$L_DAY</option></select></td>
		<td align=\"center\"><select name=\"MONTH_START\">"
		for M in "$L_JANUARY 1" "$L_FEBRAURY 2" "$L_MARCH 3" "$L_APRIL 4" "$L_MAY 5" "$L_JUNE 6" "$L_JULY 7" "$L_AUGUST 8" "$L_SEPTEMBER 9" "$L_OCTOBER 10" "$L_NOVEMBER 11" "$L_DECEMBER 12";do
			set -- $M
			echo "<option value=\"$2\">$1</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"YEAR_START\">"
		for A in $(seq 2016 $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>"
	else
		echo "<tr><td height=\"30\">$L_EXPIRY:</td>
		<td><select name=\"YEAR_START\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>
		<td align=\"center\"><select name=\"MONTH_START\">"
		for M in "$L_JANUARY 1" "$L_FEBRAURY 2" "$L_MARCH 3" "$L_APRIL 4" "$L_MAY 5" "$L_JUNE 6" "$L_JULY 7" "$L_AUGUST 8" "$L_SEPTEMBER 9" "$L_OCTOBER 10" "$L_NOVEMBER 11" "$L_DECEMBER 12";do
			set -- $M
			echo "<option value=\"$2\">$1</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"DAY_START\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
			echo "<option value=\"\" selected>$L_DAY</option></select></td>"
		fi
		echo "<td>&nbsp;</td>"
	if [ "$C_FORM_DATE" == "ita" ];then
			echo "<td height=\"30\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$LM_TO:</td>
			<td><select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\" selected>$L_DAY</option></select></td>
			<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
			for M in "$L_JANUARY 1" "$L_FEBRAURY 2" "$L_MARCH 3" "$L_APRIL 4" "$L_MAY 5" "$L_JUNE 6" "$L_JULY 7" "$L_AUGUST 8" "$L_SEPTEMBER 9" "$L_OCTOBER 10" "$L_NOVEMBER 11" "$L_DECEMBER 12";do
				set -- $M
				echo "<option value=\"$2\">$1</option>"
			done
			echo "<option value=\"\" selected>$L_MONTH</option></select></td>
			<td align=\"right\"><select name=\"YEAR_EXPIRE\">"
			for A in $(seq 2016 $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\" selected>$L_YEAR</option></select></td>"
		else
			echo "<tr><td height=\"30\">$L_EXPIRY:</td>
			<td><select name=\"YEAR_EXPIRE\">"
			for A in $(seq $YNOW $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\" selected>$L_YEAR</option></select></td>
			<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
			for M in "$L_JANUARY 1" "$L_FEBRAURY 2" "$L_MARCH 3" "$L_APRIL 4" "$L_MAY 5" "$L_JUNE 6" "$L_JULY 7" "$L_AUGUST 8" "$L_SEPTEMBER 9" "$L_OCTOBER 10" "$L_NOVEMBER 11" "$L_DECEMBER 12";do
				set -- $M
				echo "<option value=\"$2\">$1</option>"
			done
			echo "<option value=\"\" selected>$L_MONTH</option></select></td>
			<td align=\"right\"><select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\" selected>$L_DAY</option></select></td>"
		fi	
			echo "</tr></table>"
			echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DOOROPENERS\">
			<input type=\"submit\" name=\"CONF_FREE_TEL\" class=\"bottone\" value=\"$L_SAVE\"></form><br>&nbsp;<br>"
			LAST=$( cat $CM_MUDC_DIR/conf/FreeTel 2>/dev/null )
			if [ -n "$LAST" ] ; then
				echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
				echo "<table class=\"tabellain\" width=\"700\" border=\"1\">
				<tr>
				<td width=\"4%\" class=\"intesta\">N.</td>
				<td width=\"25%\" class=\"intesta\">$L_NAME</td>
				<td width=\"20%\" class=\"intesta\">$L_TELEPHONE</td>
				<td width=\"15%\" class=\"intesta\">Keypad</td>
				<td width=\"18%\" class=\"intesta\">$LM_FROM</td>
				<td width=\"18%\" class=\"intesta\">$L_EXPIRY</td>			
				<td width=\"3%\" class=\"intesta\">D.</td>
				</tr>"
				NC=1
				R="$(cat $CM_MUDC_DIR/conf/FreeTel | wc -l | awk '{print $1}')"
				for C in $(seq 1 $R);do
					RIG="$(cat $CM_MUDC_DIR/conf/FreeTel | sed -n ${C}p)"
					BG="$C_BG"
					[ $(expr $NC % 2 ) -eq 0 ] && BG="$C_BG1"
					TEL="$(echo "$RIG" | cut -d'|' -f1)"
					KEYPAD="$(echo "$RIG" | cut -d'|' -f2)"
					NAME="$(echo "$RIG" | cut -d'|' -f3)"
					DAYS="$(echo "$RIG" | cut -d'|' -f4)"
					if [ -n "$DAYS" ];then
						DAYSTART="$(echo "$DAYS" | cut -d' ' -f1)"
						DAYEXPIRE="$(echo "$DAYS" | cut -d' ' -f2)"
						if [ "$C_FORM_DATE" == "ita" ];then
							DATESTART="$(date -d  "1970-01-01 $DAYSTART days" "+%d/%m/%Y")"
							DATEEXPIRE="$(date -d  "1970-01-01 $DAYEXPIRE days" "+%d/%m/%Y"	)"
						else
							DATESTART="$(date -d  "1970-01-01 $DAYSTART days" "+%Y/%m/%d")"
							DATEEXPIRE="$(date -d  "1970-01-01 $DAYEXPIRE days" "+%Y/%m/%d"	)"
						
						fi
					fi 
					[ -z "$DAYSTART" ] && DATESTART="&nbsp;"
					[ -z "$DAYEXPIRE" ] && DATEEXPIRE="&nbsp;"
					echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NC</td>
					<td align=left>$NAME</td>
					<td style=\"text-align:center;\">$TEL</td>
					<td style=\"text-align:center;\">$KEYPAD</td>
					<td style=\"text-align:center;\">$DATESTART</td>
					<td style=\"text-align:center;\">$DATEEXPIRE</td>
					<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
					<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"DOOROPENERS\">
					<input type=\"hidden\" name=\"DEL_FREE_TEL\" value=\"$NC\">
					<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
					title=\"$L_DELETE $NC $NAME\"
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE $NC $NAME?');\"></form>
					</td></tr>"
					NC=$(($NC+1))
				done
				echo "</table>"
				echo "<br>&nbsp;<br>"
			fi
			./footer.sh
			exit
		fi
	if [ "$SUBSUB_SECTION" == "KEYPAD" ];then
		echo "<br><font color=\"blue\">KEYPAD</font><p>"
		
		if [ -n "$STARTDAEMON" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			$C_ZT_BIN_DIR/zt "mudc" "StartKeypad" "$SD"
			sleep 1
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=KEYPAD"
			exit
		fi
		if [ -n "$SK" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			sleep 2
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=KEYPAD"
			exit
		fi
		if [ -n "$RKEY" ];then
			echo "<img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			for CONF in "CM_KEYRELAY1" "CM_KEYRELAY2" "CM_KEYRELAY4" "CM_KEYRELAY5" "CM_KEYRELAY6" "CM_KEYRELAY7" "CM_KEYRELAY8" "CM_KEYRELAY9" "CM_KEYCCTV" "CM_KEYSCRIPT" "CM_ALLARMK" "CM_TIMEALLARM";do
				$C_ZT_BIN_DIR/zt "mudc" "SalvaConfig" "$CONF" "${!CONF}"
			done
			sleep 1
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=KEYPAD"
			exit
		fi
		
		if [[ ! -f $CM_MUDC_DIR/conf/dev.conf || ! -f $CM_MUDC_DIR/conf/keys.conf ]];then
			$C_ZT_BIN_DIR/zt "Errore" "$LM_ERRORKEYPAD" "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=KEYPAD"
			exit
		fi
		if [ -z  "$($C_ZT_BIN_DIR/zt "mudc" "SearchKP" )" ];then
			$C_ZT_BIN_DIR/zt "Errore" "$LM_ERRORKEYPAD" "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=MUDC&SUBSUB_SECTION=KEYPAD"
			exit
		fi
		if [[ -f $CM_MUDC_DIR/conf/dev.conf && -f $CM_MUDC_DIR/conf/keys.conf ]];then
			echo "<form method=\"POST\" action=\"config.sh\">"
			echo "$L_ACTIVE_SERVICE:&nbsp;"
			if [[ -n "$(pidof readkeys)" && -n "$CM_KEYPAD" ]];then
				echo "<input name=\"SD\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SD\" type=\"checkbox\">"
			fi
			echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
			<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"KEYPAD\">
			<input type=\"submit\" name=\"STARTDAEMON\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		fi
		echo "<img src=\"/images/barra.png\" alt=\"barra\"><br>"
		echo "<p><font color=\"blue\">CONFIG KEYS</font><p>"
		
		echo "<table width=\500px\"  border=\"0\"><tr><td>"
		
		echo "<table class=\"tabellakeys\"  border=\"1\">"
		echo "<td class=\"intesta\" width=\"50%\">Key</td>
		<td class=\"intesta\" width=\"50%\">Code</td></tr>"
		[ $(expr $I % 2 ) -eq 0 ] && BG="$C_BG1"
		for I in $(seq 1 7);do
			BG="$C_BG"
			[ $(expr $I % 2 ) -eq 0 ] && BG="$C_BG1"
			RIGA=$(cat $CM_MUDC_DIR/conf/keys.conf | /bin/sed -n "${I}p")
			NUM=$(echo "$RIGA" | cut -d' ' -f1)
			CODE=$(echo "$RIGA" | cut -d' ' -f2)
			echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NUM</td><td align=\"center\">$CODE</td></tr>"
		done
		echo "</table></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<td><td>"
		echo "<table class=\"tabellakeys\"  border=\"1\">"
		echo "<td class=\"intesta\" width=\"50%\">Key</td>
		<td class=\"intesta\" width=\"50%\">Code</td></tr>"
		[ $(expr $I % 2 ) -eq 0 ] && BG="$C_BG1"
		for I in $(seq 8 14);do
			BG="$C_BG"
			[ $(expr $I % 2 ) -eq 0 ] && BG="$C_BG1"
			RIGA=$(cat $CM_MUDC_DIR/conf/keys.conf | /bin/sed -n "${I}p")
			NUM=$(echo "$RIGA" | cut -d' ' -f1)
			CODE=$(echo "$RIGA" | cut -d' ' -f2)
			echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NUM</td><td align=\"center\">$CODE</td></tr>"
		done
		RIGA=$(cat $CM_MUDC_DIR/conf/keys.conf | /bin/sed -n "15p")
		NUM=$(echo "$RIGA" | cut -d' ' -f1)
		CODE=$(echo "$RIGA" | cut -d' ' -f2)
		echo "<tr><td align=\"center\">ENTER</td><td align=\"center\">$CODE</td></tr>"
		echo "</table>"
		echo "<td></tr></table>"
		echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><br>"
		echo "<br><font color=\"#0000FF\" size=\"5\">Relays</font><p>"
		if [  "$CM_HEATING" == "on" ];then
			R2="$LM_HEATING"
		else
			R2="$LM_NAMERELAY2"
		fi
		echo "<div id=ris>
		<form name=\"BODOOR\" action=\"./config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"BODO\" value=\"ok\">"
		echo "<div id=content1>
		<form method=\"post\" action=\"config.sh\"><p><p><center>
		<table width=\"85%\" border=0>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>(R1) $LM_NAMERELAY1: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:160px\" name=\"CM_KEYRELAY1\" value=\"$CM_KEYRELAY1\">
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>(R2) $R2:</strong></td>
		<td ><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY2\" value=\"$CM_KEYRELAY2\">
		&nbsp;on +1 off +0
		</td></tr>"
		echo "<tr style=\"height:4px;\"><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td></tr>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>(R4) $LM_NAMERELAY4: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY4\" value=\"$CM_KEYRELAY4\">
		&nbsp;on +1 off +0
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>(R5) $LM_NAMERELAY5:</strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY5\" value=\"$CM_KEYRELAY5\">
		&nbsp;on +1 off +0
		</td></tr>"
		echo "<tr style=\"height:4px;\"><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td></tr>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>(R6) $LM_NAMERELAY6: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY6\" value=\"$CM_KEYRELAY6\">
		&nbsp;on +1 off +0
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>(R7) $LM_NAMERELAY7:</strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY7\" value=\"$CM_KEYRELAY7\">
		&nbsp;on +1 off +0
		</td></tr>"
		echo "<tr style=\"height:4px;\"><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td></tr>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>(R8) $LM_NAMERELAY8: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY8\" value=\"$CM_KEYRELAY8\">
		&nbsp;on +1 off +0
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>$LM_GENERAL:</strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYRELAY9\" value=\"$CM_KEYRELAY9\">
		&nbsp;on +1 off +0
		</td></tr>"
		echo "<tr style=\"height:4px;\"><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td></tr>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>$LM_CCTV: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYCCTV\" value=\"$CM_KEYCCTV\">
		&nbsp;on +1 off +0
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>Script:</strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_KEYSCRIPT\" value=\"$CM_KEYSCRIPT\">-var1-var2-...
		</td>"
		echo "<tr style=\"height:4px;\"><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>&nbsp;<td>&nbsp;</td><td>&nbsp;</td></tr>"
		echo "<tr><td style=\"vertical-align:middle\"><strong>Start $LM_ALLARM: </strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_ALLARMK\" value=\"$CM_ALLARMK\">
		&nbsp;on +1 off +0
		<td style=\"vertical-align:middle\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style=\"vertical-align:middle\"><strong>$LM_TIMEALLARM (sec):</strong></td>
		<td style=\"vertical-align:middle;\"><input type=\"text\" style=\"width:60px\" name=\"CM_TIMEALLARM\" value=\"$CM_TIMEALLARM\"></td>
		</tr></table>"
		echo "<br><input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"KEYPAD\">
		<input type=\"submit\" name=\"RKEY\" class=\"bottone\" value=\"$L_SAVE\"></form><br>&nbsp;"
		echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><br>"
		echo "<p><font color=\"blue\">Script</font><p>"
		echo "<form method=\"POST\" action=\"config.sh\">
		<p>scriptkeypad.sh<br><textarea name=\"SCRIPTKEY\" rows=\"20\" cols=\"90\">$(cat $CM_MUDC_DIR/scripts/scriptkeypad.sh)</textarea>"
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"MUDC\">
		<input type=\"hidden\" name=\"SUBSUB_SECTION\" value=\"KEYPAD\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<p><input type=\"submit\" name=\"SK\" class=\"bottone\" value=\"$L_SAVE\"></form><br>&nbsp;"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "TEST" ];then
		if [ -n "$DISKTEST" ];then
			echo "<p>Disk Test"
			echo "<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>"
			wait "550"
			$C_ZT_BIN_DIR/zt "DiskTest"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=TEST"
			exit
		fi
		if [ -n "$CPUTEST" ];then
			echo "<p>CPU Test"
			echo "<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>"
			wait "550"
			$C_ZT_BIN_DIR/zt "CPUTest"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=TEST"
			exit
		fi
		echo "<br>&nbsp;<font color=\"blue\">Speedy Test</font>"
		if [[ -f $C_ZT_CONF_DIR/speedytest/download  && -z "$TEST" ]];then
			SERVER="$(cat $C_ZT_CONF_DIR/speedytest/server)"
			if [ -n "$SERVER" ];then
				SERVER="$(cat $C_ZT_CONF_DIR/speedytest/serversST | grep "$SERVER" | cut -d'|' -f1)"
				LASTDATE="$(ls -l --full-time $C_ZT_CONF_DIR/speedytest/server | awk '{print $6}')"
				LASTYEAR="$(echo "$LASTDATE" | cut -d'-' -f1)"
				LASTMONTH="$(echo "$LASTDATE" | cut -d'-' -f2)"
				LASTDAY="$(echo "$LASTDATE" | cut -d'-' -f3)"
				LASTHOUR="$(ls -l --full-time $C_ZT_CONF_DIR/speedytest/server | awk '{print $7}')"
				LASTH=$(echo "$LASTHOUR" | cut -d':' -f1)
				LASTM=$(echo "$LASTHOUR" | cut -d':' -f2)
				if [ "$C_FORM_DATE" == "ita" ];then
					LASTDATE="$LASTDAY/$LASTMONTH/$LASTYEAR $LASTH:$LASTM"
				else
					LASTDATE="$LASTYEAR/$LASTMONTH/$LASTDAY $LASTH:$LASTM"
				fi
				echo "<br>&nbsp;<br>Server: $SERVER ($LASTDATE)<br>&nbsp;<br>"
			fi
			echo "<table class=\"tabellain\" width=\"800\" border=\"1\">
			<tr>
			<td width=\"20%\" class=\"intesta\">Download</td>
			<td width=\"20%\" class=\"intesta\">Upload</td>
			<td class=\"intesta\">Ping</td>
			</tr>"

			SERVER="$(cat $C_ZT_CONF_DIR/speedytest/server)"
			echo "<tr><td align=\"center\">$(cat $C_ZT_CONF_DIR/speedytest/download) MB/s</td>"
			CSP="yes"
		fi
		if [[ -f $C_ZT_CONF_DIR/speedytest/upload && -z "$TEST" && -z "$TESTUP" ]];then
			echo "<td align=\"center\">$(cat $C_ZT_CONF_DIR/speedytest/upload) MB/s</td>"
			PING=" $(cat $C_ZT_CONF_DIR/speedytest/ping | grep '^rtt' | cut -d'=' -f2)"
			MIN=$(echo "$PING" | cut -d'/' -f1)
			AVG=$(echo "$PING" | cut -d'/' -f2)
			MAX=$(echo "$PING" | cut -d'/' -f3)
			MDEV=$(echo "$PING" | cut -d'/' -f4)
			echo "<td align=\"center\">min:$MIN - avg: $AVG - max: $MAX - mdev: $MDEV</td>"
			CSP="yes"
		fi
		if [[ -f $C_ZT_CONF_DIR/speedytest/download  && -z "$TEST" ]];then
			echo "</tr></table>"
		fi
		if [ -n "$CSP" ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		if [[ -n "$TEST" && -n "$SERVER_SPEED" ]];then
			echo "<p>Download Test"
			wait "550"
			$C_ZT_BIN_DIR/zt "SpeedyTest" "$SERVER_SPEED"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=TEST&TESTUP=yes&SERVER_SPEED=$SERVER_SPEED"
			exit
		fi
		if [ -n "$TESTUP" ];then
			echo "<p>Upload Test"
			echo "<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>"
			wait "480"
			$C_ZT_BIN_DIR/zt "SpeedyTest" "$SERVER_SPEED" "TESTUP"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=TEST"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		Server: <select name=\"SERVER_SPEED\">"
		RIGHE=$(cat $C_ZT_CONF_DIR/speedytest/serversST | wc -l | awk '{print $1}' )
		for I in $(seq 1 $RIGHE);do
			RIGA=$(cat $C_ZT_CONF_DIR/speedytest/serversST | /bin/sed -n "${I}p")
			NS="$(echo $RIGA | cut -d'|' -f1)"
			URLS="$(echo $RIGA | cut -d'|' -f2)"
			echo "<option value=\"$URLS\">$NS</option>"
		done
		echo "<option value=\"\" selected></option></select>
		<p>
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TEST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"TEST\" class=\"bottone\" value=\"$L_SENDS\"></form>"
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		echo "<font color=\"blue\">Disk Test</font>"
		if [ -n "$(cat $C_ZT_CONF_DIR/disktest)" ];then
			echo ": $(cat $C_ZT_CONF_DIR/disktest)"
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TEST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"DISKTEST\" class=\"bottone\" value=\"$L_SENDS\"></form>"
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		echo "<font color=\"blue\">CPU Test</font>"
		if [ -n "$(cat $C_ZT_CONF_DIR/cputest)" ];then
			echo "<br>&nbsp;<br>
			$(cat $C_ZT_CONF_DIR/cputype)<br>&nbsp;<br>
			Time taken to generate PI to 5000 decimal places with a single thread: $(cat $C_ZT_CONF_DIR/cputest)"
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TEST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"CPUTEST\" class=\"bottone\" value=\"$L_SENDS\"></form><br>"
		./footer.sh
	fi
	if [ "$SUB_SECTION" == "EXPORT" ];then
		echo "<br>&nbsp;
		<font color=\"blue\">Export Users</font>"
		if [ -n "$SEND" ];then
			wait "550"
			if [ "$TYPE_EX" == "TEXT" ];then
				EST="txt"
			else
				EST="csv"
			fi
			$C_ZT_BIN_DIR/zt "Salva" "" "/tmp/exportuser.$EST"
			search "$USERNAME_RIC" "$NAME_RIC" "$LAST_NAME_RIC" "$CLASS_RIC" "$ROOM_RIC" "$PHONE_RIC" "$EMAIL_RIC" "$EXPIRE_RIC" "$OWNER_RIC"
			PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAP" -S $SORT uid )
			USERPEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
			NUMB=1
			for USERNAME in $USERPEOPLE;do
				if [ "$USERNAME" != "admin" ];then
					ldap_search_people "uid=$USERNAME"
					ldap_search_radius "$USERNAME"
					USER_CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit)
					[ -z "$USER_CREDIT" ] && USER_CREDIT="0.00"
					SEP=" "
					if [ -n "$MAXDAYS" ];then
						EXPIRE_PRINT="$MAXDAYS $L_DAYS"
					else
						if [ "$EXPIRE" == 24836 ];then
							EXPIRE_PRINT="$L_NO_LIMIT"
						else
							if [ "$C_FORM_DATE" == "ita" ];then
								EXPIRE_PRINT=$(date -d "1970-01-01 $EXPIRE days" +%d/%m/%Y)
							else
								EXPIRE_PRINT=$(date -d "1970-01-01 $EXPIRE days" +%Y/%m/%d)
							fi
						fi
					fi
					[ "$EST" == "csv" ] && SEP=","
					TEXT=""
					[ -n "$NUMBER_EX" ] && TEXT="$NUMB$SEP"
					[ -n "$USERNAME_EX" ] && TEXT="$TEXT$USERNAME$SEP"
					if [ -n "$PASSWORD_EX" ];then
						PASSWORD="$(echo $PASSWORD | cut -d'-' -f1)"
						TEXT="$TEXT$PASSWORD$SEP"
					fi
					[ -n "$NAME_EX" ] && TEXT="$TEXT$NAME$SEP"
					[ -n "$LAST_NAME_EX" ] && TEXT="$TEXT$LAST_NAME$SEP"
					[ -n "$EMAIL_EX" ] && TEXT="$TEXT$EMAIL$SEP"
					[ -n "$PHONE_EX" ] && TEXT="$TEXT$PHONE$SEP"
					[ -n "$CLASS_EX" ] && TEXT="$TEXT$CLASS$SEP"
					[ -n "$EXPIRY_EX" ] && TEXT="$TEXT$EXPIRE_PRINT$SEP"
					TEXT=$(echo "$TEXT" | sed 's/,$//g' | sed 's/ $//g')
					$C_ZT_BIN_DIR/zt "Aggiungi" "$TEXT" "/tmp/exportuser.$EST"
				fi
				NUMB=$(($NUMB+1))
			done
			valrandom 12
			$C_ZT_BIN_DIR/zt "CompExport" "$EST" "BK_$VALRANDOM"
			return_page "config.sh?SECTION=ZEROTRUTH&SUB_SECTION=EXPORT&BK=yes&DIR=BK_$VALRANDOM"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		<br><table class=\"naked\" width=\"55%\">
		<tr><td>$L_USERNAME: </td>
		<td><input name=\"USERNAME_RIC\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td>
		<td>$L_CLASS: </td><td>
		<select name=\"CLASS_RIC\">"
		for class in $(ls $C_CLASSES_DIR);do
			if [ -d $C_CLASSES_DIR/$class ];then
				echo "<option value=\"$class\" selected>$class</option>"
			fi
		done
		echo "<option value=\"\" selected></option>
		</option></select></td></tr>
		<tr><td>$L_NAME:</td>
		<td><input name=\"NAME_RIC\" type=\"text\" value=\"\" size=\"10\" maxlength=\"50\"></td>
		<td>$L_LAST_NAME : </td>
		<td><input name=\"LAST_NAME_RIC\" type=\"text\" value=\"\" size=\"10\" maxlength=\"50\"></td></tr>
		<tr><td>$L_EMAIL:</td>
		<td><input name=\"EMAIL_RIC\" type=\"text\" value=\"\" size=\"10\" maxlength=\"50\"></td>
		<td>$L_PHONE: </td>
		<td><input name=\"PHONE_RIC\" type=\"text\" value=\"\" size=\"10\" maxlength=\"50\"></td></tr>
		<tr><td>$L_EXPIRED:<td>
		<select name=\"EXPIRE_RIC\">
		<option value=\"no\" selected>$L_YES</option>
		<option value=\"yes\" selected>$L_NO</option>
		</option></select></td>"
		if [[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]];then
			ROOMS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" roomName | sed -n '/roomName:/p' | awk '{ print $2 }' | sed '/\?/d' | sort | uniq )
			echo "<td>$C_ROOM_NAME: </td><td>
			<select name=\"ROOM_RIC\">"
			for ST in $ROOMS;do
				if [ "$ST" != "?" ];then
					echo "<option value=\"$ST\" selected>$ST</option>"
				fi
			done
			echo "<option value=\"\" selected></option>
			</select></td>"
		else
			echo "<td>$L_OWNER: </td><td>
			<select name=\"OWNER_RIC\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
		if [ -z "$CONTROLOW" ];then
			echo "<tr><td>$L_OWNER:<td>
			<select name=\"OWNER_RIC\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
		if [ -z "$CONTROLOW" ];then
			echo "<input type=\"hidden\" name=\"OWNER_EX\" value=\"$UTENTEC\">"
		fi
		echo "<tr><td>$L_FORMAT:<td>
		<select name=\"TYPE_EX\">
		<option value=\"CSV\" >CSV</option>
		<option value=\"TEXT\" selected>$L_TEXT</option></select></td>
		<td>$L_SORT_BY:<td>
		<select name=\"SORT\">
		<option value=\"givenName\" >$L_NAME</option>
		<option value=\"sn\" >$L_LAST_NAME</option>
		<option value=\"mail\">$L_EMAIL</option>
		<option value=\"telephoneNumber\" >$L_PHONE</option>
		<option value=\"shadowExpire\" >$L_EXPIRY</option>
		<option value=\"uid\" selected>Username</option></select></td></tr>
		<tr><td colspan=\"4\" align=\"center\"><font color=\"blue\">$L_PRINT</font></td></tr>
		<tr><td>$L_NUMBER:<td><input name=\"NUMBER_EX\" type=\"checkbox\"></td>
		<td>$L_USERNAME:<td><input name=\"USERNAME_EX\" type=\"checkbox\"></td></tr>
		<tr><td>$L_NAME:<td><input name=\"NAME_EX\" type=\"checkbox\"></td>
		<td>$L_LAST_NAME:<td><input name=\"LAST_NAME_EX\" type=\"checkbox\"></td></tr>
		<tr><td>$L_EMAIL:<td><input name=\"EMAIL_EX\" type=\"checkbox\"></td>
		<td>$L_PHONE:<td><input name=\"PHONE_EX\" type=\"checkbox\"></td></tr>
		<tr><td>$L_CLASS:<td><input name=\"CLASS_EX\" type=\"checkbox\"></td>
		<td>$L_CREDIT:<td><input name=\"CREDIT_EX\" type=\"checkbox\"></td></tr>
		<tr><td>$L_EXPIRY:<td><input name=\"EXPIRY_EX\" type=\"checkbox\"></td>
		<td>$L_PASSWORD:<td><input name=\"PASSWORD_EX\" type=\"checkbox\"></td></tr>
		</table>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"EXPORT\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"SEND\" class=\"bottone\" value=\"$L_SENDS\"></form><br>"
		./footer.sh
		if [ -n "$BK" ];then
			FILE_DOWNLOAD=$(ls $C_HTDOCS_DIR/$DIR/*.tgz | cut -d'/' -f6)
			echo "<script type=\"text/javascript\">window.location=\"/$DIR/$FILE_DOWNLOAD\";</script>"
		fi
		exit
	fi
	if [ "$SUB_SECTION" == "LOG" ];then
		if [ -z "$ZTLOG" ];then
			YEAR=$(date +%Y)
			DAY=$(date +%d)
			MONTH=$(date +%b)
			ZTLOG="Scripts"
		fi
		YEARS="$(ls /Database/LOG)"
		HOSTN=$(echo $HOSTNAME | cut -d'.' -f1)
		echo "<br>&nbsp;<br>
		<table width=\"550\">
		<tr><td colspan=\"4\" align=\"center\">
		<form name=\"formlog\" method=\"POST\" action=\"config.sh\">
		<select name=\"YEAR\" onChange=\"document.formlog.submit()\">"
		for A in $YEARS;do
			if [ "$A" != "$YEAR" ];then
				echo "<option value=\"$A\" selected>$A</option>"
			fi
		done
		echo "<option value=\"$YEAR\" selected>$YEAR</option></select>
		&nbsp;&nbsp;&nbsp;
		<select name=\"MONTH\" onChange=\"document.formlog.submit()\">"
		if [ ! -d /Database/LOG/$YEAR/$MONTH ];then
			for M in $(ls /Database/LOG/$YEAR);do
				MONTH="$M"
			done
		fi
		for M in $(ls /Database/LOG/$YEAR);do
			if [ "$M" != "$MONTH" ];then
				if [ -n "$(ls /Database/LOG/$YEAR | grep "$M")" ];then
					echo "<option value=\"$M\" selected>$M</option>"
				fi
			fi
		done
		echo "<option value=\"$MONTH\" selected>$MONTH</option></select>
		&nbsp;&nbsp;&nbsp;
		<select name=\"DAY\" onChange=\"document.formlog.submit()\">"
		if [ ! -d /Database/LOG/$YEAR/$MONTH/$DAY ];then
			for G in $(ls /Database/LOG/$YEAR/$MONTH);do
				DAY="$G"
			done
		fi
		for G in $(ls /Database/LOG/$YEAR/$MONTH);do
			if [ "$G" != "$DAY" ];then
				if [ -n "$(ls /Database/LOG/$YEAR/$MONTH | grep "$G")" ];then
					echo "<option value=\"$G\" selected>$G</option>"
				fi
			fi
		done
		echo "<option value=\"$DAY\" selected>$DAY</option></select>
		</td></tr>
		<tr><td colspan=\"4\">&nbsp;</td></tr>
		<tr><td>
		<font color=\"blue\">$L_SECTION:</font>&nbsp;</td><td>
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"LOG\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<select name=\"ZTLOG\" onChange=\"document.formlog.submit()\">"
		for L in $(ls /Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN);do
				echo "<option value=\"$L\">$L</option>"
		done
		ZTLOG1=$(echo "$ZTLOG" | sed 's/_/ /g')
		echo "<option value=\"$ZTLOG\" selected>$ZTLOG1</option></select></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>
		<font color=\"blue\">$L_FILTER:</font>&nbsp;
		<input type=\"text\"  name=\"FILTER\" value=\"$FILTER\" onChange=\"document.formlog.submit()\"></form>
		<tr></table>"
		if [ -z "$ZTLOG" ];then
			echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><br>"
		fi
		VAR_LOG=$(echo "$ZTLOG" | cut -sd'_' -f1)
		[ "$VAR_LOG" == "USER" ] && NAME_USER=$(echo "$ZTLOG" | cut -sd'_' -f2)
		[ "$VAR_LOG" == "SQUID" ] && SQUID_LOG=$(echo "$ZTLOG" | cut -sd'_' -f2)
		[ "$VAR_LOG" == "DG" ] && DG_LOG=$(echo "$ZTLOG" | cut -sd'_' -f2)
		if [[ -n "$DELLOG" && "$ZTLOG" != "arp" && -z "$NAME_USER" && -z "$SQUID_LOG" && -z "$DG_LOG" ]];then
			$C_ZT_BIN_DIR/zt "Cancella" "/Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN/$ZTLOG"
			$C_ZT_BIN_DIR/zt "CreaFile" "/Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN/$ZTLOG"
		fi
		if [ -n "$ZTLOG" ];then
			echo "<br>"
			echo "<div id=\"tabellalog\">"
			if [ -s /Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN/$ZTLOG ];then
				RIGHE=$(cat /Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN/$ZTLOG | wc -l )
				for I in $(seq 1 $RIGHE);do
					RIGA=$(cat cat /Database/LOG/$YEAR/$MONTH/$DAY/$HOSTN/$ZTLOG | /bin/sed -n "${I}p")
					RIGA=$(echo "$RIGA" | sed 's/\&/ \&/g' | sed 's/|/ |/g' | sed 's/\%/ \%/g' | sed 's/_/ _ /g' | sed 's/\=/ \= /g' | sed 's/__/_ _/g' | sed 's/^/<strong><font color=\"blue\">/g' | sed "s/ "$(echo "$HOSTNAME" | cut -d'.' -f1)" /<\/font><\/strong> /g")
					if [ -n "$FILTER" ];then
						if [ -n "$(echo "$RIGA" | grep "$FILTER")" ];then
							echo -e "$RIGA<br>"
						fi
					else
						echo -e "$RIGA<br>"
					fi
				done
			else
				echo "Log empty"
			fi
			echo "</div><br><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;
			<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"LOG\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"ZTLOG\" value=\"$ZTLOG\">
			<input type=\"hidden\" name=\"YEAR\" value=\"$YEAR\">
			<input type=\"hidden\" name=\"MONTH\" value=\"$MONTH\">
			<input type=\"hidden\" name=\"DAY\" value=\"$DAY\">
			<input type=\"submit\" name=\"ZTL\" class=\"bottonelinea\" value=\"$L_REFRESH\"></form>
			<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"LOG\">
			<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
			<input type=\"hidden\" name=\"ZTLOG\" value=\"$ZTLOG\">
			<input type=\"hidden\" name=\"YEAR\" value=\"$YEAR\">
			<input type=\"hidden\" name=\"MONTH\" value=\"$MONTH\">
			<input type=\"hidden\" name=\"DAY\" value=\"$DAY\">
			<input type=\"submit\" name=\"DELLOG\" class=\"bottonelineadue\" value=\"$L_DELETE\"
			onClick=\"javascript:return confirm('$L_ALERT_SURE?');\"></form>
			<br>&nbsp;<br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "VSBS" ];then
		[ -z "$COMAND" ] && COMAND="cd"
		echo "<script>
		window.onload=function(){document.getElementById(\"bash\").focus()}
		</script>"
		if [ $(echo "$COMAND" | awk '{print $1}') == "cd" ];then
			if [ -n "$(echo "$COMAND" | awk '{print $2}')" ];then
				COMAND=$(echo "$COMAND" | sed 's/%2F/\//g' )
				if [ "$(echo "$COMAND" | awk '{print $2}' | grep '^/')" ];then
					echo "$(echo "$COMAND" | awk '{print $2}')" > /tmp/dirbash
					[[ -d "$(echo "$COMAND" | awk '{print $2}')" && "$(echo "$COMAND" | awk '{print $2}')" != ".." ]] && echo "$(echo "$COMAND" | awk '{print $2}')" > /tmp/dirbashori
				else
					OLDDIR="$(cat /tmp/dirbash)"
					SUBDIR=$(echo "$COMAND" | awk '{print $2}')
					echo "$OLDDIR/$SUBDIR" > /tmp/dirbash
					[[ -d "$OLDDIR/$SUBDIR" && -z $(echo "$SUBDIR" | grep '\.\.') ]] && echo "$(echo "$OLDDIR/$SUBDIR")" > /tmp/dirbashori
				fi
			else
				echo "/root" > /tmp/dirbash
				echo "/root" > /tmp/dirbashori
			fi
		fi
		if [[ $(echo "$COMAND" | awk '{print $1}') == "ping" && $(echo "$COMAND" | awk '{print $2}') != "-c" ]];then
			COMAND="$(echo "$COMAND" | sed 's/ping/ping -c 3/g')"
		fi
		echo "<p><font color=\"blue\">Very Simple Bash Shell</font><p>
		<form name=\"modulo\" method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"VSBS\">
		<input  type=\"text\" name=\"COMAND\" id=\"bash\" value=\" \" style=\"width: 700px\">
		<input type=\"hidden\" name=\"CONTROL_PLAIN\" value=\"ok\"><br>&nbsp;<br>
		<input type=\"submit\"  name=\"INVIA\" class=\"bottone\" value=\"$L_SENDS\"></form>
		<br><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;
		<table style=\"table-layout: fixed; width: 700px; height: 150px; border-collapse: collapse; border-color: #a0a0f0; background-color: #000000;
		margin:0 auto; font: 12px/14px "Trebuchet MS",Arial,sans-serif; color: white\" border=1><tr><td align=\"left\"><pre>"
		$C_ZT_BIN_DIR/zt "Bash" "$COMAND"
		echo "</pre></td></tr></table><br>&nbsp;<br>"
	fi
	if [ "$SUB_SECTION" == "CHECKLDAP" ];then
		if [[ -n "$CHECK_LDAP" || -n "$CHECK_LDAP_REPAIR" ]];then
		
			if [ -n "$CHECK_LDAP" ];then
				echo "<p><font color=\"blue\">$L_CHECK Ldap</font><p>"
			else
				echo "<p><font color=\"blue\">LDAP: $L_CHECK_REPAIRS</font><p>"
			fi
			echo "<table class=\"tabellaldap\"  border=\"1\">
			<td class=\"intesta\" width=\"10%\">N.</td>
			<td class=\"intesta\" width=\"45%\">Username</td>
			<td class=\"intesta\" width=\"45%\">$L_STATUS</td></tr>"
			[ -n "$CHECK_LDAP" ] && ldap_repair "view"
			[ -n "$CHECK_LDAP_REPAIR" ] && ldap_repair "repair" "view"
			echo "</table><p>"
			
		fi
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CHECKLDAP\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"CHECK_LDAP\" class=\"bottonelinea\" value=\"$L_CHECK\"></form>
		<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CHECKLDAP\">
		<input type=\"hidden\" name=\"SECTION\" value=\"ZEROTRUTH\">
		<input type=\"submit\" name=\"CHECK_LDAP_REPAIR\" class=\"bottonelineadue\" value=\"$L_CHECK_REPAIRS\"
		onClick=\"javascript:return confirm('$L_ALERT_SURE?');\"></form><br>&nbsp;"
		./footer.sh
		exit
	fi
fi
if [ "$SECTION" == "IMAGE" ];then
	echo "<font color=\"#0000FF\" size=\"3\">$L_MAIN_IMAGE</font><p>"
	wait "650"
	sleep 3
	return_page "config.sh?SECTION=IMAGE"
	exit
fi
if [ "$SECTION" == "LOGO" ];then
	echo "<font color=\"#0000FF\" size=\"3\">LOGO</font><p>"
	wait "650"
	sleep 3
	return_page "config.sh?SECTION=IMAGE"
	exit
fi
if [ "$SECTION" == "CAPTIVE_PORTAL" ];then
	if [ -z "$(cat $C_CP_DIR/msg/Lang | grep 'Custom' )" ];then
		$C_ZT_BIN_DIR/zt "Salva" "Custom" "$C_CP_DIR/msg/Lang"
	fi
	if [ "$(cat $C_SYSTEM/acct/Enabled)" != "yes" ];then
		$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_SYSTEM/acct/Enabled"
		$C_ZT_BIN_DIR/zt "AccountingStart"
	fi
	echo "<font color=\"#0000FF\" size=\"4\">Captive Portal</font><p>"
	if [ -z "$C_FREE_CP" ];then
		echo "<table  border=\"0\" cellpadding=\"3\">"
	else
		echo "<table  border=\"0\" cellpadding=\"3\">"
	fi
	echo "<tr>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Captive Portal\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"SELF_REGISTERING\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"$L_SELF_REGISTERING\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ALERTS\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"$L_ALERTS\"></form></td>"
##	if [ -z "$C_FREE_CP" ];then
		echo  "<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TICKET\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_TICKET\"></form></td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYPAL\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"PayPal\"></form></td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYMENTS\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_PAYMENTS\"></form></td>"
##	fi
	echo "<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"$L_FREE_AUTHORIZED\"></form></td>
	</tr></table>
	<table width=\"545\"><tr><td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"WALLED_GARDEN\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"Walled Garden\"></form></td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"POPUP\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"Popup\"></form></td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"IMGLOGIN\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_IMAGES_LOGIN\"></form></td>
		<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FACEBOOKLIKE\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"Facebook Like\"></form></td>
		</tr>

	</table>"
	if [ -n "$CONF_CP" ];then
		wait "600"
		for CONF in "ACTIVE_CP" "FREE_CP" "ANONYMOUS_USER" "PREFIX" "LENGH_USERNAME" "LENGH_PASSWORD" "CURRENCY" "DECIMAL" "ZT_POPUP" "SHOW_TIME_DISCONNECT" \
			"FORM_DATE" "SHOW_NOT_INTERNET" "SHOW_NOT_INTERNET_ADMIN" "PREFIX_USERNAME" "ROOM_NAME" "VIEW_DOMAIN" "DISCONNECT_TIME" "SHOW_MB_DISCONNECT"\
			"WAIT_LOGIN" "WAIT_LOGIN_TIME" "TABLE_FAST" "REDIRECT_QR" "SORT_TABLE" "VIEW_PHONE" "VIEW_EMAIL" "VIEW_EXPIRY" "VIEW_CLASS";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		$C_ZT_BIN_DIR/zt "Salva" "$TEMPLATE" "$C_CP_DIR/Auth/Custom/Template"
		$C_ZT_BIN_DIR/zt "ConfigTemplate" "$TEMPLATE"
		$C_ZT_BIN_DIR/zt "ZtPopup" "$ZT_POPUP"
		if [ -n "$TABLE_FAST" ];then
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/usersfull.sh"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/users.sh"
			$C_ZT_BIN_DIR/zt "Copia" "$C_ZT_CONF_DIR/table/usersfast" "$C_ZT_DIR/users.sh"
			$C_ZT_BIN_DIR/zt "Copia" "$C_ZT_CONF_DIR/table/usersfull" "$C_ZT_DIR/usersfull.sh"
		else
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/usersfull.sh"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/users.sh"
			$C_ZT_BIN_DIR/zt "Copia" "$C_ZT_CONF_DIR/table/usersfull" "$C_ZT_DIR/users.sh"
		fi
		
		if [[ -z "$SHOW_NOT_INTERNET" && -f $C_ZT_CONF_DIR/fakedns ]];then
			$C_ZT_BIN_DIR/zt "RestoreDns"
		fi
		if [ -n "$POPUP" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Popup"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/Popup"
		fi
		if [ -n "$WGARDEN" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/WalledGarden"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/WalledGarden"
		fi
		if [ -n "$REPASS" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/RePass"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/RePass"
		fi
		if [ -n "$SHOWMB" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ShowMB"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ShowMB"
		fi
		if [ -n "$SHOWCOST" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ShowCost"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ShowCost"
		fi
		if [ -n "$SHOWIMGLOGIN" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ShowImgLogin"
			$C_ZT_BIN_DIR/zt "CreateImageRandom"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ShowImgLogin"
		fi
		if [ -n "$LOGINML" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/LoginML"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/LoginML"
		fi
		if [[ -n "$ACTIVE_CP" && -z "$FREE_CP" ]];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-on" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
			if [ "$VIEW_DOMAIN" == "on" ];then
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/Domain"
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/DomainVisible"
			else
				DOMAIN="$(cat $C_SYSTEM/ldap/base | sed 's/,/./g' | sed 's/dc=//g')"
				#DOMAIN="$(echo $HOSTNAME | cut -d'.' -f2,3,4)"
				$C_ZT_BIN_DIR/zt "Salva" "$DOMAIN" "$C_CP_DIR/Auth/Custom/Domain"
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/DomainVisible"
			fi
			$C_ZT_BIN_DIR/zt "Salva" "no" "$C_CP_DIR/Auth/Custom/CpFree"
		fi
		if [[ -n "$ACTIVE_CP" && -n "$FREE_CP" ]];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-free" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
			DOMAIN="$(echo $HOSTNAME | cut -d'.' -f2).$(echo $HOSTNAME | cut -d'.' -f3)"
			$C_ZT_BIN_DIR/zt "Salva" "$DOMAIN" "$C_CP_DIR/Auth/Custom/Domain"
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/CpFree"
		fi
		if [ -z "$ACTIVE_CP" ];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-off" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
		fi
		PASS_CHARS=0
		if [ -n "$PASS_CHARS_1" ];then
			PASS_CHARS=`expr $PASS_CHARS + 1`
		fi
		if [ -n "$PASS_CHARS_2" ];then
			PASS_CHARS=`expr $PASS_CHARS + 2`
		fi
		if [ -n "$PASS_CHARS_3" ];then
			PASS_CHARS=`expr $PASS_CHARS + 4`
		fi
		if [ -n "$PASS_CHARS_4" ];then
			PASS_CHARS=`expr $PASS_CHARS + 8`
		fi
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_PASS_CHARS" "$PASS_CHARS"
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		CONTROLV=$(echo "$INTERFACECP" | cut -sd'.' -f2)
		if [ -n "$CONTROLV" ];then
			INTERFACE=$(echo "$INTERFACECP" | cut -d'.' -f1)
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		else
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "Requested" "$C_CP_DIR/Auth/RedirectionMode"
		return_page "config.sh?SECTION=CAPTIVE_PORTAL"
		exit
	fi
	if [ -n "$CONF_CP_FREE" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "Salva" "$TEMPLATE" "$C_CP_DIR/Auth/Custom/Template"
		$C_ZT_BIN_DIR/zt "ConfigTemplate" "$TEMPLATE"
		for CONF in "ACTIVE_CP" "FREE_CP"  "DECIMAL" "FORM_DATE" "DISCONNECT_TIME";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		if [[ -n "$ACTIVE_CP" && -z "$FREE_CP" ]];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-on" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
			$C_ZT_BIN_DIR/zt "Salva" "no" "$C_CP_DIR/Auth/Custom/CpFree"
		fi
		if [[ -n "$ACTIVE_CP" && -n "$FREE_CP" ]];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-free" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
			DOMAIN="$(echo $HOSTNAME | cut -d'.' -f2).$(echo $HOSTNAME | cut -d'.' -f3)"
			$C_ZT_BIN_DIR/zt "Salva" "$DOMAIN" "$C_CP_DIR/Auth/Custom/Domain"
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/CpFree"
		fi
		if [ -z "$ACTIVE_CP" ];then
			$C_ZT_BIN_DIR/zt "SLink" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-off" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
		fi
		if [ -n "$NO_SSL" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/NoSSL"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/NoSSL"
		fi
		if [ -n "$USE_CN" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/UseCN"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/UseCN"
		fi
		$C_ZT_BIN_DIR/zt "ChangeProtUrl"
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		CONTROLV=$(echo "$INTERFACECP" | cut -sd'.' -f2)
		if [ -n "$CONTROLV" ];then
			INTERFACE=$(echo "$INTERFACECP" | cut -d'.' -f1)
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		else
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "Requested" "$C_CP_DIR/Auth/RedirectionMode"
		return_page "config.sh?SECTION=CAPTIVE_PORTAL"
		exit
	fi
	if [ -n "$CONF_AR" ];then
		echo "<br><font color=\"#0000FF\" size=\"3\">$L_SELF_REGISTER</font>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		wait "550"
		DAYS=$(date +%w)
		ORAS=$(date +%H)
		MINS=$(date +%M)
		ORAMIN=$ORAS$MINS
		ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" gecos=free uid)
		USERFREE=$(echo "$LINE" | sed -n '/uid:/p' | awk '{ print $2 }')
		if [ -z $DAY_EXPIRE ];then
			AR_EXPIRE=24836
		else
			AR_EXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
		fi
		[ -z "$AR_CLASS" ] && AR_CLASS="DEFAULT"
		for CONF in "AUTO_REGISTER" "USER_AS_PHONE" "NEW_REGISTER" "AUTO_PASS_EMAIL" "WAIT_REGISTER" "AR_FROM_TICKET" "AR_NOT_EMAIL" "AR_CLASS" \
			"AR_EXPIRE" "AR_EXPIRE_DAYS" "AR_ONLY_SMS" "PASS_ASTERISK" "TIME_WAIT_ASTERISK" "PHONE_ASTERISK" "PHONE_ASTERISK_FORGOT";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		if [ -n "$LOGIN_SOCIAL" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/RegisterSocial"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/RegisterSocial"
		fi
		if [ -n "$REGISTER_ASTERSK" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/RegisterAsterisk"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/RegisterAsterisk"
		fi
		for dc in $(ls $C_CLASSES_DIR);do
			if [[ $(cat $C_CLASSES_DIR/$dc/ChargeType) == "pre" && -n "$C_ACTIVE_PP" ]];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ChargePayPal"
				CONTROLPRE="ok"
			fi
		done
		if [ -z "$CONTROLPRE" ];then
			$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/ChargePayPal"
		fi
		if [[ -n "$AUTO_REGISTER" && -z "$AR_ONLY_SMS" ]];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Registered"
		else
			$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/Registered"
		fi
		if [[ $(cat $C_CLASSES_DIR/$AR_CLASS/ChargeType) == "pre" && -z "$C_ACTIVE_PP" ]];then
			$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/Registered"
		fi
		if [[ "$C_CP_LOCAL_TYPE" == "Server" && "$AUTO_REGISTER" == "" ]];then
			if [ -d $C_ZT_CONF_DIR/RemoteClients ];then
				for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
					remoteclient "DisactiveAr"
				done
				fi
		fi
	return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=SELF_REGISTERING"
	exit
	fi
	if [ -n "$CONF_WG" ];then
		wait "600" "Walled Garden"
		$C_ZT_BIN_DIR/zt "Salva" "Requested" "$C_CP_DIR/Auth/RedirectionMode"
		if [ -n "$(cat $C_CP_DIR/Auth/Custom/SRVWalledGarden)" ];then
			$C_ZT_BIN_DIR/zt "RemoveFreeService" "$(cat $C_CP_DIR/Auth/Custom/SRVWalledGarden)"
		fi
		for SCRIPTWG in "WalledGarden" "TypeWalledGarden" "RedUrlWalledGarden" "IpUrlWalledGarden" "SRVWalledGarden" ;do
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/$SCRIPTWG"
		done
		if [ -n "$ACTIVE_WG" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/WalledGarden"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$TYPE_WG" "$C_CP_DIR/Auth/Custom/TypeWalledGarden"
		if [ "$TYPE_WG" == "Redirect" ];then
			$C_ZT_BIN_DIR/zt "Salva" "$REDIRECT_URL" "$C_CP_DIR/Auth/Custom/RedUrlWalledGarden"
			if [ -n "$IP_URL" ];then
				$C_ZT_BIN_DIR/zt "Salva" "$IP_URL" "$C_CP_DIR/Auth/Custom/IpUrlWalledGarden"
				$C_ZT_BIN_DIR/zt "AddFreeService" "WalledGarden" "$IP_URL" "80" "tcp" "SRVWalledGarden"
			fi
		fi
		return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=WALLED_GARDEN"
		exit
	fi
	if [ -n "$CONF_PP" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">PayPal</font><p>
		<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		wait "550"
		for CONF in "ACTIVE_PP" "TIME_PP" "TIMES_PP" "GMT";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		if [ -n "$FREE_MAC" ];then
			if [ "$FREE_MAC" == "$L_ALL" ];then
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_ZT_CONF_DIR/banmac"
			else
				$C_ZT_BIN_DIR/zt "RimuoviRiga" "$FREE_MAC" "$C_ZT_CONF_DIR/banmac"
			fi
		fi
		for dc in $(ls $C_CLASSES_DIR);do
			if [[ $(cat $C_CLASSES_DIR/$dc/ChargeType) == "pre" && -n "$ACTIVE_PP" ]];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ChargePayPal"
				CONTROLPRE="ok"
			fi
		done
		if [ -z "$CONTROLPRE" ];then
			$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/ChargePayPal"
		fi
		if [[ $(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType) == "pre" && -n "$ACTIVE_PP" ]];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Registered"
		fi
		if [[ $(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType) == "pre" && -z "$ACTIVE_PP" ]];then
			$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/Registered"
		fi
		return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=PAYPAL"
		exit
	fi
	if [ -n "$DEL_IMAGES" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_ZT_DIR/images/template/wg/$DEL_IMAGES"
		return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=WALLED_GARDEN"
		exit
	fi
	if [ -z "$SUB_SECTION" ];then
		echo "<p><form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_CP:&nbsp"
		if [ "$(cat $C_SYSTEM/cp/Enabled)" == "yes" ];then
			echo "<input name=\"ENABLED_CP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"ENABLED_CP\" type=\"checkbox\">"
		fi
		echo "<br>&nbsp;<br>$L_INTERFACES"
		namelan
		CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface | sed 's/\./_/g')"
		CP_INTERFACES=" $CP_INTERFACES "
		echo "$INTER_LAN<br>"
		echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
		<tr>
		<td width=\"20\" class=\"intesta\">C.</td>
		<td width=\"100\" class=\"intesta\">Int.</td>
		<td width=\"150\" class=\"intesta\">IP</td>
		<td width=\"150\" class=\"intesta\">Netmask</td>
		<td width=\"15\" class=\"intesta\">S.</td></tr>"
		NR=1
		for INTER_LAN in $NAME_LAN;do
			BG="#f3f3f3"
			[ $(expr $NR % 2 ) -eq 0 ] && BG="white"
			INTER_LANC="$(echo "$INTER_LAN" | sed 's/\./_/g')"
			INT_BR="$(cat $C_SYSTEM/net/interfaces/BRIDGE*/BridgeList)"
			CONTROL_BRIDGE="$(echo "$INT_BR" | grep "$INTER_LAN")"
			if [ -z "$CONTROL_BRIDGE" ];then
				echo "<tr BGCOLOR=\"$BG\"><td>"
				CONTROL_IN=$(echo "$INTER_LAN" | cut -sd'.' -f2)
				if [ -z "$CONTROL_IN" ]; then
					IP_IN="$(cat $C_SYSTEM/net/interfaces/$INTER_LAN/IP/00/IP)"
					NM_IN="$(cat $C_SYSTEM/net/interfaces/$INTER_LAN/IP/00/Netmask)"
					ST_IN="$(cat $C_SYSTEM/net/interfaces/$INTER_LAN/IP/00/STATUS)"
				else
					INT_PRI=$(echo "$INTER_LAN" | cut -d'.' -f1)
					INT_SEC=$(echo "$INTER_LAN" | cut -d'.' -f2)
					IP_IN="$(cat $C_SYSTEM/net/interfaces/$INT_PRI/VLAN/$INT_SEC/IP/00/IP)"
					NM_IN="$(cat $C_SYSTEM/net/iRePassnterfaces/$INT_PRI/VLAN/$INT_SEC/IP/00/Netmask)"
					ST_IN="$(cat $C_SYSTEM/net/interfaces/$INT_PRI/VLAN/$INT_SEC/IP/00/STATUS)"
				fi
				if [ "$ST_IN" == "up" ];then
					if [ -n "$(echo "$CP_INTERFACES" | grep " $INTER_LAN ")" ];then
						echo "<input name=\"$INTER_LANC\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"$INTER_LANC\" type=\"checkbox\">"
					fi
				else
					echo "&nbsp;"
				fi
				if [ -n "$(echo "$INTER_LAN" | grep 'BRIDGE' )" ];then
					INT_B="$(cat $C_SYSTEM/net/interfaces/$INTER_LAN/BridgeList)"
					echo "</td><td>$INTER_LAN ($INT_B)</td>"
				else
					echo "</td><td>&nbsp;$INTER_LAN</td>"
				fi
				echo "<td>&nbsp;$IP_IN</td>"
				echo "<td>&nbsp;$NM_IN</td>"
				if [ "$ST_IN" == "up" ];then
				echo "<td width=\"20px\" align=\"center\"><img src=\"/images/unlock.png\"></td>"
				else
					echo "<td width=\"20px\" align=\"center\"><img src=\"/images/lock.png\"></td>"
				fi
				echo "</tr>"
			fi
			NR=$(($NR+1))
		done
		echo "</table>"
		echo "<br>&nbsp;<br><table id=\"tablefirst\" class=\"naked\"><tr>
		<td align=\"left\" style=\"width:260px\">$L_DOS_PROTECTION:&nbsp;</td><td>
		<select name=\"DOS_PROTECTION\" style=\"width:120px\">"
		DOS_PRO="$(cat $C_SYSTEM/cp/DoSProtection)"
		for DOSPRO in "low $L_LOW" "medium $L_MEDIUM" "high $L_HIGH";do
			set -- $DOSPRO
			if [ "$DOS_PRO" != $1 ];then
				echo "<option value=\"$1\">$2</option>"
			fi
		done
		[ "$DOS_PRO" == "low" ] && DOS_PRO1="$L_LOW"
		[ "$DOS_PRO" == "medium" ] && DOS_PRO1="$L_MEDIUM"
		[ "$DOS_PRO" == "high" ] && DOS_PRO1="$L_HIGH"
		echo "<option value=\"$DOS_PRO\" selected>$DOS_PRO1</option></select></td>
		<td align=\"left\" style=\"width:260px\">&nbsp;&nbsp;$L_CLIENT_IDENTITY:&nbsp;</td><td>
		<select name=\"CLIENT_IDENTITY\" style=\"width:120px\">"
		CLI_ID="$(cat $C_SYSTEM/cp/ClientIdentity)"
		for CLIID in "IP IP" "IPMAC IP-MAC";do
			set -- $CLIID
			if [ "$CLI_ID" != $1 ];then
				echo "<option value=\"$1\">$2</option>"
			fi
		done
		[ "$CLI_ID" == "IP" ] && CLI_ID1="IP"
		[ "$CLI_ID" == "IPMAC" ] && CLI_ID1="IP-MAC"
		echo "<option value=\"$CLI_ID\" selected>$CLI_ID1</option></select></td></tr>
		<tr>
		<td align=\"left\">$L_SIM_CONNECTION:&nbsp;</td><td>
		<select name=\"SIM_CONNECTION\" style=\"width:120px\">"
		if [ -z "$C_SIM_CONN_CLASSES" ];then
			SIM_COM="$(cat $C_SYSTEM/cp/Simultaneous)"
		else
			SIM_COM="$L_CLASSES"
		fi
		for SIMCON in "yes $L_ALLOWED" "no $(echo $L_NOT_ALLOWED | sed "s/ /_/g")" "$L_CLASSES $L_CLASSES";do
			set -- $SIMCON
			if [ "$SIM_COM" != $1 ];then
				echo "<option value=\"$1\">"$( echo "$2" | sed "s/_/ /g")"</option>"
			fi
		done
		[ "$SIM_COM" == "yes" ] && SIM_COM1="$L_ALLOWED"
		[ "$SIM_COM" == "no" ] && SIM_COM1="$L_NOT_ALLOWED"
		[ "$SIM_COM" == "$L_CLASSES" ] && SIM_COM1="$L_CLASSES"
		echo "<option value=\"$SIM_COM\" selected>"$( echo "$SIM_COM1" | sed "s/_/ /g")"</option></select></td>
		<td align=\"left\">&nbsp;&nbsp;$L_AUTH_VALIDITY:&nbsp;</td><td>
		<select name=\"AUTH_VALIDITY\" style=\"width:120px\">"
		AUTH_VAL="$(cat $C_SYSTEM/cp/Timeout)"
		for AUTHVAL in "1" "2" "3" "4" "5" "10" "15" "30" "60" "120" "300" "600" "1200" "1440" "10080" "7200000";do
			if [ "$AUTH_VAL" != "$AUTHVAL" ];then
				AUTHVAL1="$AUTHVAL"
				if [ "$AUTHVAL" == "7200000" ];then
					echo "<option value=\"$AUTHVAL\">$L_NO_LIMIT</option>"
				else
					echo "<option value=\"$AUTHVAL\">$AUTHVAL1 Min.</option>"
				fi
			fi
		done
		if [ "$AUTH_VAL" == "7200000" ];then
			echo "<option style=\"width:120px\" value=\"$AUTH_VAL\" selected>$L_NO_LIMIT</option></select></td></tr>"
		else
			echo "<option style=\"width:120px\" value=\"$AUTH_VAL\" selected>$AUTH_VAL Min.</option></select></td></tr>"
		fi
		echo "<tr><td align=\"left\">$L_MAX_CONN_GLOBAL:&nbsp;</td><td>
		<select name=\"CONN_GLOBAL\" style=\"width:120px\">"
		for CB in $(seq 50 50 200);do
			if [ "$CB" != "$C_CONN_GLOBAL" ];then
				echo "<option value=\"$CB\">$CB</option>"
			fi
		done
		if [ -z "$C_CONN_GLOBAL" ];then
			echo "<option style=\"width:120px\" value=\"\" selected>$L_NO_LIMIT</option></select>"
		else
			echo "<option style=\"width:120px\" value=\"\">$L_NO_LIMIT</option>
			<option style=\"width:120px\" value=\"$C_CONN_GLOBAL\" selected>$C_CONN_GLOBAL</option></select>"
		fi
		echo "</td><td>&nbsp;&nbsp;$L_USE_CN:&nbsp;</td><td align=\"right\">"
		[ "$(cat $C_CP_DIR/Auth/UseCN)" == "yes" ] && TYPER="CN"
		[[ "$(cat $C_CP_DIR/Auth/UseCN)" != "yes" &&  "$(cat $C_CP_DIR/Auth/URLrid)" != "yes"  ]] && TYPER="IP"
		[ -n "$(cat $C_CP_DIR/Auth/URLrid)" ] && TYPER="URL"
		echo "<select name=\"TYPER\" onchange=\"redirect(this.options[this.selectedIndex].value,'tableURL')\">"
		if [ "$TYPER" == "CN" ];then
			echo "<option value=\"URL\">URL</option>
			<option value=\"IP\">IP</option>
			<option value=\"CN\" selected>CN</option></select>"
		fi
		if [ "$TYPER" == "URL" ];then
			REDURL="yes"
			echo "<option value=\"CN\">CN</option>
			<option value=\"IP\">IP</option>
			<option value=\"URL\" selected>URL</option></select>"
		fi
		if [ "$TYPER" == "IP" ];then
			echo "<option value=\"CN\">CN</option>
			<option value=\"URL\">URL</option>
			<option value=\"IP\" selected>IP</option></select>"
		fi
		echo "</td></tr></table>"
		if [ "$TYPER" == "URL" ];then
			echo "<table id=\"tableURL\" class=\"naked\">"
		else
			echo "<table id=\"tableURL\" class=\"naked\" style=\"display:none\">"
		fi
		NCP="$(cat $C_CP_DIR/Interface | wc -w | awk '{print $1}')"
		NCP=$(echo "($NCP+1)/2" | $C_ZT_BIN_DIR/bc)
		NN="1"
		for ICP in $(seq 1 $NCP);do
			NICP="$(cat $C_CP_DIR/Interface | awk -v N="$NN" '{print $N}')"
			echo "<tr><td align=\"left\" style=\"width:260px\">$L_USE_URL <font size=\"2\">($NICP)</font>:&nbsp;</td>
			<td><input type=\"text\" style=\"width:120px\" name=\"URL_RID_$NICP\" value=\"$(cat $C_CP_DIR/Auth/URLrid_$NICP)\"></td>"
			NN=$(($NN+1))
			if [ -n "$(cat $C_CP_DIR/Interface | awk -v N="$NN" '{print $N}')" ];then
				NICP="$(cat $C_CP_DIR/Interface | awk -v N="$NN" '{print $N}')"
				echo "<td align=\"left\" style=\"width:260px\">&nbsp;&nbsp;$L_USE_URL <font size=\"2\">($NICP)</font>:&nbsp;</td>
				<td><input type=\"text\" style=\"width:120px\" name=\"URL_RID_$NICP\" value=\"$(cat $C_CP_DIR/Auth/URLrid_$NICP)\"></td></tr>"
			
			else
				echo "<td style=\"width:260px\"></td><td style=\"width:120px\"></td></tr>"
			fi
			NN=$(($NN+1))
		done
		echo "</table>"
		echo "<table id=\"tablefirst1\" class=\"naked\"><tr><td align=\"left\" style=\"width:260px\">$L_NO_SSL:&nbsp;</td><td style=\"width:120px\">"
		NO_SSL="$(cat $C_CP_DIR/Auth/NoSSL)"
		if [ "$NO_SSL" == "yes" ];then
			echo "<input name=\"NO_SSL\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"NO_SSL\" type=\"checkbox\">"
		fi
		echo "</td><td style=\"width:260px\">&nbsp;&nbsp;$L_DISABLE443:&nbsp;</td><td align=\"right\" style=\"width:120px\">"
		$C_ZT_BIN_DIR/zt "ControlCp443"
		echo "</td></tr><tr><td align=\"left\">$L_PAGE_MOBILE:&nbsp;</td><td>"
		if [ -n "$C_USE_PAGE_MOBILE" ];then
			echo "<input name=\"USE_PM\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"USE_PM\" type=\"checkbox\">"
		fi
		echo "</td>
		<td align=\"left\">&nbsp;&nbsp;$L_AUTH_VALIDITY:&nbsp;</td><td>
		<select name=\"AUTH_VALIDITY_MOBILE\" style=\"width:120px\">"
		AUTH_VALM="$C_AUTH_VALIDITY_MOBILE"
		if [ -z "$AUTH_VALM" ];then
			AUTH_VALM="5"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AUTH_VALIDITY_MOBILE" "5"
		fi
		for AUTHVALM in "1" "2" "3" "4" "5" "10" "15" "30" "60" "120" "300" "600" "1200" "1440" "10080" "7200000";do
			if [ "$AUTH_VALM" != "$AUTHVALM" ];then
				AUTHVALM1="$AUTHVALM"
				if [ "$AUTHVALM" == "7200000" ];then
					echo "<option value=\"$AUTHVALM\">$L_NO_LIMIT</option>"
				else
					echo "<option value=\"$AUTHVALM\">$AUTHVALM1 Min.</option>"
				fi
			fi
		done
		if [ "$AUTH_VALM" == "7200000" ];then
			echo "<option style=\"width:120px\" value=\"$AUTH_VALM\" selected>$L_NO_LIMIT</option></select></td></tr>"
		else
			echo "<option style=\"width:120px\" value=\"$AUTH_VALM\" selected>$AUTH_VALM Min.</option></select></td></tr>"
		fi
		
		if [[ "$(echo $C_LANGUAGE)" == "francais" || "$(echo $C_LANGUAGE)" == "deutsch" ]];then
			CTL="yes"
			SPACE=""
			AL="left"
		else
			SPACE="&nbsp;&nbsp"
			AL="right"
		fi
		echo "</table>"
		if [ $(cat $C_SYSTEM/cp/Enabled) == "no" ];then
			echo "<br>&nbsp;<br><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"INT_CP\">
		<p><input type=\"submit\" name=\"INT_CP\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		if [ $(cat $C_SYSTEM/cp/Enabled) == "no" ];then
			./footer.sh
			exit
		else
			echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		echo "<p><form method=\"POST\" action=\"config.sh\">
		<br><table class=\"naked\" border=\"0\"><tr>
		<td align=\"left\">Online:&nbsp;</td><td>"
		if [ -n "$C_ACTIVE_CP"  ];then
			echo "<input name=\"ACTIVE_CP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"ACTIVE_CP\" type=\"checkbox\">"
		fi
		if [ -z "$CTL" ];then
			echo "</td>"
		else
			echo "</td></tr>"
		fi
		if [ -z "$C_FREE_CP"  ];then
			echo "<td align=\"left\">$SPACE$L_FREE_CP:&nbsp;</td><td align=\"$AL\">"
			echo "<input name=\"FREE_CP\" type=\"checkbox\">"
			echo "</td></tr>
			<td align=\"left\">$L_ZT_POPUP:&nbsp;</td><td>"
			if [ "$C_ZT_POPUP" == "on" ];then
				echo "<input name=\"ZT_POPUP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ZT_POPUP\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_ANONYMOUS_USER:&nbsp;</td><td align=\"$AL\">"
			if [ "$C_ANONYMOUS_USER" == "on" ];then
				echo "<input name=\"ANONYMOUS_USER\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ANONYMOUS_USER\" type=\"checkbox\">"
			fi
			echo "</td></tr><tr>
			<td align=\"left\">$L_LENGTH_USERNAME:&nbsp;</td><td>
			<select name=\"LENGH_USERNAME\" style=\"width:100px\">"
			for LU in $(seq 5 10);do
				echo "<option value=\"$LU\">$LU</option>"
			done
			echo "<option value=\"$C_LENGH_USERNAME\" selected>$C_LENGH_USERNAME</option>
			</select>"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_LENGTH_PASSWORD:&nbsp;</td><td>
			<select name=\"LENGH_PASSWORD\" style=\"width:100px\">"
			for LP in $(seq 5 10);do
				echo "<option value=\"$LP\">$LP</option>"
			done
			echo "<option value=\"$C_LENGH_PASSWORD\" selected>$C_LENGH_PASSWORD</option>
			</select></td></tr>"
			echo "<tr>
			<td align=\"left\">$L_PASS_CHARS:</td><td>"
			if [ "${C_PASS_CHARS:-0}" -eq 0 ];then
				C_PASS_CHARS=7
			fi
			echo "$L_PASS_CHARS_1: <input name=\"PASS_CHARS_1\" type=\"checkbox\""
			if [ $(( $C_PASS_CHARS & 1 )) -gt 0 ];then
				echo "checked=\"checked\""
			fi
			echo ">"
			if [ -z "$CTL" ];then
				echo "</td><td align=\"center\">"
			else
				echo "</td></tr><tr><td></td><td>"
			fi
			echo "$L_PASS_CHARS_2: <input name=\"PASS_CHARS_2\" type=\"checkbox\""
			if [ $(( $C_PASS_CHARS & 2 )) -gt 0 ];then
				echo " checked=\"checked\""
			fi
			echo ">"
			if [ -z "$CTL" ];then
				echo "</td><td align=\"right\">"
			else
				echo "</td></tr><tr><td></td><td>"
			fi
			echo "$L_PASS_CHARS_3: <input name=\"PASS_CHARS_3\" type=\"checkbox\""
			if [ $(( $C_PASS_CHARS & 4 )) -gt 0 ];then
				echo " checked=\"checked\""
			fi
			echo "></td></tr>
			<tr>
			<td align=\"left\">$L_CURRENCY:&nbsp;</td>
			<td><input style=\"width:100px\" type=\"text\" size=\"1\" name=\"CURRENCY\" value=\"$C_CURRENCY\">"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_DECIMAL:&nbsp;</td><td><input type=\"text\" style=\"width:100px\"
			name=\"DECIMAL\" value=\"$C_DECIMAL\"></td>
			</tr><tr>
			<td align=\"left\">$L_FORMAT_DATE:&nbsp;</td><td>
			<select name=\"FORM_DATE\" style=\"width:100px\">"
			if [ "$C_FORM_DATE" == "ita" ];then
				echo "<option value=\"eng\">yyyy/mm/dd</option>
				<option value=\"ita\" selected>dd/mm/yyyy</option></select>"
			else
				echo "<option value=\"ita\">dd/mm/yyyy</option>
				<option value=\"eng\" selected>yyyy/mm/dd</option></select>"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_PREFIX:&nbsp;</td><td><input style=\"width:100px\" type=\"text\" size=\"1\"
			name=\"PREFIX\" value=\"$C_PREFIX\"></td>
			</tr><tr>
			<td align=\"left\">$L_NAME_ROOM:&nbsp;</td>
			<td><input type=\"text\" style=\"width:100px\" name=\"ROOM_NAME\" value=\"$C_ROOM_NAME\">"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_USERNAME_PREFIX (Multi):&nbsp;</td>
			<td><input type=\"text\" style=\"width:100px\" name=\"PREFIX_USERNAME\" value=\"$C_PREFIX_USERNAME\"></td></tr>
			<tr><td align=\"left\">$L_VIEW_DOMAIN:&nbsp;</td><td>"
			if [ "$C_VIEW_DOMAIN" == "on" ];then
				echo "<input name=\"VIEW_DOMAIN\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"VIEW_DOMAIN\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_DISCONNECT_AFTER:&nbsp;</td><td>
			<select name=\"DISCONNECT_TIME\" style=\"width:100px\">"
			for ST in $(seq 600 600 43200);do
				echo "<option value=\"$ST\">$(($ST/60))</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_DISCONNECT_TIME\" selected>"
			if [ -n "$C_DISCONNECT_TIME" ];then
				echo "$(($C_DISCONNECT_TIME/60))"
			else
				echo ""
			fi
			echo "</option></select></td></tr>
			<tr><td align=\"left\">$L_BLOCK_NUM:&nbsp;</td><td>
			<select name=\"WAIT_LOGIN\" style=\"width:100px\">"
			for SN in $(seq 1 10);do
				echo "<option value=\"$SN\">$SN</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_WAIT_LOGIN\" selected>$C_WAIT_LOGIN</option>
			</select>"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_UNBLOCK_MIN:&nbsp;</td><td>
			<select name=\"WAIT_LOGIN_TIME\" style=\"width:100px\">"
			for ST in "1" "2" "3" "4" "5" "10" "15" "20" "30" "60";do
				echo "<option value=\"$ST\">$ST</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_WAIT_LOGIN_TIME\" selected>$C_WAIT_LOGIN_TIME</option>
			</select>
			</td></tr>
			<tr><td align=\"left\">$L_VIEW_IN_TABLE:&nbsp;</td>
			<td colspan=\"2\">$L_TELEPHONE: "
			if [ "$C_VIEW_PHONE" == "on" ];then
				echo "<input name=\"VIEW_PHONE\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"VIEW_PHONE\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
			else
				echo "</td></tr><tr><td></td><td>"
			fi
			echo "$L_EXPIRY: "
			if [ "$C_VIEW_EXPIRY" == "on" ];then
				echo "<input name=\"VIEW_EXPIRY\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"VIEW_EXPIRY\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
			else
				echo "</td></tr><tr><td></td><td>"
			fi
			echo "$L_CLASS: "
			if [ "$C_VIEW_CLASS" == "on" ];then
				echo "<input name=\"VIEW_CLASS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"VIEW_CLASS\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td><td align=\"right\">"
			else
				echo "</td></tr><tr><td></td><td>"
			fi		
			echo "$L_EMAIL: "
			if [ "$C_VIEW_EMAIL" == "on" ];then
				echo "<input name=\"VIEW_EMAIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"VIEW_EMAIL\" type=\"checkbox\"></td>"
			fi
			echo "</td></tr>
			<tr><td align=\"left\">$L_ENABLE_TABLE_FAST:&nbsp;</td><td>"
			if [ "$C_TABLE_FAST" == "on" ];then
				echo "<input name=\"TABLE_FAST\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"TABLE_FAST\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_ENABLE_POPUP:&nbsp;</td><td align=\"$AL\">"
			if [ "$(cat $C_CP_DIR/Auth/Custom/Popup)" == "yes" ];then
				echo "<input name=\"POPUP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"POPUP\" type=\"checkbox\">"
			fi
			echo "</td></tr>
			<tr><td align=\"left\">$L_ENABLE_WG:&nbsp;</td><td>"
			if [ "$(cat $C_CP_DIR/Auth/Custom/WalledGarden)" == "yes" ];then
				echo "<input name=\"WGARDEN\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"WGARDEN\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_ENABLE_REPASS:&nbsp;</td><td align=\"$AL\">"
			if [ $(cat $C_CP_DIR/Auth/Custom/RePass == "yes") ];then
				echo "<input name=\"REPASS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"REPASS\" type=\"checkbox\">"
			fi
			echo "</td></tr>
			<tr><td align=\"left\">$L_SHOW_MB:&nbsp;</td><td>"
			if [ "$(cat $C_CP_DIR/Auth/Custom/ShowMB)" == "yes" ];then
				echo "<input name=\"SHOWMB\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SHOWMB\" type=\"checkbox\">"
			fi
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_SHOW_COST:&nbsp;</td><td align=\"$AL\">"
			if [ $(cat $C_CP_DIR/Auth/Custom/ShowCost == "yes") ];then
				echo "<input name=\"SHOWCOST\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SHOWCOST\" type=\"checkbox\">"
			fi
			echo "</td></tr>
			<tr><td align=\"left\">$L_SHOW_MB_BLOCK:&nbsp;</td><td>
			<select name=\"SHOW_MB_DISCONNECT\" style=\"width:100px\">"
			for MT in "5" "10" "15" "20" "25" "50" "100";do
				if [ "$MT" != "$C_SHOW_MB_DISCONNECT" ];then
					echo "<option value=\"$MT\">$MT</option>"
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_SHOW_MB_DISCONNECT\" selected>$C_SHOW_MB_DISCONNECT</option>
			</select>"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_SHOW_TIME_BLOCK:&nbsp;</td><td align=\"$AL\">
			<select name=\"SHOW_TIME_DISCONNECT\" style=\"width:100px\">"
			for TT in "5" "10" "15" "20" "25" "30" "60";do
				if [ "$TT" != "$C_SHOW_MB_DISCONNECT" ];then
					echo "<option value=\"$TT\">$TT</option>"
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_SHOW_TIME_DISCONNECT\" selected>$C_SHOW_TIME_DISCONNECT</option>
			</select>"
			echo "</td></tr>"
			echo "<tr><td align=\"left\">$L_SORT_TABLE:&nbsp;</td><td>
			<select name=\"SORT_TABLE\" style=\"width:100px\">"
			USERSORT="$(echo "$L_USERNAME" | sed 's/ /_/g')"
			NAMESORT="$(echo "$L_NAME" | sed 's/ /_/g')"
			LNAMESORT="$(echo "$L_LAST_NAME" | sed 's/ /_/g')"
			for SORT_IT in "$USERSORT uid" "$NAMESORT givenName" "$LNAMESORT sn" "$L_EMAIL mail" "$L_TELEPHONE telephoneNumber" "$L_EXPIRY shadowExpire" ;do
			set -- $SORT_IT
				if [ "$SORT_IT" != "$C_SORT_TABLE" ];then
					echo "<option value=\"$2\">"$(echo $1 | sed 's/_/ /g')"</option>"
				fi
			done
			for OT in "$USERSORT uid" "$NAMESORT givenName" "$LNAMESORT sn" "$L_EMAIL mail" "$L_TELEPHONE telephoneNumber" "$L_EXPIRY shadowExpire" "";do
			set -- $OT
				if [ "$C_SORT_TABLE" = "$2" ];then
					echo "<option value=\"$2\" selected>"$(echo $1 | sed 's/_/ /g')"</option></select>"
				fi
			done
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			echo "<td align=\"left\">$SPACE$L_ENABLE_LOGIN_IMG:&nbsp;</td><td align=\"$AL\">"
			if [ "$(cat $C_CP_DIR/Auth/Custom/ShowImgLogin)" == "yes" ];then
				echo "<input name=\"SHOWIMGLOGIN\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SHOWIMGLOGIN\" type=\"checkbox\"></td></tr>"
			fi
			echo "<tr><td align=\"left\">$L_SWOW_NOT_INTERNET:&nbsp;</td><td>"
			if [ -n "$C_SHOW_NOT_INTERNET" ];then
				echo "<input name=\"SHOW_NOT_INTERNET\" type=\"checkbox\" checked=\"checked\"></td>"
			else
				echo "<input name=\"SHOW_NOT_INTERNET\" type=\"checkbox\">"
			fi
			if [ "$C_SMS_PROVIDER" == "Gammu" ];then
				if [ -z "$CTL" ];then
					echo "<td align=\"left\">&nbsp;&nbsp;"
				else
					echo "</td></tr><tr><td>"
				fi
				echo "$L_SWOW_NOT_INTERNET_ADMIN:&nbsp;</td><td align=\"$AL\">"
				if [ -n "$C_SHOW_NOT_INTERNET_ADMIN" ];then
					echo "<input name=\"SHOW_NOT_INTERNET_ADMIN\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"SHOW_NOT_INTERNET_ADMIN\" type=\"checkbox\">"
				fi
				echo "</td></tr>
				<tr><td align=\"left\">$L_ENABLE_LOGIN_ML:&nbsp;</td><td>"
				if [ "$(cat $C_CP_DIR/Auth/Custom/LoginML)" == "yes" ];then
					echo "<input name=\"LOGINML\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"LOGINML\" type=\"checkbox\"></td>"
				fi
				echo "<td align=\"left\">&nbsp;&nbsp;&nbsp;</td><td align=\"right\"></td></tr>"
			else
				if [ -z "$CTL" ];then
					echo "</td>"
				else
					echo "</td></tr>"
				fi
				echo "<td align=\"left\">$SPACE$L_ENABLE_LOGIN_ML:&nbsp;</td><td align=\"$AL\">"
				if [ "$(cat $C_CP_DIR/Auth/Custom/LoginML)" == "yes" ];then
					echo "<input name=\"LOGINML\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"LOGINML\" type=\"checkbox\"></td></tr>"
				fi
			fi
			
			echo "</tr><tr>
			<td align=\"left\">$L_REDIRECT_QR:&nbsp;</td>
			<td><input type=\"text\" style=\"width:100px\" name=\"REDIRECT_QR\" value=\"$C_REDIRECT_QR\">"
			if [ -z "$CTL" ];then
				echo "</td>"
			else
				echo "</td></tr>"
			fi
			URL_CT="$(echo $HTTP_REFERER | cut -d'/' -f3)"
			TEMPN="$(cat $C_CP_DIR/Auth/Custom/Template)" 
			echo "<td align=\"left\">${SPACE}<a href=\"https://$URL_CT/zerotruth/templates/$TEMPN/preview.html\" target=\"popupview\"
				onClick=\"window.open('', 'popupview', 'height=500,width=550,left=70,top=50,status=no,menu=no,scrollbars=yes');\">Template</a>:&nbsp;
				<div style=\"display: inline-block;\" id=\"newtemplate\"></div>
			</td>
			<td><select name=\"TEMPLATE\" style=\"width:100px\" onchange=\"previewtemplate(this.options[this.selectedIndex].value, this.options[this.selectedIndex].id, '$URL_CT', '$TEMPN')\">"
			for TEMP in $(ls -A $C_HTDOCS_ZT_DIR/templates);do
				if [ "$TEMP" != "$TEMPN" ];then
					echo "<option value=\"$TEMP\">$TEMP</option>"
				fi
			done
			echo "<option value=\"$TEMPN\" selected>$TEMPN</option></select></td></tr>"
			echo "</table>"
			NAMECP="CONF_CP"
		else
			echo "<td align=\"left\">&nbsp;&nbsp;$L_FREE_CP:&nbsp;</td><td align=\"right\">"
			echo "<input name=\"FREE_CP\" type=\"checkbox\" checked=\"checked\">
			</td><tr>
			<td align=\"left\">$L_ZT_POPUP:&nbsp;</td><td>"
			if [ "$C_ZT_POPUP" == "on" ];then
				echo "<input name=\"ZT_POPUP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ZT_POPUP\" type=\"checkbox\">"
			fi
			echo "<td align=\"left\">&nbsp;&nbsp;$L_FORMAT_DATE:&nbsp;</td>
			<td><select name=\"FORM_DATE\">"
			if [ "$C_FORM_DATE" == "ita" ];then
				echo "<option value=\"eng\">yyyy/mm/dd</option>
				<option value=\"ita\" selected>dd/mm/yyyy</option></select>"
			else
				echo "<option value=\"ita\">dd/mm/yyyy</option>
				<option value=\"eng\" selected>yyyy/mm/dd</option></select>"
			fi
			echo "</td></tr><tr><td align=\"left\">$L_DECIMAL:&nbsp;</td><td>
			<input type=\"text\" size=\"1\"
			name=\"DECIMAL\" value=\"$C_DECIMAL\">
			</td>
			<td align=\"left\">&nbsp;&nbsp;$L_DISCONNECT_AFTER:&nbsp;</td><td align=\"right\">
			<select name=\"DISCONNECT_TIME\">"
			for ST in $(seq 600 600 3600);do
				echo "<option value=\"$ST\">$(($ST/60))</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_DISCONNECT_TIME\" selected>"
			if [ -n "$C_DISCONNECT_TIME" ];then
				echo "$(($C_DISCONNECT_TIME/60))"
			else
				echo ""
			fi
			echo "</option></select></td></tr>
			<tr><td>"
			RED_URL=$(cat $C_CP_DIR/Auth/Custom/RedirectFree)
			echo "Redirect URL: http://<td>
			<input type=\"text\" style=\"width:100px\" name=\"REDIRECT_FREE\" value=\"$RED_URL\">
			<td align=\"left\">&nbsp;&nbsp;Template:&nbsp;</td>
			<td><select name=\"TEMPLATE\" style=\"width:100px\">"
			for TEMP in $(ls -A $C_HTDOCS_ZT_DIR/templates);do
				TEMPN="$(cat $C_CP_DIR/Auth/Custom/Template)"
				if [ "$TEMP" != "$TEMPN" ];then
					echo "<option value=\"$TEMP\">$TEMP</option>"
				fi
			done
			echo "<option value=\"$TEMPN\" selected>$TEMPN</option></select></td></tr>"
			echo "</table>"
			NAMECP="CONF_CP_FREE"
		fi
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>"
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\"><br>
		<input type=\"submit\" name=\"$NAMECP\" class=\"bottone\" value=\"$L_SAVE \"></form><br>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "INT_CP" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "Salva" "$AUTH_VALIDITY" "$C_SYSTEM/cp/Timeout"
		if [ "$SIM_CONNECTION" != "$L_CLASSES" ];then
			$C_ZT_BIN_DIR/zt "Salva" "$SIM_CONNECTION" "$C_SYSTEM/cp/Simultaneous"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SIM_CONN_CLASSES" ""
		else
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SIM_CONN_CLASSES" "on"
			$C_ZT_BIN_DIR/zt "SetSimConnClasses"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$CLIENT_IDENTITY" "$C_SYSTEM/cp/ClientIdentity"
		$C_ZT_BIN_DIR/zt "Salva" "$DOS_PROTECTION" "$C_SYSTEM/cp/DoSProtection"
		
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_USE_PAGE_MOBILE" "$USE_PM"
		$C_ZT_BIN_DIR/zt "Salva" "$USE_PM" "$C_CP_DIR/Auth/Custom/PageMobile"
		$C_ZT_BIN_DIR/zt "SaveClientctrl" "$USE_PM"
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AUTH_VALIDITY_MOBILE" "$AUTH_VALIDITY_MOBILE"
		if [ -n "$C_CONN_GLOBAL" ];then
			$C_ZT_BIN_DIR/zt "RuleCB"  "$C_CONN_GLOBAL" "no"
		fi
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CONN_GLOBAL" "$CONN_GLOBAL"
		if [ -n "$CONN_GLOBAL" ];then
			$C_ZT_BIN_DIR/zt "RuleCB" "$CONN_GLOBAL"
		fi
		namelan
		NAME_LAN="$(echo "$NAME_LAN" | sed 's/\./_/g')"
		for INTER_LAN in $NAME_LAN;do
			eval INT_LAN=\$$INTER_LAN
			if [ -n "$INT_LAN" ];then
				LAN_CP="$LAN_CP $INTER_LAN"
			fi
		done
		LAN_CP="$(echo "$LAN_CP" | sed 's/_/\./g' | sed 's/^ *//g')"
		$C_ZT_BIN_DIR/zt "ConfigLanCp" "$ENABLED_CP" "$LAN_CP"
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_DISABLE_CP_443" "$DISABLE_CP_443"
		$C_ZT_BIN_DIR/zt "DisableCp443" "$DISABLE_CP_443"
		if [ -n "$NO_SSL" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/NoSSL"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/NoSSL"
		fi
		if [ "$TYPER" == "CN" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/UseCN"
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/URLrid"
			$C_ZT_BIN_DIR/zt "Cancella" "" "/root/kerbynet.cgi/template/cp_as_URL-httpd.ssl"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/UseCN"
		fi
		if [ "$TYPER" == "URL" ];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/URLrid"
			$C_ZT_BIN_DIR/zt "Cancella" "" "/root/kerbynet.cgi/template/cp_as_URL-httpd.ssl"
			for ICP in $(cat $C_CP_DIR/Interface);do
				NAMEVAR="URL_RID_$ICP"
				eval CR=\$$NAMEVAR
				if [ -n "$CR" ];then
					CUR="yes"
					break
				fi
			done
			if [ -n "$CUR" ];then
				for ICP in $(cat $C_CP_DIR/Interface);do
					URL_RID="URL_RID_$ICP"
					eval URL_RID=\$$URL_RID
					$C_ZT_BIN_DIR/zt "Salva" "$URL_RID" "$C_CP_DIR/Auth/URLrid_$ICP"
				done
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/UseCN"
				$C_ZT_BIN_DIR/zt "CreateCpSsl" "$C_CP_DIR/Auth/UseCN"
				CU="yes"
			fi
		fi
		if [[ "$TYPER" != "CN" && -z "$CU" ]];then
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/URLrid"
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/UseCN"
			$C_ZT_BIN_DIR/zt "Cancella" "" "/root/kerbynet.cgi/template/cp_as_URL-httpd.ssl"
		fi
		$C_ZT_BIN_DIR/zt "ChangeProtUrl"
		return_page "config.sh?SECTION=CAPTIVE_PORTAL"
		exit
	fi
	if [ "$SUB_SECTION" == "SELF_REGISTERING" ];then
		limitclassjs
		echo "<br><font color=\"#0000FF\" size=\"3\">$L_SELF_REGISTER</font>"
		if [ -n "$C_FREE_CP" ];then
			echo "<font color=\"#0000FF\">($L_FREE_CP)</font>"
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		<table class=\"naked\" width=\"770px\">
		<tr height=\"3\"><td width=\"100px\"><td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\"></td>
		<td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\">
		<td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\"></td>
		<td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\"></td><td width=\"50px\"></td></tr>
		<tr><td colspan=\"3\">$L_ACTIVE_CP: "
		if [ "$C_AUTO_REGISTER" == "on" ];then
			echo "<input name=\"AUTO_REGISTER\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"AUTO_REGISTER\" type=\"checkbox\">"
		fi
		echo "</td><td colspan=\"12\" align=\"right\">
		$L_SELF_REGISTERING_CLASS:
		<select name=\"AR_CLASS\" onchange=\"limitclass(this.options[this.selectedIndex].value, this.options[this.selectedIndex].id)\">"
		for ARCL in $(ls $C_CLASSES_DIR);do
			if [ $ARCL != "$C_AR_CLASS" ];then
				eval LIMITCLASS="\$LIMITCLASS$ARCL"
				echo "<option id=\"$LIMITCLASS\" name=\"AR_CLASS\" value=\"$ARCL\">$ARCL</option>"
			fi
		done
		CL="$C_AR_CLASS"
		eval LIMITCLASS="\$LIMITCLASS$CL"
		echo "<option id=\"$LIMITCLASS\" name=\"AR_CLASS\" value=\"$C_AR_CLASS\" selected>$C_AR_CLASS</option>
		</select></td></tr>"
		if [ -z "$C_FREE_CP" ];then
			echo "<tr><td colspan=\"4\">$L_ASTERISK_REGISTER:"
			if [ "$(cat $C_CP_DIR/Auth/Custom/RegisterAsterisk)" == "yes" ];then
				echo "<input name=\"REGISTER_ASTERSK\" type=\"checkbox\" checked=\"checked\"></td>"
			else
				echo "<input name=\"REGISTER_ASTERSK\" type=\"checkbox\"></td>"
			fi
			echo "<td colspan=\"5\" align=\"right\">
			$L_ASTERISK_PASSORD:&nbsp;<input type=\"text\" class=\"room1\" name=\"PASS_ASTERISK\" value=\"$C_PASS_ASTERISK\"></td>
			<td colspan=\"7\" align=\"right\">
			$L_ASTERISK_TIME ($L_HOURS):&nbsp;<select name=\"TIME_WAIT_ASTERISK\">"
			[ -z "$C_TIME_WAIT_ASTERISK" ] && C_TIME_WAIT_ASTERISK=1
			for TA in $(seq 1 24);do
				if [ "$TA" != "$C_TIME_WAIT_ASTERISK" ];then
					echo "<option value=\"$TA\" selected>$TA</option>"
				fi
			done
			echo "<option value=\"$C_TIME_WAIT_ASTERISK\" selected>$C_TIME_WAIT_ASTERISK</option>
			</select></td><tr>
			<tr><td colspan=\"6\">$L_ASTERISK_PHONE:
			<input style=\"width:100px\" type=\"text\" name=\"PHONE_ASTERISK\" value=\"$C_PHONE_ASTERISK\"></td>
			<td colspan=\"10\" align=\"right\">$L_ASTERISK_PHONE_FORGOT:
			<input  style=\"width:100px\" type=\"text\" name=\"PHONE_ASTERISK_FORGOT\" value=\"$C_PHONE_ASTERISK_FORGOT\"></td></tr>
			<tr><td colspan=\"7\">$L_ALLOW_LOGIN_SOCIAL:"
			if [ "$(cat $C_CP_DIR/Auth/Custom/RegisterSocial)" == "yes" ];then
				echo "<input name=\"LOGIN_SOCIAL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"LOGIN_SOCIAL\" type=\"checkbox\">"
			fi
			echo "</td>"
			if [ "$C_SMS_PROVIDER" != "Gammu" ];then
				echo "<td colspan=\"8\" align=\"right\">"
				echo "$L_USER_AS_PHONE: "
				if [ "$C_USER_AS_PHONE" == "on" ];then
					echo "<input name=\"USER_AS_PHONE\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"USER_AS_PHONE\" type=\"checkbox\">"
				fi
				echo "</td><tr>"
			else
				echo "<td colspan=\"8\" align=\"right\">"
				echo "$L_ALLOW_REGISTER_FULL_SMS: "
				if [ "$C_AR_ONLY_SMS" == "on" ];then
					echo "<input name=\"AR_ONLY_SMS\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"AR_ONLY_SMS\" type=\"checkbox\">"
				fi
				echo "</td><tr>"
			fi
			echo "<tr><td colspan=\"9\">$L_NEW_REGISTER: "
			if [ "$C_NEW_REGISTER" == "on" ];then
				echo "<input name=\"NEW_REGISTER\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"NEW_REGISTER\" type=\"checkbox\">"
			fi
			echo "<td align=\"right\" colspan=\"7\">$L_AUTO_PASS_EMAIL: "
			if [ "$C_AUTO_PASS_EMAIL" == "on" ];then
				echo "<input name=\"AUTO_PASS_EMAIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"AUTO_PASS_EMAIL\" type=\"checkbox\">"
			fi
			echo "</td></tr>"

			echo "<tr><td colspan=\"11\">$L_WAIT_REGISTER:
			<select name=\"WAIT_REGISTER\">"
			for MD in $(seq 1 120);do
				echo "<option value=\"$MD\" selected>$MD</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_WAIT_REGISTER\" selected>$C_WAIT_REGISTER</option>
			</select>"
			echo "</td><td align=\"right\" colspan=\"4\">$L_FROM_TICKET:"
			if [ "$C_AR_FROM_TICKET" == "on" ];then
				echo "<input name=\"AR_FROM_TICKET\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"AR_FROM_TICKET\" type=\"checkbox\">"
			fi
			echo "</td></tr>"
			echo "<tr><td colspan=\"5\">$L_DISABLE_EMAIL:"
			if [ "$C_AR_NOT_EMAIL" == "on" ];then
				echo "<input name=\"AR_NOT_EMAIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"AR_NOT_EMAIL\" type=\"checkbox\">"
			fi
			echo "</td><td align=\"right\" colspan=\"10\">"
		fi
		if [ -n "$C_FREE_CP" ];then
			echo "<tr><td align=\"left\">"
		
		fi
		YNOW=$(date +%Y)
		YEND=$(($YNOW+10))
		if [ -n "$C_AR_EXPIRE" ] && [ "$C_AR_EXPIRE" != 24836 ];then
			YEAR_EXPIRE=$(date -d "1970-01-01 $C_AR_EXPIRE days" +%Y)
			YEAR_EXP=$YEAR_EXPIRE
			MONTH_EXPIRE=$(date -d "1970-01-01 $C_AR_EXPIRE days" +%m)
			MONTH_EXP=$MONTH_EXPIRE
			DAY_EXPIRE=$(date -d "1970-01-01 $C_AR_EXPIRE days" +%d)
			DAY_EXP=$DAY_EXPIRE
		else
			YEAR_EXPIRE="$L_YEAR"
			YEAR_EXP=""
			MONTH_EXPIRE="$L_MONTH"
			MONTH_EXP=""
			DAY_EXPIRE="$L_DAY"
			DAY_EXP=""
		fi
		if [ "$C_FORM_DATE" == "ita" ];then
			echo "$L_SELF_REGISTERING_EXPIRED:"
			if [ -n "$C_FREE_CP" ];then
				echo "</td><td colspan=\"7\" align=\"left\">"
			fi
			echo "<select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\">$L_DAY</option>
			<option value=\"$DAY_EXP\" selected>$DAY_EXPIRE</option></select>
			<select name=\"MONTH_EXPIRE\">"
			for M in $(seq 1 12);do
				echo "<option value=\"$M\" selected>$M</option>"
			done
			echo "<option value=\"\" >$L_MONTH</option>
			<option value=\"$MONTH_EXP\" selected>$MONTH_EXPIRE</option></select>
			<select name=\"YEAR_EXPIRE\">"
			for A in $(seq $YNOW $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\" >$L_YEAR</option>
			<option value=\"$YEAR_EXP\" selected>$YEAR_EXPIRE</option></select>"
		else
			echo "$L_SELF_REGISTERING_EXPIRED:"
			if [ -n "$C_FREE_CP" ];then
				echo "</td><td colspan=\"7\" align=\"left\">"
			fi
			echo "<select name=\"YEAR_EXPIRE\">"
			for A in $(seq $YNOW $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\">$L_YEAR</option>
			<option value=\"$YEAR_EXP\" selected>$YEAR_EXPIRE</option></select>
			<select name=\"MONTH_EXPIRE\">"
			for M in $(seq 1 12);do
				echo "<option value=\"$M\" selected>$M</option>"
			done
			echo "<option value=\"\">$L_MONTH</option>
			<option value=\"$MONTH_EXP\" selected>$MONTH_EXPIRE</option></select>
			<select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\">$L_DAY</option>
			<option value=\"$DAY_EXP\" selected>$DAY_EXPIRE</option></select>"
		fi
		if [ -n "$C_FREE_CP" ];then
			echo "</td><td colspan=\"7\" align=\"right\">"
		fi
		echo "$L_OR_DAYS:
		<select name=\"AR_EXPIRE_DAYS\">"
		for MD in $(seq 365 1);do
			echo "<option value=\"$MD\" selected>$MD</option>"
		done
		echo "<option value=\"\"></option>
		<option value=\"$C_AR_EXPIRE_DAYS\" selected>$C_AR_EXPIRE_DAYS</option>
		</select></td></tr>"
		limitclass "$C_AR_CLASS"
		echo "<td>$L_LIMIT: </td><td colspan=\"7\">
		$L_HOURS $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limithoursday\">"$HDC"</div> 
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$L_HOURS $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limithoursmonth\">"$HMC"</div></td>
		<td colspan=\"7\" align=\"right\">
		MB $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limitmbday\">"$MDC"</div> 
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	MB $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limitmbmonth\">"$MMC"</div></td>
		</tr><tr>
		<td>$L_DAYS:</td><td colspan=\"7\">
		<div style=\"display: inline-block;\" id=\"limitdays\">"$DC"</div>
		</td>
		<td colspan=\"7\" align=\"right\">$L_TIME:
		<div style=\"display: inline-block;\" id=\"limitrange\">"$RANGE"</div>
		</td></tr>
		</table>
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"SELF_REGISTERING\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"submit\" name=\"CONF_AR\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "IMGLOGIN" ];then
		$C_ZT_BIN_DIR/zt "PermCartella" "777" "$C_HTDOCS_ZT_DIR/images/template/imglogin"
		echo "<p><font color=\"#0000FF\" size=\"3\">$L_IMAGES_LOGIN</font><p>"
		if [ -n "$DEL_IMAGES_LOGIN" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_ZT_DIR/images/template/imglogin/$DEL_IMAGES_LOGIN"
			$C_ZT_BIN_DIR/zt "CreateImageRandom"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=IMGLOGIN"
			exit
		fi
		if [ -n "$CREATEJS" ];then
			$C_ZT_BIN_DIR/zt "CreateImageRandom"
		fi
		if [ -n "$CONF_IMGLOGIN" ];then
			wait 550
			if [ -n "$SHOWIMGLOGIN" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ShowImgLogin"
				$C_ZT_BIN_DIR/zt "CreateImageRandom"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ShowImgLogin"
			fi
			if [ -n "$LOGINIMAGETIME" ];then
				$C_ZT_BIN_DIR/zt "Salva" "$LOGINIMAGETIME" "$C_CP_DIR/Auth/Custom/TimeImageLogin"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/TimeImageLogin"
			fi
			if [ -n "$LOGINIMAGERANDOM" ];then
				$C_ZT_BIN_DIR/zt "Salva" "$LOGINIMAGERANDOM" "$C_CP_DIR/Auth/Custom/RandomImageLogin"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/RandomImageLogin"
			fi
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=IMGLOGIN"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_CP:&nbsp;"
		if [ "$(cat $C_CP_DIR/Auth/Custom/ShowImgLogin)" == "yes" ];then
			echo "<input name=\"SHOWIMGLOGIN\" type=\"checkbox\" checked=\"checked\">"
			echo "<br>&nbsp;<br>$L_LOGIN_IMAGE_SEC:&nbsp;
			<select name=\"LOGINIMAGETIME\" style=\"width:45px\">"
			for ST in $(seq 5 5 60);do
				echo "<option value=\"$ST\">$ST</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$(cat $C_CP_DIR/Auth/Custom/TimeImageLogin)\" selected>$(cat $C_CP_DIR/Auth/Custom/TimeImageLogin)</option></select>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			$L_LOGIN_IMAGE_RANDOM:&nbsp;
			<select name=\"LOGINIMAGERANDOM\" style=\"width:110px\">"
			for IR in $(ls $C_HTDOCS_ZT_DIR/images/template/imglogin);do
				if [ "$IR" != "$(cat $C_CP_DIR/Auth/Custom/RandomImageLogin)" ];then
					echo "<option value=\"$IR\">$IR</option>"
				fi
			done
			if [ "$(cat $C_CP_DIR/Auth/Custom/RandomImageLogin)" != "random" ];then
				echo "<option value=\"random\">Random</option>"
			fi
			echo "<option value=\"\"></option>
			<option value=\"$(cat $C_CP_DIR/Auth/Custom/RandomImageLogin)\" selected>"$(cat $C_CP_DIR/Auth/Custom/RandomImageLogin)"</option></select>"
			echo "<br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"IMGLOGIN\">
			<input type=\"submit\" name=\"CONF_IMGLOGIN\" class=\"bottone\" value=\"$L_SAVE \"></form>"
			echo "<br>&nbsp;<img src=\"/images/barra.png\" alt=\"barra\"><p>
			<font color=\"blue\" size=\"3\">$L_IMAGES_LOGIN (700 x 600 px)</font><p>
			<form action=\"scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
			<input type=\"hidden\" name=\"config\" value=\"Login\">
			<input type=\"file\" name=\"imagetest\" size=\"20\">
			<p><input name=\"login\" type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\"><br>&nbsp;</form>"
			CONTROL_IMAGES=$(ls $C_HTDOCS_ZT_DIR/images/template/imglogin)
			if [ -n "$CONTROL_IMAGES" ];then
				nc=1
				echo "<table cellpadding=\"10\" align=\"center\" ><tr>"
				for IMAGE in $(ls $C_HTDOCS_ZT_DIR/images/template/imglogin/);do
					echo "<td align=\"center\"><img src=\"/zerotruth/images/template/imglogin/$IMAGE\" height=\"80\" alt=\"wg\"><br>$IMAGE<br>
					<form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"IMGLOGIN\">
					<input type=\"hidden\" name=\"DEL_IMAGES_LOGIN\" value=\"$IMAGE\">
					<input type=\"image\" class=\"wg\" src=\"/images/action_x.png\"  title=\"$L_DELETE\"
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IMAGE?');\"></form></td>"
					if [ $nc == 5 ];then
						echo "</tr><tr>"
						nc=0
					fi
					nc=$(($nc+1))
				done
				echo "</table><br>"
			fi
		else
			echo "<input name=\"SHOWIMGLOGIN\" type=\"checkbox\"><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"IMGLOGIN\">
			<input type=\"submit\" name=\"CONF_IMGLOGIN\" class=\"bottone\" value=\"$L_SAVE \"></form>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "FACEBOOKLIKE" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">Facebook Like</font><p>"
		if [ -n "$DEL_IMAGES_FB" ];then
			wait "550"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_ZT_DIR/images/template/fb/$DEL_IMAGES_FB"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FACEBOOKLIKE"
			exit
		fi
		if [ -n "$CONF_FACEBOOKLIKE" ];then
			wait 550
			if [ -n "$SHOWLIKE" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ShowLike"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ShowLike"
			fi
			if [ -n "$ENFORCE_POPUP" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/EnforcePopup"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/EnforcePopup"
			fi
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FACEBOOKLIKE"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_CP:&nbsp;"
		if [ "$(cat $C_CP_DIR/Auth/Custom/ShowLike)" == "yes" ];then
			echo "<input name=\"SHOWLIKE\" type=\"checkbox\" checked=\"checked\">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$L_ENFORCE_POPUP: "
			if [ "$(cat $C_CP_DIR/Auth/Custom/EnforcePopup)" == "yes" ];then
				echo "<input name=\"ENFORCE_POPUP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ENFORCE_POPUP\" type=\"checkbox\">"
			fi
			echo "<br>"
			$C_ZT_BIN_DIR/zt "PermCartella" "777" "$C_HTDOCS_ZT_DIR/images/template/fb"
			echo "<br><textarea name=\"FBLIKE\" rows=\"20\" cols=\"110\">$(cat $C_HTDOCS_ZT_DIR/cgi-bin/template/likefb.sh)</textarea><br>&nbsp;<br>
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FACEBOOKLIKE\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\" name=\"CONF_FACEBOOKLIKE\" class=\"bottone\" value=\"$L_SAVE \"></form>"
			echo "<br>&nbsp;<img src=\"/images/barra.png\" alt=\"barra\"><p>
			<font color=\"blue\" size=\"3\">$L_IMAGES</font><p>
			<form action=\"scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
			<input type=\"hidden\" name=\"config\" value=\"fb\">
			<input type=\"file\" name=\"imagetest\" size=\"20\">
			<p><input name=\"fb\" type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\"><br>&nbsp;</form>"
			CONTROL_IMAGES=$(ls $C_HTDOCS_ZT_DIR/images/template/fb)
			if [ -n "$CONTROL_IMAGES" ];then
				nc=1
				echo "<table cellpadding=\"10\" align=\"center\" ><tr>"
				for IMAGE in $(ls $C_HTDOCS_ZT_DIR/images/template/fb/);do
					echo "<td align=\"center\"><img src=\"/zerotruth/images/template/fb/$IMAGE\" height=\"80\" alt=\"wg\"><br>$IMAGE<br>
					<form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FACEBOOKLIKE\">
					<input type=\"hidden\" name=\"DEL_IMAGES_FB\" value=\"$IMAGE\">
					<input type=\"image\" class=\"wg\" src=\"/images/action_x.png\"  title=\"$L_DELETE\"
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IMAGE?');\"></form></td>"
					if [ $nc == 5 ];then
						echo "</tr><tr>"
						nc=0
					fi
					nc=$(($nc+1))
				done
				echo "</table><br>"
			fi
		else
			echo "<input name=\"SHOWLIKE\" type=\"checkbox\"><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FACEBOOKLIKE\">
			<input type=\"submit\" name=\"CONF_FACEBOOKLIKE\" class=\"bottone\" value=\"$L_SAVE \"></form>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "TICKET" ];then
		echo "<br><font color=\"#0000FF\" size=\"3\">$L_TICKET</font><br>"
		if [ -n "$CONF_SCRIPT" ];then
			wait "570"
			for CONF in  "PRINT_QR" "PRINT_QR_ONLY" "PRINT_CREATED" "PRINT_NAME" "PRINT_EXP" "PRINT_CLASS" "TICKETS_PAGE";do
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
			done
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=TICKET"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_TICKETS_PAGE: <select name=\"TICKETS_PAGE\">"
		for NT in $(seq 2 2 16);do
			if [ "$NT" != "$C_TICKETS_PAGE" ];then
				echo "<option value=\"$NT\">$NT</option>"
			fi
		done
		echo "<option value=\"\"></option>
		<option value=\"$C_TICKETS_PAGE\" selected>$C_TICKETS_PAGE</option></select>"
		echo "<p><table class=\"naked\"><tr>
		<td align=\"left\">$L_PRINT_QR:&nbsp;</td><td>"
		if [ -n "$C_PRINT_QR"  ];then
			echo "<input name=\"PRINT_QR\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_QR\" type=\"checkbox\">"
		fi

		echo "</td><td align=\"left\">&nbsp;&nbsp;$L_PRINT_QR_ONLY:&nbsp;</td><td>"
		if [ -n "$C_PRINT_QR_ONLY"  ];then
			echo "<input name=\"PRINT_QR_ONLY\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_QR_ONLY\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		<td align=\"left\">$L_PRINT_NAME:&nbsp;</td><td>"
		if [ -n "$C_PRINT_NAME"  ];then
			echo "<input name=\"PRINT_NAME\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_NAME\" type=\"checkbox\">"
		fi

		echo "</td><td align=\"left\">&nbsp;&nbsp;$L_PRINT_CREATED:&nbsp;</td><td>"
		if [ -n "$C_PRINT_CREATED"  ];then
			echo "<input name=\"PRINT_CREATED\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_CREATED\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		<td align=\"left\">$L_PRINT_EXP:&nbsp;</td><td>"
		if [ -n "$C_PRINT_EXP"  ];then
			echo "<input name=\"PRINT_EXP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_EXP\" type=\"checkbox\">"
		fi
		echo "</td><td align=\"left\">&nbsp;&nbsp;$L_PRINT_CLASS:&nbsp;</td><td>"
		if [ -n "$C_PRINT_CLASS"  ];then
			echo "<input name=\"PRINT_CLASS\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"PRINT_CLASS\" type=\"checkbox\">"
		fi
		echo "</td></tr><tr>
		</table>"
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"TICKET\">
		<img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "ALERTS" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">$L_ALERTS</font><p>"
		if [ -n "$CONF_SCRIPT" ];then
			wait "570"
			sleep 2
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=ALERTS"
			exit
		fi
		GENERAL_INFO=$(cat $C_CP_DIR/Auth/Custom/GeneralInfo)
		ACCOUNT_INFO=$(cat $C_CP_DIR/Auth/Custom/AccountInfo)
		INFO_OFF_LINE=$(cat $C_CP_DIR/Auth/Custom/InfoOffLine)
		POST_REGISTRATION=$(cat $C_CP_DIR/Auth/Custom/PostRegistration)
		USER_BLOCKED=$(cat $C_CP_DIR/Auth/Custom/UserBlocked)
		DESCRIPTION=$(cat $C_CP_DIR/Auth/Custom/Image/Description)
		TEXT_PRIVACY=$(cat $C_ZT_CONF_DIR/privacy)
		INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
		INTERFACECP=$( cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		THANKS_FB=$(cat $C_ZT_CONF_DIR/ThanksFb)
		NO_INTERNET=$(cat $C_ZT_CONF_DIR/NoInternet)
		echo "<form method=\"POST\" action=\"config.sh\">
		<table>
		<tr>
		<td align=\"center\">"
		if [ -z "$C_FREE_CP" ];then
			echo "$L_POST_REGISTRATION:"
		else
			echo "$L_FREE_REGISTRATION:"
		fi
		echo "<br>
		<textarea name=\"POST_REGISTRATION\" rows=\"6\" cols=\"30\">$POST_REGISTRATION</textarea></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td align=\"center\">$L_INFO_TICKET:<br>
		<textarea name=\"INFO_TICKET\" rows=\"6\" cols=\"30\">$INFO_TICKET</textarea><br>&nbsp;</td>
		</tr><tr>
		<td align=\"center\">$L_PRIVACY_RULES:<br>
		<textarea name=\"TEXT_PRIVACY\" rows=\"6\" cols=\"30\">$TEXT_PRIVACY</textarea></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td align=\"center\">$L_INFO_USER_BLOCKED:<br>
		<textarea name=\"USER_BLOCKED\" rows=\"6\" cols=\"30\">$USER_BLOCKED</textarea><br>&nbsp;</td>
		</tr></tr>
		<td align=\"center\">$L_INFO_OFFLINE:<br>
		<textarea name=\"INFO_OFF_LINE\" rows=\"6\" cols=\"30\">$INFO_OFF_LINE</textarea></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td align=\"center\">$L_GENERAL_INFO:<br>
		<textarea name=\"GENERAL_INFO\" rows=\"6\" cols=\"30\">$GENERAL_INFO</textarea><br>&nbsp;</td>
		</tr>
		<tr>
		<td align=\"center\">$L_ACCOUNT_INFO:<br>
		<textarea name=\"ACCOUNT_INFO\" rows=\"6\" cols=\"30\">$ACCOUNT_INFO</textarea></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td align=\"center\">$L_NAME_HOTSPOT:<br>
		<textarea name=\"DESCRIPTION\" rows=\"6\" cols=\"30\">$DESCRIPTION</textarea><br>&nbsp;</td>
		</tr>
		<tr>
		<td align=\"center\">Facebook Like - $L_THANKS:<br>
		<textarea name=\"THANKS_FB\" rows=\"6\" cols=\"30\">$THANKS_FB</textarea></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td align=\"center\">$L_INTERNET_DOWN:<br>
		<textarea name=\"NO_INTERNET\" rows=\"6\" cols=\"30\">$NO_INTERNET</textarea><br>&nbsp;</td>
		</tr>
		</table>
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ALERTS\">
		<img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "WALLED_GARDEN" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">Walled Garden</font><p>
		<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_CP:&nbsp;"
		if [ "$(cat $C_CP_DIR/Auth/Custom/WalledGarden)" == "yes" ];then
			echo "<input name=\"ACTIVE_WG\" type=\"checkbox\" checked=\"checked\">"
			[ -z $(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden) ] && $C_ZT_BIN_DIR/zt "Salva" "Internal" "$C_CP_DIR/Auth/Custom/TypeWalledGarden"
			echo "&nbsp;&nbsp;&nbsp;$L_WG_TYPE: <select name=\"TYPE_WG\">"
			for TWG in "Internal" "Redirect";do
				if [ "$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)" != "$TWG" ];then
					echo "<option value=\"$TWG\">$TWG</option>"
				fi
			done
			echo "<option value=\"$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)\" selected>"$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)"</option></select>"
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)" == "Redirect" ];then
				echo "<p>URL: http://<input type=\"text\" name=\"REDIRECT_URL\" value=\"$(cat $C_CP_DIR/Auth/Custom/RedUrlWalledGarden)\">&nbsp;&nbsp;&nbsp;
				IP URL: <input type=\"text\" name=\"IP_URL\" value=\"$(cat $C_CP_DIR/Auth/Custom/IpUrlWalledGarden)\"><p>"
			fi
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)" == "Internal" ];then
				$C_ZT_BIN_DIR/zt "PermCartella" "777" "$C_HTDOCS_ZT_DIR/images/template/wg/"
				echo "<p>walledgarden.html<br><textarea name=\"WALLED_GARDEN\" rows=\"20\" cols=\"80\">$(cat $C_HTDOCS_ZT_DIR/template/walledgarden.html)</textarea>"
			fi
			URL_WG="$(echo $HTTP_REFERER | cut -d'/' -f3)"
			echo "<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"WALLED_GARDEN\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<p><input type=\"submit\" name=\"CONF_WG\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>"
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)" == "Redirect" ];then
				echo "<form name=\"formins\" method=\"post\" action=\"http://$(cat $C_CP_DIR/Auth/Custom/RedUrlWalledGarden)\" target=\"popupview\"
				onSubmit=\"window.open('', 'popupview', 'height=500,width=1000,left=50,top=50,status=no,menu=no,scrollbars=yes');\">
				<p><input name=\"popup\" type=\"submit\" class=\"bottonelineadue\" value=\"$L_CHECK\"><br>&nbsp;</form>"
			fi
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypeWalledGarden)" == "Internal" ];then
				echo "<form name=\"formins\" method=\"post\" action=\"https://$URL_WG/zerotruth/template/walledgarden.html\" target=\"popupview\"
				onSubmit=\"window.open('', 'popupview', 'height=600,width=650,left=70,top=50,status=no,menu=no,scrollbars=yes');\">
				<p><input name=\"popup\" type=\"submit\" class=\"bottonelineadue\" value=\"$L_CHECK\"><br>&nbsp;</form>"
				echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<font color=\"#0000FF\" size=\"3\">$L_IMAGES_WG</font><p>
				<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
				<input type=\"hidden\" name=\"config\" value=\"Wg\">
				<input type=\"file\" name=\"imagetest\" size=\"20\">
				<p><input name=\"wg\" type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\"></form>"
				CONTROL_IMAGES=$(ls $C_HTDOCS_ZT_DIR/images/template/wg/)
				if [ -n "$CONTROL_IMAGES" ];then
					nc=1
					echo "<table cellpadding=\"10\" align=\"center\" ><tr>"
					for IMAGE in $(ls $C_HTDOCS_ZT_DIR/images/template/wg/);do
						echo "<td align=\"center\"><img src=\"/zerotruth/images/template/wg/$IMAGE\" height=\"80\" alt=\"wg\"><br>$IMAGE<br>
						<form action=\"config.sh\" method=\"POST\">
						<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
						<input type=\"hidden\" name=\"SUB_SECTION\" value=\"WALLED_GARDEN\">
						<input type=\"hidden\" name=\"DEL_IMAGES\" value=\"$IMAGE\">
						<input type=\"image\" class=\"wg\" src=\"/images/action_x.png\"  title=\"$L_DELETE\"
						onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IMAGE?');\"></form></td>"
						if [ $nc == 5 ];then
							echo "</tr><tr>"
							nc=0
						fi
						nc=$(($nc+1))
					done
					echo "</table><br>"
				fi
			fi
		else
			echo "<input name=\"ACTIVE_WG\" type=\"checkbox\">
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"WALLED_GARDEN\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<p><input type=\"submit\" name=\"CONF_WG\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "POPUP" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">Popup</font><p>"
		if [ -n "$CONF_POPUP" ];then
			wait "550"
			if [ -n "$DEL_IMAGES_POPUP" ];then
				$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_ZT_DIR/images/template/popup/$DEL_IMAGES_POPUP"
				return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=POPUP"
				exit
			fi
			if [ -n "$ACTIVE_POPUP" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Popup"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/Popup"
			fi
			if [ -n "$NUM_POPUP" ];then
				$C_ZT_BIN_DIR/zt "Salva" "$NUM_POPUP" "$C_CP_DIR/Auth/Custom/NumPopup"
			fi
			if [ -n "$ENFORCE_POPUP" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/EnforcePopup"
			else
				$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/EnforcePopup"
			fi
			if [ -n "$HEIGHTPP" ];then
				$C_ZT_BIN_DIR/zt "Salva" "$HEIGHTPP" "$C_CP_DIR/Auth/Custom/HeightPopup"
				$C_ZT_BIN_DIR/zt "Salva" "$WIDTHTPP" "$C_CP_DIR/Auth/Custom/WidthPopup"
				$C_ZT_BIN_DIR/zt "Salva" "$TOPPP" "$C_CP_DIR/Auth/Custom/TopPopup"
				$C_ZT_BIN_DIR/zt "Salva" "$LEFTPP" "$C_CP_DIR/Auth/Custom/LeftPopup"
			fi
			$C_ZT_BIN_DIR/zt "Salva" "$TYPE_PP" "$C_CP_DIR/Auth/Custom/TypePopup"
			if [ -n "$REDIRECT_URL_PP" ];then
				REDIRECT_URL_PP="$(echo $REDIRECT_URL_PP | sed 's/%2F/\//g')"
				$C_ZT_BIN_DIR/zt "Salva" "$REDIRECT_URL_PP" "$C_CP_DIR/Auth/Custom/RedUrlPopup"
			fi
			cronpopup
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=POPUP"
			exit
		fi
		$C_ZT_BIN_DIR/zt "PermCartella" "777" "$C_HTDOCS_ZT_DIR/images/template/popup"
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_CP:&nbsp;"
		if [ "$(cat $C_CP_DIR/Auth/Custom/Popup)" == "yes" ];then
			echo "<input name=\"ACTIVE_POPUP\" type=\"checkbox\" checked=\"checked\">
			&nbsp;&nbsp;&nbsp;$L_WG_TYPE: <select name=\"TYPE_PP\">"
			[ -z $(cat $C_CP_DIR/Auth/Custom/TypePopup) ] && $C_ZT_BIN_DIR/zt "Salva" "Internal" "$C_CP_DIR/Auth/Custom/TypePopup"
			for TPP in "Internal" "Redirect";do
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypePopup)" != "$TPP" ];then
				echo "<option value=\"$TPP\">$TPP</option>"
			fi
			done
			echo "<option value=\"$(cat $C_CP_DIR/Auth/Custom/TypePopup)\" selected>"$(cat $C_CP_DIR/Auth/Custom/TypePopup)"</option></select>
			&nbsp;&nbsp;&nbsp;$L_ENFORCE_POPUP: "
			if [ "$(cat $C_CP_DIR/Auth/Custom/EnforcePopup)" == "yes" ];then
				echo "<input name=\"ENFORCE_POPUP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ENFORCE_POPUP\" type=\"checkbox\">"
			fi
			echo "<br>&nbsp;<br><table class=\"naked\" border=\"0\"><tr>
			<td align=\"left\">$L_NUM_POPUP:</td><td>
			<select name=\"NUM_POPUP\">"
			NUM_POPUP_REG=$(cat $C_CP_DIR/Auth/Custom/NumPopup)
			if [ "$NUM_POPUP_REG" == "1" ];then
				echo "<option value=\"100\">$L_MANY</option>
				<option value=\"1\" selected>1</option>"
			else
				echo "<option value=\"1\">1</option>
				   <option value=\"100\" selected>$L_MANY</option>"
			fi
			echo "</select>
			</td><td height=\"30\">&nbsp;
			$L_TIME:</td><td colspan=\"4\">"
			if [ -d $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron ];then
				HOUR_START=$(cat $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Hour)
				MINUTES_START=$(cat $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Minute)
				HOUR_STOP=$(cat $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Hour)
				MINUTES_STOP=$(cat $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Minute)
			fi
			echo "<select name=\"HOUR_START\">"
			for OS in $(seq 0 23);do
				echo "<option value=\"$OS\">$OS</option>"
			done
			if [ -n "$HOUR_START" ];then
				echo "<option value=\"\"></option>
				<option value=\"$HOUR_START\" selected>$L_FROM: $HOUR_START</option></select>"
			else
				 echo "<option value=\"\" selected>$L_FROM_HOUR</option></select>"
			fi
			echo "<select name=\"MINUTES_START\">"
			for MS in $(seq 0 59);do
				echo "<option value=\"$MS\" >$MS</option>"
			done
			if [ -n "$MINUTES_START" ];then
				echo "<option value=\"\"></option>
				<option value=\"$MINUTES_START\" selected>$MINUTES_START</option></select>"
			else
				echo "<option value=\"\" selected>$L_MINUTES</option></select>"
			fi
			echo "<select name=\"HOUR_STOP\">"
			for OS in $(seq 0 23);do
				echo "<option value=\"$OS\">$OS</option>"
			done
			if [ -n "$HOUR_STOP" ];then
				echo "<option value=\"\"></option>
				<option value=\"$HOUR_STOP\" selected>$L_TO: $HOUR_STOP</option></select>"
			else
				echo "<option value=\"\" selected>$L_TO_HOUR</option></select>"
			fi
			echo "<select name=\"MINUTES_STOP\">"
			for MS in $(seq 0 59);do
				echo "<option value=\"$MS\" selected>$MS</option>"
			done
			if [ -n "$MINUTES_STOP" ];then
				echo "<option value=\"\" selected></option>
				<option value=\"$MINUTES_STOP\" selected>$MINUTES_STOP</option></select>"
			else
				echo "<option value=\"\" selected>$L_MINUTES</option></select>"
			fi
			[ -z $(cat $C_CP_DIR/Auth/Custom/LeftPopup) ] && $C_ZT_BIN_DIR/zt "Salva" "70" "$C_CP_DIR/Auth/Custom/LeftPopup"
			[ -z $(cat $C_CP_DIR/Auth/Custom/TopPopup) ] && $C_ZT_BIN_DIR/zt "Salva" "50" "$C_CP_DIR/Auth/Custom/TopPopup"
			[ -z $(cat $C_CP_DIR/Auth/Custom/HeightPopup) ] && $C_ZT_BIN_DIR/zt "Salva" "600" "$C_CP_DIR/Auth/Custom/HeightPopup"
			[ -z $(cat $C_CP_DIR/Auth/Custom/WidthPopup) ] && $C_ZT_BIN_DIR/zt "Salva" "550" "$C_CP_DIR/Auth/Custom/WidthPopup"
			echo "</td></tr>
			<tr><td>height:</td><td><input type=\"text\" class=\"text2\" name=\"HEIGHTPP\" value=\"$(cat $C_CP_DIR/Auth/Custom/HeightPopup)\"></td>
			<td align=\"right\">width:</td><td>
			<input type=\"text\" class=\"text2\" name=\"WIDTHTPP\" value=\"$(cat $C_CP_DIR/Auth/Custom/WidthPopup)\">
			&nbsp;left:&nbsp;<input type=\"text\" class=\"text2\" name=\"LEFTPP\" value=\"$(cat $C_CP_DIR/Auth/Custom/LeftPopup)\">
			&nbsp;top:&nbsp;<input type=\"text\" class=\"text2\" name=\"TOPPP\" value=\"$(cat $C_CP_DIR/Auth/Custom/TopPopup)\">
			</td></tr></table><p>"
			if [ "$(cat $C_CP_DIR/Auth/Custom/TypePopup)" == "Internal" ];then
				echo "<p>popup.html<br><textarea name=\"POPUP_HTML\" rows=\"20\" cols=\"80\">$(cat $C_HTDOCS_ZT_DIR/template/popup.html)</textarea>"
				URL_POPUP="$(echo $HTTP_REFERER | cut -d'/' -f3)"
				echo "<p>
				<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"POPUP\">
				<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
				<input type=\"submit\" name=\"CONF_POPUP\" class=\"bottonelinea\" value=\"$L_SAVE \"></form>
				<form name=\"formins\" method=\"post\" action=\"https://$URL_POPUP/zerotruth/template/popup.html\" target=\"popupview\"
				onSubmit=\"window.open('', 'popupview', 'height=$(cat $C_CP_DIR/Auth/Custom/HeightPopup),width=$(cat $C_CP_DIR/Auth/Custom/WidthPopup),left=$(cat $C_CP_DIR/Auth/Custom/LeftPopup),top=$(cat $C_CP_DIR/Auth/Custom/TopPopup),status=no,menu=no,scrollbars=yes');\">
				<p><input name=\"popup\" type=\"submit\" class=\"bottonelineadue\" value=\"$L_CHECK\"><br>&nbsp;</form>
				<br>"
				echo "<img src=\"/images/barra.png\" alt=\"barra\"><p>
				<font color=\"blue\" size=\"3\">$L_IMAGES_POPUP</font><p>
				<form action=\"scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
				<input type=\"hidden\" name=\"config\" value=\"Popup\">
				<input type=\"file\" name=\"imagetest\" size=\"20\">
				<p><input name=\"popup\" type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_IMAGE\"><br>&nbsp;</form>"
				CONTROL_IMAGES=$(ls $C_HTDOCS_ZT_DIR/images/template/popup)
				if [ -n "$CONTROL_IMAGES" ];then
					nc=1
					echo "<table cellpadding=\"10\" align=\"center\" ><tr>"
					for IMAGE in $(ls $C_HTDOCS_ZT_DIR/images/template/popup/);do
						echo "<td align=\"center\"><img src=\"/zerotruth/images/template/popup/$IMAGE\" height=\"80\" alt=\"wg\"><br>$IMAGE<br>
						<form action=\"config.sh\" method=\"POST\">
						<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
						<input type=\"hidden\" name=\"SUB_SECTION\" value=\"POPUP\">
						<input type=\"hidden\" name=\"DEL_IMAGES_POPUP\" value=\"$IMAGE\">
						<input type=\"hidden\" name=\"CONF_POPUP\" value=\"YES\">
						<input type=\"image\" class=\"wg\" src=\"/images/action_x.png\"  title=\"$L_DELETE\"
						onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IMAGE?');\"></form></td>"
						if [ $nc == 5 ];then
							echo "</tr><tr>"
							nc=0
						fi
						nc=$(($nc+1))
					done
					echo "</table><br>"
				fi
			else
				echo "<p>URL/IP: http://<input type=\"text\" style=\"width: 400px;\" name=\"REDIRECT_URL_PP\" value=\"$(cat $C_CP_DIR/Auth/Custom/RedUrlPopup)\"><p>"
				echo "<p>
				<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"POPUP\">
				<input type=\"submit\" name=\"CONF_POPUP\" class=\"bottonelinea\" value=\"$L_SAVE \"></form>
				<form name=\"formins\" method=\"post\" action=\"http://$(cat $C_CP_DIR/Auth/Custom/RedUrlPopup)\" target=\"popupview\"
				onSubmit=\"window.open('', 'popupview', 'height=$(cat $C_CP_DIR/Auth/Custom/HeightPopup),width=$(cat $C_CP_DIR/Auth/Custom/WidthPopup),left=$(cat $C_CP_DIR/Auth/Custom/LeftPopup),top=$(cat $C_CP_DIR/Auth/Custom/TopPopup),status=no,menu=no,scrollbars=yes');\">
				<p><input name=\"popup\" type=\"submit\" class=\"bottonelineadue\" value=\"$L_CHECK\"><br>&nbsp;</form>
				<br>"
			fi
		else
			echo "<input name=\"ACTIVE_POPUP\" type=\"checkbox\"><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"POPUP\">
			<input type=\"hidden\" name=\"DEL_IMAGES_POPUP\" value=\"$IMAGE\">
			<input type=\"submit\" name=\"CONF_POPUP\" class=\"bottone\" value=\"$L_SAVE \"></form>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "PAYPAL" ];then
		echo "<p><font color=\"#0000FF\" size=\"3\">PayPal</font><p>"
		if [ $(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType) == "pre" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			$L_ACTIVE_CP:&nbsp;"
			if [ "$C_ACTIVE_PP" == "on" ];then
				echo "<input name=\"ACTIVE_PP\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"ACTIVE_PP\" type=\"checkbox\">"
			fi
			echo "<p>$L_BUTTON_PAYPAL<br>"
			PP_BUTTON=$(cat $C_ZT_CONF_DIR/ppbutton)
			echo "<textarea name=\"PP_BUTTON\" rows=\"6\" cols=\"75\">$(echo -e $PP_BUTTON )</textarea><p>
			<p><input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<p>
			$L_POST_PAYMENT:<br>"
			PP_NOTICE=$(cat $C_ZT_CONF_DIR/ppnotice)
			echo "<textarea name=\"PP_NOTICE\" rows=\"6\" cols=\"75\">$(echo -e $PP_NOTICE )</textarea><p>
			<p>$L_ATTEMPTS: <select name=\"TIMES_PP\">"
			for TIMESPP in $(seq 1 10 );do
				echo "<option value=\"$TIMESPP\">$TIMESPP</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_TIMES_PP\" selected>$C_TIMES_PP</option></select>
			&nbsp;&nbsp;&nbsp;
			$L_OPEN_FIREWALL: <select name=\"TIME_PP\">"
			for TIMEPP in $(seq 20 20 240);do
				echo "<option value=\"$TIMEPP\">$TIMEPP</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_TIME_PP\" selected>$C_TIME_PP</option></select>
			&nbsp;&nbsp;&nbsp;
			$L_FREE_MAC: <select name=\"FREE_MAC\">"
			RIGHE=$(cat $C_ZT_CONF_DIR/banmac | wc -l )
			for I in $(seq 1 $RIGHE);do
				MAC_BAN="$(cat $C_ZT_CONF_DIR/banmac | /bin/sed -n "${I}p")"
				echo "<option value=\"$MAC_BAN\">$MAC_BAN</option>"
			done
			echo "<option value=\"$L_ALL\">$L_ALL</option>
			<option value=\"\" selected></option></select>
			&nbsp;&nbsp;&nbsp;
			GMT: <select name=\"GMT\">"
			for GMTMENO in $(seq 12 1);do
				echo "<option value=\"- $GMTMENO\">- $GMTMENO</option>"
			done
			for GMTPIU in $(seq 0 12);do
				echo "<option value=\"+ $GMTPIU\">+ $GMTPIU</option>"
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_GMT\" selected>$C_GMT</option></select><p>
			<p><input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYPAL\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"submit\" name=\"CONF_PP\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
			./footer.sh
			exit
		else
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<p><font color=\"red\">$L_CLASS_PP_ERROR</font><p>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			./footer.sh
			exit
		fi
	fi
	if [ "$SUB_SECTION" == "PAYMENTS" ];then
		if [ -n "$DELETE" ];then
			RIGHE=$(cat $C_ZT_LOG_DIR/pp/payments | wc -l | awk '{print $1}')
			for I in $(seq $RIGHE 1);do
				CONTROLLINE="LINE$I"
				eval CONTROLLINE="\$$CONTROLLINE"
				if [ -n "$CONTROLLINE" ];then
					$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$I" "$C_ZT_LOG_DIR/pp/payments"
				fi
			done
		fi
		if [ -n "$CREDIT" ];then
			CREDIT_LOG=$(echo "$CREDIT" | awk '{printf("%.2f\n", $0)}')
			CREDITES=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
			if [ $( echo $CREDIT | cut -sd'-' -f2) ];then
				CREDIT=$( echo $CREDIT | cut -d'-' -f2)
				CREDIT=$(echo "$CREDITES-$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
			else
				CREDIT=$(echo "$CREDITES+$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
			fi
			$C_ZT_BIN_DIR/zt "Salva" "$CREDIT" "$C_ACCT_DIR/credits/$USERNAME/Credit"
			if [ "$CREDIT_LOG" != "0.00" ];then
				$C_ZT_BIN_DIR/zt "Aggiungi"	"$USERNAME+$(date '+%b %d, %Y')+$( date '+%T')+$CREDIT_LOG+cash" "$C_ZT_LOG_DIR/pp/payments"
			fi
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UPDATED $L_CREDIT user $USERNAME $CREDIT_LOG"
			CONTROL="$USERNAME"
		fi
		CURRENCY=$(cat $C_ZT_SCRIPTS_DIR/send_pay_pp.sh | grep currency | cut -d'"' -f4)
		echo "<p><font color=\"#0000FF\" size=\"3\">$L_PAYMENTS</font><p>
		<form action=\"config.sh\" method=\"POST\">
		<table class=\"tabellain\" width=\"800\" border=\"1\">
		<tr><td width=\"17\" class=\"intesta\">"
		if [ -z "$CHECK" ];then
				echo "<a href=\"config.sh?SORT=USERNAME&amp;CONTROL=$CONTROL&amp;CHECK=YES&amp;SECTION=CAPTIVE_PORTAL&amp;SUB_SECTION=PAYMENTS\">C.</a>"
			else
				echo "<a href=\"config.sh?SORT=USERNAME&amp;CONTROL=$CONTROL&amp;CHECK=&amp;SECTION=CAPTIVE_PORTAL&amp;SUB_SECTION=PAYMENTS\">C.</a>"
			fi
		echo "</td>

		<td width=\"17\" class=\"intesta\">N.</td>
		<td class=\"intesta\">"
		if [ -z "$CONTROL" ];then
			echo "<a href=\"config.sh?SORT=USERNAME&amp;CONTROL=$CONTROL&amp;CHECK=$CHECK&amp;SECTION=CAPTIVE_PORTAL&amp;SUB_SECTION=PAYMENTS\">$L_USERNAME</a></td>"
		else
			echo "<a href=\"config.sh?SORT=&amp;CONTROL=&amp;CHECK=&amp;SECTION=CAPTIVE_PORTAL&amp;SUB_SECTION=PAYMENTS\">$L_ALL</a></td>"
		fi
		echo "<td class=\"intesta\">$L_DATE</td>"
		echo "<td class=\"intesta\">$L_HOUR</td>
		<td class=\"intesta\">ID</td>
		<td class=\"intesta\">$C_CURRENCY</td>
		</tr>"
		TOTM="0"
		if [[ -f $C_ZT_LOG_DIR/pp/payments && -n $(cat $C_ZT_LOG_DIR/pp/payments) ]];then
			if [ "$SORT" == "USERNAME" ];then
				PAYMENTS=$(cat $C_ZT_LOG_DIR/pp/payments | sort)
			else
				PAYMENTS=$(cat $C_ZT_LOG_DIR/pp/payments)
			fi
			RIGHE=$(echo "$PAYMENTS" | wc -l )
			NUM=1
			for I in $(seq 1 $RIGHE);do
				BG="$C_BG"
				[ $(expr $I % 2 ) -eq 0 ] && BG="$C_BG1"
				RIGA="$(echo "$PAYMENTS" | sed -n "${I}p")"
				USERP=$(echo "$RIGA" | cut -d'+' -f1)
				DATAP=$(echo "$RIGA" | cut -d'+' -f2 | sed "s/PDT//g")
				HOURP=$(echo "$RIGA" | cut -d'+' -f3)
				SEC_DATA=$( date --utc --date "$DATAP $HOURP" +%s)
				if [[ -n "$C_GMT" && $(echo "$RIGA" | cut -d'+' -f5) != "cash" ]];then
					SEC_DATA_HERE=$(($C_GMT+8))
					SEC_DATA_HERE=$(($SEC_DATA_HERE*3600))
					if [ $(echo "$C_GMT" | awk '{print $1}') == "+" ];then
						SEC_HERE=$(($SEC_DATA+$SEC_DATA_HERE))
					else
						SEC_HERE =$(($SEC_DATA-$SEC_DATA_HERE))
					fi
				else
					SEC_HERE=$SEC_DATA
				fi
				if [ "$C_FORM_DATE" == "ita" ];then
					DATA_HERE=$(date --utc --date "1970-01-01 $SEC_HERE sec" "+%d-%m-%Y %T")
				else
					DATA_HERE=$(date --utc --date "1970-01-01 $SEC_HERE sec" "+%Y-%m-%d %T")
				fi
				DATAP=$(echo "$DATA_HERE" | awk '{ print $1 }')
				HOURP=$(echo "$DATA_HERE" | awk '{ print $2 }')
				IDP=$(echo "$RIGA" | cut -d'+' -f5)
				MONEYP=$(echo "$RIGA" | cut -d'+' -f4)
				if [[ -z "$CONTROL" || "$CONTROL" == "$USERP" ]];then
					echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">"
					if [ -n "$CHECK" ];then
						echo "<input name=\"LINE$I\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"LINE$I\" type=\"checkbox\">"
					fi
					echo "</td>
					<td align=\"center\">$NUM</td><td align=\"center\">"
					if [ -z "$CONTROL" ];then
						echo "<a href=\"config.sh?SORT=no&amp;CONTROL=$USERP&amp;CHECK=&amp;SECTION=CAPTIVE_PORTAL&amp;SUB_SECTION=PAYMENTS\">$USERP</a>"
					else
						echo "$USERP"
					fi
					echo "</td><td align=\"center\">$DATAP</td>
					<td align=\"center\">$HOURP</td><td align=\"center\">$IDP</td><td align=right>$MONEYP &nbsp;</td></tr>"
					TOTM="$TOTM+$MONEYP"
					NUM=$(($NUM+1))
				fi
			done
			TOTM=$(echo "$TOTM" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		fi
		echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td></td><td>
		<td align=right bgcolor=\"#8cc7f1\">$TOTM &nbsp;</td></tr>
		</table>
		<br><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYMENTS\">
		<input type=\"hidden\" name=\"DELETE\" value=\"YES\">"
		echo "<table><tr><td>"
		echo "<input type=\"submit\" name=\"SAVE\" class=\"bottone\" value=\"$L_DELETE\"
		onClick=\"javascript:return confirm('$L_ALERT_SURE?');\"></form></td>"
		if [ -n "$CONTROL" ];then
			echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td><form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_ADD ($C_CURRENCY)\">
			<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
			<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYMENTS\">
			<input type=\"hidden\" name=\"USERNAME\" value=\"$CONTROL\">
			<input type=\"text\" class=\"credit\" name=\"CREDIT\" value=\"\">
			</form></td>"
		fi
	#	else
	#		echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>
	#		<form name=\"paypal\" method=\"post\" action=\"config.sh\">
	#		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
	#		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PAYPAL\">
	#		<input type=\"submit\" class=\"bottonelineadue\" value=\"Paypal\">
	#		</form></td>"
	#	fi
		echo "</tr></table>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "FREE_AUTHORIZED" ];then
		if [ -n "$ADD_MAC" ];then
			wait "600" "$L_MAC_BLOCKED"
			sleep 2
			if [ -n "$MAC_ADDRESS" ];then
				MAC_ADDRESS=$(echo "$MAC_ADDRESS" | tr '[:lower:]' '[:upper:]')
				$C_ZT_BIN_DIR/zt "Aggiungi" "$MAC_ADDRESS" "$C_ZT_CONF_DIR/macblocked"
			fi
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$DEL_MAC" ];then
			wait "600" "$L_MAC_BLOCKED"
			sleep 2
			$C_ZT_BIN_DIR/zt "RemoveMacBlocked" "$DEL_MAC"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$DEL_FREE_CLIENT" ];then
			wait "600" "$L_FREE"
			sleep 2
			$C_ZT_BIN_DIR/zt "RemoveFreeClient" "$DEL_FREE_CLIENT"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$DEL_FREE_SERVICE" ];then
			wait "600" "$L_FREE"
			sleep 2
			$C_ZT_BIN_DIR/zt "RemoveFreeService" "$DEL_FREE_SERVICE"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$LOCK_FREE_CLIENT" ];then
			wait "600" "$L_FREE"
			sleep 2
			$C_ZT_BIN_DIR/zt "LockFreeClient" "$LOCK_FREE_CLIENT"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$UNLOCK_FREE_CLIENT" ];then
			wait "600" "$L_FREE"
			sleep 2
			$C_ZT_BIN_DIR/zt "UnlockFreeClient" "$UNLOCK_FREE_CLIENT"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$CONF_FREE_CLI" ];then
			wait "600" "$L_FREE"
			sleep 2
			if [[ -n "$IP_FREE_CLI" || -n "$MAC_FREE_CLI" ]];then
				$C_ZT_BIN_DIR/zt "AddFreeClient" "$DESC_FREE_CLI" "$IP_FREE_CLI" "$MAC_FREE_CLI"
			fi
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		if [ -n "$CONF_FREE_SER" ];then
			wait "600" "$L_FREE"
			sleep 2
			$C_ZT_BIN_DIR/zt "AddFreeService" "$DESC_FREE_SER" "$IP_FREE_SER" "$PORT_FREE_SER" "$PROTO_FREE_SER"
			return_page "config.sh?SECTION=CAPTIVE_PORTAL&SUB_SECTION=FREE_AUTHORIZED"
			exit
		fi
		echo "<p><font color=\"#0000FF\" size=\"3\">$L_FREE</font><p>"
		LAST=$( ls -d $C_CP_DIR/FreeClients/* 2>/dev/null | tail -1)
		if [ -n "$LAST" ] ; then
			echo "Client<table class=\"tabellain\" width=\"800\" border=\"1\">
			<tr>
			<td width=\"4%\" class=\"intesta\">N.</td>
			<td width=\"50%\" class=\"intesta\">$L_DESCRIPTION</td>
			<td width=\"20%\" class=\"intesta\">IP Address</td>
			<td class=\"intesta\">MAC Address</td>
			<td width=\"3%\" class=\"intesta\">C.</td>
			<td width=\"3%\" class=\"intesta\">B.</td>
			<td width=\"3%\" class=\"intesta\">D.</td></tr>"
			NC=1
			for C in $(ls $C_CP_DIR/FreeClients/);do
				BG="$C_BG"
				[ $(expr $NC % 2 ) -eq 0 ] && BG="$C_BG1"
				DESC=$(cat $C_CP_DIR/FreeClients/$C/Desc)
				IP=$(cat $C_CP_DIR/FreeClients/$C/IP)
				if [ -z "$IP" ];then
					IP=Any
				else
					if [ "$(echo $IP | cut -d'-' -f2)" == "000" ];then
						BL="yes"
						IP="$(echo $IP | cut -d'-' -f1)"
					fi
				fi
				MAC=$(cat $C_CP_DIR/FreeClients/$C/MAC)
				BL="no"
				if [ "$(echo $MAC | cut -d'-' -f2)" == "000" ];then
					BL="yes"
					MAC="$(echo $MAC | cut -d'-' -f1)"
				fi
				ACTIVE="no"
				if [ -z "$MAC" ];then
					MAC=Any
				else
					MACMIN=$( echo "$MAC" | sed 's/://g' | tr '[:upper:]' '[:lower:]')
					if [ -d $C_ACCT_DIR/entries/$MACMIN ];then
						SESSIONAC=$(ls -lia $C_ACCT_DIR/entries/$MACMIN/sessions | tail -1 | awk '{print $10}')
						if [ -f $C_ACCT_DIR/entries/$MACMIN/sessions/$SESSIONAC/stop ];then
							ACTIVE="no"
						else
							ACTIVE="yes"
						fi
					fi
				fi
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NC</td><td align=left>$DESC</td><td align=\"center\">$IP</td><td align=\"center\">$MAC</td>"
				if [[ $ACTIVE == "yes" && $BL == "no" ]];then
					echo "<td width=\"20px\" style=\"text-align:center;\"><img src=\"/images/collegato.png\"></td>"
				else
					echo "<td></td>"
				fi
				if [ "$BL" == "no" ];then
					echo "<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
					<input type=\"hidden\" name=\"LOCK_FREE_CLIENT\" value=\"$C\">
					<input type=\"image\" class=\"image\" src=\"/images/unlock.png\"
					title=\"$L_LOCK $DESC\"
					onClick=\"javascript:return confirm('$L_ALERT_LOCKED $DESC?');\"></form>
					</td>"
				else
					echo "<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
					<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
					<input type=\"hidden\" name=\"UNLOCK_FREE_CLIENT\" value=\"$C\">
					<input type=\"image\" class=\"image\" src=\"/images/lock.png\"
					title=\"$L_UNLOCK $DESC\"
					onClick=\"javascript:return confirm('$L_ALERT_UNLOCK $DESC?');\"></form>
					</td>"
				fi
				echo "<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
				<input type=\"hidden\" name=\"DEL_FREE_CLIENT\" value=\"$C\">
				<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
				title=\"$L_DELETE $DESC\"
				onClick=\"javascript:return confirm('$L_ALERT_REMOVE $DESC?');\"></form>
				</td></tr>"
				NC=$(($NC+1))
			done
			echo "</table><p>"
		fi
		echo "Add Client<p>
		<form method=\"POST\" action=\"config.sh\">
		$L_DESCRIPTION: <input type=\"text\" name=\"DESC_FREE_CLI\" value=\"\">&nbsp;&nbsp;
		IP: <input type=\"text\" size=\"8\" name=\"IP_FREE_CLI\" value=\"\">&nbsp;&nbsp;
		MAC: <input type=\"text\" size=\"12\" name=\"MAC_FREE_CLI\" value=\"\">
		<p><input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
		<input type=\"submit\" name=\"CONF_FREE_CLI\" class=\"bottone\" value=\"$L_SAVE\"></form><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		LAST=$( ls -d $C_CP_DIR/FreeServices/* 2>/dev/null | tail -1)
		if [ -n "$LAST" ] ; then
			echo "Service<table class=\"tabellain\" width=\"800\" border=\"1\">
			<tr>
			<td width=\"4%\" class=\"intesta\">N.</td>
			<td width=\"50%\" class=\"intesta\">$L_DESCRIPTION</td>
			<td width=\"20%\" class=\"intesta\">IP Address</td>
			<td class=\"intesta\">Port/Proto</td>
			<td width=\"3%\" class=\"intesta\">D.</td>
			</tr>"
			NC=1
			for C in $(ls $C_CP_DIR/FreeServices/);do
				BG="$C_BG"
				[ $(expr $NC % 2 ) -eq 0 ] && BG="$C_BG1"
				DESC=$(cat $C_CP_DIR/FreeServices/$C/Desc)
				IP=$(cat $C_CP_DIR/FreeServices/$C/IP)
				[ -z "$IP" ] && IP=Any
				PORT=$(cat $C_CP_DIR/FreeServices/$C/Port)
				PROTO=$(cat $C_CP_DIR/FreeServices/$C/Proto)
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NC</td><td align=left>$DESC</td><td>$IP</td><td>$PORT/$PROTO</td>
				<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
				<input type=\"hidden\" name=\"DEL_FREE_SERVICE\" value=\"$C\">
				<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
				title=\"$L_DELETE $DESC\"
				onClick=\"javascript:return confirm('$L_ALERT_REMOVE $DESC?');\"></form>
				</td></tr>"
				NC=$(($NC+1))
			done
			echo "</table>"
		fi
		echo "<p>Add Service<p>
		<form method=\"POST\" action=\"config.sh\">
		$L_DESCRIPTION: <input type=\"text\" name=\"DESC_FREE_SER\" value=\"\">&nbsp;&nbsp;
		IP: <input type=\"text\" size=\"8\" name=\"IP_FREE_SER\" value=\"\">&nbsp;&nbsp;
		Port: <input type=\"text\" size=\"3\" name=\"PORT_FREE_SER\" value=\"\">&nbsp;&nbsp;
		Proto: <select name=\"PROTO_FREE_SER\">"
		for PFS in "tcp" "udp";do
			echo "<option value=\"$PFS\">$PFS</option>"
		done
		echo "<option value=\"\" selected></option></select>
		<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
		<p><input type=\"submit\" name=\"CONF_FREE_SER\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p><br>"
		MAC_BLOCKED=$(cat $C_ZT_CONF_DIR/macblocked 2>/dev/null | tail -1)
		echo "<font color=\"blue\">$L_MAC_BLOCKED</font><br>&nbsp;<br>"
		if [ -n "$MAC_BLOCKED" ];then
			echo "<table class=\"tabellain\" width=\"400\" border=\"1\">
			<tr>
			<td width=\"4%\" class=\"intesta\">N.</td>
			<td width=\"50%\" class=\"intesta\">MAC</td>
			<td width=\"3%\" class=\"intesta\">D.</td></tr>"
			NC=1
			RIGHE=$(cat $C_ZT_CONF_DIR/macblocked | wc -l | awk '{print $1}')
			for MB in $(seq 1 $RIGHE);do
				RIGA=$(cat $C_ZT_CONF_DIR/macblocked | /bin/sed -n "${MB}p")
				DESC=$(cat $C_CP_DIR/FreeClients/$C/Desc)
				echo "<tr><td align=\"center\">$NC</td><td align=left>$RIGA</td><td align=\"center\"><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
				<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
				<input type=\"hidden\" name=\"DEL_MAC\" value=\"$RIGA\">
				<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
				title=\"$L_DELETE $RIGA\"
				onClick=\"javascript:return confirm('$L_ALERT_REMOVE $RIGA?');\"></form>
				</td></tr>"
				NC=$(($NC+1))
			done
			echo "</table><p>"
		fi
		echo "$L_ADD_MAC<p>
		<form method=\"POST\" action=\"config.sh\">
		MAC Address: <input type=\"text\" name=\"MAC_ADDRESS\" value=\"\">&nbsp;&nbsp;
		<p><input type=\"hidden\" name=\"SECTION\" value=\"CAPTIVE_PORTAL\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FREE_AUTHORIZED\">
		<input type=\"submit\" name=\"ADD_MAC\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		./footer.sh
		exit
	fi
fi
if [ "$SECTION" == "PROXY" ];then
	echo "<font color=\"blue\" size=\"3\">Proxy - Antivirus</font><p>
	<table  border=\"0\" cellpadding=\"3\">
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"PROXY\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Proxy\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"RULES\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"$L_RULES\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"BLACKLIST\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Blacklist\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"WHITELIST\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Whitelist\"></form></td>"
	if ! [[ -f $C_ZT_PROXY_DIR/sbin/squid && -z "$INSTALL_SQUID" ]];then
		echo "<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"submit\" name=\"INSTALL_SQUID\" class=\"bottoneconf\" value=\"$L_INSTALL Squid\"
		onClick=\"javascript:return confirm('$L_ALERT_INSTALL_SQUID');\"></form></td>"
	fi
	if ! [[ -f $C_ZT_PROXY_DIR/sbin/dansguardian && -z "$INSTALL_DG" ]];then
		echo "<td><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"submit\" name=\"INSTALL_DG\" class=\"bottoneconf\" value=\"$L_INSTALL DG\"
		onClick=\"javascript:return confirm('$L_ALERT_INSTALL_DG');\"></form></td>"
	fi
	echo "</tr>
	</table>"
	if [ "$SUB_SECTION" == "INSTALLSQUID" ];then
		$C_ZT_BIN_DIR/zt "InstallSquid"
		return_page "config.sh?SECTION=PROXY"
		exit
	fi
	if [ -n "$INSTALL_SQUID" ];then
		if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
			echo "<br><font color=\"blue\">$L_ALERT_INSTALL</font>"
			wait "600"
			$C_ZT_BIN_DIR/zt "InstallSquid"
			if [ -f  $C_ZT_PROXY_DIR/sbin/squid ];then
				return_page "config.sh?SECTION=PROXY"
				exit
			else
				echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">Download Error</font><p>
				<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<form action=\"config.sh?SECTION=PROXY\" method=\"POST\">
				<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
				</form>"
				exit
			fi
			./footer.sh
			exit
		else
			echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ZT</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
			./footer.sh
			exit
		fi
	fi
	if [ "$SUB_SECTION" == "INSTALLDG" ];then
		$C_ZT_BIN_DIR/zt "InstallDG"
		return_page "config.sh?SECTION=PROXY"
		exit
	fi
	if [ -n "$INSTALL_DG" ];then
		if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
			echo "<br><font color=\"blue\">$L_ALERT_INSTALL</font>"
			wait "600"
			$C_ZT_BIN_DIR/zt "InstallDG"
			if [ -f  $C_ZT_PROXY_DIR/sbin/dansguardian ];then
				return_page "config.sh?SECTION=PROXY"
				exit
			else
				echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">Download Error</font><p>
				<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<form action=\"config.sh?SECTION=PROXY\" method=\"POST\">
				<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
				</form>"
				exit
			fi
			./footer.sh
			exit
		else
			echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ZT</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
			./footer.sh
			exit
		fi
	fi
	if [ -n "$CONF_RULES" ];then
		wait "600"
		if [ -n "$ACTION_RULE" ] && [ -n "$SOURCE_INT" ];then
			DIR=$(ls $C_SYSTEM/havp/redirects | sort | tail -1)
			DIR=$(($DIR + 1))
			[ $DIR -lt 10 ] && DIR="0$DIR"
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_SYSTEM/havp/redirects/$DIR"
			$C_ZT_BIN_DIR/zt "Salva" "$ACTION_RULE" "$C_SYSTEM/havp/redirects/$DIR/Action"
			$C_ZT_BIN_DIR/zt "Salva" "$SOURCE_INT" "$C_SYSTEM/havp/redirects/$DIR/Interface"
			$C_ZT_BIN_DIR/zt "Salva" "$SOURCE_IP" "$C_SYSTEM/havp/redirects/$DIR/SourceIP"
			$C_ZT_BIN_DIR/zt "Salva" "$DEST_IP" "$C_SYSTEM/havp/redirects/$DIR/DestinationIP"
			if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
			fi
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=RULES"
		exit
	fi
	if [ -n "$REMOVE_RULE" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_SYSTEM/havp/redirects/$REMOVE_RULE"
		if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=RULES"
		exit
	fi
	if [ -n "$CONF_PROXY" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "Salva" "$COUNTRYHAVP" "$C_SYSTEM/ClamAV/CountryMirror"
		$C_ZT_BIN_DIR/zt "Salva" "$NUMHAVP" "$C_SYSTEM/ClamAV/AutoUpdateInterval"
		if [ "$AUTOHAVP" == "on" ];then
			AUTOHAVP="yes"
		else
			AUTOHAVP="no"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$AUTOHAVP" "$C_SYSTEM/ClamAV/AutoUpdate"
		if [ "$IMGHAVP" == "on" ];then
			IMGHAVP="yes"
		else
			IMGHAVP="no"
		fi
		$C_ZT_BIN_DIR/zt "SetSquid" "$SETCACHE" "$SETCACHEMEM" "$SETCACHESWAPHIGH" "$SETCACHESWAPLOW" "$SETMAXIMUMOBJECTSIZE" "$SETMINIMUMOBJECTSIZE" "$SETMAXIMUMOBJECTSIZEINMEMORY"
		$C_ZT_BIN_DIR/zt "SetDansguardian" "$SETNAUGHT" "$SETFGM" "$SETLL" "$SETLEH"
		$C_ZT_BIN_DIR/zt "Salva" "$IMGHAVP" "$C_SYSTEM/ClamAV/CheckImages"
		$C_ZT_BIN_DIR/zt "Salva" "$LOGGINGHAVP" "$C_SYSTEM/havp/AccessLog"
		$C_ZT_BIN_DIR/zt "Salva" "$VIRUSSCAN" "$C_SYSTEM/ClamAV/VirusCheck"
		$C_ZT_BIN_DIR/zt "ConfClam" "$IMGHAVP" "$LOGGINGHAVP" "$VIRUSSCAN"
		for CONF in "SQUID" "SQ_LOG" "HAVP" "DANSGUARDIAN";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		$C_ZT_BIN_DIR/zt "Proxy" "$SQUID-$HAVP"
		sleep 3
		return_page "config.sh?SECTION=PROXY"
		exit
	fi
	if [ -n "$BLACK_LIST" ];then
		wait "600"
		if [ -n "$ADD_URL_BLACK" ];then
			ADD_URL_BLACK="$(echo "$ADD_URL_BLACK" | sed 's/%2F/\//g')"
			if [ "$ADD_URL_BLACK" != "*/*" ];then
				$C_ZT_BIN_DIR/zt "Aggiungi" "$ADD_URL_BLACK" "$C_SYSTEM/havp/BlackList.txt"
				$C_ZT_BIN_DIR/zt "RimuoviRiga" "\*\/\*" "$C_SYSTEM/havp/BlackList.txt"
			else
				$C_ZT_BIN_DIR/zt "Salva" "$ADD_URL_BLACK" "$C_SYSTEM/havp/BlackList.txt"
			fi
			NURL=$(cat $C_SYSTEM/havp/BlackList.N)
			NURL=$(($NURL+1))
			$C_ZT_BIN_DIR/zt "Salva" "$NURL" "$C_SYSTEM/havp/BlackList.N"
			if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
			fi
		fi
		if [ -n "$ACBLACK_LIST" ];then
			if [ "$AC_BLACKLIST" == "on" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_SYSTEM/havp/BlackList"
			else
				$C_ZT_BIN_DIR/zt "Salva" "no" "$C_SYSTEM/havp/BlackList"
			fi
			if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
			fi
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=BLACKLIST"
		exit
	fi
	if [ -n "$WHITE_LIST" ];then
		wait "600"
		if [ -n "$ADD_URL_WHITE" ];then
			ADD_URL_WHITE="$(echo "$ADD_URL_WHITE" | sed 's/%2F/\//g')"
			$C_ZT_BIN_DIR/zt "Aggiungi" "$ADD_URL_WHITE" "$C_SYSTEM/havp/WhiteList.txt"
			NURL=$(cat $C_SYSTEM/havp/WhiteList.N)
			NURL=$(($NURL+1))
			$C_ZT_BIN_DIR/zt "Salva" "$NURL" "$C_SYSTEM/havp/WhiteList.N"
			if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
			fi
		fi
		if [ -n "$ACWHITE_LIST" ];then
			if [ "$AC_WHITELIST" == "on" ];then
				$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_SYSTEM/havp/WhiteList"
			else
				$C_ZT_BIN_DIR/zt "Salva" "no" "$C_SYSTEM/havp/WhiteList"
			fi
			if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
				$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
			fi
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=WHITELIST"
		exit
	fi
	if [ -n "$REMOVE_BLACK" ];then
		wait "600"
		REMOVE_BLACK="$(echo "$REMOVE_BLACK")"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$REMOVE_BLACK" "$C_SYSTEM/havp/BlackList.txt"
		NURL=$(cat $C_SYSTEM/havp/BlackList.N)
		NURL=$(($NURL-1))
		$C_ZT_BIN_DIR/zt "Salva" "$NURL" "$C_SYSTEM/havp/BlackList.N"
		if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=BLACKLIST"
		exit
	fi
	if [ -n "$REMOVE_WHITE" ];then
		wait "600"
		REMOVE_WHITE="$(echo "$REMOVE_WHITE")"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$REMOVE_WHITE" "$C_SYSTEM/havp/WhiteList.txt"
		NURL=$(cat $C_SYSTEM/havp/WhiteList.N)
		NURL=$(($NURL-1))
		$C_ZT_BIN_DIR/zt "Salva" "$NURL" "$C_SYSTEM/havp/WhiteList.N"
		if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
			$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
		fi
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=WHITELIST"
		exit
	fi
	if [ -n "$UPDATE_CLAMAV" ];then
		wait "600"
		$C_ZT_BIN_DIR/zt "UpdateClamav"
		return_page "config.sh?SECTION=PROXY&SUB_SECTION=PROXY"
		exit
	fi
	if [ "$SUB_SECTION" == "RULES" ];then
		NUM_RULES=$(ls $C_SYSTEM/havp/redirects | wc -l | awk '{print $1}')
		if [ "$NUM_RULES" -gt "0" ];then
			N_RULE=1
			echo "<br>
			<table class=\"tabellain\" width=\"650\" border=\"1\">
			<tr>
			<td  class=\"intesta\" size=\"3\"  width=\"25\">N.</td>
			<td width=\"400\" class=\"intesta\">Rule</td>
			<td width=\"208\" class=\"intesta\">Action</td>
			<td  class=\"intesta\" size=\"3\"  width=\"25\">C</td></tr>"
			for RUL in $(ls $C_SYSTEM/havp/redirects );do
				IN=$(cat $C_SYSTEM/havp/redirects/$RUL/Interface)
				AC=$(cat $C_SYSTEM/havp/redirects/$RUL/Action)
				[ $(cat $C_SYSTEM/havp/redirects/$RUL/SourceIP) ] && SO="src: $(cat $C_SYSTEM/havp/redirects/$RUL/SourceIP)"
				[ $(cat $C_SYSTEM/havp/redirects/$RUL/DestinationIP) ] && DE="dst: $(cat /$C_SYSTEM/havp/redirects/$RUL/DestinationIP)"
				echo "<tr><td align=\"center\">$N_RULE</td><td align=\"center\">$IN $SO $DE</td><td align=\"center\">$AC
				</td><td align=\"center\"><form action=\"config.sh\" method=\"POST\">
				<input type=\"hidden\" name=\"REMOVE_RULE\" value=\"$RUL\">
				<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
				<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
				title=\"$L_DELETE\"
				onClick=\"javascript:return confirm('$L_ALERT_REMOVE Rule $N_RULE?');\"></form>
				</td></tr>"
				SO=""
				DE=""
				N_RULE=$(($N_RULE+1))
			done
			echo "</table><p>"
		fi
		echo "<br><font color=\"#0000FF\" size=\"3\">Add Capturing Rules</font><p>
		<form method=\"POST\" action=\"config.sh\">
		<table class=\"naked\" WIDTH=\"400\">
		<tr>
		<td width=\"50%\">Action: </td><td align=\"right\">
		<select name=\"ACTION_RULE\">
		<option value=\"Capture\">Capture Request</option>
		<option value=\"NotCapture\">Do not Capture Request</option>
		<option value=\"\" selected></option>
		</select>
		</td></tr><tr>
		<td width=\"50%\">Source Interface/VLAN: </td><td align=\"right\">
		<select name=\"SOURCE_INT\">"
		for INTERF in $(ls $C_SYSTEM/net/interfaces );do
			echo "<option value=\"$INTERF\">$INTERF</option>"
			if [ -d $C_SYSTEM/net/interfaces/$INTERF/VLAN ];then
				for INTV in $(ls $C_SYSTEM/net/interfaces/$INTERF/VLAN);do
					echo "<option value=\"$INTERF.$INTV\">$INTERF.$INTV</option>"
				done
			fi
		done
		echo "<option value=\"\" selected></option>
		</select>
		</td></tr>
		<tr><td width=\"50%\">Source IP: </td><td align=\"right\">
		<input type=\"text\" name=\"SOURCE_IP\" value=\"\">
		</td></tr>
		<tr><td width=\"50%\">Destination IP: </td><td align=\"right\">
		<input type=\"text\" name=\"DEST_IP\" value=\"\">
		</td>
		</tr>
		</table>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"submit\" name=\"CONF_RULES\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		./footer.sh
		exit
	fi
	if [[ -z  "$SUB_SECTION" ||  "$SUB_SECTION" == "PROXY" ]];then
		NUM_RULES=$(ls $C_SYSTEM/havp/redirects | wc -l | awk '{print $1}')
		if [ "$NUM_RULES" == 0 ];then
			echo "<br>&nbsp;<br><font color=\"red\" size=\"3\">$L_RULES_MISSING</font><p>"
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;<br>"
			./footer.sh
			exit
		fi
		if [ -n "$($C_ZT_BIN_DIR/zt "ControlActive" "havp")" ]; then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_HAVP" "on"
			C_HAVP="on"
		else
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_HAVP" ""
			C_HAVP=""
		fi
		if [ -n "$($C_ZT_BIN_DIR/zt "ControlActive" "squid")" ]; then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SQUID" "on"
			C_SQUID="on"
		else
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SQUID" ""
			C_SQUID=""
		fi
		echo "<form name=\"squid\" method=\"POST\" action=\"config.sh\">"
		if  [ -f $C_ZT_PROXY_DIR/sbin/squid ];then
			echo "<br><font color=\"#0000FF\" size=\"3\">Squid</font><p>
			<table class=\"naked\" WIDTH=\"400\">
			<tr>
			<td width=\"90%\">$L_ACTIVE: </td><td align=\"right\">"
			if [ "$C_SQUID" == "on" ];then
				echo "<input name=\"SQUID\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SQUID\" type=\"checkbox\">"
			fi
			echo "</td></tr>
			<tr><td>$L_SQUID_LOG: </td><td align=\"right\">"
			if [ "$C_SQ_LOG" == "on" ];then
				echo "<input name=\"SQ_LOG\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SQ_LOG\" type=\"checkbox\">";
			fi
			CACHE_MB=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^cache_dir' | awk '{print $4}')
			CACHE_MEM=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^cache_mem' | awk '{print $2}')
			CACHE_SWAP_HIGH=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^cache_swap_high' | awk '{print $2}')
			CACHE_SWAP_LOW=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^cache_swap_low' | awk '{print $2}')
			MAXIMUM_OBJECT_SIZE=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^maximum_object_size ' | awk '{print $2}')
			MINIMUM_OBJECT_SIZE=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^minimum_object_size' | awk '{print $2}')
			MAXIMUM_OBJECT_SIZE_IN_MEMORY=$(cat $C_ZT_PROXY_DIR/etc/squid/squid-only.conf | grep '^maximum_object_size_in_memory' | awk '{print $2}')
			echo "</td></tr>
			<tr><td>Cache (MB): </td><td align=\"right\">
			<input size=\"2\"  style=\"text-align: right; padding: 2px;\" type=\"text\" name=\"SETCACHE\" value=\"$CACHE_MB\">
			</td></tr>
			<tr><td>Cache Memory(MB): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETCACHEMEM\" value=\"$CACHE_MEM\">
			</td></tr>
			<tr><td>Cache swap high (%): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETCACHESWAPHIGH\" value=\"$CACHE_SWAP_HIGH\">
			</td></tr>
			<tr><td>Cache swap low (%): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETCACHESWAPLOW\" value=\"$CACHE_SWAP_LOW\">
			</td></tr>
			<tr><td>Maximum object size (MB): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETMAXIMUMOBJECTSIZE\" value=\"$MAXIMUM_OBJECT_SIZE\">
			</td></tr>
			<tr><td>Minimum object size (KB): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETMINIMUMOBJECTSIZE\" value=\"$MINIMUM_OBJECT_SIZE\">
			</td></tr>
			<tr><td>Maximum object size in memory (KB): </td><td align=\"right\">
			<input size=\"2\" style=\"text-align: right; padding: 2px;\" type=\"text\"  name=\"SETMAXIMUMOBJECTSIZEINMEMORY\" value=\"$MAXIMUM_OBJECT_SIZE_IN_MEMORY\">
			</td></tr>
			</table><p>
			<br><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		if [ -n "$($C_ZT_BIN_DIR/zt "ControlActive" "dansguardian")" ]; then
			DSACTIVE="<font color=\"blue\">$L_YES</font>"
		else
			DSACTIVE="<font color=\"blue\">$L_NO</font>"
		fi
		if   [ -f $C_ZT_PROXY_DIR/sbin/dansguardian ];then
			echo "<font color=\"blue\" size=\"3\">Dansguardian</font><p>
			<table class=\"naked\" WIDTH=\"400\">
			<tr>
			<td width=\"75%\">$L_ACTIVE: </td><td align=\"right\">$DSACTIVE</td></tr>
			<td>$L_ENABLED: </td><td align=\"right\">"
			if [ "$C_DANSGUARDIAN" == "on" ];then
				echo "<input name=\"DANSGUARDIAN\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"DANSGUARDIAN\" type=\"checkbox\">"
			fi
			echo "</td></tr>
			<tr><td>Filter level: </td><td align=\"right\">
			<select name=\"SETNAUGHT\">"
			VALNAUGHT=$(cat $C_ZT_PROXY_DIR/etc/dansguardian/dansguardianf1.conf | grep '^naughtynesslimit' | cut -d'=' -f2 | sed 's/ //g')
			for VN in $(seq 10 10 300);do
				if [ "$VN" != "$VALNAUGHT" ];then
					echo "<option value=\"$VN\">"$VN"</option>"
				fi
			done
			echo "<option value=\"$VALNAUGHT\" selected>$VALNAUGHT</option></select>
			</td></tr>
			<tr><td>Filter mode: </td><td align=\"right\">
			<select name=\"SETFGM\">"
			VALFGM=$(cat $C_ZT_PROXY_DIR/etc/dansguardian/dansguardianf1.conf | grep '^groupmode' | cut -d'=' -f2 | sed 's/ //g')
			for VF in "0" "1" "2";do
				if [ "$VF" != "$VALFGM" ];then
					[ "$VF" == "0" ] && VF1="Banned"
					[ "$VF" == "1" ] && VF1="Filtered"
					[ "$VF" == "2" ] && VF1="Unfiltered"
					echo "<option value=\"$VF\">"$VF1"</option>"
				fi
			done
			[ "$VALFGM" == "0" ] && VALFGM1="Banned"
			[ "$VALFGM" == "1" ] && VALFGM1="Filtered"
			[ "$VALFGM" == "2" ] && VALFGM1="Unfiltered"
			echo "<option value=\"$VALFGM\" selected>$VALFGM1</option></select>
			</td></tr>
			<tr><td>Log Level: </td><td align=\"right\">
			<select name=\"SETLL\">"
			VALLL=$(cat $C_ZT_PROXY_DIR/etc/dansguardian/dansguardian.conf | grep '^loglevel' | cut -d'=' -f2 | sed 's/ //g')
			for VLL in "0" "1" "2" "3";do
				if [ "$VLL" != "$VALLL" ];then
					[ "$VLL" == "0" ] && VLL1="None"
					[ "$VLL" == "1" ] && VLL1="Just denied"
					[ "$VLL" == "2" ] && VLL1="All text based"
					[ "$VLL" == "3" ] && VLL1="All requests"
					echo "<option value=\"$VLL\">"$VLL1"</option>"
				fi
			done
			[ "$VALLL" == "0" ] && VALLL1="None"
			[ "$VALLL" == "1" ] && VALLL1="Just denied"
			[ "$VALLL" == "2" ] && VALLL1="All text based"
			[ "$VALLL" == "3" ] && VALLL1="All requests"
			echo "<option value=\"$VALLL\" selected>$VALLL1</option></select>
			</td></tr>
			<tr><td>Log Exception Hits: </td><td align=\"right\">
			<select name=\"SETLEH\">"
			VALLEH=$(cat $C_ZT_PROXY_DIR/etc/dansguardian/dansguardian.conf | grep '^logexceptionhits' | cut -d'=' -f2 | sed 's/ //g')
			for VLEH in "0" "1" "2";do
				if [ "$VLEH" != "$VALLEH" ];then
					[ "$VLEH" == "0" ] && VLEH1="Never"
					[ "$VLEH" == "1" ] && VLEH1="Log exceptions"
					[ "$VLEH" == "2" ] && VLEH1="Always"
					echo "<option value=\"$VLEH\">"$VLEH1"</option>"
				fi
			done
			[ "$VALLEH" == "0" ] && VALLEH1="Never"
			[ "$VALLEH" == "1" ] && VALLEH1="Log exceptions"
			[ "$VALLEH" == "2" ] && VALLEH1="Always"
			echo "<option value=\"$VALLEH\" selected>$VALLEH1</option></select>

			</td></tr></table><p>
			<br><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		echo "<font color=\"#0000FF\" size=\"3\">HAVP - ClamAV</font><p>
		<table class=\"naked\" WIDTH=\"400\">
		<tr>
		<td width=\"75%\">$L_ACTIVE: </td><td align=\"right\">"
		if [ "$C_HAVP" == "on" ];then
			echo "<input name=\"HAVP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"HAVP\" type=\"checkbox\">"
		fi
		echo "</td></tr>
		<tr><td>$L_HAVP_LOGGING: </td><td align=\"right\">
		<select name=\"LOGGINGHAVP\">"
		VALLOG=$(cat /$C_SYSTEM/havp/AccessLog)
		if [ "$VALLOG" == "OnlyVirus" ];then
			echo "<option value=\"AnyAccess\">$L_ALL_ACCESS</option>
			<option value=\"OnlyVirus\" selected>$L_ONLY_VIRUS</option>"
		else
			echo "<option value=\"OnlyVirus\">$L_ONLY_VIRUS</option>
			<option value=\"AnyAccess\" selected>$L_ALL_ACCESS</option>"
		fi
		echo "</select></td></tr>
		<tr><td>Virus Scanning: </td><td align=\"right\">
		<select name=\"VIRUSSCAN\">"
		VALSCAN=$(cat $C_SYSTEM/ClamAV/VirusCheck)
		if [ "$VALSCAN" == "Enabled" ];then
			echo "<option value=\"Disabled\">$L_NO</option>
			<option value=\"Enabled\" selected>$L_YES</option>"
		else
			echo "<option value=\"Enabled\">$L_YES</option>
			<option value=\"Disabled\" selected>$L_NO</option>"
		fi
		echo "</select></td></tr>
		<tr><td>$L_HAVP_IMG: </td><td align=\"right\">"
		VALIMG=$(cat $C_SYSTEM/ClamAV/CheckImages)
		if [ "$VALIMG" == "yes" ];then
			echo "<input name=\"IMGHAVP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"IMGHAVP\" type=\"checkbox\">"
		fi
		echo "</td></tr>
		<tr><td>$L_HAVP_AUTOUPDATE: </td><td align=\"right\">"
		VALAU=$(cat $C_SYSTEM/ClamAV/AutoUpdate)
		if [ "$VALAU" == "yes" ];then
			echo "<input name=\"AUTOHAVP\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"AUTOHAVP\" type=\"checkbox\">"
		fi
		echo "</td>
		</tr><tr>
		<td>$L_HAVP_UPDATE_DAY: </td><td align=\"right\">
		<select name=\"NUMHAVP\">"
		VALNUM=$(cat $C_SYSTEM/ClamAV/AutoUpdateInterval)
		for NUM in "1" "2" "4" "6" "12" "24" "48";do
			if [ "$NUM" != "$VALNUM" ];then
				echo "<option value=\"$NUM\">$NUM</option>"
			fi
		done
		echo "<option value=\"$VALNUM\" selected>$VALNUM</option></select>
		</td></tr>"
		VALC=$(cat $C_SYSTEM/ClamAV/CountryMirror)
		VALCO=$(cat $C_ZT_CONF_DIR/country | grep $VALC | cut -d'>' -f2 | cut -d'<' -f1)
		echo "<tr>
		<td>$L_HAVP_UCOUNTRY: </td><td align=\"right\">
		<select name=\"COUNTRYHAVP\">"
		cat $C_ZT_CONF_DIR/country
		echo "<option value=\"$VALC\" selected>$VALCO</option>
		</select>
		</td>
		</tr>
		</table><p>"
		if [ -z "$($C_ZT_BIN_DIR/zt "ControlActive" "havp")" ]; then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		fi
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"submit\" name=\"CONF_PROXY\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		if [ -n "$($C_ZT_BIN_DIR/zt "ControlActive" "havp")" ]; then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_HAVP" "on"
			C_HAVP="on"
			CONFIG=$C_SYSTEM/ClamAV
			if ! [ -f $CONFIG/WR/LastUpdate ] ; then
				echo "<font color=\"red\">Clamav - Warning: Virus signatures not updated</font>"
			else
				if [ -f $CONFIG/WR/UpdateError ] ; then
					echo "<font color=\"red\"> Clamav - Check Failed. Last update on `cat $CONFIG/WR/LastUpdate`</font>"
				else
					echo "<font color=\"blue\">Clamav - Last update on `cat $CONFIG/WR/LastUpdate`</font>"
				fi
			fi
			echo "<p><form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
			<input type=\"submit\" name=\"UPDATE_CLAMAV\" class=\"bottone\" value=\"$L_MODIFY\"></form>"
		fi
		echo "<br>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "WHITELIST" ];then
		echo "<form method=\"POST\" action=\"config.sh\"><p>
		$L_ACTIVE_SERVICE:&nbsp;"
		if [ "$(cat $C_SYSTEM/havp/WhiteList)" == "no" ];then
			echo "<input name=\"AC_WHITELIST\" type=\"checkbox\">"
		else
			echo "<input name=\"AC_WHITELIST\" type=\"checkbox\" checked=\"checked\">"
		fi
		echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"hidden\" name=\"ACWHITE_LIST\" value=\"yes\">
		<input type=\"submit\" name=\"WHITE_LIST\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		if [ "$(cat $C_SYSTEM/havp/WhiteList)" == "yes" ];then
			NUM_WHITE=$(cat $C_SYSTEM/havp/WhiteList.txt | wc -l)
			if [ "$NUM_WHITE" -gt "0" ];then
				N_B=1
				echo "<br><table class=\"tabellain\" width=\"650\" border=\"1\">
				<tr>
				<td class=\"intesta\" size=\"3\" width=\"25px\">N.</td>
				<td class=\"intesta\">White List</td>
				<td class=\"intesta\" size=\"3\" width=\"25px\">C</td></tr>"
				for WHITE in $(cat $C_SYSTEM/havp/WhiteList.txt );do
					echo "<tr><td align=\"center\">$N_B</td><td align=\"center\">$WHITE
					</td><td align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"REMOVE_WHITE\" value=\"$N_B\">
					<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
					<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
					title=\"$L_DELETE\"
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE $WHITE?');\"></form>
					</td></tr>"
					N_B=$(($N_B+1))
				done
				echo "</table><p>"
			fi
			echo "<form method=\"POST\" action=\"config.sh\"><p>
			<table class=\"naked\" WIDTH=\"400\">
			<tr>
			<td>$L_SQUID_ADD_WHITE:</td><td align=\"right\">
			<input type=\"text\" name=\"ADD_URL_WHITE\" value=\"\">
			</td>
			</tr></table><p>
			<img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
			<input type=\"submit\" name=\"WHITE_LIST\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "BLACKLIST" ];then
		echo "<form method=\"POST\" action=\"config.sh\"><p>
		$L_ACTIVE_SERVICE:&nbsp;"
		if [ "$(cat $C_SYSTEM/havp/BlackList)" == "no" ];then
			echo "<input name=\"AC_BLACKLIST\" type=\"checkbox\">"
		else
			echo "<input name=\"AC_BLACKLIST\" type=\"checkbox\" checked=\"checked\">"
		fi
		echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
		<input type=\"hidden\" name=\"ACBLACK_LIST\" value=\"yes\">
		<input type=\"submit\" name=\"BLACK_LIST\" class=\"bottone\" value=\"$L_SAVE\"></form>
		<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		if [ "$(cat $C_SYSTEM/havp/BlackList)" == "yes" ];then
			NUM_BLACK=$(cat $C_SYSTEM/havp/BlackList.txt | wc -l)
			echo "($L_ALL = */*)"
			if [ "$NUM_BLACK" -gt "0" ];then
				N_B=1
				echo "<br><table class=\"tabellain\" width=\"650\" border=\"1\">
				<tr>
				<td class=\"intesta\" size=\"3\" width=\"25px\">N.</td>
				<td class=\"intesta\">Black List</td>
				<td class=\"intesta\" size=\"3\" width=\"25px\">C</td></tr>"
				if [ "$(cat $C_SYSTEM/havp/BlackList.txt )" != "*/*" ];then
					for BLACK in $(cat $C_SYSTEM/havp/BlackList.txt );do
						echo "<tr><td align=\"center\">$N_B</td><td align=\"center\">$BLACK
						</td><td align=\"center\"><form action=\"config.sh\" method=\"POST\">
						<input type=\"hidden\" name=\"REMOVE_BLACK\" value=\"$N_B\">
						<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
						<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
						title=\"$L_DELETE\"
						onClick=\"javascript:return confirm('$L_ALERT_REMOVE $BLACK?');\"></form>
						</td></tr>"
						N_B=$(($N_B+1))
					done
			else
					echo "<tr><td align=\"center\">$N_B</td><td align=\"center\">*/*
					</td><td align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"REMOVE_BLACK\" value=\"$N_B\">
					<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
					<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
					title=\"$L_DELETE\"
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE $BLACK?');\"></form>
					</td></tr>"
				fi
				echo "</table><p>"
			fi
			echo "<form method=\"POST\" action=\"config.sh\"><p>
			<table class=\"naked\" WIDTH=\"400\">
			<tr>
			<td>$L_SQUID_ADD_BLACK:</td><td align=\"right\">
			<input type=\"text\" name=\"ADD_URL_BLACK\" value=\"\">
			</td>
			</tr></table><p>
			<img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"PROXY\">
			<input type=\"submit\" name=\"BLACK_LIST\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		fi
		./footer.shBLOCKER
		exit
	fi
fi
if [ "$SECTION" == "BLOCKER" ];then
	echo "<font color=\"blue\" size=\"3\">Blocker</font><br>&nbsp;<br>"
	echo "<table width=\"410\" ><tr>
		<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FAIL2BAN\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"fail2ban\"></form></td>
		<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"SIB\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"SIB\"></form></td>
		<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"ADB\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"AD Blocker\"></form></td>
		</tr></table><br>"	
	
	if [ -n "$DEL_BAN_IP" ];then
		wait "650"
		RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${DEL_BAN_IP}p")"
		IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
		$C_ZT_BIN_DIR/zt "RimuoviLogBan" "$IP"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$DEL_BAN_IP" "$C_ZT_CONF_DIR/ipbanned"
		$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$IP"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=SIB"
		exit
	fi
	if [ -n "$FREE_BAN_IP" ];then
		wait "650"
		RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${FREE_BAN_IP}p")"
		$C_ZT_BIN_DIR/zt "RimuoviLogBan" "$IP"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$FREE_BAN_IP" "$C_ZT_CONF_DIR/ipbanned"
		IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
		$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$IP"
		if [ "$C_FORM_DATE" == "ita" ];then
			DATA_TODAY=$(date  "+%d/%m/%Y %T")
		else
			DATA_TODAY=$(date "+%Y/%m/%d %T")
		fi
		$C_ZT_BIN_DIR/zt "Aggiungi" "$IP # Free # $DATA_TODAY" "$C_ZT_CONF_DIR/ipfree"
		return_page "config.sh?SECTION=BLOCKERSUB_SECTION=SIB"
		exit
	fi
	if [ -n "$BAN_FREE_IP" ];then
		wait "650"
		RIGA="$(cat $C_ZT_CONF_DIR/ipfree | sed -n "${BAN_FREE_IP}p")"
		IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
		$C_ZT_BIN_DIR/zt "RimuoviLogBan" "$IP"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$BAN_FREE_IP" "$C_ZT_CONF_DIR/ipfree"
		$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$IP" "BAN"
		if [ "$C_FORM_DATE" == "ita" ];then
			DATA_TODAY=$(date  "+%d/%m/%Y %T")
		else
			DATA_TODAY=$(date "+%Y/%m/%d %T")
		fi
		$C_ZT_BIN_DIR/zt "Aggiungi" "$IP # Blocked # $DATA_TODAY" "$C_ZT_CONF_DIR/ipbanned"
		return_page "config.sh?SECTION=BLOCKERSUB_SECTION=SIB"
		exit
	fi
	if [ -n "$BAN_IP_ERROR" ];then
		wait "650"
		RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${BAN_IP_ERROR}p")"
		IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
		$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$IP" "BAN"
		return_page "config.sh?SECTION=BLOCKERSUB_SECTION=SIB"
		exit
	fi
	if [ -n "$DEL_FREE_IP" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "$DEL_FREE_IP" "$C_ZT_CONF_DIR/ipfree"
		return_page "config.sh?SECTION=BLOCKERSUB_SECTION=SIB"
		exit
	fi
	if [ -n "$DELETE_CP_BLOCKED" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_LOG_DIR/controllogin/control"
		return_page "config.sh?SECTION=BLOCKERSUB_SECTION=SIB"
		exit
	fi
	if [ -n "$CONF_BLOCKED" ];then
		wait "650"
		for CONF in "IPBLOCKED" "NUM_FAIL";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		if [ -z "$IPBLOCKED" ];then
			NUM_BAN=$(cat $C_ZT_CONF_DIR/ipbanned | wc -l | awk '{print $1}')
			if [ "$NUM_BAN" -gt "0" ];then
				for N in $(seq 1 $NUM_BAN);do
					RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${N}p")"
					IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
					$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$IP"
				done
			fi
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/ipbanned"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/ipfree"
			$C_ZT_BIN_DIR/zt "CreaFile" "$C_ZT_CONF_DIR/ipbanned"
			$C_ZT_BIN_DIR/zt "CreaFile" "$C_ZT_CONF_DIR/ipfree"
		fi
		if [[ -n "$NEW_IP" && -n  "$IPBLOCKED" ]];then
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_TODAY=$(date  "+%d/%m/%Y %T")
			else
				DATA_TODAY=$(date "+%Y/%m/%d %T")
			fi
			if [ "$RULE_IP" == "FREE" ];then
				$C_ZT_BIN_DIR/zt "Aggiungi" "$NEW_IP # $INFO_IP # $DATA_TODAY" "$C_ZT_CONF_DIR/ipfree"
				$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "100000" "$C_ZT_CONF_DIR/ipfree"
				$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$NEW_IP"
			else
				$C_ZT_BIN_DIR/zt "Aggiungi" "$NEW_IP # $INFO_IP # $DATA_TODAY" "$C_ZT_CONF_DIR/ipbanned"
				$C_ZT_BIN_DIR/zt "RimuoviNumRiga" "100000" "$C_ZT_CONF_DIR/ipbanned"
				$C_ZT_BIN_DIR/zt "IpTablesIPBan" "$NEW_IP" "BAN"
			fi
		fi
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=SIB"
		exit
	fi
	if [ -n "$ACTIVE_F2B" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FAIL2BAN" "$FAIL2BAN"
		$C_ZT_BIN_DIR/zt  "ActiveF2B" "$FAIL2BAN"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=FAIL2BAN"
		exit
	fi
	if [ -n "$DEL_IPF2B" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt  "DEL_IPF2B" "$DEL_IPF2B"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=FAIL2BAN"
		exit
	fi
	if [ -n "$ADD_IPF2B" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt  "ADD_IPF2B" "$ADD_IPF2B"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=FAIL2BAN"
		exit
	fi
	if [ -n "$CONF_F2B" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt  "ConfigF2B" "$NUM_MAXRETRY-$NUM_BANTIME-$NUM_FINDTIME-$SSHJ-$ASTERISKJ-$ZTJ"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=FAIL2BAN"
		exit
	fi
	if [ -n "$JAILCONF" ];then
		echo "<form action=\"config.sh\" method=\"POST\">
		<p>jail.conf<br><textarea name=\"CONF_JAIL\" rows=\"20\" cols=\"80\">$(cat /DB/apache2/cgi-bin/zerotruth/bin/fail2ban/config/jail.conf)</textarea><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<input type=\"hidden\" name=\"JAILCONF\" value=\"yes\">
		<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKED\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FAIL2BAN\">
		<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
		./footer.sh
		exit
	fi
	if [ -n "$FAILCONF" ];then
		echo "<form action=\"config.sh\" method=\"POST\">
		<p>fail2ban.conf<br><textarea name=\"CONF_FAIL2BAN\" rows=\"20\" cols=\"80\">$(cat /DB/apache2/cgi-bin/zerotruth/bin/fail2ban/config/fail2ban.conf)</textarea><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"FAILCONF\" value=\"yes\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<input type=\"submit\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"FAIL2BAN\">
		<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;"
		./footer.sh
		exit
	fi
	if [ -n "$CONF_AD" ];then
		wait "650"
		for CONF in "ACTIVE_AD" "TIME_AD";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		[[ -z "$TIME_AD" || -z "$ACTIVE_AD" ]] && TIME_AD=""
		$C_ZT_BIN_DIR/zt "CronAD" "$TIME_AD"
		$C_ZT_BIN_DIR/zt "RestartCron"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=ADB"
		exit
	fi
	if [ -n "$CONF_AD_NOW" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "UpdateBlockHosts"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=ADB"
		exit
	fi
	if [ -n "$DEL_MAC_LOGIN" ];then
		wait "650"
		MACN="${DEL_MAC_LOGIN:0:2}:${DEL_MAC_LOGIN:2:2}:${DEL_MAC_LOGIN:4:2}:${DEL_MAC_LOGIN:6:2}:${DEL_MAC_LOGIN:8:2}:${DEL_MAC_LOGIN:10:2}"
		$C_ZT_BIN_DIR/zt "Esegui" "$C_ZT_SCRIPTS_DIR/unblocklogin.sh" "$MACN"
		return_page "config.sh?SECTION=BLOCKER&SUB_SECTION=SIB"
		exit
	fi
	if [ -n "$C_WAIT_LOGIN_TIME" ];then
		echo "<p><font color=\"blue\" size=\"3\">CP Login Blocker</font><p>"
		echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
		<tr>
		<td width=\"20\" class=\"intesta\">N.</td>
		<td width=\"140\" class=\"intesta\">MAC</td>
		<td width=\"140\" class=\"intesta\">$L_ATTEMPTS</td>
		<td width=\"80\" class=\"intesta\">Username</td>
		<td width=\"50\" class=\"intesta\">$L_EXPIRY</td></td>
		<td width=\"50\" class=\"intesta\">C. D.</td></td>
		<td width=\"15\" class=\"intesta\">S</td></tr>"
		if [ -n "$(cat $C_ZT_LOG_DIR/controllogin/control)" ];then
			NRIGHE="$(cat $C_ZT_LOG_DIR/controllogin/control | wc -l | awk '{print $1}')"
			for N in $(seq 1 $NRIGHE);do
				BG="$C_BG"
				[ $(expr $N % 2 ) -eq 0 ] && BG="$C_BG1"
				RIGA="$(cat $C_ZT_LOG_DIR/controllogin/control | sed -n "${N}p")"
				MAC="$(echo "$RIGA" | awk '{print $1}')"
				MACN="${MAC:0:2}:${MAC:2:2}:${MAC:4:2}:${MAC:6:2}:${MAC:8:2}:${MAC:10:2}"
				NE="$(echo "$RIGA" |  awk '{print $2}')"
				UN="$(echo "$RIGA" |  awk '{print $3}')"
				if [ -d $C_CRON_SCRIPTS_DIR/ZT${MAC}-Cron ];then
					TDH="$(cat $C_CRON_SCRIPTS_DIR/ZT${MAC}-Cron/cron/Hour)"
					[ $TDH -lt 10 ] && TDH="0$TDH"
					TDM="$(cat $C_CRON_SCRIPTS_DIR/ZT${MAC}-Cron/cron/Minute)"
					[ $TDM -lt 10 ] && TDM="0$TDM"
					TD="$TDH:$TDM"
					CDAY="$(cat $C_CRON_SCRIPTS_DIR/ZT${MAC}-Cron/cron/DoM)"
					CMONTH="$(cat $C_CRON_SCRIPTS_DIR/ZT${MAC}-Cron/cron/Month)"
					CYEAR="$(date +%Y)"
					CSEC="$(date -d  "$CYEAR-$CMONTH-$CDAY $TDH:$TDM:00" "+%s")"
				else
					CSEC=""
					TD="&nbsp;"
				fi
				echo "<tr BGCOLOR=\"$BG\">
				<td align=\"center\">$N</td>
				<td>&nbsp;$MACN</td>
				<td align=\"center\">$NE</td>
				<td>&nbsp;$UN</td>
				<td align=\"center\">$TD</td>
				<td align=\"center\">"
				if [ -n "$CSEC" ];then
					NOW="$(date +%s)"
					SEC_WAIT="$(($CSEC-$NOW))"
					echo "<span id=\"countdown${N}\" class=\"timer\"></span>
					<script>
					var seconds${N} = \"$SEC_WAIT\";
					function secondPassed${N}() {
						var minutes${N} = Math.round((seconds${N} - 30)/60);
						var remainingSeconds${N} = seconds${N} % 60;
						if (remainingSeconds${N} < 10) {
							remainingSeconds${N} = \"0\" + remainingSeconds${N};
						}
						document.getElementById('countdown${N}').innerHTML = minutes${N} + \":\" + remainingSeconds${N};
						if (seconds${N} == 0) {
							window.location = \"config.sh?SECTION=BLOCKER&DEL_MAC_LOGIN=${MAC}\"
						} else {
							seconds${N}--;
						}
					}
					var countdownTimer${N} = setInterval('secondPassed${N}()', 1000);
					</script>"
				else
					echo "&nbsp;"
				fi
				echo "</td>
				<td width=\"20px\" align=\"center\">
				<a href=\"config.sh?SECTION=BLOCKER&DEL_MAC_LOGIN=$MAC\">
				<img src=\"/images/action_x.png\" onClick=\"javascript:return confirm('$L_ALERT_REMOVE $MACN?');\"></a></td></tr>"
			done
		fi
		echo "</table><br>
		<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"SIB\">
		<input type=\"submit\" name=\"DELETE_CP_BLOCKED\" class=\"bottone\" value=\"$L_DELETE\"
		onClick=\"javascript:return confirm('$L_ALERT_REMOVE?');\"></form><br>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><br>"
	fi
	if [[ "$SUB_SECTION" == "FAIL2BAN" || -z "$SUB_SECTION" ]];then
		echo "<font color=\"blue\" size=\"3\">Fail2ban</font><p>"
		if [ ! -f  /opt/python/bin/python3 ];then
			echo "<font color=\"red\">$L_PYTHON_MISSING</font><br>&nbsp;<br>"
			CFB=""
			CPY="NO"
		fi
		
		if [ -z "$CPY" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			$L_ACTIVE_SERVICE:&nbsp;"
			if [ "$($C_ZT_BIN_DIR/zt  ControlF2B)" == "YES" ];then
				CFB="YES"
				echo "<input name=\"FAIL2BAN\" type=\"checkbox\" checked=\"checked\">"
			else
				CFB=""
				echo "<input name=\"FAIL2BAN\" type=\"checkbox\">"
			fi
			echo "<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<p><input type=\"submit\" name=\"ACTIVE_F2B\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		fi
		if [ -n "$CFB" ];then
			MAXRETRY="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep  '^maxretry' | awk '{print $NF}' | sed -n '1p')"
			BANTIME="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep  '^bantime' | awk '{print $NF}' | sed -n '1p')"
			FINDTIME="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep  '^findtime' | awk '{print $NF}' | sed -n '1p')"
			[ -f /opt/asterisk/var/log/asterisk/messages ] && CONTROLAST="YES"
			echo "<form method=\"POST\" action=\"config.sh\">"
			echo "<table><tr>
			<td>$L_ATTEMPTS: <select name=\"NUM_MAXRETRY\">"
			for MR in $(seq 2 25);do
				if [ "$MAXRETRY" != "$MR" ];then
					echo "<option value=\"$MR\">$MR</option>"
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$MAXRETRY\" selected>$MAXRETRY</option></select</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td>Bantime sec.: <select name=\"NUM_BANTIME\">"
			for BT in $(seq 600 600 85800);do
				if [ "$BANTIME" != "$BT" ];then
					echo "<option value=\"$BT\">$BT</option>"
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$BANTIME\" selected>$BANTIME</option></select</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td>Findtime sec.: <select name=\"NUM_FINDTIME\">"
			for FT in $(seq 600 600 85800);do
				if [ "$FINDTIME" != "$FT" ];then
					echo "<option value=\"$FT\">$FT</option>"
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$FINDTIME\" selected>$FINDTIME</option></select </td>
			</tr></table>"
			echo "<br><table><tr><td>
			ssh:&nbsp;"
			SSHDACT="$( $C_ZT_BIN_DIR/zt "StatusF2B" | grep 'sshd')"
			if [ -n "$SSHDACT" ];then
				echo "<input name=\"SSHJ\" type=\"checkbox\" checked=\"checked\">"
			else
				CFB=""
				echo "<input name=\"SSHJ\" type=\"checkbox\">"
			fi
			echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>"
			if [ -n "$CONTROLAST" ];then
				ASTERISKACT="$( $C_ZT_BIN_DIR/zt "StatusF2B" | grep 'asterisk')"
				echo "<td>Asterisk:&nbsp;"
				if [ -n "$ASTERISKACT" ];then
					echo "<input name=\"ASTERISKJ\" type=\"checkbox\" checked=\"checked\">"
				else
					CFB=""
					echo "<input name=\"ASTERISKJ\" type=\"checkbox\">"
				fi
				echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>"
				AST="asterisk"
			fi
			ZTACT="$( $C_ZT_BIN_DIR/zt "StatusF2B" | grep 'Zerotruth-login')"
			echo "<td>Zerotruth-login:&nbsp;"
			if [ -n "$ZTACT" ];then
				echo "<input name=\"ZTJ\" type=\"checkbox\" checked=\"checked\">"
			else
				CFB=""
				echo "<input name=\"ZTJ\" type=\"checkbox\">"
			fi
			echo "</td></table>"
			echo "<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<p><input type=\"submit\" name=\"CONF_F2B\" class=\"bottone\" value=\"$L_SAVE\"></form>"
			echo "<table width=\"800\" ><tr>
			<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<input type=\"hidden\" name=\"FAILCONF\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"fail2ban.conf\"></form></td>
			<td align=\"center\"><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<input type=\"hidden\" name=\"JAILCONF\" value=\"yes\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"jail.conf\"></form></td>
			<td align=\"right\"><form method=\"POST\" action=\"config.sh\">
			$L_ADDIPF2B: <input type=\"text\" name=\"ADD_IPF2B\" value=\"\"></td>
			<td>&nbsp;&nbsp;<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<input type=\"submit\"  class=\"bottone\" value=\"$L_SAVE\"></form></td>
			</tr></table><br>"
			FREEIPF2B="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep '^ignoreip' | cut -d'=' -f2 | sed 's/ //g' | sed 's/127.0.0.1\/8//g' | sed 's/^,//g' )"
			if [ -n "$FREEIPF2B" ];then
				FREEIPF2B="$(echo "$FREEIPF2B" | sed 's/,/ /g')"
				NFREE="$(echo "$FREEIPF2B" | wc -w)"
				if [ "$NFREE" -gt 1 ];then
					WD=450
				else
					WD=225
				fi
				echo "<font color=\"blue\">$L_FREE</font>"
				echo "<table class=\"tabellain\" width=\"$WD\" border=\"1\">
				<tr>
				<td width=\"20\" class=\"intesta\">N.</td>
				<td width=\"150\" class=\"intesta\">IP</td>
				<td width=\"15\" class=\"intesta\">S.</td>"
				if [ "$NFREE" -gt 1 ];then
					echo "<td>&nbsp;&nbsp;</td>
					<td width=\"20\" class=\"intesta\">N.</td>
					<td width=\"150\" class=\"intesta\">IP</td>
					<td width=\"15\" class=\"intesta\">S.</td>"
				fi
				echo "</tr>"
				R=0
				M=0
				for N in $(seq 1 $NFREE);do
					R=$(($R+1))
					M=$(($M+$R))
					BG="$C_BG"
					[ $(expr $M % 2 ) -eq 0 ] && BG="$C_BG1"
					IP="$(echo "$FREEIPF2B" |  cut -d' ' -f$N)"
					if [ "$R" == 1 ];then
						echo "<tr BGCOLOR=\"$BG\">"
					fi
					echo "<td align=\"center\">$N</td>
					<td>$IP</td>
					<td width=\"20px\" align=\"center\">
					<a href=\"config.sh?SECTION=BLOCKER&DEL_IPF2B=$IP\"><img src=\"/images/action_x.png\" onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IP?');\"></a></td></td>"
					if [[ "$R" == 1 && "$NFREE" -gt 1 ]];then
						echo "<td>&nbsp;&nbsp;</td>"
					else
						if [ "$R" == 2 ];then
							echo "</tr>"
							R=0
						fi
					fi
				done
				echo "</table><br>"
			fi
			echo "<table class=\"tabellain\" width=\"750\" border=\"1\">
			<tr>
			<td width=\"150\" class=\"intesta\">Jail</td>
			<td width=\"150\" class=\"intesta\">Currently failed</td>
			<td width=\"150\" class=\"intesta\">Total failed</td>
			<td width=\"150\" class=\"intesta\">Total banned</td>
			<td width=\"150\" class=\"intesta\">Currently banned</td></tr>"
			N=0
			for PR in "sshd" "Zerotruth-login" "$AST";do
				if [ -n "$PR" ];then
					STATUS="$($C_ZT_BIN_DIR/zt  "StatusF2BP" "$PR")"
					BG="$C_BG"
					N=$(($N+1))
					[ $(expr $N % 2 ) -eq 0 ] && BG="$C_BG1"
					echo "<tr BGCOLOR=\"$BG\">
					<td align=\"center\">$PR</td>
					<td align=\"center\">$(echo $STATUS | cut -d'-' -f1)</td>
					<td align=\"center\">$(echo $STATUS | cut -d'-' -f2)</td>
					<td align=\"center\">$(echo $STATUS | cut -d'-' -f3)</td>
					<td align=\"center\">$(echo $STATUS | cut -d'-' -f3)</td>
					</td></tr>"
				fi
			done
			echo "</table><br>"
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "SIB" ];then
		echo "<font color=\"blue\" size=\"3\">Simple IP Blocker</font><p>"
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_SERVICE:&nbsp;"
		if [ "$C_IPBLOCKED" == "on" ];then
			echo "<input name=\"IPBLOCKED\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"IPBLOCKED\" type=\"checkbox\">"
		fi
		echo "&nbsp;&nbsp;&nbsp;&nbsp;$L_ATTEMPTS:&nbsp;
		<select name=\"NUM_FAIL\">"
		for TENT in $(seq 2 20);do
			if [ "$C_NUM_FAIL" != "$TENT" ];then
				echo "<option value=\"$TENT\">$TENT</option>"
			fi
		done
		echo "<option value=\"\"></option>
		<option value=\"$C_NUM_FAIL\" selected>$C_NUM_FAIL</option></select><br>"
		if [[ -n "$C_IPBLOCKED" && -n "$C_NUM_FAIL" ]];then
			echo "<br>$L_ADDIP: <input type=\"text\" name=\"NEW_IP\" value=\"\">&nbsp;&nbsp;
			$L_INFO: <input type=\"text\" name=\"INFO_IP\" value=\"\">&nbsp;&nbsp;
			$L_RULE: <select name=\"RULE_IP\">
			<option value=\"FREE\">$L_TRUSTY</option>
			<option value=\"BLOCKED\" selected>$L_BLOCKED</option></select>"
			echo "<br>&nbsp;<br>"
		fi
		echo "<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<p><input type=\"submit\" name=\"CONF_BLOCKED\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
		if ! [ -f $C_ZT_CONF_DIR/ipbanned ];then
			$C_ZT_BIN_DIR/zt "CreaFile" "$C_ZT_CONF_DIR/ipbanned"
		fi
		if ! [ -f $C_ZT_CONF_DIR/ipfree ];then
			$C_ZT_BIN_DIR/zt "CreaFile" "$C_ZT_CONF_DIR/ipfree"
		fi
		if [[ -n "$C_IPBLOCKED" && -n "$C_NUM_FAIL" ]];then
			NUM_BAN=$(cat $C_ZT_CONF_DIR/ipbanned | wc -l | awk '{print $1}')
			if [ "$NUM_BAN" -gt "0" ];then
				$C_ZT_BIN_DIR/zt "ControlBan"
				echo "<font color=\"blue\">$L_BLOCK</font>"
				echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
				<tr>
				<td width=\"20\" class=\"intesta\">N.</td>
				<td width=\"150\" class=\"intesta\">IP</td>
				<td width=\"150\" class=\"intesta\">$L_INFO</td>
				<td width=\"150\" class=\"intesta\">$L_DATE</td>
				<td width=\"15\" class=\"intesta\">D.</td>
				<td width=\"15\" class=\"intesta\">S.</td></tr>"
				for N in $(seq 1 $NUM_BAN);do
					BG="$C_BG"
					[ $(expr $N % 2 ) -eq 0 ] && BG="$C_BG1"
					RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${N}p")"
					IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
					INFO="$(echo "$RIGA" | cut -d'#' -f2)"
					DATA="$(echo "$RIGA" | cut -d'#' -f3)"
					echo "<tr BGCOLOR=\"$BG\">
					<td align=\"center\">$N</td>
					<td>$IP</td>
					<td>$INFO</td>
					<td align=\"center\">$DATA</td>
					<td width=\"20px\" align=\"center\">
					<a href=\"config.sh?SECTION=BLOCKER&DEL_BAN_IP=$N\"><img src=\"/images/action_x.png\" onClick=\"javascript:return confirm('$L_ALERT_UNLOCK $IP?');\"></a></td>
					<td width=\"20px\" align=\"center\">
					<a href=\"config.sh?SECTION=BLOCKER&FREE_BAN_IP=$N\"><img src=\"/images/lock.png\" onClick=\"javascript:return confirm('$L_ALERT_UNLOCK $IP?');\"></a></td>
					</td></tr>"
				done
				echo "</table><br>"
			fi
			NUM_FREE=$(cat $C_ZT_CONF_DIR/ipfree | wc -l | awk '{print $1}')
			if [ "$NUM_FREE" -gt "0" ];then
				echo "<font color=\"blue\">$L_TRUST</font>"
				echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
				<tr>
				<td width=\"20\" class=\"intesta\">N.</td>
				<td width=\"150\" class=\"intesta\">IP</td>
				<td width=\"150\" class=\"intesta\">$L_INFO</td>
				<td width=\"150\" class=\"intesta\">$L_DATE</td>
				<td width=\"15\" class=\"intesta\">D.</td>
				<td width=\"15\" class=\"intesta\">S.</td></tr>"
				for N in $(seq 1 $NUM_FREE);do
					BG="$C_BG"
					[ $(expr $N % 2 ) -eq 0 ] && BG="$C_BG1"
					RIGA="$(cat $C_ZT_CONF_DIR/ipfree | sed -n "${N}p")"
					IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
					INFO="$(echo "$RIGA" | cut -d'#' -f2)"
					DATA="$(echo "$RIGA" | cut -d'#' -f3)"
					echo "<tr BGCOLOR=\"$BG\">
					<td align=\"center\">$N</td>
					<td>$IP</td>
					<td>$INFO</td>
					<td align=\"center\">$DATA</td>
					<td width=\"20px\" align=\"center\">
					<a href=\"config.sh?SECTION=BLOCKER&DEL_FREE_IP=$N\"><img src=\"/images/action_x.png\" onClick=\"javascript:return confirm('$L_ALERT_REMOVE $IP?');\"></a></td>
					<td width=\"20px\" align=\"center\">
					<a href=\"config.sh?SECTION=BLOCKER&BAN_FREE_IP=$N\"><img src=\"/images/unlock.png\" onClick=\"javascript:return confirm('$L_ALERT_LOCKED $IP?');\"></a></td>
					</tr>"
				done
				echo "</table><br>"
			fi
		fi
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "ADB" ];then
		echo "<font color=\"blue\" size=\"3\">Ad Blocker</font><br>"
		if [ -n "$C_UPDATES_AD" ];then
			if [ "$C_FORM_DATE" == "ita" ];then
				DATE_UP=$(date -d  "1970-01-01 $C_UPDATES_AD sec" "+%d-%m-%Y %T")
			else
				DATE_UP=$(date -d  "1970-01-01 $C_UPDATES_AD sec" "+%Y-%m-%d %T")
			fi
			echo "<p><font color=\"#0000FF\" size=\"3\">$L_UPDATED: $DATE_UP $HOUR_UP&nbsp;&nbsp;
			<a href=\"javascript:ShowHosts()\">($L_HOSTS_LIST)</a>
			</font><p>"
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		$L_ACTIVE_SERVICE:&nbsp;"
		if [ "$C_ACTIVE_AD" == "on" ];then
			echo "<input name=\"ACTIVE_AD\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"ACTIVE_AD\" type=\"checkbox\">"
		fi
		echo "<p>$L_UPDATES_EVERY:&nbsp;
		<select name=\"TIME_AD\">"
		for TAD in "1 $L_DAY" "2 $L_WEEK" "3 $L_MONTH";do
			set -- $TAD
			if [ "$C_TIME_AD" != $1 ] || [ -z "$C_TIME_AD" ];then
				echo "<option value=\"$1\">$2</option>"
			else
				C_TIMEN_AD=$1
				C_TIME_AD=$2
			fi
		done
		echo "<option value=\"\"></option>
		<option value=\"$C_TIMEN_AD\" selected>$C_TIME_AD</option></select><br>
		<p><input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<input type=\"submit\" name=\"CONF_AD\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>"
		if [ -n "$C_ACTIVE_AD" ];then
			echo "<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\" name=\"CONF_AD_NOW\" class=\"bottonelineadue\" value=\"$L_UPDATE_NOW\"></form>"
		else
			echo "<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BLOCKER\">
			<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
			<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_UPDATE_NOW\"></form>"
		fi
		echo "<br>&nbsp;<br>"
		./footer.sh
		exit
	fi
fi
if [ "$SECTION" == "SHAPER" ];then
	$C_ZT_BIN_DIR/zt "PermCartella" "755" "$C_ZT_CONF_DIR/cbqconf"
	echo "<font color=\"#0000FF\" size=\"3\">Shaper</font>"
	if [ -n "$CONF_SHAPER" ];then
		wait "650"
		if [ "$C_SHAPER" != "$SHAPER" ];then
			$C_ZT_BIN_DIR/zt "Shaper" "$SHAPER"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SHAPER" "$SHAPER"
		fi
		return_page "config.sh?SECTION=SHAPER"
		exit
	fi
	echo "<form method=\"POST\" action=\"config.sh\">$L_ACTIVE_SERVICE:&nbsp;"
	if [ "$C_SHAPER" == "on" ];then
		echo "<input name=\"SHAPER\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"SHAPER\" type=\"checkbox\">"
	fi
	if [ -z "$C_SHAPER" ];then
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\">"
	fi
	echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"SHAPER\">
	<input type=\"submit\" name=\"CONF_SHAPER\" class=\"bottone\" value=\"$L_SAVE\"></form>"
	if [ "$C_SHAPER" == "on" ];then
		if [ "$(ls $C_ZT_CONF_DIR/cbqconf/ |  grep -v '[0-9]\-' | cut -sd'-' -f2 | cut -d'.' -f1 | sort -n | sed -n '1p')" -lt 100 ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<font color=\"blue\">Download $L_CLASSES</font><br>&nbsp;"
			echo "<table class=\"tabellain\" width=\"900\" border=\"1\">
			<tr>
			<td class=\"intesta\" width=\"16%\">$L_CLASS</td>
			<td class=\"intesta\" width=\"12%\">Device</td>
			<td class=\"intesta\" width=\"12%\">Rate (Mbit)</td>
			<td class=\"intesta\" width=\"12%\">Sent (KB)</td>
			<td class=\"intesta\" width=\"12%\">Pkt</td>
			<td class=\"intesta\" width=\"12%\">Dropped</td>
			<td class=\"intesta\" width=\"12%\">Overlimits</td>
			</tr>"
			NR=1
			for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep 'cbq-' |  grep -v '[0-9]\-' | grep -v '\-[0-9][0-9][0-9]\.');do
				if [ -z "$(echo "$SHAP" | cut -sd'-' -f4)" ];then
					echo "<script language=\"JavaScript\" type=\"text/javascript\">window.setTimeout(\"shaperdown($NR)\", 100);</script>"
					BG="$C_BG"
					[ $(expr $NR % 2 ) -eq 0 ] && BG="$C_BG1"
					echo "<tr BGCOLOR=\"$BG\">
					<td align=\"center\"><div id=\"sclass$NR\">-</div></td>
					<td align=\"center\"><div id=\"sdevice$NR\">-</div></td>
					<td align=\"center\"><div id=\"srate$NR\">-</div></td>
					<td align=\"center\"><div id=\"ssent$NR\">-</div></td>
					<td align=\"center\"><div id=\"spkt$NR\">-</div></td>
					<td align=\"center\"><div id=\"sdrop$NR\">-</div></td>
					<td align=\"center\"><div id=\"sover$NR\">-</div></td>
					</tr>"
					NR=$(($NR+1))
				fi
			done
			echo "</table>"
			echo "<br>"
		fi
	 	if [ "$(ls $C_ZT_CONF_DIR/cbqconf/ | cut -sd'-' -f2 | cut -d'.' -f1 | grep -v '[0-9]\-' | sort -nr | sed -n '1p')" -gt 100 ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<font color=\"blue\">Upload $L_CLASSES</font><br>&nbsp;"
			echo "<table class=\"tabellain\" width=\"900\" border=\"1\">
			<tr>
			<td class=\"intesta\" width=\"16%\">$L_CLASS</td>
			<td class=\"intesta\" width=\"12%\">Device</td>
			<td class=\"intesta\" width=\"12%\">Rate (Mbit)</td>
			<td class=\"intesta\" width=\"12%\">Sent (KB)</td>
			<td class=\"intesta\" width=\"12%\">Pkt</td>
			<td class=\"intesta\" width=\"12%\">Dropped</td>
			<td class=\"intesta\" width=\"12%\">Overlimits</td>
			</tr>"
			NR=1
			for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep 'cbq-' | grep -v '[0-9]\-' | grep '\-[0-9][0-9][0-9]\.');do
				if [ -z "$(echo "$SHAP" | cut -sd'-' -f4)" ];then
					echo "<script language=\"JavaScript\" type=\"text/javascript\">window.setTimeout(\"shaperup($NR)\", 100);</script>"
					BG="$C_BG"
					[ $(expr $NR % 2 ) -eq 0 ] && BG="$C_BG1"
					echo "<tr BGCOLOR=\"$BG\">
					<td align=\"center\"><div id=\"suclass$NR\">-</div></td>
					<td align=\"center\"><div id=\"sudevice$NR\">-</div></td>
					<td align=\"center\"><div id=\"surate$NR\">-</div></td>
					<td align=\"center\"><div id=\"susent$NR\">-</div></td>
					<td align=\"center\"><div id=\"supkt$NR\">-</div></td>
					<td align=\"center\"><div id=\"sudrop$NR\">-</div></td>
					<td align=\"center\"><div id=\"suover$NR\">-</div></td>
					</tr>"
					NR=$(($NR+1))
				fi
			done
			echo "</table>"
		fi
		echo "<br>"
		if [ -n "$(ls $C_ZT_CONF_DIR/cbqconf/ |  grep '^cbq-4[0-9]')" ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<font color=\"blue\">Download $L_USERS</font><br>&nbsp;"
			echo "<table class=\"tabellain\" width=\"900\" border=\"1\">
			<tr>
			<td class=\"intesta\" width=\"16%\">$L_USER</td>
			<td class=\"intesta\" width=\"16%\">$L_CLASS</td>
			<td class=\"intesta\" width=\"12%\">Device</td>
			<td class=\"intesta\" width=\"12%\">Rate (Mbit)</td>
			<td class=\"intesta\" width=\"12%\">Sent (KB)</td>
			<td class=\"intesta\" width=\"12%\">Pkt</td>
			<td class=\"intesta\" width=\"12%\">Dropped</td>
			<td class=\"intesta\" width=\"12%\">Overlimits</td>
			</tr>"
			NR=1
			for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep '^cbq-4[0-9]' | sort );do
				echo "<script language=\"JavaScript\" type=\"text/javascript\">window.setTimeout(\"shaperdownu($NR)\", 100);</script>"
				BG="$C_BG"
				[ $(expr $NR % 2 ) -eq 0 ] && BG="$C_BG1"
				echo "<tr BGCOLOR=\"$BG\">
				<td align=\"center\"><div id=\"ususer$NR\">-</div></td>
				<td align=\"center\"><div id=\"usclass$NR\">-</div></td>
				<td align=\"center\"><div id=\"usdevice$NR\">-</div></td>
				<td align=\"center\"><div id=\"usrate$NR\">-</div></td>
				<td align=\"center\"><div id=\"ussent$NR\">-</div></td>
				<td align=\"center\"><div id=\"uspkt$NR\">-</div></td>
				<td align=\"center\"><div id=\"usdrop$NR\">-</div></td>
				<td align=\"center\"><div id=\"usover$NR\">-</div></td>
				</tr>"
				NR=$(($NR+1))
			done
			echo "</table>"
			echo "<br>"
		fi
	 	if [ -n "$(ls $C_ZT_CONF_DIR/cbqconf/ |  grep '^cbq-5[0-9]')" ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			echo "<font color=\"blue\">Upload $L_USERS</font><br>&nbsp;"
			echo "<table class=\"tabellain\" width=\"900\" border=\"1\">
			<tr>
			<td class=\"intesta\" width=\"16%\">$L_USER</td>
			<td class=\"intesta\" width=\"16%\">$L_CLASS</td>
			<td class=\"intesta\" width=\"12%\">Device</td>
			<td class=\"intesta\" width=\"12%\">Rate (Mbit)</td>
			<td class=\"intesta\" width=\"12%\">Sent (KB)</td>
			<td class=\"intesta\" width=\"12%\">Pkt</td>
			<td class=\"intesta\" width=\"12%\">Dropped</td>
			<td class=\"intesta\" width=\"12%\">Overlimits</td>
			</tr>"
			NR=1
			for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep '^cbq-5[0-9]' | sort);do
				echo "<script language=\"JavaScript\" type=\"text/javascript\">window.setTimeout(\"shaperupu($NR)\", 100);</script>"
				BG="$C_BG"
				[ $(expr $NR % 2 ) -eq 0 ] && BG="$C_BG1"
				echo "<tr BGCOLOR=\"$BG\">
				<td align=\"center\"><div id=\"usuuser$NR\">-</div></td>
				<td align=\"center\"><div id=\"usuclass$NR\">-</div></td>
				<td align=\"center\"><div id=\"usudevice$NR\">-</div></td>
				<td align=\"center\"><div id=\"usurate$NR\">-</div></td>
				<td align=\"center\"><div id=\"ususent$NR\">-</div></td>
				<td align=\"center\"><div id=\"usupkt$NR\">-</div></td>
				<td align=\"center\"><div id=\"usudrop$NR\">-</div></td>
				<td align=\"center\"><div id=\"usuover$NR\">-</div></td>
				</tr>"
				NR=$(($NR+1))
			done
			echo "</table>"
		fi
	fi
	./footer.sh
	if [ "$C_SHAPER" == "on" ];then
		sleep 60
		return_page "config.sh?SECTION=SHAPER"
	fi
	exit
fi
if [ "$SECTION" == "REMOTE_CP" ];then
	echo "<font color=\"#0000FF\" size=\"3\">MultiCP</font><p>"
	if [ -n "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
		echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ALERT</font><br>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
		./footer.sh
		exit
	fi
	
	if [ -n "$SYNC_NOW" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "Esegui" "$C_ZT_SCRIPTS_DIR/SyncRemote.sh" "$CLIENT"
		return_page "config.sh?SECTION=REMOTE_CP&CONF_CP_REMOTE=yes&EDIT_CLIENT=yes&CLIENT=$CLIENT"
		exit
	fi
	if [ -n "$DEL_CLIENT" ];then
		wait "650"
		##aggiungere disconnessione eventuali ip connessi
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/RemoteClients/$DEL_CLIENT"
		if [ -d $C_CRON_SCRIPTS_DIR/ZTSyncRemote$DEL_CLIENT-Cron ];then
			$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZTSyncRemote$DEL_CLIENT-Cron"
			$C_ZT_BIN_DIR/zt "RestartCron"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$ACTIVE_CLIENT" ];then
		wait "650"
		if [ "$ACTIVE_CLIENT" == "yes" ];then
			remoteclient "ActiveCp"
		else
			remoteclient "DisactiveCp"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$AR_CLIENT" ];then
		wait "650"
		if [ "$AR_CLIENT" == "yes" ];then
			remoteclient "ActiveAr"
		else
			remoteclient "DisactiveAr"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$SHAPER_CLIENT" ];then
		wait "650"
		if [ "$SHAPER_CLIENT" == "yes" ];then
			CONTROL=$(remoteclient "ActiveShaper")
		else
			CONTROL=$(remoteclient "DisactiveShaper")
		fi
		while [ "$CONTROL" == "ok" ];do
			sleep 2
		done
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$HAVP_CLIENT" ];then
		wait "650"
		if [ "$HAVP_CLIENT" == "yes" ];then
			remoteclient "ActiveHAVP"
		else
			remoteclient "DisactiveHAVP"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$SQUID_CLIENT" ];then
		wait "650"
		if [ "$SQUID_CLIENT" == "yes" ];then
			remoteclient "ActiveSquid"
		else
			remoteclient "DisactiveSquid"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ -n "$DS_CLIENT" ];then
		wait "650"
		if [ "$DS_CLIENT" == "yes" ];then
			remoteclient "ActiveDS"
		else
			remoteclient "DisactiveDS"
		fi
		return_page "config.sh?SECTION=REMOTE_CP"
		exit
	fi
	if [ "$CONF_CP_REMOTE" ];then
		if [ -n "$ADD_CLIENT" ];then
			echo "<font color=\"#0000FF\" size=\"3\">$L_ADD Client</font><p>"
			echo "<form method=\"POST\" action=\"config.sh\">
			Hostname: <input type=\"text\" size=\"12\" name=\"CLIENT\" value=\"\">&nbsp;&nbsp;
			IP: <input type=\"text\" size=\"12\" name=\"REMOTE_IP\" value=\"\">&nbsp;&nbsp;
			$L_PASSWORD: <input id=\"pwd1\" size=\"12\" type=\"password\"  name=\"REMOTE_PASSWORD\" value=\"\">&nbsp;
			<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a><p>
			<p><input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
			<p><input type=\"hidden\" name=\"REG_CLIENT\" value=\"ok\">
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottone\" value=\"$L_SAVE\"></form>"
			./footer.sh
			exit
		fi
		if [ -n "$EDIT_CLIENT" ];then
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			ERROR_EMAIL_SYNC=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/ERROR_EMAIL_SYNC)
			ERROR_EMAIL_LINK=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/ERROR_EMAIL_LINK)
			echo "<font color=\"#0000FF\" size=\"3\">$L_MODIFY Client</font><p>"
			echo "<form method=\"POST\" action=\"config.sh\">
			Hostname: <input type=\"text\" size=\"12\" name=\"CP_REMOTE_NAME\" value=\"$CLIENT\">&nbsp;&nbsp;
			IP: <input type=\"text\" size=\"12\" name=\"CP_REMOTE_IP\" value=\"$IP_REMOTE\">&nbsp;&nbsp;
			$L_PASSWORD: <input id=\"pwd1\" size=\"12\" type=\"password\"  name=\"CP_REMOTE_PASSWORD\" value=\"$PASSWORD\">&nbsp;
			<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a><p>"
			remoteclient "ControlAll" "Control"
			if [ "$CONTROL_UP" == "ok" ];then
				echo "$L_LDAP_REMOTE: <select name=\"HOUR_LDAP\">"
				HOUR_EX=$(cat $C_CRON_SCRIPTS_DIR/ZTSyncRemote$CLIENT-Cron/cron/Hour)
				for OS in $(seq 0 23);do
					echo "<option value=\"$OS\" selected>$OS</option>"
				done
				echo "<option value=\"\"></option>
				<option value=\"$HOUR_EX\" selected>$HOUR_EX</option>
				</select>&nbsp;&nbsp;
				$L_MINUTES:&nbsp;
				<select name=\"MINUTE_LDAP\">"
				MIN_EX=$(cat $C_CRON_SCRIPTS_DIR/ZTSyncRemote$CLIENT-Cron/cron/Minute)
				for MS in $(seq 0 59);do
					echo "<option value=\"$MS\" selected>$MS</option>"
				done
				echo "<option value=\"\" selected></option>
				<option value=\"$MIN_EX\" selected>$MIN_EX</option>
				</select><p>"
				if [ -n "$CONTROL_REMOTE_SYNC" ];then
					echo "<font color=\"blue\" size=\"3\">$L_LAST_SYNC: $CONTROL_REMOTE_SYNC</font><p>"
				fi
				echo "<table><tr><td>
				$L_LDAP_REMOTE_ERROR: </td><td>"
				if [ -n "$ERROR_EMAIL_SYNC" ];then
					echo "<input name=\"ERROR_EMAIL_SYNC\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"ERROR_EMAIL_SYNC\" type=\"checkbox\">"
				fi
				echo "<br>&nbsp;</td></tr><tr><td>$L_LINK_REMOTE_ERROR: </td><td>"
				if [ "$CONTROL_AUTO" == "ok" ];then
					echo "<input name=\"AUTO_CLIENT\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"AUTO_CLIENT\" type=\"checkbox\">"
				fi
				echo "<br>&nbsp;</td></tr><tr><td>$L_LINK_REMOTE_ERROR_EMAIL: </td><td>"
				if [ -n "$ERROR_EMAIL_LINK" ];then
					echo "<input name=\"ERROR_EMAIL_LINK\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"ERROR_EMAIL_LINK\" type=\"checkbox\">"
				fi
				echo "<p></td></tr></table>"
			fi
			echo "<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
			<input type=\"hidden\" name=\"UPDATE_CLIENT\" value=\"ok\">
			<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottonelineatre\" value=\"$L_MODIFY\">
			</form>"
			echo "<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
			<input type=\"hidden\" name=\"SYNC_NOW\" value=\"OK\">
			<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
			<input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottonelineadue\" value=\"$L_SYNC_NOW\"
			onClick=\"javascript:return confirm('$L_ALERT_SYNC');\"></form>"
			echo "<form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
			<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><p>&nbsp;<p>"
			echo "<p>&nbsp;<p>"
			./footer.sh
			exit
		fi
		if [ -n "$REG_CLIENT" ];then
			wait "650"
			if [ ! -d $C_ZT_CONF_DIR/RemoteClients ];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/RemoteClients"
			fi
			if [ ! -d $C_ZT_CONF_DIR/RemoteClients/$CLIENT ];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT"
			fi
			if [ ! -d $C_ZT_CONF_DIR/RemoteClients/$CLIENT/LoginRemote ];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT/LoginRemote"
			fi
			$C_ZT_BIN_DIR/zt "Salva" "$REMOTE_IP" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP"
			$C_ZT_BIN_DIR/zt "Salva" "$REMOTE_PASSWORD" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD"
			return_page "config.sh?SECTION=REMOTE_CP&CONF_CP_REMOTE=yes&EDIT_CLIENT=yes&CLIENT=$CLIENT"
			exit
		fi
		if [ -n "$UPDATE_CLIENT" ];then
			wait "650"
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			REMOTE_PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/PASSWORD)
			if [[ -n "$HOUR_LDAP" && -n "$MINUTE_LDAP" ]];then
				$C_ZT_BIN_DIR/zt "CronSyncRemote" "$CLIENT" "$HOUR_LDAP" "$MINUTE_LDAP"
				$C_ZT_BIN_DIR/zt "RestartCron"
			else
				if [ -d $C_CRON_SCRIPTS_DIR/ZTSyncRemote$CLIENT-Cron ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZTSyncRemote$CLIENT-Cron"
					$C_ZT_BIN_DIR/zt "RestartCron"
				fi
			fi
			$C_ZT_BIN_DIR/zt "Salva" "$ERROR_EMAIL_SYNC" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT/ERROR_EMAIL_SYNC"
			$C_ZT_BIN_DIR/zt "Salva" "$ERROR_EMAIL_LINK" "$C_ZT_CONF_DIR/RemoteClients/$CLIENT/ERROR_EMAIL_LINK"

			if [ -n "$AUTO_CLIENT" ];then
				remoteclient "ActiveAuto"
			else
				remoteclient "DisactiveAuto"
			fi

			return_page "config.sh?SECTION=REMOTE_CP&CONF_CP_REMOTE=yes&EDIT_CLIENT=yes&CLIENT=$CLIENT"
			exit
		fi
		if [[ "$CP_LOCAL_TYPE" == "Client" && -n "$CP_REMOTE" ]];then
			wait "650"
			NAME_HOST=$( echo "$HOSTNAME" | cut -d'.' -f1)
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_REMOTE" "$CP_REMOTE"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_NAME" "$NAME_HOST"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_IP" "$CP_LOCAL_IP"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_TYPE" "Client"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_REMOTE_IP" "$CP_REMOTE_IP"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_REMOTE_PASSWORD" "$CP_REMOTE_PASSWORD"
			return_page "config.sh?SECTION=REMOTE_CP"
			exit
		fi
		if [[ "$CP_LOCAL_TYPE" == "Server" && -n "$CP_REMOTE" ]];then
			wait "650"
			NAME_HOST=$( echo "$HOSTNAME" | cut -d'.' -f1)
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_REMOTE" "$CP_REMOTE"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_NAME" "$NAME_HOST"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_IP" "$CP_LOCAL_IP"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_TYPE" "Server"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_ROOM_NAME" ""
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_ROOM_NAME" ""
			[[ -n "$CP_SYNC_DEF" && -z "$CP_SYNC_DEF_TIME" ]] && CP_SYNC_DEF_TIME="15"
			[ -z "$CP_SYNC_DEF" ] && CP_SYNC_DEF_TIME=""
			$C_ZT_BIN_DIR/zt "SyncRemoteDefCron" "$CP_SYNC_DEF" "$CP_SYNC_DEF_TIME"
			$C_ZT_BIN_DIR/zt "KeyRemoteCp"
			return_page "config.sh?SECTION=REMOTE_CP"
			exit
		fi
		if [ -z "$CP_REMOTE" ];then
			wait "650"
			for CONFREM in "C_CP_REMOTE" "C_CP_LOCAL_NAME" "C_CP_LOCAL_NAME" "C_CP_LOCAL_IP" "C_CP_LOCAL_TYPE" "C_CP_LOCAL_IP";do
				$C_ZT_BIN_DIR/zt "SalvaConfig" "$CONFREM" ""
			done
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/RemoteKey"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/RemoteClients"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/RemoteClients"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZTSyncRemote*"
			$C_ZT_BIN_DIR/zt "RestartCron"
			return_page "config.sh?SECTION=REMOTE_CP"
			exit
		fi
	fi
	for i in $(seq 2 10);do
		IP_L=$(echo -e $(ifconfig) | awk '{split ($0, a, "inet addr:");print a['$i']}' | awk '{split ($0, a, " Bcast");print a[1]}')
		if [ -z $( echo "$IP_L" | grep '127') ];then
			IP_LOCAL="$IP_LOCAL $IP_L"
		fi
	done
	echo "<form method=\"POST\" action=\"config.sh\">$L_ACTIVE_SERVICE:&nbsp;"
	if [ "$C_CP_REMOTE" == "on" ];then
		echo "<input name=\"CP_REMOTE\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"CP_REMOTE\" type=\"checkbox\">"
	fi
	echo "&nbsp;&nbsp;&nbsp;$L_AS_A:&nbsp;&nbsp;&nbsp;"
	echo "<select name=\"CP_LOCAL_TYPE\">"
	for t in "Client" "Server";do
		if [ "$C_CP_LOCAL_TYPE" != "$t" ];then
			echo "<option value=\"$t\">$t</option>"
		fi
	done
	echo "<option value=\"\"></option>
	<option value=\"$C_CP_LOCAL_TYPE\" selected>$C_CP_LOCAL_TYPE</option></select>
	&nbsp;&nbsp;&nbsp;IP:&nbsp;&nbsp;&nbsp;"
	echo "<select name=\"CP_LOCAL_IP\">"
	for lip in $IP_LOCAL;do
		if [ "$C_CP_LOCAL_IP" != "$lip" ];then
			echo "<option value=\"$lip\">$lip</option>"
		fi
	done
	echo "<option value=\"\"></option>
	<option value=\"$C_CP_LOCAL_IP\" selected>$C_CP_LOCAL_IP</option></select>"
	if [[ -z "$C_CP_REMOTE" || -z "$C_CP_LOCAL_TYPE" || -z $C_CP_LOCAL_IP ]];then
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		echo "<p><input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
		<input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		./footer.sh
		exit
	fi
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<table>
		<tr><td align=\"left\">$L_SYNC_BG:&nbsp;</td><td>"
		STEP=$(cat $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/cron/Step | cut -d' ' -f1 2>/dev/null)
		if [ -d $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron ];then
			echo "<input name=\"CP_SYNC_DEF\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"CP_SYNC_DEF\" type=\"checkbox\">"
		fi
		echo "</td>
		<td align=\"left\">&nbsp;&nbsp;$L_EVERY ($L_MINUTES):&nbsp;</td><td>
		<select name=\"CP_SYNC_DEF_TIME\">"
			
		for ST in "3" "5" "8" "10" "15" "30";do
			if [ "$ST" != "$STEP" ];then
				echo "<option value=\"$ST\">$ST</option>"
			fi
		done
		echo "<option value=\"\" selected></option>
		<option value=\"$STEP\" selected>$STEP</option></select></td></tr>
		</table><p>
		
		
		<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
		<table><tr>
		<td><input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottone\" value=\"$L_SAVE\"></form></td>
		<form method=\"POST\" action=\"config.sh\"><td>&nbsp;&nbsp;</td>
		<input type=\"hidden\" name=\"ADD_CLIENT\" value=\"ok\">
		<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
		<td><input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottone\" value=\"$L_ADDCLIENT\"></form></td>
		</tr></table>"
	fi
	if [[ -n "$C_CP_REMOTE" && -n "$C_CP_LOCAL_TYPE" ]];then
		if [ "$C_CP_LOCAL_TYPE" == "Client" ];then
			echo "<p><font color=\"#0000FF\" size=\"3\">Server</font><p>
			<p><table><tr><td>
			IP: <input type=\"text\" size=\"12\" name=\"CP_REMOTE_IP\" value=\"$C_CP_REMOTE_IP\"></td><td>
			&nbsp;&nbsp;</td>
			<td>$L_PASSWORD: <input id=\"pwd1\" size=\"12\" type=\"password\"  name=\"CP_REMOTE_PASSWORD\" value=\"$C_CP_REMOTE_PASSWORD\">&nbsp;
			<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></td><td>"
			remoteserverlink
			if [ "$CONTROL_LINK" == "ok" ];then
				echo "&nbsp;<img src=\"/images/abilita.png\" alt=\"barra\">"
			else
				echo "&nbsp;<img src=\"/images/disabilita.png\" alt=\"disabled\">"
			fi
			echo "</td></tr></table>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
			<input type=\"submit\" name=\"CONF_CP_REMOTE\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		else
			if [ -d $C_ZT_CONF_DIR/RemoteClients ];then
				CONTROL=$(ls $C_ZT_CONF_DIR/RemoteClients | wc -w | awk '{print $1}')
				[ "$CONTROL" -gt "0" ] && CONTROL_CL="yes"
			fi
			if [ -n "$CONTROL_CL" ];then
				echo "<p><font color=\"#0000FF\" size=\"3\">Clients</font><p>
				<table class=\"tabellain\" width=\"650\" border=\"1\">
				<tr>
				<td class=\"intesta\" size=\"33\">N.</td>
				<td class=\"intesta\" size=\"33\">U.</td>
				<td class=\"intesta\">Hostname</td>
				<td class=\"intesta\">IP</td>
				<td class=\"intesta\">Password</td>
				<td class=\"intesta\">S</td>"
				COLSPAN=8
				[ "$C_AUTO_REGISTER" == "on" ] && COLSPAN=$(($COLSPAN+1))
				echo "<td class=\"intesta\" colspan=\"$COLSPAN\">$L_ACTIONS</td></tr><tr>"
				NU="1"
				for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
					CONTROL_LINK="no"
					CONTROL_ACTIVE="no"
					CONTROL_AR="no"
					CONTROL_SHAPER="no"
					CONTROL_PROXY="no"
					remoteclient "ControlAll" "Control"
					[[ "$CONTROL_KEY" == "no" && "$CONTROL_CON_CLIENT" != "down" ]] && putprivkey
					USCL=$(ls $C_ZT_CONF_DIR/RemoteClients/$CLIENT/RemoteLogin | wc -w | awk '{print $1}')
					echo "<td align=\"center\">$NU</td><td align=\"center\">$USCL</td><td>&nbsp;$CLIENT</td><td>&nbsp;$IP_REMOTE</td>
					<td width=\"140px\">
					<div id=\"pwd$NU\"><a href=\"#\" onclick=\"hidden_passwordline('pwd$NU','$PASSWORD','show','hide', '$NU');\" id=\"showhide$NU\">
					&nbsp;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</a></div>
					</td>
					<td width=\"20px\" align=\"center\">"
					if [ -n "$CONTROL" ];then
						[ "$CONTROL_KEY" != "$(cat $C_ZT_CONF_DIR/RemoteKey/controlkey)" ] && putprivkey
						if [ "$CONTROL_UP" == "ok"  ];then
							echo "<img src=\"/images/abilita.png\" alt=\"enabled\">"
						else
							echo "<img src=\"/images/disabilita.png\" alt=\"disabled\">"
						fi
						echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
						<input type=\"hidden\" name=\"DEL_CLIENT\" value=\"$CLIENT\">
						<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
						<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
						title=\"$L_DELETE\"
						onClick=\"javascript:return confirm('$L_ALERT_REMOVE $C_CP_NAME?');\"></form>
						</td>"
						if [ "$CONTROL_ACTIVE" == "ok" ];then
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"ACTIVE_CLIENT\" value=\"no\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/unlock.png\"
							title=\"\"
							onClick=\"javascript:return confirm('$L_ALERT_LOCKED $C_CP_NAME?');\"></form>
							</td>"
						else
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"ACTIVE_CLIENT\" value=\"yes\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/lock.png\"
							title=\"\"
							onClick=\"javascript:return confirm('$L_ALERT_UNLOCK $C_CP_NAME?');\"></form>
							</td>"
						fi
						if [ "$C_AUTO_REGISTER" == "on" ];then
							if [ "$CONTROL_AR" == "ok" ];then
								echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
								<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
								<input type=\"hidden\" name=\"AR_CLIENT\" value=\"no\">
								<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
								<input type=\"image\" class=\"image\" src=\"/images/reg.png\"
								title=\"\" onClick=\"javascript:return confirm('$L_ALERT_AR_LOCKED');\"></form>
								</td>"
							else
								echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
								<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
								<input type=\"hidden\" name=\"AR_CLIENT\" value=\"yes\">
								<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
								<input type=\"image\" class=\"image\" src=\"/images/noreg.png\"
								title=\"\" onClick=\"javascript:return confirm('$L_ALERT_AR');\"></form>
								</td>"
							fi
						fi
						if [ "$CONTROL_SHAPER" == "ok" ];then
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"SHAPER_CLIENT\" value=\"no\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/shaper.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_SHAPER_LOCKED');\"></form>
							</td>"
						else
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"SHAPER_CLIENT\" value=\"yes\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/noshaper.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_SHAPER');\"></form>
							</td>"
						fi
						if [ "$CONTROL_HAVP" == "ok" ];then
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"HAVP_CLIENT\" value=\"no\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/proxy.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_PROXY_LOCKED');\"></form>
							</td>"
						else
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"HAVP_CLIENT\" value=\"yes\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/noproxy.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_PROXY');\"></form>
							</td>"
						fi
						if [ "$CONTROL_SQUID" == "ok" ];then
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"SQUID_CLIENT\" value=\"no\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/squid.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_SQUID_LOCKED');\"></form>
							</td>"
						else
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"SQUID_CLIENT\" value=\"yes\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/nosquid.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_SQUID');\"></form>
							</td>"
						fi

						if [ "$CONTROL_DS" == "ok" ];then
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"DS_CLIENT\" value=\"no\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/dansguardian.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_DS_LOCKED');\"></form>
							</td>"
						else
							echo "</td><td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
							<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
							<input type=\"hidden\" name=\"DS_CLIENT\" value=\"yes\">
							<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
							<input type=\"image\" class=\"image\" src=\"/images/nodansguardian.png\"
							title=\"\" onClick=\"javascript:return confirm('$L_ALERT_DS');\"></form>
							</td>"
						fi
					else
						COLS=$(($COLSPAN-1))
						echo "<img src=\"/images/disabilita.png\" alt=\"disabled\"></td>
						<td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
						<input type=\"hidden\" name=\"DEL_CLIENT\" value=\"$CLIENT\">
						<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
						<input type=\"image\" class=\"image\" src=\"/images/action_x.png\"
						title=\"$L_DELETE\"	onClick=\"javascript:return confirm('$L_ALERT_REMOVE $C_CP_NAME?');\"></form></td>
						<td width=\"20px\" align=\"center\"><img src=\"/images/lock.png\"></td>"
						if [ "$C_AUTO_REGISTER" == "on" ];then
							echo "<td width=\"20px\" align=\"center\"><img src=\"/images/noreg.png\"></td>"
						fi
						echo "<td width=\"20px\" align=\"center\"><img src=\"/images/noshaper.png\"></td>
						<td width=\"20px\" align=\"center\"><img src=\"/images/noproxy.png\"></td>
						<td width=\"20px\" align=\"center\"><img src=\"/images/nosquid.png\"></td>
						<td width=\"20px\" align=\"center\"><img src=\"/images/nodansguardian.png\"></td>"
					fi
					echo "<td width=\"20px\" align=\"center\"><form action=\"config.sh\" method=\"POST\">
					<input type=\"hidden\" name=\"EDIT_CLIENT\" value=\"yes\">
					<input type=\"hidden\" name=\"CLIENT\" value=\"$CLIENT\">
					<input type=\"hidden\" name=\"SECTION\" value=\"REMOTE_CP\">
					<input type=\"hidden\" name=\"CONF_CP_REMOTE\" value=\"ok\">
					<input type=\"image\" class=\"image\" src=\"/images/edit.png\"
					title=\"\"></form>
					</td></tr>"
					NU=$(($NU+1))
				done
				echo "</table>"
				echo "<br>
				<table  width=\"650\" border=\"0\"><tr>
				<td><img src=\"/images/unlock.png\">&nbsp;CP $L_ACTIVE</td>
				<td><img src=\"/images/reg.png\">&nbsp;$L_SELF_REGISTER</td>
				<td><img src=\"/images/shaper.png\">&nbsp;Shaper</td>
				<td><img src=\"/images/proxy.png\">&nbsp;Havp-Clamav</td>
				<td><img src=\"/images/squid.png\">&nbsp;Squid</td>
				<td align=\"right\"><img src=\"/images/dansguardian.png\">&nbsp;DansGuardian</td><tr>
				</table>"
				
			fi
		fi
	fi
	./footer.sh
	exit
fi
if [ "$SECTION" == "GRAPHS" ];then
	echo "<font color=\"#0000FF\" size=\"3\">$L_GRAPHS</font><p>
	<table border=\"0\" align=\"center\" cellpadding=\"3\">
	<tr>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CPU\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"CPU\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"RAM\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Mem\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"NET\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Net\"></form></td>
	<td><form action=\"config.sh\" method=\"POST\">
	<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
	<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
	<input type=\"submit\" class=\"bottoneconf\" value=\"Captive Portal\"></form></td>"
	echo "</tr></table>"
	if [[ "$SUB_SECTION" == "CPU" || -z "$SUB_SECTION" ]];then
		echo "<p><table width=\"650\" border=\"0\"><tr><td>"
		cat $C_HTDOCS_DIR/svg/graph_cpu.svg
		echo "</td></tr></table>"
		echo "<p>&nbsp;<p>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "RAM" ];then
		echo "<p><table width=\"650\" border=\"0\"><tr><td>"
		cat $C_HTDOCS_DIR/svg/graph_mem.svg
		echo "</td></tr></table>"
		echo "<p>&nbsp;<p>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "NET" ];then
		echo "<p><table width=\"650\" border=\"0\"><tr><td>"
		cat $C_HTDOCS_DIR/svg/graph_if.svg
		echo "</td></tr></table>"
		echo "<p>&nbsp;<p>"
		./footer.sh
		exit
	fi
	if [ "$SUB_SECTION" == "CP" ];then
		if ! [ -f $C_ZT_DIR/log/graphs/graphs ];then
			echo "<p><font color=\"blue\" size=\"3\">$L_UPDATE_DATA</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_GRAPHS\">
			<input type=\"submit\" class=\"bottoneconf\" value=\"$L_MODIFY\"
			onClick=\"javascript:return confirm('$L_ALERT_UPDATE_GRAPHS');\"></form>
			<p>"
			./footer.sh
			exit
		fi
		if [ -n "$RANGE" ];then
			if [[ -n "$GRAPH_DATA_IN" || -n "$GRAPH_DATA_OUT" ]];then
				for CONF in "GRAPH_DATA_IN" "GRAPH_DATA_OUT";do
					DATAC=$(echo "${!CONF}" | sed 's/\%2F/-/g')
					DAY_G=$(echo "$DATAC" | cut -d'-' -f1)
					MONTH_G=$(echo "$DATAC" | cut -d'-' -f2)
					YEAR_G=$(echo "$DATAC" | cut -d'-' -f3)
					DATA_GRAPH_SEC=$(date -d "$YEAR_G-$MONTH_G-$DAY_G 1 day" +%s)
					$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "$DATA_GRAPH_SEC"
				done
			fi
			source $C_ZT_CONF_DIR/zt.config
		fi
		if [ -n "$GRAPHS_ALL" ];then
			for CONF in "GRAPH_DATA_IN" "GRAPH_DATA_OUT";do
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" ""
			done
			source $C_ZT_CONF_DIR/zt.config
		fi
		if [ -z "$C_GRAPH_DATA_IN" ];then
			DATA_IN="0"
		else
			DATA_IN="$C_GRAPH_DATA_IN"
		fi
		if [ -z "$C_GRAPH_DATA_OUT" ];then
			DATA_OUT="$(date +%s)"
		else
			DATA_OUT="C_GRAPH_DATA_OUT"
		fi
		SECUP=$(stat -c "%Y" $C_ZT_DIR/log/graphs/graphs)
		if [ -z "$SSUB_SECTION" ];then
		ANNIUNIQ=$(cat $C_ZT_DIR/log/graphs/graphs | cut -d' ' -f2 | cut -d'-' -f2 | sort | uniq)
			YEARS_TIME=""
			YEARS_TRAFFIC=""
			for ANNI in $(echo -e $ANNIUNIQ);do
				ANNITIME=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/anno-$ANNI/ {if(\$1>da && \$1<db) print \$7}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				ANNITIME=$(echo -e $ANNITIME |  sed 's/ /+/g')
				ANNITIME=$(echo -e $ANNITIME | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				ANNITRAFFIC=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/anno-$ANNI/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				ANNITRAFFIC=$(echo -e $ANNITRAFFIC |  sed 's/ /+/g')
				ANNITRAFFIC=$(echo -e $ANNITRAFFIC | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				[ -z "$ANNITIME" ] && ANNITIME="0"
				[ -z "$ANNITRAFFIC" ] && ANNITRAFFIC="0"
				if [ -n "$YEARS_TIME" ];then
					YEARS_TIME=$(echo "$YEARS_TIME\n$ANNI $ANNITIME")
				else
					YEARS_TIME=$(echo "$ANNI $ANNITIME")
				fi
				if [ -n "$YEARS_TRAFFIC" ];then
					YEARS_TRAFFIC=$(echo "$YEARS_TRAFFIC\n$ANNI $ANNITRAFFIC")
				else
					YEARS_TRAFFIC=$(echo "$ANNI $ANNITRAFFIC")
				fi
			done
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%d-%m-%Y %T")
			else
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%Y-%m-%d %T")
			fi
			echo "<p>&nbsp;<p><font color=\"blue\" size=\"3\">$L_YEARS</font><br> <font color=\"blue\" size=\"2\">($L_UPDATED: $DATA_AGG)</font>"
			echo "<table><tr><td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Year');
				data.addColumn('number', 'Hours');
				data.addRows(["
				RIGHE=$(echo -e "$YEARS_TIME"  | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$(echo -e "$YEARS_TIME" | sed -n "${I}p")
					ANNO=$(echo "$RIGA" | cut -d' ' -f1)
					ORE=$(echo "$RIGA" | cut -d' ' -f2)
					ORE=$( echo "$ORE/3600" | $C_ZT_BIN_DIR/bc )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$ANNO ', $ORE ],"
					else
						echo "[ '$ANNO', $ORE ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div1'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div1\" style=\"width: 480px; height: 350px;\"></div>
			<td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Year');
				data.addColumn('number', 'Traffic (MB)');
				data.addRows(["
				RIGHE=$(echo -e "$YEARS_TRAFFIC"  | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$(echo -e "$YEARS_TRAFFIC" | sed -n "${I}p")
					ANNO=$(echo "$RIGA" | cut -d' ' -f1)
					TRAFFIC=$(echo "$RIGA" | cut -d' ' -f2)
					TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
					SCRITTA=""
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$ANNO', $TRAFFIC ],"
					else
						echo "[ '$ANNO', $TRAFFIC ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div2'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div2\" style=\"width: 480px; height: 350px;\"></div>"
		fi
		if [ "$SSUB_SECTION" == "MONTHS" ];then
			MESIUNIQ=$(cat $C_ZT_DIR/log/graphs/graphs | cut -d' ' -f3 | cut -d'-' -f2 | sort | uniq)
			MONTHS_TIME=""
			MONTHS_TRAFFIC=""
			for MESI in $(echo -e $MESIUNIQ);do
				MESITIME=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/mese-$MESI/ {if(\$1>da && \$1<db) print \$7}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				MESITIME=$(echo -e $MESITIME |  sed 's/ /+/g')
				MESITIME=$(echo -e $MESITIME | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				MESITRAFFIC=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/mese-$MESI/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				MESITRAFFIC=$(echo -e $MESITRAFFIC |  sed 's/ /+/g')
				MESITRAFFIC=$(echo -e $MESITRAFFIC | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				[ -z "$MESITIME" ] && MESITIME="0"
				[ -z "$MESITRAFFIC" ] && MESITRAFFIC="0"
				if [ -n "$MONTHS_TIME" ];then
					MONTHS_TIME=$(echo "$MONTHS_TIME\n$MESI $MESITIME")
				else
					MONTHS_TIME=$(echo "$MESI $MESITIME")
				fi
				if [ -n "$MONTHS_TRAFFIC" ];then
					MONTHS_TRAFFIC=$(echo "$MONTHS_TRAFFIC\n$MESI $MESITRAFFIC")
				else
					MONTHS_TRAFFIC=$(echo "$MESI $MESITRAFFIC")
				fi
			done
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%d-%m-%Y %T")
			else
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%Y-%m-%d %T")
			fi
			echo "<p>&nbsp;<p><font color=\"blue\" size=\"3\">$L_MONTHS</font><br> <font color=\"blue\" size=\"2\">($L_UPDATED: $DATA_AGG)</font>"
			echo "<table><tr><td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Month');
				data.addColumn('number', 'Hours');
				data.addRows(["
				RIGHE=$(echo -e "$MONTHS_TIME" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$MONTHS_TIME" | sed -n "${I}p")
					MESE=$(echo "$RIGA" | cut -d' ' -f1)
					ORE=$(echo "$RIGA" | cut -d' ' -f2)
					ORE=$( echo "$ORE/3600" | $C_ZT_BIN_DIR/bc )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$MESE', $ORE ],"
					else
						echo "[ '$MESE', $ORE ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div3'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div3\" style=\"width: 480px; height: 350px;\"></div>
			<td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Month');
				data.addColumn('number', 'Traffic (MB)');
				data.addRows(["
				RIGHE=$(echo -e "$MONTHS_TRAFFIC" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$MONTHS_TRAFFIC" | sed -n "${I}p")
					MESE=$(echo "$RIGA" | cut -d' ' -f1)
					TRAFFIC=$(echo "$RIGA" | cut -d' ' -f2)
					TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$MESE', $TRAFFIC ],"
					else
						echo "[ '$MESE', $TRAFFIC ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div4'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div4\" style=\"width: 480px; height: 350px;\"></div>"
		fi
		if [ "$SSUB_SECTION" == "DAYS" ];then
			GIORNIUNIQ=$(cat $C_ZT_DIR/log/graphs/graphs | cut -d' ' -f9 | cut -d'-' -f2 | sort | uniq)
			DAYS_TIME=""
			DAYS_TRAFFIC=""
			for GIORNI in $(echo -e $GIORNIUNIQ);do
				GIORNITIME=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/giornosettnum-$GIORNI/ {if(\$1>da && \$1<db) print \$7}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				GIORNITIME=$(echo -e $GIORNITIME |  sed 's/ /+/g')
				GIORNITIME=$(echo -e $GIORNITIME | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				GIORNITRAFFIC=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/giornosettnum-$GIORNI/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				GIORNITRAFFIC=$(echo -e $GIORNITRAFFIC |  sed 's/ /+/g')
				GIORNITRAFFIC=$(echo -e $GIORNITRAFFIC | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				[ -z "$GIORNITIME" ] && GIORNITIME="0"
				[ -z "$GIORNITRAFFIC" ] && GIORNITRAFFIC="0"
				GIORNOS=$(cat $C_ZT_DIR/log/graphs/graphs  | grep -m1 "giornosettnum-$GIORNI" |  cut -d' ' -f5 | cut -d'-' -f2)
				if [ -n "$DAYS_TIME" ];then
					DAYS_TIME=$(echo "$DAYS_TIME\n$GIORNOS $GIORNITIME")
				else
					DAYS_TIME=$(echo "$GIORNOS $GIORNITIME")
				fi
				if [ -n "$DAYS_TRAFFIC" ];then
					DAYS_TRAFFIC=$(echo "$DAYS_TRAFFIC\n$GIORNOS $GIORNITRAFFIC")
				else
					DAYS_TRAFFIC=$(echo "$GIORNOS $GIORNITRAFFIC")
				fi
			done
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%d-%m-%Y %T")
			else
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%Y-%m-%d %T")
			fi
			echo "<p>&nbsp;<p><font color=\"blue\" size=\"3\">$L_DAYS</font><br> <font color=\"blue\" size=\"2\">($L_UPDATED: $DATA_AGG)</font>"
			echo "<table><tr><td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Days');
				data.addColumn('number', 'Hours');
				data.addRows(["
				RIGHE=$(echo -e "$DAYS_TIME" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$DAYS_TIME" | sed -n "${I}p")
					GIORNO=$(echo "$RIGA" | cut -d' ' -f1)
					ORE=$(echo "$RIGA" | cut -d' ' -f2)
					ORE=$( echo "$ORE/3600" | $C_ZT_BIN_DIR/bc )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$GIORNO', $ORE ],"
					else
						echo "[ '$GIORNO', $ORE ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div5'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div5\" style=\"width: 480px; height: 350px;\"></div>
			<td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Month');
				data.addColumn('number', 'Traffic (MB)');
				data.addRows(["
				RIGHE=$(echo -e "$DAYS_TRAFFIC" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$DAYS_TRAFFIC" | sed -n "${I}p")
					GIORNO=$(echo "$RIGA" | cut -d' ' -f1)
					TRAFFIC=$(echo "$RIGA" | cut -d' ' -f2)
					TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$GIORNO', $TRAFFIC ],"
					else
						echo "[ '$GIORNO', $TRAFFIC ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div6'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div6\" style=\"width: 480px; height: 350px;\"></div>"
		fi
		if [ "$SSUB_SECTION" == "HOURS" ];then
			OREUNIQ=$(cat $C_ZT_DIR/log/graphs/graphs | cut -d' ' -f6 | cut -d'-' -f2 | sort | uniq)
			HOURS_SESSIONS=""
			HOURS_TRAFFIC=""
			for ORE in $(echo -e $OREUNIQ);do
				NUM=$(cat $C_ZT_DIR/log/graphs/graphs | grep "ora-$ORE" |  wc -l | awk '{print $1}')
				NUM=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/ora-$ORE/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs |  wc -l | awk '{print $1}')
				ORETRAFFIC=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/ora-$ORE/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				ORETRAFFIC=$(echo -e $ORETRAFFIC |  sed 's/ /+/g')
				ORETRAFFIC=$(echo -e $ORETRAFFIC | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				[ -z "$ORETRAFFIC" ] && ORETRAFFIC="0"
				if [ -n "$HOURS_SESSIONS" ];then
					HOURS_SESSIONS=$(echo "$HOURS_SESSIONS\n$ORE $NUM")
				else
					HOURS_SESSIONS=$(echo "$ORE $NUM")
				fi
				if [ -n "$HOURS_TRAFFIC" ];then
					HOURS_TRAFFIC=$(echo "$HOURS_TRAFFIC\n$ORE $ORETRAFFIC")
				else
					HOURS_TRAFFIC=$(echo "$ORE $ORETRAFFIC")
				fi
			done
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%d-%m-%Y %T")
			else
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%Y-%m-%d %T")
			fi
			echo "<p>&nbsp;<p><font color=\"blue\" size=\"3\">$L_HOURS</font><br> <font color=\"blue\" size=\"2\">($L_UPDATED: $DATA_AGG)</font>"
			echo "<table><tr><td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Hour');
				data.addColumn('number', 'Sessions');
				data.addRows(["
				RIGHE=$(echo -e "$HOURS_SESSIONS" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$HOURS_SESSIONS" | sed -n "${I}p")
					ORARIO=$(echo "$RIGA" | cut -d' ' -f1)
					NUM=$(echo "$RIGA" | cut -d' ' -f2)
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$ORARIO', $NUM ],"
					else
						echo "[ '$ORARIO', $NUM ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div7'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div7\" style=\"width: 480px; height: 350px;\"></div>
			</td><td>
			<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
			<script type=\"text/javascript\">
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Hour');
				data.addColumn('number', 'Traffic (MB)');
				data.addRows(["
				RIGHE=$(echo -e "$HOURS_TRAFFIC" | wc -l | awk '{print $1}')
				for I in $(seq 1 $RIGHE);do
					RIGA=$( echo -e "$HOURS_TRAFFIC" | sed -n "${I}p")
					ORARIO=$(echo "$RIGA" | cut -d' ' -f1)
					TRAFFIC=$(echo "$RIGA" | cut -d' ' -f2)
					TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
					if [ "$I" != "$RIGHE" ];then
						echo "[ '$ORARIO', $TRAFFIC ],"
					else
						echo "[ '$ORARIO', $TRAFFIC ]"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div6'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div6\" style=\"width: 480px; height: 350px;\"></div>"
		fi
		if [ "$SSUB_SECTION" == "TOP_TEN" ];then
			USERUNIQ=$(cat $C_ZT_DIR/log/graphs/graphs | cut -d' ' -f10 | cut -d'-' -f2 | sort | uniq)
			USER_TIME=""
			USER_TRAFFIC=""
			for USER in $(echo -e $USERUNIQ);do
				USERTIME=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/user-$USER/ {if(\$1>da && \$1<db) print \$7}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				USERTIME=$(echo -e $USERTIME |  sed 's/ /+/g')
				USERTIME=$(echo -e $USERTIME | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				USERTRAFFIC=$(awk -v da=$DATA_IN -v db=$DATA_OUT "/user-$USER/ {if(\$1>da && \$1<db) print \$8}" $C_ZT_DIR/log/graphs/graphs | cut -d'-' -f2)
				USERTRAFFIC=$(echo -e $USERTRAFFIC |  sed 's/ /+/g')
				USERTRAFFIC=$(echo -e $USERTRAFFIC | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
				[ -z "$USERTIME" ] && USERTIME="0"
				[ -z "$USERTRAFFIC" ] && USERTRAFFIC="0"
				if [ -n "$USER_TIME" ];then
					USER_TIME=$(echo "$USER_TIME\n$USER $USERTIME")
				else
					USER_TIME=$(echo "$USER $USERTIME")
				fi
				if [ -n "$USER_TRAFFIC" ];then
					USER_TRAFFIC=$(echo "$USER_TRAFFIC\n$USER $USERTRAFFIC")
				else
					USER_TRAFFIC=$(echo "$USER $USERTRAFFIC")
				fi
			done
			if [ "$C_FORM_DATE" == "ita" ];then
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%d-%m-%Y %T")
			else
				DATA_AGG=$(date -d "1970-01-01 $SECUP sec" "+%Y-%m-%d %T")
			fi
			echo "<p>&nbsp;<p><font color=\"blue\" size=\"3\">Top Ten</font><br> <font color=\"blue\" size=\"2\">($L_UPDATED: $DATA_AGG)</font>"
			echo "<table><tr><td>
			<script type='text/javascript' src='https://www.google.com/jsapi'></script>
			<script type='text/javascript'>
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
                var data = new google.visualization.DataTable();
				data.addColumn('string', 'Username');
				data.addColumn('number', 'Hours');
				data.addRows(["
				FILE_SORT_TIME=$(echo -e "$USER_TIME" | sort -n -r -k2)
				RIGHE=$(echo -e "$USER_TIME" | wc -l | awk '{print $1}')
				if [ "$RIGHE" -lt 11 ];then
					NRIGHE=$RIGHE
				else
					NRIGHE=10
				fi
				for numero in $(seq 1 $NRIGHE); do
					RIGA="$(echo -e "$FILE_SORT_TIME" | sed -n "${numero}p")"
					USERNAME="$(echo "$RIGA" | cut -d' ' -f1)"
					ORE="$(echo "$RIGA" | cut -d' ' -f2)"
					ORE=$( echo "$ORE/3600" | $C_ZT_BIN_DIR/bc )
					[ "$ORE" == "0" ] && USERNAME=""
					if [ "$numero" == "10" ];then
						echo "[ '$USERNAME', $ORE ]"
					else
						echo "[ '$USERNAME', $ORE ],"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div7'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div7\" style=\"width: 480px; height: 350px;\"></div>
			</td><td>
			<script type='text/javascript' src='https://www.google.com/jsapi'></script>
			<script type='text/javascript'>
			google.load('visualization', '1', {packages:['corechart']});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Username');
				data.addColumn('number', 'Traffic (MB)');
				data.addRows(["
				FILE_SORT_TRAFFIC=$(echo -e "$USER_TRAFFIC" | sort -n -r -k2)
				RIGHE=$(echo -e "$USER_TRAFFIC" | wc -l | awk '{print $1}')
				if [ "$RIGHE" -lt 11 ];then
					NRIGHE=$RIGHE
				else
					NRIGHE=10
				fi
				for numero in $(seq 1 $NRIGHE); do
					RIGA="$(echo -e "$FILE_SORT_TRAFFIC" | sed -n "${numero}p")"
					USERNAME="$(echo "$RIGA" | cut -d' ' -f1)"
					TRAFFIC="$(echo "$RIGA" | cut -d' ' -f2)"
					TRAFFIC=$( echo "$TRAFFIC/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}' )
					[ "$TRAFFIC" == "0.00" ] && USERNAME=""
					if [ "$numero" == "10" ];then
						echo "[ '$USERNAME', $TRAFFIC ]"
					else
						echo "[ '$USERNAME', $TRAFFIC ],"
					fi
				done
				echo "]);
				var options = {
					title: '',
					hAxis: {title: '', titleTextStyle: {color: 'blue'}}
				};
				var chart = new google.visualization.ColumnChart(document.getElementById('chart_div8'));
				chart.draw(data, options);
			}
			</script>"
			echo "<div id=\"chart_div8\" style=\"width: 480px; height: 350px;\"></div>"
		fi
		echo "</td></tr></table>
		<table><tr><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_YEARS\"></form>
		</td><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"MONTHS\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_MONTHS\"></form>
		</td><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"DAYS\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_DAYS\"></form>
		</td><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"HOURS\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_HOURS\"></form>
		</td><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"TOP_TEN\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"Top Ten\"></form>
		</td><td>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_GRAPHS\">
		<input type=\"submit\" class=\"bottoneconf\" value=\"$L_MODIFY\"
		onClick=\"javascript:return confirm('$L_ALERT_UPDATE_GRAPHS');\"></form>
		</td></tr>
		</table><p>"
		[ -n "$C_GRAPH_DATA_IN" ] && GRAPH_DATA_IN=$(date -d "1970-01-01 $C_GRAPH_DATA_IN sec" "+%d/%m/%Y")
		[ -n "$C_GRAPH_DATA_OUT" ] && GRAPH_DATA_OUT=$(date -d "1970-01-01 $C_GRAPH_DATA_OUT sec" "+%d/%m/%Y")
		echo "<font color=\"blue\" size=\"3\">Range</font><br>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"$SSUB_SECTION\">
		<input type=\"text\" size=\"8\" name=\"GRAPH_DATA_IN\" id=\"datespan\" value=\"$GRAPH_DATA_IN\">
		<input type=\"text\" size=\"8\" name=\"GRAPH_DATA_OUT\" id=\"datespan1\" value=\"$GRAPH_DATA_OUT\"><p>
		<input type=\"submit\" name=\"RANGE\" class=\"bottonelinea\" value=\"Range\"></form>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"GRAPHS\">
		<input type=\"hidden\" name=\"SUB_SECTION\" value=\"CP\">
		<input type=\"hidden\" name=\"SSUB_SECTION\" value=\"$SSUB_SECTION\">
		<input type=\"submit\" name=\"GRAPHS_ALL\" class=\"bottonelineadue\" value=\"$L_ALL\"></form>
		<br><br><br>"
		./footer.sh
		exit
	fi
fi

if [ "$SECTION" == "UPDATE_GRAPHS" ];then
	if ! [ -d $C_ZT_DIR/log/graphs ];then
		$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/log/graphs"
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/log/graphs/graphs"
	wait "650" "$L_UPDATE_DATA"
	$C_ZT_BIN_DIR/zt "UPDATE_GRAPHS"
	return_page "config.sh?SECTION=GRAPHS&SUB_SECTION=CP"
	exit
fi

if [ "$SECTION" == "SMS" ];then
	echo "<font color=\"blue\" size=\"3\">SMS</font><br>&nbsp;<br>"
	if [ -n  "$UPDATECREDIT" ];then
		echo "<img src=\"/images/barra.png\" alt=\"barra\">"
		wait "650"
		$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$UPDATECREDIT"
		return_page "config.sh?SECTION=SMS"
		exit
	fi
	if [ "$C_SMS_PROVIDER" == "Gammu" ];then
		$C_ZT_BIN_DIR/zt "CheckKey"
	fi
	if [[ -n "$C_SMS_CREDIT" && "$C_SMS_PROVIDER" != "Gammu" && -z "$INSTALL_GAMMU" ]];then
		echo "<font color=\"blue\">($L_CREDIT: $C_SMS_CREDIT)</font><br>"
	fi
	if [[ "$C_SMS_PROVIDER" != "my_SMS_script" && "$C_SMS_PROVIDER" != "Gammu" && -n "$C_SMS_PROVIDER" && -z "$INSTALL_GAMMU" ]];then
		echo "<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
		<input type=\"hidden\" name=\"UPDATECREDIT\" value=\"$C_SMS_PROVIDER\">
		<input type=\"submit\"  class=\"bottone\" value=\"$L_UPDATE_CREDIT\"></form>"
	fi
	echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	if [ -n "$INSTALL_GAMMU" ];then
		if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
			echo "<br><font color=\"blue\">$L_ALERT_INSTALL</font>"
			wait "600"
			$C_ZT_BIN_DIR/zt "InstallGammu"
			if [ -f  $C_ZT_CONF_DIR/gammu.conf ];then
				return_page "config.sh?SECTION=SMS"
				exit
			else
				echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">Download Error</font><p>
				<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
				<form action=\"config.sh?SECTION=SMS\" method=\"POST\">
				<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
				</form>"
				exit
			fi
			./footer.sh
			exit
		else
			echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ZT</font><br>
			<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
			./footer.sh
			exit
		fi
	fi
	if [ -n "$CONF_SMS" ];then
		wait "575"
		for CONF in "SMS_ABIL" "SMS_SENDER" "SMS_USER" "SMS_PROVIDER" "SMS_PASSWORD" "SMS_NOT" "MY_NUMBER" "MY_CODE";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		if [ "$SMS_PROVIDER" == "Gammu" ];then
			$C_ZT_BIN_DIR/zt "ConfGammu" "$GAMMU_PORT" "$GAMMU_CONNECTION" "$SEND_SMS_GAMMU" "$SMS_ABIL"
			if [ -z "$SEND_SMS_GAMMU" ];then
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SMS_NOT" ""
			fi
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Gammu"
			POST_REGISTRATION="$(cat $C_CP_DIR/Auth/Custom/PostRegistration | cut -d'-' -f2 )"
			POST_REGISTRATION="Use MY_NUMBER and USERNAME into the post registration info if you use gammu -$POST_REGISTRATION"
			$C_ZT_BIN_DIR/zt "Salva" "$POST_REGISTRATION" "$C_CP_DIR/Auth/Custom/PostRegistration"
		else
			$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/Gammu"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AR_ONLY_SMS" ""
		fi
		return_page "config.sh?SECTION=SMS"
		exit
	fi
	if [ -n "$CONF_SCRIPT" ];then
		wait "600"
		return_page "config.sh?SECTION=SMS"
		exit
	fi
	echo "<form method=\"POST\" action=\"config.sh\">
	<table class=\"naked\">
	<tr><td>$L_ACTIVE_SERVICE:</td><td>"
	if [ "$C_SMS_ABIL" == "on" ];then
		echo "<input name=\"SMS_ABIL\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"SMS_ABIL\" type=\"checkbox\">"
	fi
	echo "<td>&nbsp;&nbsp;</td><td>
	$L_NOTIFICATION:</td><td>"
	if [ "$C_SMS_NOT" == "on" ];then
		echo "<input name=\"SMS_NOT\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"SMS_NOT\" type=\"checkbox\">"
	fi
	echo "</td></tr>
	<tr><td>$L_SERVICE: </td>"
	if [[ "$C_SMS_PROVIDER" != "Gammu" || -z "$C_SMS_PROVIDER" ]];then
		echo "<td><select name=\"SMS_PROVIDER\" onchange=\"viewgammu(this.options[this.selectedIndex].value,'gammuview','gammuviewone','gammuviewtwo')\">"
	fi
	if [ "$C_SMS_PROVIDER" == "Gammu" ];then
		echo "<td><select name=\"SMS_PROVIDER\" onchange=\"viewgammutwo(this.options[this.selectedIndex].value,'gammuview','gammuviewone','gammuviewtwo', 'gammuviewthree','gammuviewfour')\">"
	fi
	if [ -f $C_ZT_CONF_DIR/gammu.conf ];then
		SGAMMU="Gammu"
	fi
	for PROV in "skebby" "smsbiz" "mobyt_old" "mobyt_new" "smsglobal" "aimon" "subitosms" "my_SMS_script" "$SGAMMU";do
		if [ "$PROV" != "$C_SMS_PROVIDER" ];then
			echo "<option value=\"$PROV\">$PROV</option>"
		fi
	done
	echo "<option value=\"\"></option>
	<option value=\"$C_SMS_PROVIDER\" selected>$C_SMS_PROVIDER</option></select>"
	echo "<td>&nbsp;&nbsp;</td>"
	if [ "$C_SMS_PROVIDER" != "Gammu" ];then
		echo "<td>$L_SENDER: </td>
		<td><div id=\"gammuview\" style=\"display: block;\"><input type=\"text\" size=\"15\" name=\"SMS_SENDER\"  value=\"$C_SMS_SENDER\"></div></td>
		</tr><tr>
		<td>$L_USER_SMS: </td>
		<td><div id=\"gammuviewone\" style=\"display: block;\"><input type=\"text\" size=\"15\" name=\"SMS_USER\"  value=\"$C_SMS_USER\"></div></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_PASS_SMS: </td>
		<td><div id=\"gammuviewtwo\" style=\"display: block;\">
		<input type=\"password\" name=\"SMS_PASSWORD\"  size=\"15\" value=\"$C_SMS_PASSWORD\" id=\"pwd1\">
		&nbsp;<a href=\"#\" onclick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></div></td>"

	else
		GAMMU_PORT=$(cat $C_ZT_CONF_DIR/gammu.conf | grep '^port' | awk '{print $3}')
		GAMMU_CONNECTION=$(cat $C_ZT_CONF_DIR/gammu.conf | grep '^connection' | awk '{print $3}')
		GAMMU_LOGGING=$(cat $C_ZT_CONF_DIR/gammu.conf | grep '^logfile' | awk '{print $3}')
		echo "<td>$L_PORT: </td>
		<td><div id=\"gammuview\" style=\"display: block;\"><input type=\"text\" style=\"width:120px\" name=\"GAMMU_PORT\"  value=\"$GAMMU_PORT\"></div></td>
		</tr><tr>
		<td>$L_CONNECTION: </td>
		<td><div id=\"gammuviewone\" style=\"display: block;\">
		<select  name=\"GAMMU_CONNECTION\" style=\"width:120px\">"
		for GC in "at" "at115200" "at19200" "blueobex" "bluephonet" "bluerfat" "bluerfat" "dku2at" "dku2phonet" "dku5fbus" "fbus" "fbusdlr3" "fbuspl2303";do
			if [ "$GAMMU_CONNECTION" != "$GC" ];then
				echo "<option value=\"$GC\">$GC</option>"
			fi
		done
		echo "<option value=\"\"></option>
		<option value=\"$GAMMU_CONNECTION\" selected>$GAMMU_CONNECTION</option>"
		echo "</div></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_SEND_SMS: </td><td>
		<div id=\"gammuviewtwo\" style=\"display: block;\">"
		if [ -n "$C_SEND_SMS_GAMMU"  ];then
			echo "<input name=\"SEND_SMS_GAMMU\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"SEND_SMS_GAMMU\" type=\"checkbox\">"
		fi
		echo "</div></td></tr><tr>
		<td>$L_MY_NUMBER: + </td>
		<td><div id=\"gammuviewthree\" style=\"display: block;\"><input type=\"text\" size=\"15\" style=\"width:120px\" name=\"MY_NUMBER\"  value=\"$C_MY_NUMBER\"></div></td>
		<td>&nbsp;&nbsp;</td>
		<td>$L_MY_CODE: </td>
		<td><div id=\"gammuviewfour\" style=\"display: block;\"><input type=\"text\" style=\"width:120px\" size=\"15\" name=\"MY_CODE\"  value=\"$C_MY_CODE\"></div></td>"
	fi
	echo "</tr></table>"
	if [[ "$C_SMS_PROVIDER" == "Gammu" && -n "$C_SMS_ABIL" ]];then
		CONTROLG=$($C_ZT_BIN_DIR/zt "ControlGammu")
		echo "$CONTROLG"
	fi

	echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
	<p>"
	if ! [ -f $C_ZT_CONF_DIR/gammu.conf ];then
		echo "<input type=\"submit\" name=\"CONF_SMS\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
		<input type=\"submit\" name=\"INSTALL_GAMMU\" class=\"bottonelineadue\" value=\"$L_INSTALL Gammu\"
		onClick=\"javascript:return confirm('$L_ALERT_INSTALL_GAMMU');\"></form>"
	else
		echo "<input type=\"submit\" name=\"CONF_SMS\" class=\"bottone\" value=\"$L_SAVE\"></form>"

	fi
	echo "<p>"
	if [[ "$C_SMS_PROVIDER" == "Gammu" && -z "$(echo "$CONTROLG" | grep 'disabilita')" ]];then
		echo "$L_COMMAND_FROM_SMS"
		echo "<form method=\"POST\" action=\"config.sh\">
		<textarea name=\"EXEC_MY_SCRIPT\" rows=\"20\" cols=\"70\">$(cat $C_ZT_SCRIPTS_DIR/esec_from_sms.sh)</textarea><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
		<p><input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
	fi
	if [ "$C_SMS_PROVIDER" == "my_SMS_script" ];then
		echo "<form method=\"POST\" action=\"config.sh\">
		<textarea name=\"TEXT_MY_SCRIPT\" rows=\"20\" cols=\"70\">$(cat $C_ZT_SCRIPTS_DIR/my_SMS_script.sh)</textarea><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"SMS\">
		<p><input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
	fi
	./footer.sh
	exit
fi
if [ "$SECTION" == "EMAIL" ];then
	echo "<font color=\"#0000FF\" size=\"3\">$L_EMAIL</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	if [ -n "$CONF_EMAIL" ];then
		wait "650"
		for CONF in "EMAIL_ABIL" "EMAIL_NOT";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		$C_ZT_BIN_DIR/zt "Salva" "account $ACCOUNTEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "host $HOSTEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "auth $AUTHEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "port $PORTEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "user $USEREMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "password $PASSEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "auto_from $AUTO_FROMEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "from $FROMEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "AddMuttrc" "$FROMEMAIL"
		$C_ZT_BIN_DIR/zt "Aggiungi" "tls $TLSEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "tls_starttls $TLS_STARTTLSEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "tls_certcheck $TLS_CERTCHECKEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		$C_ZT_BIN_DIR/zt "Aggiungi" "syslog $SYSLOGEMAIL" "$C_ZT_CONF_DIR/msmtprc"
		return_page "config.sh?SECTION=EMAIL"
		exit
	fi
	if [ -n "$CONF_SCRIPT" ];then
		wait "650"
		return_page "config.sh?SECTION=EMAIL"
		exit
	fi
	ACCOUNTEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/account /p'| awk '{ print $2 }')
	HOSTEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/host /p'| awk '{ print $2 }')
	PORTEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/port /p'| awk '{ print $2 }')
	AUTHEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/auth /p'| awk '{ print $2 }')
	USEREMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/user /p'| awk '{ print $2 }')
	PASSEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/password /p'| awk '{ print $2 }')
	AUTO_FROMEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/auto_from /p'| awk '{ print $2 }')
	FROMEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/^from /p'| awk '{ print $2 }')
	TLSEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/^tls /p'| awk '{ print $2 }')
	TLS_STARTTLSEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/^tls_starttls /p'| awk '{ print $2 }')
	TLS_CERTCHECKEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/^tls_certcheck /p'| awk '{ print $2 }')
	SYSLOGEMAIL=$(cat $C_ZT_CONF_DIR/msmtprc | sed -n '/syslog/p'| awk '{ print $2 }')
	EMAIL_TEXT_NOT=$(cat $C_ZT_CONF_DIR/emailh)
	EMAIL_FOOTER_NOT=$(cat $C_ZT_CONF_DIR/emailf)
	echo "<form method=\"POST\" action=\"config.sh\">
	<table class=\"naked\">
		<tr>
			<td>$L_ACTIVE_SERVICE: </td><td>"
			if [ "$C_EMAIL_ABIL" == "on" ];then
				echo "<input name=\"EMAIL_ABIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"EMAIL_ABIL\" type=\"checkbox\">"
			fi
			echo "</td><td>&nbsp;&nbsp;</td>

			<td>$L_NOTIFICATION: </td><td>"
			if [ "$C_EMAIL_NOT" == "on" ];then
				echo "<input name=\"EMAIL_NOT\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"EMAIL_NOT\" type=\"checkbox\">"
			fi
			echo "</td>
		</tr><tr>
			<td>Account: </td>
			<td><input type=\"text\" name=\"ACCOUNTEMAIL\" size=\"18\" value=\"$ACCOUNTEMAIL\"></td>
			<td>&nbsp;&nbsp;</td>
			<td>Host: </td>
			<td><input type=\"text\" name=\"HOSTEMAIL\" size=\"18\" value=\"$HOSTEMAIL\"></td>
		</tr><tr>
			<td>Port: </td>
			<td><input type=\"text\" name=\"PORTEMAIL\" size=\"18\" value=\"$PORTEMAIL\"></td>
			<td>&nbsp;&nbsp;</td>
			<td>Auth: </td>
			<td><input type=\"text\" name=\"AUTHEMAIL\" size=\"18\" value=\"$AUTHEMAIL\"></td>
		</tr><tr>
			<td>User: </td>
			<td><input type=\"text\" name=\"USEREMAIL\" size=\"18\" value=\"$USEREMAIL\"></td>
			<td>&nbsp;&nbsp;</td>
			<td>$L_PASSWORD: </td>
			<td><input id=\"pwd\" size=\"18\" type=\"password\" name=\"PASSEMAIL\" value=\"$PASSEMAIL\">
			&nbsp;<a href=\"#\" onclick=\"hidden_password('pwd', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a>
			</td>
		</tr><tr>
			<td>Auto From: </td>
			<td><input type=\"text\" name=\"AUTO_FROMEMAIL\" size=\"18\" value=\"off\" readonly></td>
			<td>&nbsp;&nbsp;</td>
			<td>From: </td>
			<td><input type=\"text\" name=\"FROMEMAIL\" size=\"18\" value=\"$FROMEMAIL\"></td>
		</tr><tr>
			<td>Tls: </td>
			<td><input type=\"text\" name=\"TLSEMAIL\" size=\"18\" value=\"$TLSEMAIL\"></td>
			<td>&nbsp;&nbsp;</td>
			<td>Tls_starttls: </td>
			<td><input type=\"text\" name=\"TLS_STARTTLSEMAIL\" size=\"18\" value=\"$TLS_STARTTLSEMAIL\"></td>
		</tr><tr>
			<td>Tls_certcheck: </td>
			<td><input type=\"text\" name=\"TLS_CERTCHECKEMAIL\" size=\"18\" value=\"$TLS_CERTCHECKEMAIL\"></td>
			<td>&nbsp;&nbsp;</td>
			<td>Syslog: </td>
			<td><input type=\"text\" name=\"SYSLOGEMAIL\" size=\"18\" value=\"$SYSLOGEMAIL\"></td>
		</tr>
	</table>
	<p><input type=\"hidden\" name=\"SECTION\" value=\"EMAIL\">
	<input type=\"submit\" name=\"CONF_EMAIL\" class=\"bottone\" value=\"$L_SAVE\"></form><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form method=\"POST\" action=\"config.sh\"><p>
	<table>
		<tr>
			<td align=\"center\">$L_TEXT:<br>
			<textarea name=\"EMAIL_TEXT_NOT\" rows=\"8\" cols=\"30\">$EMAIL_TEXT_NOT</textarea></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</td>
			<td align=\"center\">$L_FOOTER:<br>
			<textarea name=\"EMAIL_FOOTER_NOT\" rows=\"8\" cols=\"30\">$EMAIL_FOOTER_NOT</textarea></td>
		</tr>
	</table>
	<p><input type=\"hidden\" name=\"SECTION\" value=\"EMAIL\">
	<input type=\"submit\" name=\"CONF_SCRIPT\" class=\"bottone\" value=\"$L_SAVE\"></form><br>"
	./footer.sh
	exit
fi
if [ "$SECTION" == "NOT_ADMIN" ];then
	echo "<font color=\"#0000FF\" size=\"3\">$L_NOTIFICATION_ADMIN</font><br>"
	if [ -n "$CONF_NOT_ADMIN" ];then
		wait "650"
		for CONF in "NOT_EMAIL_ADD_USER" "NOT_SMS_ADD_USER" "NOT_EMAIL_UPDATE_USER" "NOT_SMS_UPDATE_USER" "NOT_EMAIL_ADD_CLASS" \
			"NOT_SMS_ADD_CLASS" "NOT_EMAIL_UPDATE_CLASS" "NOT_SMS_UPDATE_CLASS" "NOT_EMAIL_MULTI_USERS" "NOT_SMS_MULTI_USERS" \
			"NOT_EMAIL_DELETE_USER" "NOT_SMS_DELETE_USER" "NOT_EMAIL_DELETE_CLASS" "NOT_SMS_DELETE_CLASS" "NOT_EMAIL_START_ZT" "NOT_SMS_START_ZT";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		return_page "config.sh?SECTION=NOT_ADMIN"
		exit
	fi
	if [[ -n "$C_EMAIL_ABIL" && -n "$C_ADMIN_EMAIL" ]] || [[ -n "$C_SMS_ABIL" && -n "$C_ADMIN_PHONE" ]];then
		echo "<form method=\"POST\" action=\"config.sh\">
		<table WIDTH=\"350\">
			<tr>
				<td></td><td align=\"center\">"
				[[ -n "$C_EMAIL_ABIL" && -n "$C_ADMIN_EMAIL" ]] && EM="Email"
				[[ -n "$C_SMS_ABIL" && -n "$C_ADMIN_PHONE" ]] && SM="SMS"
				echo "$EM</td><td align=\"center\">
				$SM</td></tr>"
				echo "<tr><td>$L_USERADD: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_ADD_USER" == "on" ];then
						echo "<input name=\"NOT_EMAIL_ADD_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_ADD_USER\" type=\"checkbox\">";
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_ADD_USER" == "on" ];then
						echo "<input name=\"NOT_SMS_ADD_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_ADD_USER\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_USERMULTI: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_MULTI_USERS" == "on" ];then
						echo "<input name=\"NOT_EMAIL_MULTI_USERS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_MULTI_USERS\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_MULTI_USERS" == "on" ];then
						echo "<input name=\"NOT_SMS_MULTI_USERS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_MULTI_USERS\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_USERUPDATE: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_UPDATE_USER" == "on" ];then
						echo "<input name=\"NOT_EMAIL_UPDATE_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_UPDATE_USER\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_UPDATE_USER" == "on" ];then
						echo "<input name=\"NOT_SMS_UPDATE_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_UPDATE_USER\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_USERDELETE: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_DELETE_USER" == "on" ];then
						echo "<input name=\"NOT_EMAIL_DELETE_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_DELETE_USER\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_DELETE_USER" == "on" ];then
						echo "<input name=\"NOT_SMS_DELETE_USER\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_DELETE_USER\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_CLASSADD: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_ADD_CLASS" == "on" ];then
						echo "<input name=\"NOT_EMAIL_ADD_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_ADD_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_ADD_CLASS" == "on" ];then
						echo "<input name=\"NOT_SMS_ADD_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_ADD_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_CLASS_UPDATE: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_UPDATE_CLASS" == "on" ];then
						echo "<input name=\"NOT_EMAIL_UPDATE_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_UPDATE_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_UPDATE_CLASS" == "on" ];then
						echo "<input name=\"NOT_SMS_UPDATE_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_UPDATE_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_CLASSDELETE: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_DELETE_CLASS" == "on" ];then
						echo "<input name=\"NOT_EMAIL_DELETE_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_DELETE_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_DELETE_CLASS" == "on" ];then
						echo "<input name=\"NOT_SMS_DELETE_CLASS\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_DELETE_CLASS\" type=\"checkbox\">"
					fi
				fi
				echo "</td>
			</tr><tr>
				<td>$L_START_ZT: </td><td align=\"center\">"
				if [ "$C_EMAIL_ABIL" == "on" ];then
					if [ "$C_NOT_EMAIL_START_ZT" == "on" ];then
						echo "<input name=\"NOT_EMAIL_START_ZT\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_EMAIL_START_ZT\" type=\"checkbox\">"
					fi
				fi
				echo "</td><td align=\"center\">"
				if [ "$C_SMS_ABIL" == "on" ];then
					if [ "$C_NOT_SMS_START_ZT" == "on" ];then
						echo "<input name=\"NOT_SMS_START_ZT\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"NOT_SMS_START_ZT\" type=\"checkbox\">"
					fi
				fi
					echo "</td>
				</tr>
		</table>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"NOT_ADMIN\">
		<p><input type=\"submit\" name=\"CONF_NOT_ADMIN\" class=\"bottone\" value=\"$L_SAVE\"></form><p>"
	else
		echo "<br><p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		[ -z "$C_EMAIL_ABIL" ] && ALERTND="$L_NO_SERVICE_EMAIL <br> "
		[ -z "$C_ADMIN_EMAIL" ] && ALERTND="$ALERTND $L_NO_EMAIL_ADMIN <br>"
		[ -z "$C_SMS_ABIL" ] && ALERTND="$ALERTND $L_NO_SERVICE_SMS <br> "
		[ -z "$C_ADMIN_PHONE" ] && ALERTND="$ALERTND $L_NO_PHONE_ADMIN"
		echo "<font color=\"red\" size=\"3\">$ALERTND</font><p>"
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	fi
	./footer.sh
	exit
fi
if [ "$SECTION" == "DROPBOX" ];then
	$C_ZT_BIN_DIR/zt "TokenDb"
	sleep 5
	TMPTOKEN="$(cat /tmp/tokendb | tail -1 | cut -d'=' -f3 )"
	echo "<br>&nbsp;<br>$L_CONFIRM_DB:<br>&nbsp;<br>
	<a href=\"https://www.dropbox.com/1/oauth/authorize?oauth_token=$TMPTOKEN\" target=\"_blank\">
	<img src=\"/images/dropbox.png\" alt=\"dropbox\"></a><br>&nbsp;<br>
	$L_CONFIRM_LOCAL<br>&nbsp;<br>"
	echo "<p><form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SECTION\" value=\"DROPBOX_ACCESS\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_CONTINUE\"></form><p>"
	./footer.sh
	exit
fi
if [ "$SECTION" == "DROPBOX_ACCESS" ];then
	wait "600"
	$C_ZT_BIN_DIR/zt "TokenAccessDb"
	return_page "config.sh?SECTION=BACKUP"
	exit
fi
if [ "$SECTION" == "BACKUP" ];then
	echo "<script>
	function viewkey() {
		var newwin=window.open(\"viewkey.sh\",\"viewkey\",\"top=200,left=100,width=1100,height=60,scrollbars=yes,menubar=no,toolbar=no,statusbar=no\");
		newwin.focus();
	}
	</script>"
	
	if [ -z "$STARTBK" ];then
		echo "<font color=\"#0000FF\" size=\"3\">$L_BACKUP</font><br>"
		if [ -n "$DELETEBK" ];then
			wait "650"
				$C_ZT_BIN_DIR/zt "DeleteBackupScp" "$DELETEBK"
				return_page "config.sh?SECTION=BACKUP&VIEW_BACKUP=yes"
			exit
		fi
		if [ -n "$RESTOREBK" ];then
			wait "650"
			$C_ZT_BIN_DIR/zt "DownloadBackupScp" "$RESTOREBK"
			return_page "config.sh?SECTION=BACKUP&STARTBK=yes&SCP=yes"
			exit
		fi
		if [ -n "$DOWNLOADSCP" ];then
			wait "650"
			valrandom 12
			$C_ZT_BIN_DIR/zt "DownloadBackupScp" "$DOWNLOADSCP" "DOWN_NOW" "BK_$VALRANDOM"
			return_page "config.sh?SECTION=BACKUP&VIEW_BACKUP=yes&DBK=$DOWNLOADSCP&DIR=BK_$VALRANDOM"
			exit
		fi
		if  [ -n "$VIEW_BACKUP" ];then
			if [ -n "$DELBK" ];then
				$C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_DIR/$DELBK"
			fi
			RBK="$($C_ZT_BIN_DIR/zt "RemoteBackup")"
			if [ "$RBK" != "no" ];then
				NRBK="$(echo -e "$RBK"  | wc -l)"
				#NRBK=$(grep -o "tgz" <<< "$RBK" | wc -l)
				echo "<br>REMOTE BACKUP ($C_IP_SCP_REMOTE)<br>&nbsp;"
				echo "<table class=\"tabellain\" width=\"460\" border=\"1\">
				<tr>
				<td width=\"20\" class=\"intesta\">N.</td>
				<td width=\"150\" class=\"intesta\">Backup</td>
				<td width=\"100\" class=\"intesta\">$L_DATE</td>
				<td width=\"100\" class=\"intesta\">$L_HOUR</td>
				<td width=\"60\" class=\"intesta\">MB</td>
				<td width=\"45\" colspan=\"3\"class=\"intesta\">AC.</td></tr>"
				for NB in $(seq 1 $NRBK);do
					MBBK="$(echo $RBK | cut -d' ' -f$NB  | cut -d'+' -f1)"
					TBK="$(echo $RBK | cut -d' ' -f$NB  | cut -d'+' -f2)"
					NAMEBK="$(echo $TBK | cut -d'-' -f1 )"
					DATABK="$(echo $TBK | cut -d '-' -f3 | cut -d'_' -f1)"
					DAYBK=${DATABK:0:2} 
					MONTHBK=${DATABK:2:2}
					YEARBK=${DATABK:4:4}
					if [ "$C_FORM_DATE" == "ita" ];then
						DATABK="$DAYBK/$MONTHBK/$YEARBK"
					else
						DATABK="$YEARBK/$MONTHBK/$MONTHBK"
					fi
					HOURCBK="$(echo $TBK | cut -d '-' -f3 | cut -d'_' -f2 | cut -d'.' -f1)"
					HOURBK=${HOURCBK:0:2} 
					MINUTEBK=${HOURCBK:2:2}
					SECBK=${HOURCBK:4:2}
					HOURBK="$HOURBK:$MINUTEBK:$SECBK"
					echo "<tr><td align=\"center\">$NB</td><td>&nbsp;$NAMEBK</td><td>&nbsp;$DATABK</td><td>&nbsp;$HOURBK</td><td>&nbsp;$MBBK</td>
					
					<td>
					<form method=\"POST\" action=\"config.sh\">
					<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
					<input type=\"hidden\" name=\"DELETEBK\" value=\"$TBK\">
					<input type=\"image\" class=\"image\" src=\"/images/action_x.png\" title=\"$L_DELETE Num: $NB\" 
					onClick=\"javascript:return confirm('$L_ALERT_REMOVE Backup N. $NB?');\"></form>
					</td>
					<td>
					<form method=\"POST\" action=\"config.sh\">
					<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
					<input type=\"hidden\" name=\"DOWNLOADSCP\" value=\"$TBK\">
					<input type=\"image\" class=\"image\" src=\"/images/download.png\" title=\"Download Backup Num: $NB\"></form>
					</td>
					<td>
					<form method=\"POST\" action=\"config.sh\">
					<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
					<input type=\"hidden\" name=\"RESTOREBK\" value=\"$TBK\">
					<input type=\"image\" class=\"image\" src=\"/images/restore.png\" title=\"$L_RESTORE_BACKUP Num: $NB\" 
					onClick=\"javascript:return confirm('$L_RESTORE_BACKUP  N. $NB?');\"></form>
					</td></tr>"
				done
				echo "</table>"
			else
				echo "<br>&nbsp;<br><font color=\"red\">$L_NO_BACKUP</font>"
			fi
			echo "<br><form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form><br>"
			./footer.sh
			if [ -n "$DBK" ];then
				echo "<script type=\"text/javascript\">window.location=\"/$DIR/$DBK\";</script>"
			fi
			
			exit
		fi
	fi
	if [ -n "$STARTBK" ];then
		echo "<font color=\"#0000FF\" size=\"3\">$L_RESTORE_BACKUP</font><br>"
		BK_FILE="$(ls $C_ZT_DIR/tmp/restorebk)"
		C_FILE="$(echo "$BK_FILE" | cut -d'-' -f1)"
		if [ "$(echo "$BK_FILE" | cut -d'-' -f2)" == "SCP" ];then
			C_DATE="$(echo "$BK_FILE" | cut -d'-' -f3 | cut -d'.' -f1 | cut -d'_' -f1 )"
		else
			C_DATE="$(echo "$BK_FILE" | cut -d'-' -f2 | cut -d'.' -f1 )"
			[ -n "$( echo $C_DATE | grep '_' )" ] && C_DATE="$(echo "$C_DATE" | cut -d'_' -f1)"
		fi
		if [ -n "$CONTINUE_BK" ];then
			if [ -n "$BK_DEL" ];then
				wait "650"
				[ -n "$BK_USERS" ] && BK_USERS="yes"
				[ -n "$BK_PROG" ] && BK_PROG="yes"
				[ -n "$BK_SESSIONS" ] && BK_SESSIONS="yes"
				[ -n "$BK_CLASSES" ] && BK_CLASSES="yes"
				[ -n "$BK_FREECLIENTS" ] && BK_FREECLIENTS="yes"
				[ -n "$BK_FREESERVICES" ] && BK_FREESERVICES="yes"
				[ -n "$BK_CONFIG" ] && BK_CONFIG="yes"
				$C_ZT_BIN_DIR/zt "DeleteDataBk" "$BK_USERS" "$BK_PROG" "$BK_SESSIONS" "$BK_CLASSES" "$BK_FREECLIENTS" "$BK_FREESERVICES"
				return_page "config.sh?SECTION=BACKUP&STARTBK=yes&CONTINUE_BK=yes&BK_USERS=$BK_USERS&BK_PROG=$BK_PROG&BK_SESSIONS=$BK_SESSIONS&BK_CLASSES=$BK_CLASSES&BK_CONFIG=$BK_CONFIG&BK_FREESERVICES=$BK_FREESERVICES&BK_FREECLIENTS=$BK_FREECLIENTS"
				exit
			fi
			if [ -n "$BK_USERS" ];then
				echo "<font color=\"#0000FF\" size=\"3\">$L_USERS</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td class=\"intesta\" WIDTH=\"10px\">N.</td>
				<td class=\"intesta\">$L_USERNAME</td>
				<td class=\"intesta\">$L_NAME</td>
				<td class=\"intesta\">$L_LAST_NAME</td>
				<td class=\"intesta\" WIDTH=\"80px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreUsers" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_PROG" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$L_PROGRAMMING</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td class=\"intesta\" WIDTH=\"10px\">N.</td>
				<td class=\"intesta\">$L_PROGRAMMING</td>
				<td class=\"intesta\" WIDTH=\"80px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreProg" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
				$C_ZT_BIN_DIR/zt "RestartCron"
			fi
			if [ -n "$BK_SESSIONS" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$L_SESSIONS</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td class=\"intesta\" WIDTH=\"10px\">N.</td>
				<td class=\"intesta\">$L_USER</td>
				<td class=\"intesta\">$L_SESSIONS</a></td>
				<td class=\"intesta\" WIDTH=\"80px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreSessions" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_CLASSES" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$L_CLASSES</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$L_CLASS</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreClasses" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_FREECLIENTS" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">Free Clients</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">Free Clients</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreFreeClients" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_FREESERVICES" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">Free Services</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">Free Services</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreFreeServices" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_CONFIG" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$L_CONFIG1</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$L_CONFIG1</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreConfig" "$BK_FILE"
				echo "</table><p>"
			fi
			if [ -n "$BK_USERS_LOG" ];then
				echo "<font color=\"#0000FF\" size=\"3\">$L_USERS</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\">$L_USERNAME</td>
				<td background=\"/images/imgtable.png\">$L_SESSION</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"80px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreUsersLog" "$BK_FILE" "$BK_DEL"
				echo "</table><p>"
			fi
			if [ -n "$BK_CONFIGMUDC" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$LM_CONFMUDC</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$LM_CONFMUDC</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreConfigMudc" "$BK_FILE"
				echo "</table><p>"
			fi
			if [ -n "$BK_PROGMUDC" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$LM_PROGMUDC</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$LM_PROGMUDC</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreProgMudc" "$BK_FILE"
				echo "</table><p>"
			fi
			if [ -n "$BK_GRAPHSMUDC" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$LM_GRAPHSMUDC</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$LM_GRAPHSMUDC</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreGraphsMudc" "$BK_FILE"
				echo "</table><p>"
			fi
			if [ -n "$BK_SESSIONSMUDC" ];then
				echo "<p><p><font color=\"#0000FF\" size=\"3\">$LM_SESSIONSMUDC</font><br>
				<table class=\"tabellain\" width=\"700\" border=\"1\"><tr>
				<td background=\"/images/imgtable.png\" WIDTH=\"10px\">N.</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"580px\">$LM_SESSIONSMUDC</td>
				<td background=\"/images/imgtable.png\" WIDTH=\"110px\">$L_STATUS</a></td></tr>"
				$C_ZT_BIN_DIR/zt "RestoreSessionsMudc" "$BK_FILE"
				echo "</table><p>"
			fi
			echo "<p><form method=\"POST\" action=\"config.sh\">
			<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
			<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form><p>"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/restorebk"
			echo "<br>"
			./footer.sh
			exit
		fi
		$C_ZT_BIN_DIR/zt "OpenBk" "$BK_FILE"
		if [[ -z "$C_DATE" || "$(cat $C_ZT_DIR/tmp/restorebk/*/version)" != "$(cat $C_ZT_CONF_DIR/version)" ]];then
			$C_ZT_BIN_DIR/zt "Errore" "$L_BACKUP_NOT_VALID" "config.sh?SECTION=BACKUP"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/restorebk/*"
			exit
		fi
		echo "<form method=\"POST\" action=\"config.sh\">
		<table WIDTH=\"250\">"
		if [ -f $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/ldap_ldif ];then
			echo "<tr><td>$L_USERS: </td><td align=\"right\">
			<input name=\"BK_USERS\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/prog ];then
			for PROGDIR in $(ls $C_SYSTEM/startup/scripts/);do
				if [[ "$PROGDIR" != "ZTcontrolore-Cron" && "$PROGDIR" != "ZTrestartored-Cron" && "$PROGDIR" != "ZTrestartorem-Cron" ]];then
					CONTROLPROG="yes"
				fi
			done
			if [ "$CONTROLPROG" == "yes" ];then
				echo "<tr><td>$L_PROGRAMMING: </td><td align=\"right\">
				<input name=\"BK_PROG\" type=\"checkbox\">
				</td></tr>"
			fi
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/sessions ];then
			echo "<tr><td>$L_SESSIONS: </td><td align=\"right\">
			<input name=\"BK_SESSIONS\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/classes ];then
			echo "<tr><td>$L_CLASSES: </td><td align=\"right\">
			<input name=\"BK_CLASSES\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/FreeClients ];then
			echo "<tr><td>Free Clients: </td><td align=\"right\">
			<input name=\"BK_FREECLIENTS\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/FreeServices ];then
			echo "<tr><td>Free Services: </td><td align=\"right\">
			<input name=\"BK_FREESERVICES\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/conf ];then
			echo "<tr><td>$L_CONFIGURATION: </td><td align=\"right\">
			<input name=\"BK_CONFIG\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/mudcconf ];then
			echo "<tr><td>$LM_CONFMUDC: </td><td align=\"right\">
			<input name=\"BK_CONFIGMUDC\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/mudcprog ];then
			echo "<tr><td>$LM_PROGMUDC: </td><td align=\"right\">
			<input name=\"BK_PROGMUDC\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/mudcgraphs ];then
			echo "<tr><td>$LM_GRAPHSMUDC: </td><td align=\"right\">
			<input name=\"BK_GRAPHSMUDC\" type=\"checkbox\">
			</td></tr>"
		fi
		if [ -d $C_ZT_DIR/tmp/restorebk/backup_$C_DATE/mudcsessions ];then
			echo "<tr><td>$LM_SESSIONSMUDC: </td><td align=\"right\">
			<input name=\"BK_SESSIONSMUDC\" type=\"checkbox\">
			</td></tr>"
		fi
		echo "<tr><td>$L_DELETE_EXISTING_DATA: </td><td align=\"right\">
		<input name=\"BK_DEL\" type=\"checkbox\">
		</td></tr></table><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
		<input type=\"hidden\" name=\"STARTBK\" value=\"OK\">
		<input type=\"submit\" name=\"CONTINUE_BK\" class=\"bottone\" value=\"$L_CONTINUE\"></form>"
		./footer.sh
		exit
	fi
	if [ -n "$CONF_BK" ];then
		wait "650"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_SYSTEM/logs/Auto/Delete"
		for CONF in "BK_EMAIL" "BK_FTP" "BK_DB" "BK_SCP" "SERVER_FTP" "USER_FTP" "PASSWORD_FTP" "DIR_FTP" "BK_USERS" "BK_DELETED_USERS" \
		"BK_PROG" "BK_CONFIG" "BK_SESSIONS" "BK_TIME" "BK_CLASSES" "BK_SLAPCAT" "BK_FREECLIENTS" "BK_FREESERVICES" "BK_DELETE_USERS" "APP_KEY_DB" "APP_SECRET_DB" "REMOTE_DIR_DB" \
		"ACCESS_LEVEL_DB"  "BK_LOGS" "BK_DELETE_LOGS" "IP_SCP_REMOTE" "DIR_SCP_REMOTE" "USER_SCP_REMOTE";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
			if [ "$CONF" == "BK_TIME" ];then
				TIMECRON="${!CONF}"
			fi
		done
		if [ -d $C_ZT_DIR/mudc ];then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_BK_CONFMUDC" "$BK_CONFMUDC"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_BK_PROGMUDC" "$BK_PROGMUDC"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_BK_GRAPHSMUDC" "$BK_GRAPHSMUDC"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_BK_SESSIONSMUDC" "$BK_SESSIONSMUDC"
		fi
		if [[ -n "$DIR_FTP" || -n "$REMOTE_DIR_DB" || -n "$DIR_SCP_REMOTE" ]];then
			$C_ZT_BIN_DIR/zt "ControlSlash"
		fi
		$C_ZT_BIN_DIR/zt "CronBk" "$TIMECRON"
		$C_ZT_BIN_DIR/zt "RestartCron"
		if [[ -n "$APP_KEY_DB" && -n "$APP_SECRET_DB"  ]];then
			if [ -z "$C_TOKEN_DB" ];then
				return_page "config.sh?SECTION=DROPBOX"
				exit
			fi
		else
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_TOKEN_DB" ""
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_TOKEN_SECRET_DB" ""
		fi
		if [ -z "$CM_REMOTESAVE" ];then
			if [[ -n "$BK_SCP" && -n "$IP_SCP_REMOTE" &&  -n "$DIR_SCP_REMOTE" && -n "$USER_SCP_REMOTE" ]];then
				$C_ZT_BIN_DIR/zt "CreateKeyScp"
			else
				$C_ZT_BIN_DIR/zt "RemoveKeyScp"
			fi	
		fi
		return_page "config.sh?SECTION=BACKUP"
		exit
	fi
	if [ -n "$SEND_NOW" ];then
		if [[ -n "$C_BK_EMAIL" && -z "$C_ADMIN_EMAIL" ]];then
			$C_ZT_BIN_DIR/zt "Errore" "$L_NO_EMAIL_ADMIN" "config.sh?SECTION=BACKUP"
			exit
		fi
		if [ -n "$C_BK_FTP" ] && [[ -z "$C_SERVER_FTP" || -z "$C_USER_FTP" || -z "$C_PASSWORD_FTP" || -z "$C_DIR_FTP" ]];then
			$C_ZT_BIN_DIR/zt "Errore" "$L_NO_FTP_DATA" "config.sh?SECTION=BACKUP"
			exit
		fi
		if [[ -n "$C_BK_EMAIL" || -n "$C_BK_FTP" || -n "$C_BK_DB" || -n "$C_BK_SCP" ]];then
			wait "650"
			$C_ZT_BIN_DIR/zt "BkNow"
			return_page "config.sh?SECTION=BACKUP"
			exit
		else
			$C_ZT_BIN_DIR/zt "Errore" "ERROR" "config.sh?SECTION=BACKUP"
		fi
		
	fi
	if [ -n "$DOWNLOAD_NOW" ];then
		wait "650"
		valrandom 12
		$C_ZT_BIN_DIR/zt "BkDownload" "BK_$VALRANDOM"
		return_page "config.sh?SECTION=BACKUP&LINK=ok&DIR=BK_$VALRANDOM"
		exit
	fi
	if [ -n "$RESULT_BK" ];then
		if [ $(ls $C_ZT_DIR/tmp | grep backup) ];then
			echo "<p>"
			$C_ZT_BIN_DIR/zt "Errore" "$L_BACKUP_NOT_SENT" "config.sh?SECTION=BACKUP"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/backup_*"
		else
			echo "<p>"
			$C_ZT_BIN_DIR/zt "ControlOk" "$L_BACKUP_SENT" "config.sh?SECTION=BACKUP"
		fi
		exit
	fi
	echo "<br><font color=\"blue\">$L_SEND_WITH</font><br>
	<form method=\"POST\" action=\"config.sh\">
	<table WIDTH=\"490px\"><tr><td width=\"70\" align=\"right\">"
	if [ -n "$C_EMAIL_ABIL" ] && [ -n "$C_ADMIN_EMAIL" ];then
		echo "$L_EMAIL:</td><td width=\"70\" align=\"left\">"
		if [ -n "$C_BK_EMAIL" ];then
			echo "<input name=\"BK_EMAIL\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"BK_EMAIL\" type=\"checkbox\">"
		fi
	else
		echo "$L_EMAIL:</td><td width=\"70\" align=\"left\">&nbsp;"
	fi
	echo "</td><td width=\"70\"align=\"right\">FTP:</td><td width=\"70\"align=\"left\">"
	if [ -n "$C_BK_FTP" ];then
		echo "<input name=\"BK_FTP\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"BK_FTP\" type=\"checkbox\">"
	fi
	echo "</td><td width=\"70\"align=\"right\">Dropbox:</td><td width=\"70\"align=\"left\">"
	if [ -n "$C_BK_DB" ];then
		echo "<input name=\"BK_DB\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"BK_DB\" type=\"checkbox\">"
	fi
	echo "</td><td width=\"70\"align=\"right\">SCP:</td>"
	if [ -n "$C_BK_SCP" ];then
		echo "<td width=\"250\"align=\"left\"><input name=\"BK_SCP\" type=\"checkbox\" checked=\"checked\">"
		if [ "$($C_ZT_BIN_DIR/zt "Checkidrsa")" == "yes" ];then
			echo "<a href=\"javascript:viewkey()\">SSH Key</a>"
		fi
	else
		echo "<td width=\"70\"align=\"left\"><input name=\"BK_SCP\" type=\"checkbox\">"
	fi
	echo "</td></tr>
	</table><br>"
	[ -z "$C_EMAIL_ABIL" ] && ALERTBK="$L_NO_SERVICE_EMAIL <br> "
	[ -z "$C_ADMIN_EMAIL" ] && ALERTBK="$ALERTBK $L_NO_EMAIL_ADMIN"
	echo "<font color=\"red\" size=\"3\">$ALERTBK</font><p>"
	if [[ -n "$C_BK_FTP" || -n "$C_BK_DB" || -n "$C_BK_SCP" ]];then
		if [[  -n "$C_BK_FTP" && -n "$C_BK_DB" ]];then
			echo "<table><tr><td>"
		fi
		if [ -n "$C_BK_FTP" ];then
			echo "<table><tr>
			<td colspan=\"2\" align=\"center\">FTP</td></tr>
			<tr><td>Server FTP: </td>
			<td><input type=\"text\" name=\"SERVER_FTP\"  value=\"$C_SERVER_FTP\" ></td></tr>
			<tr><td>Password FTP: </td>
			<td><input id=\"pwd1\" type=\"password\" name=\"PASSWORD_FTP\" value=\"$C_PASSWORD_FTP\"> &nbsp;
			<a href=\"#\" onclick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a>
			</td></tr>
			<tr><td>User FTP: </td>
			<td><input type=\"text\" name=\"USER_FTP\" value=\"$C_USER_FTP\"></td></tr>
			<tr><td>Directory FTP: </td>
			<td><input type=\"text\" name=\"DIR_FTP\" value=\"$C_DIR_FTP\" ></td></tr>
			</table>"
		fi
		if [[  -n "$C_BK_FTP" && -n "$C_BK_DB" ]];then
			echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>"
			fi
		if [ -n "$C_BK_DB" ];then
			echo "<table><tr>
			<td colspan=\"2\" align=\"center\">Dropbox</td></tr>
			<tr><td>App Key: </td>
			<td><input type=\"text\" name=\"APP_KEY_DB\"  value=\"$C_APP_KEY_DB\" ></td></tr>
			<tr><td>App Secret: </td>
			<td><input id=\"pwd2\" type=\"password\" name=\"APP_SECRET_DB\" value=\"$C_APP_SECRET_DB\"> &nbsp;
			<a href=\"#\" onclick=\"hidden_password('pwd2', 'show' , 'hide' , '2');\" id=\"showhide2\"><img src=\"/images/show.png\" alt=\"show\"></a>
			</td></tr>
			<tr><td>Remote Directory: </td>
			<td><input type=\"text\" name=\"REMOTE_DIR_DB\" value=\"$C_REMOTE_DIR_DB\" ></td></tr>
			<tr><td>Access Level: </td>
			<td><input type=\"text\" name=\"ACCESS_LEVEL_DB\" value=\"dropbox\" readonly=\"readonly\"></td></tr>
			</table>"
		fi
		if [[  -n "$C_BK_FTP" && -n "$C_BK_DB" ]];then
			echo "</td></tr></table>"
		fi
		if [  -n "$C_BK_SCP" ];then
			if [[  -n "$C_BK_FTP" || -n "$C_BK_DB" ]];then
				echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
			fi
			echo "SCP"
			if [ -z "$CM_REMOTESAVE" ];then
				if [ "$($C_ZT_BIN_DIR/zt "StatusSSC")" == "yes" ];then
					echo "<img src=\"/images/abilita.png\">"
					CS="yes"
				else
					echo "<img src=\"/images/disabilita.png\">"
				fi
			else
				if [ "$($C_ZT_BIN_DIR/zt "mudc" "Motion" "RemoteControl")" == "yes" ];then
					echo " MUDC <img src=\"/images/abilita.png\">"
					CS="yes"
					$C_ZT_BIN_DIR/zt "SalvaConfig" "C_USER_SCP_REMOTE" "$CM_USERSCP"
					$C_ZT_BIN_DIR/zt "SalvaConfig" "C_IP_SCP_REMOTE" "$CM_IPSERVERSCP"
					$C_ZT_BIN_DIR/zt "SalvaConfig" "C_DIR_SCP_REMOTE" "mudc\/backup"
				else
					echo "<img src=\"/images/disabilita.png\">"
				fi
			fi
			if [ -z "$CM_REMOTESAVE" ];then
				echo "<br>&nbsp;<br>USER Remote: <input type=\"text\" name=\"USER_SCP_REMOTE\"  value=\"$C_USER_SCP_REMOTE\">
				<br>&nbsp;<br>IP Remote: <input type=\"text\" name=\"IP_SCP_REMOTE\"  value=\"$C_IP_SCP_REMOTE\">
				&nbsp;&nbsp;&nbsp;&nbsp;Directory Remote: <input type=\"text\" name=\"DIR_SCP_REMOTE\"  value=\"$C_DIR_SCP_REMOTE\">"
			fi
			if [ -n "$CS" ];then
				echo "<br>&nbsp;<br>
				<a href=\"config.sh?SECTION=BACKUP&amp;VIEW_BACKUP=yes\"><input type=\"button\" name=\"VIEW_BACKUP\" class=\"bottone\" value=\"$L_VIEW_BACKUP\"></a>"
			fi
		fi
	fi
	DULADAP=$($C_ZT_BIN_DIR/zt "TmpSlap")
	echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<br><font color=\"blue\">$L_BACKUP</font><br>
	<table WIDTH=\"600px\">
	<tr><td WIDTH=\"250px\">&nbsp;</td><td WIDTH=\"50px\">&nbsp;<td WIDTH=\"250px\">&nbsp;</td><td WIDTH=\"50px\">&nbsp;</td></tr>
		<tr>
			<td height=\"30\">Slapcat: </td><td align=\"left\">"
			if [ "$C_BK_SLAPCAT" == "on" ];then
				echo "<input name=\"BK_SLAPCAT\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_SLAPCAT\" type=\"checkbox\">"
			fi
			echo "</td>
			<td height=\"30\">$L_USERS ($DULADAP): </td><td align=\"left\">"
			if [ "$C_BK_USERS" == "on" ];then
				echo "<input name=\"BK_USERS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_USERS\" type=\"checkbox\">"
			fi
			echo "</td>
		</tr><tr>
		<td height=\"30\">$L_USERS_DELETED ($(echo "$(du -h $C_ZT_DIR/deleted | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_DELETED_USERS" == "on" ];then
				echo "<input name=\"BK_DELETED_USERS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_DELETED_USERS\" type=\"checkbox\">"
			fi
			echo "</td>
			<td height=\"30\">$L_PROGRAMMING ($(echo "$(du -h $C_CRON_SCRIPTS_DIR | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_PROG" == "on" ];then
				echo "<input name=\"BK_PROG\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_PROG\" type=\"checkbox\">"
			fi
			echo "</td>
			</tr><tr>
			<td height=\"30\">$L_CONFIGURATION ($(echo "$(du -h $C_ZT_DIR/conf | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_CONFIG" == "on" ];then
				echo "<input name=\"BK_CONFIG\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_CONFIG\" type=\"checkbox\">"
			fi
			echo "</td>
			<td height=\"30\">$L_SESSIONS ($(echo "$(du -h $C_ACCT_DIR/entries | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_SESSIONS" == "on" ];then
				echo "<input name=\"BK_SESSIONS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_SESSIONS\" type=\"checkbox\">"
			fi
			echo "</td>
		</tr><tr>
			<td height=\"30\">$L_CLASSES ($(echo "$(du -h $C_ACCT_DIR/classes | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_CLASSES" == "on" ];then
				echo "<input name=\"BK_CLASSES\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_CLASSES\" type=\"checkbox\">"
			fi
			echo "</td>
			<td height=\"30\">Free Clients ($(echo "$(du -h $C_CP_DIR/FreeClients | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_FREECLIENTS" == "on" ];then
				echo "<input name=\"BK_FREECLIENTS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_FREECLIENTS\" type=\"checkbox\">"
			fi
			echo "</td>
			</tr><tr>
			<td height=\"30\">Free Services ($(echo "$(du -h $C_CP_DIR/FreeServices | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_FREESERVICES" == "on" ];then
				echo "<input name=\"BK_FREESERVICES\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_FREESERVICES\" type=\"checkbox\">"
			fi
			echo "</td>"
			ZT_LOG="$(du -h /Database/LOG/ | tail -1 | awk '{print $1}')"
			echo "<td height=\"30\">Logs ($(echo "$(du -h /Database/LOG/ | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
			if [ "$C_BK_LOGS" == "on" ];then
				echo "<input name=\"BK_LOGS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_LOGS\" type=\"checkbox\">"
			fi
			echo "</td>
		</tr><tr>"
			if [ -d $C_ZT_DIR/mudc ];then
				echo "<td height=\"30\">$LM_CONFMUDC ($(echo "$(du -h $C_ZT_DIR/mudc/conf/ | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
				if [ "$C_BK_CONFMUDC" == "on" ];then
					echo "<input name=\"BK_CONFMUDC\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"BK_CONFMUDC\" type=\"checkbox\">"
				fi
				echo "</td>"
				echo "<td height=\"30\">$LM_PROGMUDC ($(echo "$(du -h $C_ZT_DIR/mudc/data/Prog | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
				if [ "$C_BK_PROGMUDC" == "on" ];then
					echo "<input name=\"BK_PROGMUDC\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"BK_PROGMUDC\" type=\"checkbox\">"
				fi
				echo "</td></tr><tr>
				
				<td height=\"30\">$LM_GRAPHSMUDC ($(echo "$(du -h $C_ZT_DIR/mudc/data/Graphs | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
				if [ "$C_BK_GRAPHSMUDC" == "on" ];then
					echo "<input name=\"BK_GRAPHSMUDC\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"BK_GRAPHSMUDC\" type=\"checkbox\">"
				fi
				echo "</td>"
				echo "<td height=\"30\">$LM_SESSIONSMUDC ($(echo "$(du -h $C_ZT_DIR/mudc/data/Sessions | tail -1 | awk '{print $1}')")): </td><td align=\"left\">"
				if [ "$C_BK_SESSIONSMUDC" == "on" ];then
					echo "<input name=\"BK_SESSIONSMUDC\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"BK_SESSIONSMUDC\" type=\"checkbox\">"
				fi
				echo "</td><tr>"
			fi
			echo "<td colspan=\"4\" align=\"center\" height=\"30\"><font color=\"#0000FF\" size=\"3\">$L_AFTER_BK</font></td>
		</tr><tr>"
			echo "<td height=\"30\">$L_BK_DELETE_ZS: </td><td align=\"left\">"
			if [ "$C_BK_DELETE_LOGS" == "on" ];then
				echo "<input name=\"BK_DELETE_LOGS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_DELETE_LOGS\" type=\"checkbox\">"
			fi
			echo "</td>
			<td height=\"30\">$L_BK_DELETE_USERS: </td><td align=\"left\">"
			if [ "$C_BK_DELETE_USERS" == "on" ];then
				echo "<input name=\"BK_DELETE_USERS\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"BK_DELETE_USERS\" type=\"checkbox\">"
			fi
			echo "</td>
		</tr><tr>
			<td colspan=\"4\" align=\"center\" height=\"30\"><font color=\"#0000FF\" size=\"3\">$L_SENDS</font></td>
		</tr><tr>
			<td colspan=\"2\" align=\"right\" height=\"30\">$L_SENDS_EVERY:&nbsp;&nbsp;</td><td colspan=\"4\" align=\"left\" >
			&nbsp;&nbsp;<select name=\"BK_TIME\">"
			for TBK in "1 $L_DAY" "2 $L_WEEK" "3 $L_MONTH";do
				set -- $TBK
				if [ "$C_BK_TIME" != $1 ] || [ -z "$C_BK_TIME" ];then
					echo "<option value=\"$1\">$2</option>"
				else
					C_BK_TIMEN=$1
					C_BK_TIME=$2
				fi
			done
			echo "<option value=\"\"></option>
			<option value=\"$C_BK_TIMEN\" selected>$C_BK_TIME</option></select>
			</td>
		</tr></table>
		<p><input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
		<input type=\"submit\" name=\"CONF_BK\" class=\"bottonelineatre\" value=\"$L_SAVE\"></form>
		<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
		<input type=\"submit\" name=\"SEND_NOW\" class=\"bottonelineadue\" value=\"$L_SENDS_NOW\"></form>
		<form method=\"POST\" action=\"config.sh\">
		<input type=\"hidden\" name=\"SECTION\" value=\"BACKUP\">
		<input type=\"submit\" name=\"DOWNLOAD_NOW\" class=\"bottonelineadue\" value=\"Download\"></form>
		<p>"
	if [ ! -d /$C_ZT_DIR/tmp/restorebk ];then
		$C_ZT_BIN_DIR/zt "CreaCartellaBk" "$C_ZT_DIR/tmp/restorebk"
	else
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/restorebk/*"
	fi
	echo "<br>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<font color=\"blue\" size=\"3\">$L_RESTORE_BACKUP</font><p>
	<form action=\"./scripts/upload\" method=\"post\" enctype=\"multipart/form-data\">
		<input type=\"hidden\" name=\"config\" value=\"Backup\">
		<input type=\"file\" name=\"imagetest\" size=\"20\">
		<br><br>
		<input name=\"bk\" type=\"submit\" class=\"bottone\" value=\"$L_UPLOAD_BACKUP\">
	</form><br>"
	if [ -n "$LINK" ];then
		FILE_DOWNLOAD=$(ls $C_HTDOCS_DIR/$DIR/*.tgz | cut -d'/' -f6)
		echo "<script type=\"text/javascript\">window.location=\"/$DIR/$FILE_DOWNLOAD\";</script>"
	fi
	./footer.sh
	exit
fi
if [ "$SECTION" == "DISK" ];then
	echo "<font color=\"#0000FF\" size=\"3\">DISK</font>"
	if [ -n "$CONF_DISK" ];then
		wait "650"
		for CONF in "DISK_NOTIFY" "DISK_SEND" "DISK_LIMIT" "DISK_DELETE_CACHE" "DISK_DELETE_ZS_LOG";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		return_page "config.sh?SECTION=DISK"
		exit
	fi
	SIZE=$(df -h | grep "Database" | awk '{ print $2 }')
	USED=$(df -h | grep "Database" | awk '{ print $3 }')
	AVAILABLE=$(df -h | grep "Database" | awk '{ print $4 }')
	PERC=$(df -h | grep "Database" | awk '{ print $5 }')
	echo "<br><font color=\"#0000FF\" size=\"3\">(Hard Disk $L_SIZE: $SIZE - $L_USED: $USED ($PERC) - $L_AVAILABLE: $AVAILABLE)</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	if [ "$C_EMAIL_ABIL" == "on" ] && [ -n "$C_ADMIN_EMAIL" ] || [ "$C_SMS_ABIL" == "on" ] && [ -n "$C_ADMIN_PHONE" ];then
		echo "<form method=\"POST\" action=\"config.sh\">
		<table WIDTH=\"350\">
			<tr>
				<td height=\"30\">$L_DISK_NOTIFY: </td><td align=\"right\">"
				if [ "$C_DISK_NOTIFY" == "on" ];then
					echo "<input name=\"DISK_NOTIFY\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DISK_NOTIFY\" type=\"checkbox\">"
				fi
				echo "</td>
			</tr><tr>
				<td height=\"30\">$L_DISK_SEND: </td><td align=\"right\">
				<select name=\"DISK_SEND\" style=\"width:80px\">"
				for NOTBK in "SMS" "EMAIL";do
					if [ "$C_DISK_SEND" != "$NOTBK" ];then
						echo "<option value=\"$NOTBK\">$NOTBK</option>"
					fi
				done
				echo "<option value=\"\"></option>
				<option value=\"$C_DISK_SEND\" selected>$C_DISK_SEND</option>
				</select>
				</td>
			</tr><tr>
				<td height=\"30\">$L_DISK_LIMIT (MB): </td><td align=\"right\">
				<input type=\"text\" style=\"width:80px\" name=\"DISK_LIMIT\" value=\"$C_DISK_LIMIT\"></td>
			</tr><tr>
				<td colspan=\"2\" align=\"center\" height=\"30\"><font color=\"blue\">$L_AND</font></td>
			</tr><tr>"
				if [ -f $C_ZT_PROXY_DIR/sbin/squid ];then
					echo "<td height=\"30\">$L_DISK_DELETE_SQUID_CACHE: </td><td align=\"right\">"
					if [ "$C_DISK_DELETE_CACHE" == "on" ];then
						echo "<input name=\"DISK_DELETE_CACHE\" type=\"checkbox\" checked=\"checked\">"
					else
						echo "<input name=\"DISK_DELETE_CACHE\" type=\"checkbox\">"
					fi
						echo "</td></tr><tr>"
				fi
				echo "<td height=\"30\">$L_BK_DELETE_ZS: </td><td align=\"right\">"
				if [ "$C_DISK_DELETE_ZS_LOG" == "on" ];then
					echo "<input name=\"DISK_DELETE_ZS_LOG\" type=\"checkbox\" checked=\"checked\">"
				else
					echo "<input name=\"DISK_DELETE_ZS_LOG\" type=\"checkbox\">"
				fi
				echo "</td>
			</tr>
		</table><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"hidden\" name=\"SECTION\" value=\"DISK\">
		<input type=\"submit\" name=\"CONF_DISK\" class=\"bottone\" value=\"$L_SAVE\">
		</form><br>&nbsp;"
	else
		[ -z "$C_EMAIL_ABIL" ] && ALERTCD="$L_NO_SERVICE_EMAIL <br> "
		[ -z "$C_ADMIN_EMAIL" ] && ALERTCD="$ALERTCD $L_NO_EMAIL_ADMIN <br>"
		[ -z "$C_SMS_ABIL" ] && ALERTCD="$ALERTCD $L_NO_SERVICE_SMS <br> "
		[ -z "$C_ADMIN_PHONE" ] && ALERTCD="$ALERTCD $L_NO_PHONE_ADMIN"
		echo "<font color=\"red\" size=\"3\">$ALERTCD</font><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	fi
	./footer.sh
	exit
fi
if [ "$SECTION" == "UPGRADE_ZT" ];then
	echo "<p><font color=\"blue\">ZEROTRUTH UPGRADE</font><p>
	<form action=\"config.sh\" method=\"POST\">
	<table><tr>
	<td>$L_DELETE_CONFIG: </td>
	<td><input name=\"DEL_CONFIG\" type=\"checkbox\"></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td>$L_DELETE_USERS: </td>
	<td><input name=\"DEL_USERS\" type=\"checkbox\"></td></tr>
	</table><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"hidden\" name=\"UPGRADE_VERSION\" value=\"$UPGRADE_VERSION\">
	<input type=\"hidden\" name=\"SECTION\" value=\"UPGRADE_ZT_OK\">
	<input type=\"submit\" class=\"bottone\" value=\"Upgrade\"
	onClick=\"javascript:return confirm('$L_ALERT_UPDATE');\"></form>"
	./footer.sh
	exit
fi
if [ "$SECTION" == "UPGRADE_ZT_OK" ];then
	echo "<p><font color=\"blue\">ZEROTRUTH UPGRADE</font><p>"
	wait "600"
	NEW_VERSION=$(echo "$UPGRADE_VERSION" | sed 's/zerotruth-//g' | sed 's/.tar.gz//g')
	$C_ZT_BIN_DIR/zt "Cancella" "/tmp/upgrade"
	$C_ZT_BIN_DIR/zt "Creacartella" "/tmp/upgrade"
	$C_ZT_BIN_DIR/zt "ScaricaChecksum" "/tmp/upgrade" "http://www.zerotruth.net/download/updates/$VERSION/upgrade/checksum"
	$C_ZT_BIN_DIR/zt "ScaricaUpgrade" "/tmp/upgrade" "http://www.zerotruth.net/controldlupgrade.php?file=$UPGRADE_VERSION&versionnow=$VERSION" "$UPGRADE_VERSION" "$DEL_CONFIG" "$DEL_USERS"
	return_page "config.sh?SECTION=UPGRADE_ZT_COMPLETE"
	exit
fi
if [ "$SECTION" == "UPGRADE_ZT_COMPLETE" ];then
	echo "<p><font color=\"blue\">$L_UPGRADE_COMPLETE</font><p>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_ZT\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CODE" ""
	./footer.sh
	exit
fi
if [ "$SECTION" == "UPGRADE_ZT_ERROR" ];then
	echo "<p><font color=\"blue\">$L_CHECKSUM_ERROR</font><p>
	<form method=\"POST\" action=\"config.sh\">
	<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_ZT\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	./footer.sh
	exit
fi
if [ "$SECTION" == "UPDATE_ZT" ];then
	echo "<p><font color=\"#0000FF\" size=\"3\">$L_MODIFY Zerotruth</font>"
	if [ "$SUB_SECTION" == "AUTO_UPDATE" ];then
		wait "650"
		for CONF in "AUTO_UPDATE" "AUTO_UPDATE_EMAIL";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" "${!CONF}"
		done
		return_page "config.sh?SECTION=UPDATE_ZT"
		exit
	fi
	if [ -n "$C_CODE" ];then
		echo "<br><font color=\"#0000FF\" size=\"1\">(reg: $C_CODE)</font>"

		echo "<form method=\"POST\" action=\"config.sh\">
		<table>
		<tr><td>$L_AUTO_UPDATE: </td><td>"
		if [ -n "$C_AUTO_UPDATE" ];then
			echo "<input name=\"AUTO_UPDATE\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"AUTO_UPDATE\" type=\"checkbox\">"
		fi
		if [ -n "$C_ADMIN_EMAIL" ];then
			echo "</td><td>&nbsp;&nbsp;</td><td>$L_AUTO_UPDATE_EMAIL: </td><td>"
			if [ -n "$C_AUTO_UPDATE_EMAIL" ];then
				echo "<input name=\"AUTO_UPDATE_EMAIL\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"AUTO_UPDATE_EMAIL\" type=\"checkbox\">"
			fi
		fi
		echo "</td></tr></table>
		<input type=\"hidden\" name=\"SECTION\"  value=\"UPDATE_ZT\">
		<input type=\"hidden\" name=\"SUB_SECTION\"  value=\"AUTO_UPDATE\"><p>"
		if [ -n "$C_AUTO_UPDATE" ];then
			echo "<img src=\"/images/barra.png\" alt=\"barra\" alt=\"barra\"><p>"
		fi
		echo "<input type=\"submit\" name=\"CONF_ZEROTRUTH\" class=\"bottone\" value=\"$L_SAVE\"></form>"
		if [ -z "$C_AUTO_UPDATE" ];then
			echo "<p><img src=\"/images/barra.png\" alt=\"barra\" alt=\"barra\"><p>"
		fi
		if [ -n "$C_AUTO_UPDATE" ];then
			./footer.sh
			exit
		fi
	fi
	echo "<p>"
	if [ -n "$UPDATEOK" ];then
		echo "<p> &nbsp;<p>"
		echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
		<tr>
		<td class=\"intesta\">Directory</td>
		<td class=\"intesta\">File</td>
		<td class=\"intesta\">$L_STATUS</td>
		</tr>"
		NAMEFILES=$(echo "$NAMEFILES" | sed '/\+/s// /g')
		N=1
		for NF in $NAMEFILES;do
			FILE=$(echo $NF | awk '{n=split ($0, a, "/");print a[n]'})
			DIR=$(echo $NF | sed '/'${FILE}'/s///g')
			$C_ZT_BIN_DIR/zt "Scarica" "$DIR" "http://www.zerotruth.net/download/updates/$VERSION/$NF" "$FILE" "$N"
			N=$(($N+1))
		done
		echo "</table>"
		source $C_ZT_CONF_DIR/zt.config
		if [ -z "$C_FIX_ERROR" ];then
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_UPDATE_ZT" "$C_UPDATE_SERVER"
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FIX" ""
			echo "<p>&nbsp;<p>"
			$C_ZT_BIN_DIR/zt "ControlOk" "$L_SYSTEM_UPDATED" "config.sh?SECTION=UPDATE_ZT"
		else
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_UPDATE_ZT" ""
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FIX_ERROR" ""
			echo "<p>&nbsp;<p>"
			$C_ZT_BIN_DIR/zt "Errore" "$L_SYSTEM_NOT_UPDATED" "config.sh?SECTION=UPDATE_ZT"
		fi
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		CONTROLV=$(echo "$INTERFACECP" | cut -sd'.' -f2)
		if [ -n "$CONTROLV" ];then
			INTERFACE=$(echo "$INTERFACECP" | cut -d'.' -f1)
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		else
			IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
			$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
		fi
		EXECUTABLE=$(ls -l /DB/apache2/cgi-bin/zerotruth/exec | grep '^-rwxr' | awk '{print $NF}')
		for EXECUT in $EXECUTABLE;do
			$C_ZT_BIN_DIR/zt "Esegui" "/DB/apache2/cgi-bin/zerotruth/exec/$EXECUT"
			$C_ZT_BIN_DIR/zt "PermFiles" "660" "/DB/apache2/cgi-bin/zerotruth/exec/$EXECUT"
		done
		exit
	fi
	if [ -z "$($C_ZT_BIN_DIR/zt ControlCode)" ];then
		CONTROLDOWN=$( `/usr/local/bin/nc -z -w 4 zerotruth.net 80  2> /dev/null` || echo "down")
		if [ -z "$CONTROLDOWN" ];then
			echo "<div id=\"loading\"><img src=\"/images/wait.gif\" alt=\"wait\">"
			footerwait "480"
			echo "</div>"
			NUMUPDATES=0
			if [ -d $C_ZT_DIR/mudc ];then
				NEWFILES=$(curl -s http://www.zerotruth.net/download/updates/$VERSION/elencafiles.php?code=$C_CODE | sed '/<br>/s//\n/g' | sed '/\.\//s//\//g' | sed '/^$/d')
			else
				NEWFILES=$(curl -s http://www.zerotruth.net/download/updates/$VERSION/elencafiles.php?code=$C_CODE | sed '/<br>/s//\n/g' | sed '/\.\//s//\//g' | sed '/mudc/d' | sed '/^$/d' )
			fi
			if [ -n "$C_UPDATE_ZT" ];then
				NEWFILES=$(echo -e "$NEWFILES" | awk -v lu="$C_UPDATE_ZT" '{if ($1 > lu ) print}')
			fi
			if [ ! -f $C_ZT_CONF_DIR/updates ];then
				$C_ZT_BIN_DIR/zt "Salva" "$NEWFILES" "$C_ZT_CONF_DIR/updates"
			else
				$C_ZT_BIN_DIR/zt "Salva" "$NEWFILES" "$C_ZT_CONF_DIR/newupdates"
			fi
			RIGHE=$(echo "$NEWFILES" | wc -l )
			DATE_UPDATE=$(echo "$NEWFILES" | tail -1 | cut -d' ' -f1)
			if [[ -z "$C_UPDATE_ZT" || "$C_UPDATE_ZT" -lt "$DATE_UPDATE" ]];then
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_UPDATE_SERVER" "$DATE_UPDATE"
				for I in $(seq 1 $RIGHE);do
					RIGA="$(echo -e "$NEWFILES" | sed -n "${I}p")"
					NAMEFILE=$(echo "$RIGA" | awk '{ print $2 }')
					TIMEFILE=$(echo "$RIGA" | awk '{ print $1 }')
					TIMEFILELOC=$($C_ZT_BIN_DIR/zt "Stat" "/$NAMEFILE")
					if [ $TIMEFILELOC -lt $TIMEFILE ] && [ -f /$NAMEFILE ];then
						NUMUPDATES=$(($NUMUPDATES+1))
						NAMEFILES="$NAMEFILES $NAMEFILE"
					else
						if [ ! -e /$NAMEFILE ];then
							if [ ! -d /$DIR ];then
								$C_ZT_BIN_DIR/zt "CreaCartella" "/$DIR"
							fi
							NUMUPDATES=$(($NUMUPDATES+1))
							NAMEFILES="$NAMEFILES $NAMEFILE"
						fi
					fi
				done
			else
				NUMUPDATES=0
			fi
			if [ $NUMUPDATES -gt 0 ];then
				AVVISOUP="$L_YES_UPDATES: $NUMUPDATES"
				TABLE="yes"
			else
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FIX" ""
				AVVISOUP="$L_NO_UPDATES <br>&nbsp;<br><img src=\"/images/barra.png\" alt=\"barra\">"
			fi
		else
			SERVERDOWN="yes"
		fi
		echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
	else
		echo "<br>&nbsp;<br><font color=\"blue\">$L_REGISTER_ZT</font><br>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form action=\"config.sh\" method=\"POST\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_REGISTER\">"
		./footer.sh
		exit
	fi
	if [ -n "$SERVERDOWN" ];then
		echo "<font color=\"red\" size=\"3\">$L_SERVER_DOWN</font><p>"
	else
		echo "<font color=\"#0000FF\" size=\"3\">$AVVISOUP</font><p>"
		if [ "$TABLE" == "yes" ];then
			echo "<table class=\"tabellain\" width=\"600\" border=\"1\">
			<tr>
				<td class=\"intesta\">N.</td>
				<td class=\"intesta\">Directory</td>
				<td class=\"intesta\">File</td>
			</tr>"
			N=1
			for file in $NAMEFILES;do
				BG="$C_BG"
				[ $(expr $N % 2 ) -eq 0 ] && BG="$C_BG1"
				FILE=$(echo $file | awk '{n=split ($0, a, "/");print a[n]'})
				DIR=$(echo $file | sed '/'${FILE}'/s///g')
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$N</td><td>$DIR</td><td>$FILE</td><tr>"
				N=$(($N+1))
			done
			echo "</table>"
		fi
	fi
	if [ $NUMUPDATES -gt 0 ];then
		NAMEFILES=$(echo $NAMEFILES | sed '/<br>/s// /g')
		echo "<form action=\"config.sh\" method=\"POST\">
		<input type=\"hidden\" name=\"NAMEFILES\" value=\"$NAMEFILES\">
		<input type=\"hidden\" name=\"UPDATEOK\" value=\"UPDATEOK\">
		<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"OK\">
		<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_ZT\">
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<input type=\"submit\" class=\"bottone\" value=\"$L_MODIFY\"
		onClick=\"javascript:return confirm('$L_ALERT_UPDATE');\">
		</form><p>&nbsp;"
	else
		UPGRADE_VERSION=$(curl -s http://www.zerotruth.net/download/updates/$VERSION/upgrade/ | grep 'href="zerotruth' | cut -d'>' -f 3 | cut -d'<' -f1 | sed 's/ //g')
		if [ -n "$UPGRADE_VERSION" ];then
			echo "<font color=\"blue\">$L_NEW_VERSION:<br>$UPGRADE_VERSION</font><p>
			<form action=\"config.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"UPGRADE_VERSION\" value=\"$UPGRADE_VERSION\">
			<input type=\"hidden\" name=\"UPGRADEOK\" value=\"UPGRADEOK\">
			<input type=\"hidden\" name=\"SECTION\" value=\"UPGRADE_ZT\">
			<input type=\"submit\" class=\"bottone\" value=\"Upgrade\"
			onClick=\"javascript:return confirm('$L_ALERT_UPDATE');\"></form><p>"
		fi
	fi
fi
./footer.sh

