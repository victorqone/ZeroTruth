#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$C_EMAIL_ABIL" || -z "$C_SEND_EMAIL" ]] && [ "$UTENTEC" != "$C_ADMIN" ];then
	return_page "index.sh"
	exit
fi
if [ -n "$INVIA" ];then
	if [ -z "$CONTROL_EM" ];then
		echo "<br><font color=\"#0000FF\" size=\"5\">$L_SEND_EMAIL</font><p>"
		echo "<img src=\"/images/barra.png\" alt=\"barra\"><p>"
		wait "750"
		TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n\n\n$TEXT_EMAIL\n\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		NUM=0
		$C_ZT_BIN_DIR/zt "Cancella" "/tmp/erroremail"
		for i in $(seq 0 $NUMEROTOT);do
			eval EMAIL=\$CLI$i
			if [ -n "$EMAIL" ];then
				#echo "$OGGETTO - $TEXT_EMAIL - $EMAIL"
				$C_ZT_BIN_DIR/zt "Email" "$OGGETTO" "$TEXT_EMAIL" "$EMAIL"
				NUM=$(($NUM+1))
			fi
		done
		return_page "email.sh?INVIA=yes&NUM=$NUM&CONTROL_EM=yes"
		exit
	fi
	CONTROL_ERROR=$(cat /tmp/erroremail | grep "Error sending message")
	if [ -z "$CONTROL_ERROR" ];then
		echo "<br><font color=\"#0000FF\" size=\"5\">$L_SEND_EMAIL</font><p>"
		echo "<font color=\"blue\">$L_EMAILS_SENT: $NUM</font>"
		echo "<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form method=\"POST\" action=\"email.sh\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form>"
		if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_EMAILS_SENT $NUM"
		fi
	else
		$C_ZT_BIN_DIR/zt "Errore" "$L_EMAIL_NOT_SENT" "email.sh"
		$C_ZT_BIN_DIR/zt "Cancella" "/tmp/erroremail"
		exit
	fi
	./footer.sh
	exit
fi
echo "<br><font color=\"#0000FF\" size=\"5\">$L_SEND_EMAIL</font>
<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
if [ -z "$SEARCH" ];then
	echo "<font color=\"#0000FF\" size=\"3\">$L_SEARCH</font>
	<form method=\"POST\" action=\"email.sh\">
	<p>&nbsp;<p><table class=\"naked\" width=\"55%\">
	<tr><td>$L_USERNAME: </td>
	<td><input name=\"USERNAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td>
	<td>$L_CLASS: </td><td>
	<select name=\"CLASS\">"
	for CLASS in $(ls $C_CLASSES_DIR);do
		if [ -d $C_CLASSES_DIR/$CLASS ];then
			echo "<option value=\"$CLASS\">$CLASS</option>"
		fi
	done
	echo "<option value=\"\" selected></option></select></td></tr><tr>
	<td >$L_NAME:</td>
	<td ><input name=\"NAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td>
	<td >$L_LAST_NAME: </td>
	<td ><input name=\"LAST_NAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td></tr>
	<tr><td >$L_VALID:<td>
	<select name=\"VALIDITY\">
	<option value=\"no\">$L_NO</option>
	<option value=\"yes\">$L_YES</option>
	<option value=\"\" selected></option>
	</select></td>"
	if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
	[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
		ROOMS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" roomName | sed -n '/roomName:/p' | awk '{ print $2 }' | sed '/\?/d' | sort | uniq )
		echo "<td >$C_ROOM_NAME: </td><td>
		<select name=\"ROOM\">"
		for ST in $ROOMS;do
			if [ "$ST" != "?" ];then
				echo "<option value=\"$ST\">$ST</option>"
			fi
		done
		echo "<option value=\"\" selected></option></select></td>"
	else
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<td >$L_OWNER: </td><td>
			<select name=\"OWNER\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -z "$CONTROLOW" ];then
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<tr><td >$L_OWNER:<td>
			<select name=\"OWNER\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -d $C_ZT_DIR/mudc ];then
		echo "<tr><td>Mudc</td><td><input name=\"MUDC\" type=\"checkbox\"</td><td></td><td></td>"
	fi
	if [ -z "$CONTROLOW" ];then
		echo "<input type=\"hidden\" name=\"OWNER\" value=\"$UTENTEC\">"
	fi
	echo "</tr></table>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"submit\" name=\"SEARCH\" class=\"bottone\" value=\"$L_SEARCH \"></form><p>"
fi
if [ -n "$SEARCH" ];then
	if [ -z "$MUDC" ];then
		search "$USERNAME" "$NAME" "$LAST_NAME" "$CLASS" "$ROOM" "" "" "$VALIDITY" "$OWNER"
		CLASS_RIC="$CLASS"
		echo "<form method=\"POST\" action=\"email.sh\">"
		echo "$L_USERNAME: <font color=\"blue\">$URIC</font> &nbsp;&nbsp; $L_NAME: <font color=\"blue\">$NRIC</font>
		&nbsp;&nbsp; $L_LAST_NAME: <font color=\"blue\">$CRIC</font> &nbsp;&nbsp;$L_CLASS: <font color=\"blue\">$PRIC</font>
		&nbsp;&nbsp;$L_OWNER: <font color=\"blue\">$OWRIC</font> &nbsp;&nbsp;$L_VALID: <font color=\"blue\">$SCRIC</font>"
		if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
			[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
			echo "&nbsp;&nbsp;$C_ROOM_NAME: <font color=\"blue\">$SRIC</font>"
		fi
	else
		echo "<form method=\"POST\" action=\"email.sh\">"
	fi
	echo "<table class=\"tabellain\" width=\"750\" border=\"1\">
	<tr>
	<td WIDTH=\"1%\" class=\"intesta\">N.</td>
	<td WIDTH=\"1%\" class=\"intesta\">C.</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_USERNAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_NAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_LAST_NAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_EMAIL</td>
	</tr>"
	NUM=0
	CONTROLLDAP="(&(!(mail=?)) $CONTROLLDAP )"
	USERNAMEPEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAP" -S uid uid | sed -n '/uid:/p' | awk '{ print $2 }')
	if [ -n "$MUDC" ];then
		for PROG in $(ls -A $C_ZT_DIR/mudc/prog);do
			EM="$(cat $C_ZT_DIR/mudc/prog/$PROG/Email)"
			CONTROLLDAPEM="(&(mail=$EM) $CONTROLLDAP )"
			CONTROLUIDEM=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" mail=$EM uid | sed -n '/uid:/p' | awk '{ print $2 }')
			if [ -z "$(echo "$USERNAMEPEOPLE2" | grep "$CONTROLUIDEM")" ];then
				USERNAMEPEOPLE2="$USERNAMEPEOPLE2 $(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAPEM" -S uid uid | sed -n '/uid:/p' | awk '{ print $2 }') "
			fi
		done
		USERNAMEPEOPLE="$USERNAMEPEOPLE2"
	fi
	for USERNAME in $USERNAMEPEOPLE;do
		if [ "$USERNAME" != "admin" ];then
			ldap_search_people "uid=$USERNAME"
			ldap_search_radius "$USERNAME"
				if [[ -n "$EMAIL" ]] && [[ "$HIDDEN" == "no" || "$UTENTEC" == "$C_ADMIN" ]] && [[ -z "$CLASS_RIC" || "$CLASS_RIC" == "$CLASS" ]];then
				NUM1=$(($NUM+1))
				BG="$C_BG"
				[ $(expr $NUM1 % 2 ) -eq 0 ] && BG="$C_BG1"
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NUM1</td>
				<td align=\"center\"><input id=\"$NUM\" name=\"CLI$NUM\" value=\"$EMAIL\" type=\"checkbox\" checked=\"checked\"></td>
				<td align=\"center\">$USERNAME</td>
				<td align=\"center\">$NAME</td>
				<td align=\"center\">$LAST_NAME</td>
				<td align=\"center\">$EMAIL</td>
				</tr>"
				NUM=$(($NUM+1))
			fi
		fi
	done
	NUMEROTOT=$(($NUM-1))
	echo "</table><br>"
	if [ "$NUM" == "0" ];then
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<p><font color=\"red\">$L_NO_RESULT</font><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form method=\"POST\" action=\"email.sh\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form><p>&nbsp;<p>"
		./footer.sh
		exit
	fi
	echo "$L_SENDER: $(cat $C_ZT_CONF_DIR/msmtprc | grep "^from " | awk '{ print $2 }')
	<p>$L_OBJECT: <br>
	<input type=\"text\" name=\"OGGETTO\" value=\"\">
	<p>$L_EMAIL_TEXT: <br>
	<textarea name=\"TEXT_EMAIL\" cols=\"80\" rows=\"2\"></textarea><p>
	<input type=\"hidden\" name=\"NUMEROTOT\" value=\"$NUMEROTOT\">
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"hidden\" name=\"CONF_SCRIPT\" value=\"ok\">
	<input type=\"submit\" name=\"INVIA\" class=\"bottone\" value=\"$L_SEND_EMAIL\"
	onClick=\"javascript:return confirm('$L_ALERT_SEND_EMAILS');\"></form><p>&nbsp;"
fi
./footer.sh
