#!/bin/bash

echo "Content-type: text/html"
echo ""


source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh

getvarqs

NR=1
for SHAP in $(ls $C_ZT_CONF_DIR/cbqconf/ | grep '[0-9]\-' |  sed '/-UP$/d');do
	CLASS=$(echo $SHAP | cut -d'-' -f4 )
	DEVICE=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep 'DEVICE' | cut -d'=' -f2 | cut -d',' -f1 )
	RATE=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep RATE | cut -d'=' -f2 | cut -d'K' -f1)
	RATE=$(echo "scale=$C_DECIMAL;$(echo $RATE)/1024" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./')
	WEIGHT=$(cat $C_ZT_CONF_DIR/cbqconf/$SHAP | grep WEIGHT | cut -d'=' -f2 | cut -d'K' -f1)
	WEIGHT=$(echo "scale=$C_DECIMAL;$(echo $WEIGHT)/1024" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./')
	USER=$(echo $C_ZT_CONF_DIR/cbqconf/$SHAP | cut -d'-' -f3 | cut -d'.' -f1 )
	T_SHAPER=$(tc -s qdisc show dev "$DEVICE")
	T_SHAPER=$(echo $T_SHAPER | sed 's/qdisc tbf /\n/g' | sed '/^qdisc/d')
	RIGA_SHAPER=$( echo -e "$T_SHAPER" | grep "^$USER:")
	SENT=$(echo "$RIGA_SHAPER" | cut -d' ' -f11)
	SENT=$( echo "$SENT/1024" | $C_ZT_BIN_DIR/bc )
	PKT=$(echo "$RIGA_SHAPER" | cut -d' ' -f13)
	DROP=$(echo "$RIGA_SHAPER" | cut -d' ' -f16 | sed '/\,/s///g')
	OVER=$(echo "$RIGA_SHAPER" | cut -d' ' -f18 | sed '/\,/s///g')
	DATA="$DATA\n$NR-$USER-$CLASS-$DEVICE-$RATE-$SENT-$PKT-$DROP-$OVER"
	NR=$(($NR+1))
done
echo "$(echo -e "$DATA" | grep "^$line")"
