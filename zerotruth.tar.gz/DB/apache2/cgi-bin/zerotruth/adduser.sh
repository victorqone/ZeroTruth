#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$C_REGISTER_USERS" && "$UTENTEC" != "$C_ADMIN" ]];then
	return_page "index.sh"
	exit
fi
if [ -n "$ADDUSER" ];then
	echo "<div id=\"loading\"><br><font color=\"#0000FF\" size=\"5\">$L_ADDUSER</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;<br><br>&nbsp;<br>
	<img src=\"/images/wait.gif\" alt=\"wait\">"
	footerwait "480"
	echo "</div>"
	DAYS=$(date +%w)
	ORAS=$(date +%H)
	MINS=$(date +%M)
	ORAMIN=$ORAS$MINS
	ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
	if [ -z "$C_ANONYMOUS_USER" ] && [[ -z "$NAME" || -z "$LAST_NAME" ]];then
		sleep 1
		echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
		$C_ZT_BIN_DIR/zt "Errore" "$L_ANONYMOUS_NOT_ALLOWED" "adduser.sh"
		exit
	fi
	if [ -n "$C_ANONYMOUS_USER" ] && [[ -z "$NAME" || -z "$LAST_NAME" ]];then
		if [ -z "$NAME" ];then
			NAME="$L_ANONYMOUS"
			NAME_PRINT="AN"
		fi
		if [ -z "$LAST_NAME" ];then
			LAST_NAME="$L_ANONYMOUS"
			LAST_NAME_PRINT="AN"
		fi
	fi
	if [ -z "$USERNAME" ];then
			sleep 1
			echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
			$C_ZT_BIN_DIR/zt "Errore" "$L_USERNAME_EMPTY" "adduser.sh"
		exit
	fi
	#USERNAME=$(echo "$USERNAME" | sed 's/[^[:alnum:]]//g' | tr A-Z a-z)
	PASSWORD=$(echo "$PASSWORD" | sed 's/[^[:alnum:]]//g')
	if [ -n "$MUDC" ];then
		PASSWORD="$RANDOM$RANDOM"
		PASSWORD="$(echo ${PASSWORD:0:6})"
	fi
	PASSWORD_ORI="$PASSWORD"
	LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" telephoneNumber mail)
	if [ -n "$PHONE" ];then
		controlprefix "$PREFIX" "adduser.sh"
		PHONE="$PREFIX$PHONE"
		controltelefono "$PHONE" "adduser.sh"
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" telephoneNumber=$PHONE)
		CPHONE=$(echo "$LINE" | grep -e '^telephoneNumber: ' | sed 's/^telephoneNumber: //g' )
		if [ -n "$CPHONE" ];then
			sleep 1
			echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
			$C_ZT_BIN_DIR/zt "Errore" "$L_TEL_PRE" "adduser.sh"
			exit
		fi
	fi
	if [ -n "$EMAIL" ];then
		controlemail "$EMAIL" "adduser.sh"
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" mail=$EMAIL)
		CEMAIL=$(echo "$LINE" | grep -e '^mail: ' | sed 's/^mail: //g' )
		if [ -n "$CEMAIL" ];then
			sleep 1
			echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
			$C_ZT_BIN_DIR/zt "Errore" "$L_EMAIL_PRE" "adduser.sh"
			exit
		fi
	fi
	if [[ -z $DAY_EXPIRE || -z $MONTH_EXPIRE || -z $YEAR_EXPIRE ]];then
		DAY_EXPIRE="31"
		MONTH_EXPIRE="12"
		YEAR_EXPIRE="2037"
	fi
	SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
	if [ -z "$CLASS" ];then
		CLASS=$(cat $C_ZT_CONF_DIR/Manager/$UTENTEC/CLASS_USER | awk '{ print $1 }')
	fi
	ldap_add_people
	if [ "$CONTROLADD" == "no" ]; then
		echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
		$C_ZT_BIN_DIR/zt "Errore" "$L_PROBLEM_INSERTING" "adduser.sh"
		exit
	fi
	ldap_add_radius
	if [ -n "$CONTROLADD" ]; then
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
		sleep 1
		echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
		$C_ZT_BIN_DIR/zt "Errore" "$L_PROBLEM_INSERTING" "adduser.sh"
		exit
	fi
	$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
	$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	
	$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE"
	#$C_ZT_BIN_DIR/zt "x509_user" "$USERNAME"
	
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_ADDUSER $USERNAME $L_CLASS $CLASS"
	fi
	if [ "$C_SMS_ABIL" == "on" ];then
		if [ -n "$C_SMS_NOT" ] && [ -n "$PHONE" ] && [ "$SMS_NOT" == "on" ];then
			if [ -n "$ROOM" ];then
				ROOM_SMS="$C_ROOM_NAME $ROOM"
			fi
			TEXT_SMS="$C_HOTSPOT_NAME: $L_USERADD $L_NAME $NAME $L_LAST_NAME: $LAST_NAME user: $USERNAME password: $PASSWORD_ORI $ROOM_SMS - $L_FOOTER_SMS"
			$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$PHONE" "$TEXT_SMS" "credito"
		fi
	fi
	source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
	limituser "$USERNAME"	
	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n"
	if [ -n "$ROOM" ];then
		TEXT_EMAIL="$TEXT_EMAIL\n$C_ROOM_NAME: $ROOM"
	fi
	if [ -n "$MAXDAYS" ];then
		EXP="$MAXDAYS $L_DAYS"
	else
		if [ $SHADOWEXPIRE == 24836 ];then
			EXP=$L_NO_LIMIT
		else
			if [ "$C_FORM_DATE" == "ita" ];then
				EXP=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%d/%m/%Y)
			else
				EXP=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y/%m/%d)
			fi
		fi
	fi
	if [ "$C_FORM_DATE" == "ita" ];then
		DATE_CREATED=$(date +%d/%m/%Y)
	else
		DATE_CREATED=$(date +%Y/%m/%d)
	fi
	TEXT_EMAIL="$TEXT_EMAIL\nusername: $USERNAME\n$L_PASSWORD: $PASSWORD_ORI\n$L_NAME: $NAME\n$L_LAST_NAME: $LAST_NAME"
	TEXT_EMAIL="$TEXT_EMAIL\n$L_TELEPHONE: $PHONE\n$L_CLASS: $CLASS\n$L_CREATED: $DATE_CREATED\n$L_EXPIRY: $EXP"
	limituseremail
	TEXT_EMAIL_ADMIN="$TEXT_EMAIL\n$L_BY: $UTENTEC"
	TEXT_EMAIL="$TEXT_EMAIL\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	if [ -n "$C_EMAIL_NOT" ] && [ -n "$EMAIL" ] && [ "$EMAIL_NOT" == "on" ];then
		$C_ZT_BIN_DIR/zt "Email" "$L_USERADD $C_HOTSPOT_NAME" "$TEXT_EMAIL" "$EMAIL"
	fi
	FREETIME=$(cat $C_ACCT_DIR/classes/$CLASS/FreeTime)
	if [[ -n "$CREDITO" || -n "$FREETIME" ]];then
		$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USERNAME"
		[[ -z "$CREDITO" && -n "$FREETIME" ]] && CREDITO="freetime"
		$C_ZT_BIN_DIR/zt "Salva" "$CREDITO" "$C_ACCT_DIR/credits/$USERNAME/Credit"
		if [ -z "$FREETIME" ];then
			CREDITO=$(echo "$CREDITO" | awk '{printf("%.2f\n", $0)}')
			$C_ZT_BIN_DIR/zt "Aggiungi" "$USERNAME+$(date '+%b %d, %Y')+$(date '+%T')+$CREDITO+cash" "$C_ZT_LOG_DIR/pp/payments"
		fi
	fi
	if [ -n "$C_NOT_EMAIL_ADD_USER" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_SEMAIL_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		TEXT_EMAIL_ADMIN=$(urlencode "$TEXT_EMAIL_ADMIN")
		TEXT_EMAIL_ADMIN=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL_ADMIN")
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
	if [ -n "$C_NOT_SMS_ADD_USER" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		if [ -n "$ROOM" ];then
			ROOMSMS="$ROOMN: $ROOM"
		fi
		TEXT_SMS="$C_HOTSPOT_NAME: $L_USERADD $USERNAME $NAME $LAST_NAME $ROOMSMS $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS" "credito"
	fi
	echo "<script language=\"JavaScript\" type=\"text/javascript\">document.getElementById(\"loading\").remove();</script>"
	if [ -n "$PRINT" ];then
		[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
		[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<br>&nbsp;<br><font color=\"blue\" size=\"5\">$L_USER_TICKET</font><p>
		<img src=\"/images/barra.png\" alt=\barra\"><p>"
		source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
		[ -n "$NAME_PRINT" ] && NAME="$L_ANONYMOUS"
		[ -n "$LAST_NAME_PRINT" ] && LAST_NAME="$L_ANONYMOUS"
		INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
		echo "<div id=\"ticket\">
		<table width=\"350\" border=\"1\" align=\"center\">
		<tr>
		<td colspan=\"2\"><img src=\"$APACHE_BASEDIR/images/imguser.png\" WIDTH=\"350px\"></td>
		</tr>
		<tr><td>
		<table width=\"350\" border=\"0\" style=\"font: ${C_FONT_TICKET}px "Trebuchet MS",Arial,sans-serif;\">"
		if [ -n "$C_PRINT_QR" ];then
			$C_ZT_BIN_DIR/zt "QrCode" "$USERNAME" "$PASSWORD"
			echo "<tr><td colspan =\"2\" align=\"center\"><img src=\"$APACHE_BASEDIR/images/qrcode/${USERNAME}.png\"></td></tr>"
		fi
		if [[ -z "$C_PRINT_QR" || -z "$C_PRINT_QR_ONLY" ]];then
			echo "<tr><td width=\"130px\"><b>&nbsp;$L_USERNAME: </b></td>
			<td><b>$USERNAME</b></td></tr>
			<tr><td><b>&nbsp;$L_PASSWORD: </b></td>
			<td><b>$PASSWORD_ORI</b></td></tr>"
			if [ -n "$C_PRINT_NAME" ];then
				echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
				<tr><td>&nbsp;$L_LAST_NAME: </td><td>$(echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
			else
				if [ "$NAME" != "$L_ANONYMOUS" ];then
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
					<tr><td>&nbsp;$L_LAST_NAME: </td><td>$(echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
				fi
			fi
			if [ -n "$ROOM" ];then
				echo "<tr><td>&nbsp;$C_ROOM_NAME: </td><td>$ROOM</td></tr>"
			fi
			if [ -n "$C_PRINT_CLASS" ];then
				echo "<tr><td>&nbsp;$L_CLASS: </td><td>$CLASS</td></tr>"
			fi
			if [ -n "$EMAIL" ];then
				echo "<tr><td>&nbsp;$L_EMAIL: </td><td>$EMAIL</td></tr>"
			fi
			if [ -n "$PHONE" ];then
				echo "<tr><td>&nbsp;$L_TELEPHONE: </td><td>$PHONE</td></tr>"
			fi
			if [ -n "$C_PRINT_CREATED" ];then
				echo "<tr><td>&nbsp;$L_CREATED: </td><td>$DATE_CREATED</td></tr>"
			fi
			if [ -n "$C_PRINT_EXP" ];then
				echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXP</td></tr>"
			else
				if [ "$EXP" != "$L_NO_LIMIT" ];then
					echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXP</td></tr>"
				fi
			fi
			if [[ -n "$USERDAYS" && "$USERDAYS" != "$L_ALL" ]];then
				echo "<tr><td>&nbsp;$L_DAYS: </td><td>$USERDAYS</td></tr>"
			fi
			if [[ -n "$USERTIME" && "$USERTIME" != "$L_ALL" ]];then
				echo "<tr><td>&nbsp;$L_TIME: </td><td>$USERTIME</td></tr>"
			fi
			if [ -n "$USERHOURSDAY" ];then
				echo "<tr><td>&nbsp;$L_DMAX_HOURS: </td><td>$USERHOURSDAY</td></tr>"
			fi
			if [ -n "$USERHOURSMONTH" ];then
				echo "<tr><td>&nbsp;$L_MMAX_HOURS: </td><td>$USERHOURSMONTH</td></tr>"
			fi
			if [ -n "$USERMBDAY" ];then
				echo "<tr><td>&nbsp;$L_DMAX_MB: </td><td>$USERMBDAY</td></tr>"
			fi
			if [ -n "$USERMBMONTH" ];then
				echo "<tr><td>&nbsp;$L_MMAX_MB: </td><td>$USERMBMONTH</td></tr>"
			fi
		fi
		echo "</table>"
		if [ -n "$INFO_TICKET" ];then
			echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
			<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
		fi
		echo "</table></div><p>&nbsp;<p>"
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<p><input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_TICKET\" onClick=\"StampaTicket()\">
		</center><p>&nbsp;<p>"
		./footer.sh
		exit
	else
		$C_ZT_BIN_DIR/zt "ControlOk" "$L_USER_REGISTERED" "adduser.sh"
		exit
	fi
fi
limitclassjs
echo "<br><font color=\"#0000FF\" size=\"5\">$L_ADDUSER</font>"
if [[ "$UTENTEC" == "$C_ADMIN" || -n $C_MULTI_USERS || -n "$C_USERS_FROM_TICKET" ]];then
	echo "<br><font color=\"#0000FF\" size=\"3\">("
	if [[ "$UTENTEC" == "$C_ADMIN" || -n "$C_MULTI_USERS" ]];then
		echo "<a href=\"addusers.sh\">Multi</a>"
	fi
	if [[ "$UTENTEC" == "$C_ADMIN" || -n "$C_USERS_FROM_TICKET" ]] && [ -n "$C_AR_FROM_TICKET" ];then
		echo "&nbsp;&nbsp;<a href=\"adduserstickets.sh\">$L_FROM_TICKET</a>"
	fi
	echo "&nbsp;&nbsp;<a href=\"addusersfile.sh\">$L_FROM_FILE</a>)</font>"
fi
echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;
<form name=\"ADD_USER\" action=\"adduser.sh\" method=\"POST\">"
if [[ "$C_LANGUAGE" == "francais" || "$C_LANGUAGE" == "polski" ]];then
	LARGE=900
	LARGETD=175
else
	LARGE=750
	LARGETD=100
fi
echo "$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" uid=puhjsy cn)"
echo "<table WIDTH=\"${LARGE}px\" border=\"0\" cellpadding=\"0px\">
<tr><td width=\"${LARGETD}px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"50px\">
</td><td width=\"${LARGETD}px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td></tr>"
MATRICE="abcdefghijklmnopqrstuvwxyz"
while [ "${n:=1}" -le $C_LENGH_USERNAME ]
do
	USERRANDOM="$USERRANDOM${MATRICE:$(($RANDOM%${#MATRICE})):1}"
	let n+=1
done
echo "<tr><td width=\"100px\" height=\"30\">$L_USERNAME:</td>
<td colspan=\"3\"><input class=\"text1\" type=text name=\"USERNAME\" value=\"$USERRANDOM\"></td>"
MATRICE=$(gen_pass ${C_PASS_CHARS:-7})
while [ "${a:=1}" -le $C_LENGH_PASSWORD ]
do
	PASSRANDOM="$PASSRANDOM${MATRICE:$(($RANDOM%${#MATRICE})):1}"
	let a+=1
done
echo "<td></td>
<td>$L_PASSWORD:</td>
<td colspan=\"3\"><input id=\"pwd1\" size=\"15\" type=\"password\" name=\"PASSWORD\" value=\"$PASSRANDOM\" >
&nbsp;<a href=\"#\" onClick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></td></tr>
<tr><td height=\"30\">$L_NAME:</td>
<td colspan=\"3\"><input type=\"text\" class=\"text1\" name=\"NAME\" value=\"\"></td>
<td>&nbsp;&nbsp;</td>
<td>$L_LAST_NAME:</td>
<td colspan=\"3\"><input type=text class=\"text1\" name=\"LAST_NAME\" value=\"\"></td></tr>
<tr><td height=\"30\">$L_EMAIL:</td>
<td colspan=\"3\"><input type=\"text\" class=\"text1\" name=\"EMAIL\" value=\"\"></td>
<td>&nbsp;&nbsp;</td>
<td>$L_TELEPHONE:</td>
<td colspan=\"3\"><input type=\"text\" class=\"prefix1\" name=\"PREFIX\" value=\"$C_PREFIX\">
<input type=\"text\" class=\"phone1\" name=\"PHONE\" value=\"\"></td></tr>"
if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || [[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td height=\"30\">$C_ROOM_NAME:</td><td><input type=\"text\" class=\"room1\" name=\"ROOM\" value=\"\"></td>"
	CONTROLROOM="yes"
fi
if [ -n "$C_CLASS" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$CONTROLROOM" ];then
		echo "<td height=\"30\">$L_CLASS:</td><td colspan=\"3\">"
	else
		echo "<td colspan=\"2\" align=\"right\" cellpadding=\"0\">$L_CLASS:"
	fi
	echo "<select name=\"CLASS\" onchange=\"limitclass(this.options[this.selectedIndex].value, this.options[this.selectedIndex].id)\">"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		for CL in $(ls $C_CLASSES_DIR);do
			if [ $CL != "DEFAULT" ];then
				INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
				[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
				eval LIMITCLASS="\$LIMITCLASS$CL"
				echo "<option id=\"$LIMITCLASS-$INTCL\" name=\"NCLASS\" value=\"$CL\">$CL</option>"
			fi
		done
		CL="DEFAULT"
		eval LIMITCLASS="\$LIMITCLASS$CL"
		INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
		[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
		echo "<option id=\"$LIMITCLASS-$INTCL\" value=\"DEFAULT\" selected>DEFAULT</option></select>"
	else
		for CL in $(ls $C_CLASSES_DIR);do
			if [ -n "$(echo $C_CLASS_USER | grep "$CL")" ];then
			#	if [ $CL != "DEFAULT" ];then
					NTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
					[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
					eval LIMITCLASS="\$LIMITCLASS$CL"
					echo "<option id=\"$LIMITCLASS-$INTCL\" name=\"NCLASS\" value=\"$CL\">$CL</option>"
			#	fi
			fi
		done
		echo "</select>"
	fi
	echo "</select>
	</td><td>&nbsp;&nbsp;</td>"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<td height=\"30\" align=\"left\" colspan=\"2>\">"
	else
		echo "<td height=\"30\" align=\"left\" colspan=\"4>\">"
	fi
	echo "<div id=\"intclass\">Int: <font size=\"2\">$(cat $C_CLASSES_DIR/DEFAULT/InterfacesClass)</font></div>"
fi
if [ "$UTENTEC" == "$C_ADMIN" ];then
	echo "</td><td align=\"right\" colspan=\"2\" height=\"30\">$L_HIDDEN:
	<select name=\"HIDDEN\">
	<option value=\"yes\" selected>$L_YES</option>
	<option value=\"no\" selected>$L_NO</option>
	</select>"
else
	echo "<input type=\"hidden\" name=\"HIDDEN\" value=\"no\">"
fi
echo "</td></tr>"
YNOW=$(date +%Y)
YEND=$(($YNOW+10))
if [ -n "$C_EXPIRE" ] || [ "$UTENTEC" == "$C_ADMIN" ] ;then
	if [ "$C_FORM_DATE" == "ita" ];then
		echo "<tr><td height=\"30\">$L_EXPIRY:</td>
		<td><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\" selected>$L_DAY</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"YEAR_EXPIRE\">"
		for A in $(seq 2013 $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>"
	else
		echo "<tr><td height=\"30\">$L_EXPIRY:</td>
		<td><select name=\"YEAR_EXPIRE\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" selected>$L_YEAR</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\" selected>$L_MONTH</option></select></td>
		<td align=\"right\"><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\" selected>$L_DAY</option></select></td>"
	fi
	echo "<td>&nbsp;&nbsp;</td>
	<td>$L_OR_DAYS:</td><td>
	<select name=\"MAXDAYS\">"
	for MD in $(seq 365 1);do
		echo "<option value=\"$MD\" selected>$MD</option>"
	done
	echo "<option value=\"\" selected></option></select></td>"
	CVAL="yes"
fi
if 	[ -n "$C_CREDIT" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$C_EXPIRE" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		echo "<tr><td height=\"30\">$L_CREDIT:</td><td colspan=\"8\">"
	else
		echo "<td height=\"30\" colspan=\"2\" align=\"right\">$L_CREDIT: "
	fi
	echo "<input type=\"text\" class=\"credit\" name=\"CREDITO\" value=\"\"></td>"
	CVAL="yes"
fi
[ -n "$CVAL" ] && echo "</td></tr>"
limitclass "DEFAULT"
echo "<tr><td height=\"30\">$L_LIMIT: </td><td colspan=\"4\">
$L_HOURS $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limithoursday\">"$HDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$L_HOURS $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limithoursmonth\">"$HMC"</div></td>
<td colspan=\"4\" align=\"right\">
MB $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limitmbday\">"$MDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	MB $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limitmbmonth\">"$MMC"</div></td>
</tr><tr>
<td height=\"30\">$L_DAYS:</td><td colspan=\"4\">
<div style=\"display: inline-block;\" id=\"limitdays\">"$DC"</div>
</td>
<td colspan=\"4\" align=\"right\">$L_TIME:
<div style=\"display: inline-block;\" id=\"limitrange\">"$RANGE"</div>
</td></tr>"

if [[ -n "$C_PRINT_TICKET" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<tr><td height=\"30\">$L_TICKET:</td><td colspan=\"4\">"
	echo "<input name=\"PRINT\" type=\"checkbox\" checked=\"checked\">
	<select name=\"LANGUAGE_PRINT\">"
	for LANG in $(ls -A ./language/);do
		if [ "$LANG" != "$C_LANGUAGE" ] && [ "$LANG" != "index.html" ];then
			LANG1=$LANG
			[ "$LANG" == "espanol" ] && LANG1="espa&ntilde;ol"
			[ "$LANG" == "portugues" ] && LANG1="portugu&ecirc;s"
			[ "$LANG" == "francais" ] && LANG1="fran&ccedil;ais"
			echo "<option value=\"$LANG\">$LANG1</option>"
		fi
	done
	LANGUAGE1=$C_LANGUAGE
	[ "$C_LANGUAGE" == "espanol" ] && LANGUAGE1="espa&ntilde;ol"
	[ "$C_LANGUAGE" == "portugues" ] && LANGUAGE1="portugu&ecirc;s"
	[ "$C_LANGUAGE" == "francais" ] && LANGUAGE1="fran&ccedil;ais"
	echo "<option value=\"$C_LANGUAGE\" selected=\"selected\">$LANGUAGE1</option></select>"
	CONTROLTICKET="ok"
fi
if [ -n "$CONTROLTICKET" ];then
	if [[ -n "$C_MUDC" && -n "$C_USER_MUDC" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_MUDC" ]];then
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		$LM_USERMUDC: <input name=\"MUDC\" type=\"checkbox\"></td>"
	fi
else
	if [[ -n "$C_MUDC" && -n "$C_USER_MUDC" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_MUDC" ]];then
		echo "<tr><td height=\"30\">Mudc:</td><td colspan=\"4\">$LM_USER 
		<input name=\"MUDC\" type=\"checkbox\"></td>"
		CONTROLTICKET="ok"
	fi
fi
if [ -n "$C_SMS_NOT" ] || [ -n "$C_EMAIL_NOT" ];then
	if [ -n "$CONTROLTICKET" ];then
		echo "<td colspan=\"4\" align=\"right\">$L_NOTIFICATION_USER:&nbsp;"
		CONTROLSPAN="yes"
	fi
	if [ -z "$CONTROLTICKET" ];then
		echo "<tr><td height=\"30\">$L_NOTIFICATION_USER:</td><td colspan=\"5\">"
	fi
	if [ -n "$C_EMAIL_NOT" ];then
		echo "Email: <input name=\"EMAIL_NOT\" type=\"checkbox\">"
	fi
	if [ -n "$C_SMS_NOT" ];then
		echo "&nbsp;&nbsp;SMS: <input name=\"SMS_NOT\" type=\"checkbox\">"
	fi
fi
echo "</td></tr>"
if [[ -n "$C_REGISTER_INFO" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<tr><td>$L_INFO:</td><td colspan=\"8\">
	<input type=text class=\"info\" style=\"width:655px\" name=\"INFO\" value=\"\"></td></tr>"
fi
echo "</table>
<p><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
<input type=\"hidden\" name=\"ADDUSER\" value=\"ok\">
<p><input type=\"submit\" name=\"SAVE\" class=\"bottone\" value=\"$L_SAVE\"><p>&nbsp;<p>
</form>"
./footer.sh
