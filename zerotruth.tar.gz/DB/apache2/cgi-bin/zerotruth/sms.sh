#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

if [[ -z "$C_SMS_ABIL" || -z "$C_SEND_SMS" ]] && [ "$UTENTEC" != "$C_ADMIN" ];then
	return_page "index.sh"
	exit
fi
if [ -n "$INVIA" ];then
	echo "<br><font color=\"blue\" size=\"5\">$L_SEND_SMS</font><br>"
	if [ -n "$C_SMS_CREDIT" ];then
		echo "&nbsp;<br><font color=\"blue\">($L_CREDIT: $C_SMS_CREDIT)</font><br>"
	fi
	echo "<p><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>"
	if [ -z "$CONTROL_SMS" ];then
		wait "750"
		NUM=$NUMTOT
		NUM=0
		RECIPIENTS=" "
		for i in $(seq 0 $NUMTOT);do
			eval PHONE=\$CLI$i
			if [ -n "$PHONE" ];then
				RECIPIENTS="$RECIPIENTS $PHONE"
				NUM=$(($NUM+1))
			fi
		done
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$RECIPIENTS" "$TEXT_SMS" "$NUM" "credito"
		sleep 1
		return_page "sms.sh?INVIA=yes&NUM=$NUM&CONTROL_SMS=yes"
		exit
	fi
	echo "<font color=\"blue\">$L_SMS_SENT: $NUM</font><p>
	<img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
	<form method=\"POST\" action=\"sms.sh\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form>"
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_SMS_SENT $NUM"
	fi
	./footer.sh
	exit
fi
echo "<br><font color=\"blue\" size=\"5\">$L_SEND_SMS</font><br>"
if [ "$C_SMS_PROVIDER" == "Gammu" ];then
		CONTROL_DEVICE=$($C_ZT_BIN_DIR/zt "CheckKey" "active")
		if [ "$CONTROL_DEVICE" == "notconnected" ];then
			echo "<br>Device: <font color=\"red\">$L_NOT_CONNECTED</font>"
			./footer.sh
			exit
		fi
	fi
if  [[ -n "$C_VIEW_SMS_CREDIT" || "$UTENTEC" == "$C_ADMIN" ]];then
	if [ -n "$C_SMS_CREDIT" ];then
		echo "<br><font color=\"blue\">($L_CREDIT: $C_SMS_CREDIT)</font><br>"
	fi
fi
echo "<img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\">&nbsp;<br>"
if [ -z "$SEARCH" ];then
	echo "<p><font color=\"#0000FF\" size=\"3\">$L_SEARCH</font><p>
	<form method=\"POST\" action=\"sms.sh\">
	<p>&nbsp;<p>
	<table width=\"55%\" class=\"naked\">
	<tr><td>$L_USERNAME: </td>
	<td><input name=\"USERNAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td>
	<td>$L_CLASS: </td><td>
	<select name=\"CLASS\">"
	for CLASS in $(ls $C_CLASSES_DIR);do
		if [ -d $C_CLASSES_DIR/$CLASS ];then
			echo "<option value=\"$CLASS\">$CLASS</option>"
		fi
	done
	echo "<option value=\"\" selected></option></select>
	</td>
	</tr><tr>
	<td>$L_NAME:</td>
	<td><input name=\"NAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td>
	<td>$L_LAST_NAME: </td>
	<td><input name=\"LAST_NAME\" type=\"text\" value=\"\" size=\"10\" maxlength=\"17\"></td></tr>
	<tr><td >$L_VALID:<td>
	<select name=\"VALIDITY\">
	<option value=\"no\">$L_NO</option>
	<option value=\"yes\">$L_YES</option>
	<option value=\"\" selected></option>
	</select></td>"
	if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
	[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
		ROOMS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" roomName | sed -n '/roomName:/p' | awk '{ print $2 }' | sed '/\?/d' | sort | uniq )
		echo "<td>$C_ROOM_NAME: </td><td>
		<select name=\"ROOM\">"
		for ST in $ROOMS;do
			if [ "$ST" != "?" ];then
				echo "<option value=\"$ST\">$ST</option>"
			fi
		done
		echo "<option value=\"\" selected></option></select></td>"
	else
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<td>$L_OWNER: </td><td>
			<select name=\"OWNER\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -z "$CONTROLOW" ];then
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<tr><td>$L_OWNER:<td>
			<select name=\"OWNER\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -d $C_ZT_DIR/mudc ];then
		echo "<tr><td>Mudc</td><td><input name=\"MUDC\" type=\"checkbox\"</td><td></td><td></td>"
	fi
	if [ -z "$CONTROLOW" ];then
		echo "<input type=\"hidden\" name=\"OWNER\" value=\"$UTENTEC\">"
	fi
	echo "</tr></table>
	<p><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"></p>
	<input type=\"submit\" name=\"SEARCH\" class=\"bottone\" value=\"$L_SEARCH\"></form><p>"
fi
if [ -n "$SEARCH" ];then
	if [ -z "$MUDC" ];then
		search "$USERNAME" "$NAME" "$LAST_NAME" "$CLASS" "$ROOM" "" "" "$VALIDITY" "$OWNER"
		CLASS_RIC="$CLASS"
		echo "<br><form name=\"SMS\" method=\"POST\" action=\"sms.sh\">
		$L_USERNAME: <font color=\"blue\">$URIC</font> &nbsp;&nbsp; $L_NAME: <font color=\"blue\">$NRIC</font>
		&nbsp;&nbsp; $L_LAST_NAME: <font color=\"blue\">$CRIC</font> &nbsp;&nbsp;$L_CLASS: <font color=\"blue\">$PRIC</font>
		&nbsp;&nbsp;$L_OWNER: <font color=\"blue\">$OWRIC</font> &nbsp;&nbsp;$L_VALID: <font color=\"blue\">$SCRIC</font>"
		if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
		[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
			echo "&nbsp;&nbsp;$C_ROOM_NAME: <font color=\"blue\">$SRIC</font>"
		fi
	else
		echo "<form name=\"SMS\" method=\"POST\" action=\"sms.sh\">"
	fi
	echo "<br>&nbsp;<br><table class=\"tabellain\" width=\"750\" border=\"1\">
	<tr>
	<td WIDTH=\"1%\" class=\"intesta\">N.</td>
	<td WIDTH=\"1%\" class=\"intesta\">C.</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_USERNAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_NAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_LAST_NAME</td>
	<td WIDTH=\"25%\" class=\"intesta\">$L_TELEPHONE</td>
	</tr>"
	NUM=0
	CONTROLLDAP="(&(!(telephoneNumber=?)) $CONTROLLDAP )"
	USERNAMEPEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAP" -S uid uid | sed -n '/uid:/p' | awk '{ print $2 }')
	if [ -n "$MUDC" ];then
		for PROG in $(ls -A $C_ZT_DIR/mudc/prog);do
			TM="$(cat $C_ZT_DIR/mudc/prog/$PROG/Phone)"
			CONTROLLDAPT="(&(telephoneNumber=$TM) $CONTROLLDAP )"
			CONTROLUIDT=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" telephoneNumber=$TM uid | sed -n '/uid:/p' | awk '{ print $2 }')
			if [ -z "$(echo "$USERNAMEPEOPLE2" | grep "$CONTROLUIDT")" ];then
				USERNAMEPEOPLE2="$USERNAMEPEOPLE2 $(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAPT" -S uid uid | sed -n '/uid:/p' | awk '{ print $2 }') "
			fi
		done
		USERNAMEPEOPLE="$USERNAMEPEOPLE2"
	fi
	for USERNAME in $USERNAMEPEOPLE;do
		if [ "$USERNAME" != "admin" ];then
			ldap_search_people "uid=$USERNAME"
			ldap_search_radius "$USERNAME"
			if [[ -n "$PHONE" ]] && [[ "$HIDDEN" == "no" || "$UTENTEC" == "$C_ADMIN" ]] && [[ -z "$CLASS_RIC" || "$CLASS" == "$CLASS_RIC" ]];then
				PHONE="$PHONE"
				NUM1=$(($NUM+1))
				BG="$C_BG"
				[ $(expr $NUM1 % 2 ) -eq 0 ] && BG="$C_BG1"
				echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$NUM1</td>
				<td align=\"center\"><input id=\"S$NUM\" name=\"CLI$NUM\" value=\"$PHONE\" type=\"checkbox\" checked=\"checked\"></td>
				<td align=\"center\">$USERNAME</td>
				<td align=\"center\">$NAME</td>
				<td align=\"center\">$LAST_NAME</td>
				<td align=\"center\">$PHONE</td>
				</tr>"
				NUM=$(($NUM+1))
			fi
		fi
	done
	NUMTOT=$(($NUM-1))
	echo "</table><br>"
	if [ "$NUM" == "0" ];then
		echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<p><font color=\"red\">$L_NO_RESULT</font><p>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
		<form method=\"POST\" action=\"sms.sh\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form><p>&nbsp;<p>"
		./footer.sh
		exit
	fi
	echo "$L_SENDER: $C_SMS_SENDER <p>$L_SMS_TEXT: <br>
	<textarea name=\"TEXT_SMS\" cols=\"80\" rows=\"2\" onkeyup=\"evalEntryLength(this, 160, true, '', '');
	displayRemLength('charCount');\"></textarea><br>
	<span id=\"charCount\">160</span> $L_CHARACTERS_LEFT
	</p>
	<img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
	<input type=\"hidden\" name=\"NUMTOT\" value=\"$NUMTOT\">
	<input type=\"hidden\" name=\"CONTROL_PLAIN\" value=\"ok\">
	<input type=\"submit\" name=\"INVIA\" class=\"bottone\" value=\"$L_SEND_SMS\"
	onClick=\"javascript:return confirm('$L_ALERT_SEND_SMS');\"></form><p>&nbsp;"
fi
./footer.sh
