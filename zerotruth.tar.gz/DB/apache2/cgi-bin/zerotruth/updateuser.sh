#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

DAYS=$(date +%w)
ORAS=$(date +%H)
MINS=$(date +%M)
ORAMIN=$ORAS$MINS
ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
if [ -n "$AGGIORNA" ];then
	if [ "$INFO" == "$L_NOT_ACTIVE" ];then
		return_page "updateuser.sh?USERUPDATE=$USERNAME"
		exit
	fi
	USERNAME=$(echo "$USERNAME" | sed 's/\(.*\)/\L\1/')
	$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERNAME"
	if [ -z "$C_ANONYMOUS_USER" ] && [[ -z "$NAME" || -z "$LAST_NAME" ]];then
		$C_ZT_BIN_DIR/zt "Errore" "$L_ANONYMOUS_NOT_ALLOWED" "updateuser.sh" "USERUPDATE" "$USERNAME"
		exit
	fi
	if [ -n "$C_ANONYMOUS_USER" ] && [[ -z "$NAME" || -z "$LAST_NAME" ]];then
		if [ -z "$NAME" ];then
			NAME="$L_ANONYMOUS"
			NAME_PRINT="AN"
		fi
		if [ -z "$LAST_NAME" ];then
			LAST_NAME="$L_ANONYMOUS"
			LAST_NAME_PRINT="AN"
		fi
	fi
	PASSWORD=$(echo "$PASSWORD" | sed 's/[^[:alnum:]]//g')
	if [ -n "$MUDC" ];then
		OLDPASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn | grep '^sn' | awk '{print $NF}')
		CNUMB="$(echo "$OLDPASS" |  grep [^[:digit:]] )"
		if [ -n "$(echo "$OLDPASS" |  grep [^[:digit:]] )" ];then
			PASSWORD="$RANDOM$RANDOM"
			PASSWORD="$(echo ${PASSWORD:0:6})"
		fi
	fi
	PASSWORD_ORI="$PASSWORD"
	if [ -z $PHONE ];then
		PHONE="?"
	else
		controlprefix "$PREFIX" "updateuser.sh" "USERUPDATE" "$USERNAME"
		PHONE="$PREFIX$PHONE"
		controltelefono "$PHONE" "updateuser.sh" "USERUPDATE" "$USERNAME"
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "(&(!(uid=$USERNAME))(telephoneNumber=$PREFIX$PHONE))")
		CPHONE=$( echo "$LINE" | grep -e '^telephoneNumber: ' | sed 's/^telephoneNumber: //g')
		if [ -n "$CPHONE" ];then
			$C_ZT_BIN_DIR/zt "Errore" "$L_TEL_PRE" "updateuser.sh" "USERUPDATE" "$USERNAME"
			exit
		fi
	fi
	if [ -z "$EMAIL" ];then
		EMAIL="?"
	else
		controlemail "$EMAIL" "updateuser.sh" "USERUPDATE" "$USERNAME"
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "(&(!(uid=$USERNAME))(mail=$EMAIL))")
		CEMAIL=$( echo "$LINE" | grep -e '^mail: ' | sed 's/^mail: //g')
		if [ -n "$CEMAIL" ];then
			$C_ZT_BIN_DIR/zt "Errore" "$L_EMAIL_PRE" "updateuser.sh" "USERUPDATE" "$USERNAME"
		exit
		fi
	fi
	[ -z "$DAY_EXPIRE" ] && DAY_EXPIRE="$L_DAY"
	[ -z "$MONTH_EXPIRE" ] && MONTH_EXPIRE="$L_MONTH"
	[ -z "$YEAR_EXPIRE" ] && YEAR_EXPIRE="$L_YEAR"
	if [[ "$DAY_EXPIRE" == "$L_DAY" || "$MONTH_EXPIRE" == "$L_MONTH" || "$YEAR_EXPIRE" == "$L_YEAR" ]];then
		DAY_EXPIRE="31"
		MONTH_EXPIRE="12"
		YEAR_EXPIRE="2037"
	fi
	SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
	[ -z "$INFO" ] && INFO="?"
	[ -z "$ROOM" ] && ROOM="?"
	[ -z "$HIDDEN" ] && HIDDEN="no"
	[ -z "$MCPI" ] && MCPI="?"
	[ -z "$CLASS" ] && CLASS="DEFAULT"
	[ -z "$MAXDAYS" ] && MAXDAYS="?"
	[ -z "$MUDC" ] && MUDC="?"
	ldap_modify_people "givenName sn mail telephoneNumber gecos shadowExpire hidden roomName MCpInterfaces maxDays class mudc"
	if [ -n "$CONTROLMODIFY" ]; then
		$C_ZT_BIN_DIR/zt "Errore" "$L_PROBLEM_UPDATER" "updateuser.sh" "USERUPDATE" "$USERNAME"
		exit
	fi
	ldap_modify_radius "radiusUserCategory sn"
	if [ -n "$CONTROLMODIFY" ]; then
		$C_ZT_BIN_DIR/zt "Errore" "$L_PROBLEM_UPDATER" "updateuser.sh" "USERUPDATE" "$USERNAME"
		exit
	fi
	#$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME" "UPDATE"
	#$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UPDATED user $USERNAME $L_CLASS $CLASS"
	fi
	$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USERNAME" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE"
	if [ -n "$CONTROLPASSLOCK" ];then
		PASSWORD="$PASSLOCK"
		ldap_modify_radius "sn"
	fi
	if [ -n "$CREDIT" ];then
		CREDIT_LOG=$(echo "$CREDIT" | awk '{printf("%.2f\n", $0)}')
		if [ $(cat $C_ACCT_DIR/credits/$USERNAME/Credit) ];then
			CREDITES=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
		else
			CREDITES=0
		fi
		if [ $( echo $CREDIT | cut -sd'-' -f2) ];then
			CREDIT=$( echo $CREDIT | cut -d'-' -f2)
			CREDIT=$(echo "$CREDITES-$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		else
			CREDIT=$(echo "$CREDITES+$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		fi
		if [ ! -d $C_ACCT_DIR/credits/$USERNAME ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USERNAME"
		fi
		$C_ZT_BIN_DIR/zt "Salva" "$CREDIT" "$C_ACCT_DIR/credits/$USERNAME/Credit"
		if [ "$CREDIT_LOG" != "0.00" ];then
			$C_ZT_BIN_DIR/zt "Aggiungi"	"$USERNAME+$(date '+%b %d, %Y')+$( date '+%T')+$CREDIT_LOG+cash" "$C_ZT_LOG_DIR/pp/payments"
		fi
		if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UPDATED $L_CREDIT user $USERNAME $CREDIT_LOG"
		fi
	fi
	$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME" "UPDATE"
	$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"	
	source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
	limituser "$USERNAME"
	DATE_CREATED_YEAR=$(echo "$CREATED" | cut -c 1-4 )
	DATE_CREATED_MONTH=$(echo "$CREATED" | cut -c 5-6 )
	DATE_CREATED_DAY=$(echo "$CREATED" | cut -c 7-8 )
	if [ "$C_FORM_DATE" == "ita" ];then
		CREATED="$DATE_CREATED_DAY/$DATE_CREATED_MONTH/$DATE_CREATED_YEAR"
	else
		CREATED="$DATE_CREATED_YEAR/$DATE_CREATED_MONTH/$DATE_CREATED_DAY"
	fi
	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n"
	if [ "$ROOM" != "?" ];then
		TEXT_EMAIL="$TEXT_EMAIL\n$C_ROOM_NAME: $ROOM"
	fi
	if [ "$MAXDAYS" != "?" ];then
		EXPIRE="$MAXDAYS $L_DAYS"
	else
		if [ "$SHADOWEXPIRE" == "24836" ];then
			EXPIRE=$L_NO_LIMIT
		else
			if [ "$C_FORM_DATE" == "ita" ];then
				EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%d/%m/%Y)
			else
				EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y/%m/%d)
			fi
		fi
	fi
	TEXT_EMAIL="$TEXT_EMAIL\nusername: $USERNAME\n$L_PASSWORD: $PASSWORD_ORI\n$L_NAME: $NAME\n$L_LAST_NAME: $LAST_NAME"
	TEXT_EMAIL="$TEXT_EMAIL\n$L_TELEPHONE: $PHONE\n$L_CLASS: $CLASS\n$L_CREATED: $CREATED\n$L_EXPIRY: $EXPIRE"
	limituseremail
	TEXT_ADMIN="$TEXT_EMAIL\n$L_BY: $UTENTEC"
	TEXT_EMAIL="$TEXT_EMAIL\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	if [ "$C_EMAIL_NOT" == "on" ] && [ "$EMAIL" != "?" ] && [ "$EMAIL_NOT" == "on" ];then
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_USERUPDATE" "$TEXT_EMAIL" "$EMAIL"
	fi
	if [ "$C_NOT_EMAIL_UPDATE_USER" == "on" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ];then
		TEXT_ADMIN="$TEXT_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		TEXT_ADMIN=$(urlencode "$TEXT_ADMIN")
		TEXT_ADMIN=$($C_ZT_BIN_DIR/convplain "$TEXT_ADMIN")
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_USERUPDATE" "$TEXT_ADMIN" "$C_ADMIN_EMAIL"
	fi
	if [ "$C_SMS_NOT" == "on" ] && [ $PHONE != "?" ] && [ "$SMS_NOT" == "on" ];then
		if [ "$ROOM" != "?" ];then
			ROOM1="$C_ROOM_NAME: $ROOM"
		fi
		TEXT="$C_HOTSPOT_NAME: $L_USERUPDATE $L_NAME: $NAME $L_LAST_NAME: $LAST_NAME user: $USERNAME password: $PASSWORD_ORI $ROOM1"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$PHONE" "$TEXT"
	fi
	if [ -n "$C_NOT_SMS_UPDATE_USER" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ];then
		if [ "$ROOM" != "?" ];then
			ROOM1="$C_ROOM_NAME: $ROOM"
		fi
		TEXT="$C_HOTSPOT_NAME: $L_USERUPDATE $USERNAME $NAME $LAST_NAME $ROOM1 $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT"
	fi
	if [ "$PRINT" == "on" ];then
		[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
		[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
		PASSWORD=$( echo $PASSWORD | cut -d'-' -f1)
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<br><font color=\"blue\" size=\"5\">$L_USER_TICKET</font><br>
		<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
		[ "$NAME" == "$L_ANONYMOUS" ] && NAME_PRINT="AN"
		[ "$LAST_NAME" == "$L_ANONYMOUS" ] && LAST_NAME_PRINT="AN"
		source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
		[ -n "$NAME_PRINT" ] && NAME="$L_ANONYMOUS"
		[ -n "$LAST_NAME_PRINT" ] && LAST_NAME="$L_ANONYMOUS"
		INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
		echo "<div id=\"ticket\">
		<center><table width=\"350\" border=\"1\">
		<tr><td colspan=\"2\"><img src=\"$APACHE_BASEDIR/images/imguser.png\" WIDTH=\"350px\"></td></tr>
		<tr><td>
		<table width=\"350\" border=\"0\" style=\"font: ${C_FONT_TICKET}px "Trebuchet MS",Arial,sans-serif;\">"
		if [ -n "$C_PRINT_QR" ];then
			$C_ZT_BIN_DIR/zt "QrCode" "$USERNAME" "$PASSWORD"
			echo "<tr><td colspan =\"2\" align=\"center\"><img src=\"$APACHE_BASEDIR/images/qrcode/${USERNAME}.png\"></td></tr>"
		fi
		if [[ -z "$C_PRINT_QR" || -z "$C_PRINT_QR_ONLY" ]];then
			echo "<tr><td width=\"130px\"><b>&nbsp;$L_USERNAME: </b></td><td><b>$USERNAME</b></td></tr>
			<tr><td><b>&nbsp;$L_PASSWORD: </b></td><td><b>$PASSWORD_ORI</b></td></tr>"
			if [ -n "$C_PRINT_NAME" ];then
				echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
				<tr><td>&nbsp;$L_LAST_NAME: </td><td>$( echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
			else
				if [ "$NAME" != "$L_ANONYMOUS" ];then
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
					<tr><td>&nbsp;$L_LAST_NAME: </td><td>$( echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
				fi
			fi
			if [ $ROOM != "?" ];then
				echo "<tr><td>&nbsp;$C_ROOM_NAME: </td><td>$ROOM</td></tr>"
			fi
			if [ -n "$C_PRINT_CLASS" ];then
				echo "<tr><td>&nbsp;$L_CLASS: </td><td>$CLASS</td></tr>"
			fi
			if [ $EMAIL != "?" ];then
				echo "<tr><td>&nbsp;$L_EMAIL: </td><td>$EMAIL</td></tr>"
			fi
			if [ $PHONE != "?" ];then
				echo "<tr><td>&nbsp;$L_TELEPHONE: </td><td>$PHONE</td></tr>"
			fi
			if [ -n "$C_PRINT_CREATED" ];then
				echo "<tr><td>&nbsp;$L_CREATED: </td><td>$CREATED</td></tr>"
			fi
			if [ -n "$C_PRINT_EXP" ];then
				echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXPIRE</td></tr>"
			else
					if [ "$EXPIRE" != "$L_NO_LIMIT" ];then
					echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXPIRE</td></tr>"
				fi
			fi
			if [ "$USERDAYS" != "$L_ALL" ];then
				echo "<tr><td>&nbsp;$L_DAYS: </td><td>$USERDAYS</td></tr>"
			fi
			if [ "$USERTIME" != "$L_ALL" ];then
				echo "<tr><td>&nbsp;$L_TIME: </td><td>$USERTIME</td></tr>"
			fi
			if [ -n "$USERHOURSDAY" ];then
				echo "<tr><td>&nbsp;$L_DMAX_HOURS: </td><td>$USERHOURSDAY</td></tr>"
			fi
			if [ -n "$USERHOURSMONTH" ];then
				echo "<tr><td>&nbsp;$L_MMAX_HOURS: </td><td>$USERHOURSMONTH</td></tr>"
			fi
			if [ -n "$USERMBDAY" ];then
				echo "<tr><td>&nbsp;$L_DMAX_MB: </td><td>$USERMBDAY</td></tr>"
			fi
			if [ -n "$USERMBMONTH" ];then
				echo "<tr><td>&nbsp;$L_MMAX_MB: </td><td>$USERMBMONTH</td></tr>"
			fi
		fi
		echo "</table>"
		if [ -n "$INFO_TICKET" ];then
			echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
			<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
		fi
		echo "</table></div><p>&nbsp;<p>"
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<p>
		<table><tr><td>
		<input type=button name=\"PRINT\" class=\"bottone\" value=\"$L_PRINT_TICKET\" onClick=\"StampaTicket()\">
		</td><td>"
		REFERER="$(echo "$REFERER" | sed 's/-pd-/\?/g' | sed 's/-ee-/\&/g' | sed 's/-ug-/\=/g')"
		echo "<form action=\"$REFERER\" method=\"POST\">
		<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_USERLIST\">
		</form>
		</td></tr></table>
		<p>"
		./footer.sh
		exit
	else
		CONTROL="ok"
	fi
fi
[ "$CONTROL" == "ok" ] && USERUPDATE="$USERNAME"
ldap_search_people "uid=$USERUPDATE"
ldap_search_radius "$USERNAME"
if [ $(echo $PASSWORD | grep '-') ];then
	PASSWORD=$(echo $PASSWORD | cut -d'-' -f1)
fi
CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
if [ "$CONTROL" == "ok" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_USER $USERNAME $L_UPDATED</font><br>"
else
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_UPDATE_USER $USERNAME</font><br>"
fi
if [[ "$C_CREDIT" == "on" || "$UTENTEC" == "$C_ADMIN" ]];then
	if [[ -n "$CREDIT" && "$CREDIT" != "0.00" ]];then
		echo "<br><font color=\"#0000FF\">$L_CREDIT $CREDIT $C_CURRENCY</font>"
	fi
fi
limitclassjs
echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><br>&nbsp;
<form name=\"UPDATE_USER\" action=\"updateuser.sh\" method=\"POST\">"
if [[ "$C_LANGUAGE" == "francais" || "$C_LANGUAGE" == "polski" ]];then
	LARGE=870
	LARGETD=200
	LARGETD1=120
else
	LARGE=800
	LARGETD=100
	LARGETD1=100
fi
echo "<table WIDTH=\"${LARGE}px\" border=\"0\" cellpadding=\"0px\">
<tr><td width=\"${LARGETD}px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"94px\">
</td><td width=\"${LARGETD1}px\"></td><td width=\"84px\"></td><td width=\"84px\"></td><td width=\"84px\"></td></tr>
<tr><td height=\"30\">$L_USERNAME:</td>
<td colspan=\"3\"><input class=\"text1\" readonly type=text name=\"USERNAME\" value=\"$USERNAME\"></td>
<td></td>
<td>$L_PASSWORD:</td>
<td colspan=\"3\" height=\"30\"><input id=\"pwd1\" size=\"15\" type=\"password\" name=\"PASSWORD\" value=\"$PASSWORD\" >
&nbsp;<a href=\"#\" onclick=\"hidden_password('pwd1', 'show' , 'hide', '1');\" id=\"showhide1\"><img src=\"/images/show.png\" alt=\"show\"></a></td></tr>
<tr><td>$L_NAME:</td>
<td colspan=\"3\" height=\"30\"><input type=\"text\" class=\"text1\" name=\"NAME\" value=\"$NAME\"></td>
<td>&nbsp;&nbsp;</td>
<td>$L_LAST_NAME:</td>
<td colspan=\"3\" height=\"30\"><input type=text class=\"text1\" name=\"LAST_NAME\" value=\"$LAST_NAME\"></td></tr>
<tr><td>$L_EMAIL:</td>
<td colspan=\"3\" height=\"30\"><input type=\"text\" class=\"text1\" name=\"EMAIL\" value=\"$EMAIL\"></td>
<td>&nbsp;&nbsp;</td>
<td>$L_TELEPHONE:</td>
<td colspan=\"3\" height=\"30\"><input type=\"text\" class=\"prefix1\" name=\"PREFIX\" value=\"$PREFIX\">
<input type=\"text\" class=\"phone1\" name=\"PHONE\" value=\"$PHONE1\"></td></tr>"
if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || [[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td>$C_ROOM_NAME:</td><td height=\"30\"><input type=\"text\" class=\"room1\" name=\"ROOM\" value=\"$ROOM\"></td>"
	CONTROLROOM="yes"
fi
if [ -n "$C_CLASS" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$CONTROLROOM" ];then
		echo "<td>$L_CLASS:</td><td colspan=\"3\" height=\"30\">"
	else
		echo "<td colspan=\"2\" align=\"right\" cellpadding=\"0\" height=\"30\">$L_CLASS:"
	fi
	echo "<select name=\"CLASS\" onchange=\"limitclass(this.options[this.selectedIndex].value, this.options[this.selectedIndex].id)\">"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		for CL in $(ls $C_CLASSES_DIR);do
			if [ $CL != "$CLASS" ];then
				INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
				[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
				eval LIMITCLASS="\$LIMITCLASS$CL"
				echo "<option id=\"$LIMITCLASS-$INTCL\" name=\"NCLASS\" value=\"$CL\">$CL</option>"
			fi
		done
		CL="$CLASS"
		eval LIMITCLASS="\$LIMITCLASS$CL"
		INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
		[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
		echo "<option id=\"$LIMITCLASS-$INTCL\" value=\"$CLASS\" selected>$CLASS</option></select>"
	else
		for CL in $(ls $C_CLASSES_DIR);do
			if [ -n "$(echo $C_CLASS_USER | grep "$CL")" ];then
				if [ $CL != "$CLASS" ];then
					INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
					[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
					eval LIMITCLASS="\$LIMITCLASS$CL"
					echo "<option id=\"$LIMITCLASS-$INTCL\" name=\"NCLASS\" value=\"$CL\">$CL</option>"
				fi
			fi
		done
		CL="$CLASS"
		eval LIMITCLASS="\$LIMITCLASS$CL"
		INTCL=$(cat $C_CLASSES_DIR/$CL/InterfacesClass)
		[ -z "$INTCL" ] && INTCL="$(cat $C_SYSTEM/cp/Interface)"
		echo "<option id=\"$LIMITCLASS-$INTCL\" value=\"$CLASS\" selected>$CLASS</option></select>"
	fi
	echo "</select>
	</td><td>&nbsp;&nbsp;</td>"
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<td height=\"30\" align=\"left\" colspan=\"2>\">"
	else
		echo "<td height=\"30\" align=\"left\" colspan=\"4>\">"
	fi
	INT_CLASS="$(cat $C_CLASSES_DIR/$CLASS/InterfacesClass)"
	echo "<div id=\"intclass\">Int: <font size=\"2\">$INT_CLASS</font></div>"
fi
if [ "$UTENTEC" == "$C_ADMIN" ];then
	echo "</td><td align=\"right\" colspan=\"2\" height=\"30\">$L_HIDDEN:
	<select name=\"HIDDEN\">"
	if [ "$HIDDEN" == "no" ];then
		echo "<option value=\"yes\">$L_YES</option>
		<option value=\"no\" selected>$L_NO</option>"
	else
		echo "<option value=\"no\">$L_NO</option>
		<option value=\"yes\" selected>$L_YES</option>"
	fi
	echo "</select>"
else
	echo "<input type=\"hidden\" name=\"HIDDEN\" value=\"no\">"
fi
echo "</td></tr>"
YNOW=$(date +%Y)
YEND=$(($YNOW+10))
if [ -n "$C_EXPIRE" ] || [ "$UTENTEC" == "$C_ADMIN" ] ;then
	[ -z "$DAY_EXPIRE" ] && DAY_EXPIRE="$L_DAY"
	[ -z "$MONTH_EXPIRE" ] && MONTH_EXPIRE="$L_MONTH"
	[ -z "$YEAR_EXPIRE" ] && YEAR_EXPIRE="$L_YEAR"
	if [ "$C_FORM_DATE" == "ita" ];then
		echo "<tr><td>$L_EXPIRY:</td>
		<td height=\"30\"><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\">$L_DAY</option>
		<option value=\"$DAY_EXPIRE\" selected>$DAY_EXPIRE</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\" >$L_MONTH</option>
		<option value=\"$MONTH_EXPIRE\" selected>$MONTH_EXPIRE</option></select>
		</td>
		<td align=\"right\"><select name=\"YEAR_EXPIRE\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\" >$L_YEAR</option>
		<option value=\"$YEAR_EXPIRE\" selected>$YEAR_EXPIRE</option></select></td>"
	else
		echo "<tr><td>$L_EXPIRY:</td>
		<td height=\"30\"><select name=\"YEAR_EXPIRE\">"
		for A in $(seq $YNOW $YEND);do
			echo "<option value=\"$A\" selected>$A</option>"
		done
		echo "<option value=\"\">$L_YEAR</option>
		<option value=\"$YEAR_EXPIRE\" selected>$YEAR_EXPIRE</option></select></td>
		<td align=\"center\"><select name=\"MONTH_EXPIRE\">"
		for M in $(seq 1 12);do
			echo "<option value=\"$M\" selected>$M</option>"
		done
		echo "<option value=\"\">$L_MONTH</option>
		<option value=\"$MONTH_EXPIRE\" selected>$MONTH_EXPIRE</option></select></td>
		<td align=\"right\"><select name=\"DAY_EXPIRE\">"
		for G in $(seq 1 31);do
			echo "<option value=\"$G\" selected>$G</option>"
		done
		echo "<option value=\"\">$L_DAY</option>
		<option value=\"$DAY_EXPIRE\" selected>$DAY_EXPIRE</option></select></td>"
	fi
	echo "<td>&nbsp;&nbsp;</td>
	<td>$L_OR_DAYS:</td><td>
	<select name=\"MAXDAYS\">"
	for MD in $(seq 365 1);do
		echo "<option value=\"$MD\" selected>$MD</option>"
	done
	echo "<option value=\"\"></option>
	<option value=\"$MAXDAYS\" selected>$MAXDAYS</option>
	</select></td>"
	CVAL="yes"
fi
if 	[ -n "$C_CREDIT" ] || [ "$UTENTEC" == "$C_ADMIN" ];then
	if [ -z "$C_EXPIRE" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		echo "<tr><td height=\"30\">$L_CREDIT:</td><td colspan=\"8\">"
	else
		echo "<td height=\"30\" colspan=\"2\" align=\"right\">$L_CREDIT: "
	fi
	echo "<input type=\"text\" class=\"credit\" name=\"CREDIT\" value=\"\"></td>"
	CVAL="yes"
fi
[ -n "$CVAL" ] && echo "</td></tr>"
limitclass "$CLASS"
echo "<tr><td height=\"30\">$L_LIMIT: </td><td colspan=\"4\">
$L_HOURS $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limithoursday\">"$HDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$L_HOURS $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limithoursmonth\">"$HMC"</div></td>
<td colspan=\"4\" align=\"right\">
MB $L_FOR_DAY: <div style=\"display: inline-block;\" id=\"limitmbday\">"$MDC"</div> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	MB $L_FOR_MONTH: <div style=\"display: inline-block;\" id=\"limitmbmonth\">"$MMC"</div></td>
</tr><tr>
<td height=\"30\">$L_DAYS:</td><td colspan=\"4\">
<div style=\"display: inline-block;\" id=\"limitdays\">"$DC"</div>
</td>
<td colspan=\"4\" align=\"right\">$L_TIME:
<div style=\"display: inline-block;\" id=\"limitrange\">"$RANGE"</div>
</td></tr>"

if [[ -n "$C_PRINT_TICKET" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<tr><td height=\"30\">$L_TICKET:</td><td colspan=\"4\">"
	echo "<input name=\"PRINT\" type=\"checkbox\" checked=\"checked\">
	<select name=\"LANGUAGE_PRINT\">"
	for LANG in $(ls -A ./language/);do
		if [ "$LANG" != "$C_LANGUAGE" ] && [ "$LANG" != "index.html" ];then
			LANG1=$LANG
			[ "$LANG" == "espanol" ] && LANG1="espa&ntilde;ol"
			[ "$LANG" == "portugues" ] && LANG1="portugu&ecirc;s"
			[ "$LANG" == "francais" ] && LANG1="fran&ccedil;ais"
			echo "<option value=\"$LANG\">$LANG1</option>"
		fi
	done
	LANGUAGE1=$C_LANGUAGE
	[ "$C_LANGUAGE" == "espanol" ] && LANGUAGE1="espa&ntilde;ol"
	[ "$C_LANGUAGE" == "portugues" ] && LANGUAGE1="portugu&ecirc;s"
	[ "$C_LANGUAGE" == "francais" ] && LANGUAGE1="fran&ccedil;ais"
	echo "<option value=\"$C_LANGUAGE\" selected=\"selected\">$LANGUAGE1</option></select>"
	CONTROLTICKET="ok"
fi
if [ -n "$CONTROLTICKET" ];then
	if [[ -n "$C_MUDC" && -n "$C_USER_MUDC" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_MUDC" ]];then
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$LM_USERMUDC: "
		if [ -n "$MUDC" ];then
			echo "<input name=\"MUDC\" type=\"checkbox\" checked></td>"
		else
			echo "<input name=\"MUDC\" type=\"checkbox\"></td>"
		fi
	fi
else
	if [[ -n "$C_MUDC" && -n "$C_USER_MUDC" ]] || [[ "$UTENTEC" == "$C_ADMIN" && -n "$C_MUDC" ]];then
		echo "<tr><td height=\"30\">Mudc:</td><td colspan=\"4\">$LM_USER: "
		if [ -n "$MUDC" ];then
			echo "<input name=\"MUDC\" type=\"checkbox\" checked></td>"
		else
			echo "<input name=\"MUDC\" type=\"checkbox\"></td>"
		fi
		CONTROLTICKET="ok"
	fi
fi
if [ -n "$C_SMS_NOT" ] || [ -n "$C_EMAIL_NOT" ];then
	if [[ -n "$CONTROLTICKET" && -n "$CONTROLLIMIT" ]];then
		echo "<td colspan=\"3\" align=\"right\">$L_NOTIFICATION_USER:&nbsp;"
		CONTROLSPAN="yes"
	fi
	if [[ -z "$CONTROLTICKET" && -z "$CONTROLLIMIT" ]];then
		echo "<tr><td height=\"30\">$L_NOTIFICATION_USER:</td><td colspan=\"3\">"
	fi
	if [[ -n "$CONTROLTICKET" || -n "$CONTROLLIMIT" ]] && [ -z "$CONTROLSPAN" ];then
		echo "<td colspan=\"3\" align=\"right\">$L_NOTIFICATION_USER:&nbsp;"
	fi
	if [ -n "$C_EMAIL_NOT" ];then
		echo "Email: <input name=\"EMAIL_NOT\" type=\"checkbox\">"
	fi
	if [ -n "$C_SMS_NOT" ];then
		echo "&nbsp;&nbsp;SMS: <input name=\"SMS_NOT\" type=\"checkbox\">"
	fi
fi
echo "</td></tr>"
if [[ -n "$C_REGISTER_INFO" || "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<tr><td>$L_INFO:</td><td colspan=\"8\">"
	if [ "$INFO" == "wait_asterisk" ];then
		echo "<input style=\"width:710px\" type=text readonly class=\"info\" name=\"INFO\" value=\"$L_NOT_ACTIVE\"></td></tr>"
	else
		echo "<input style=\"width:710px\" type=text class=\"info\" name=\"INFO\" value=\"$INFO\"></td></tr>"
	fi
fi
echo "</table>
<p><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
<input type=\"hidden\" name=\"CREATED\" value=\"$CREATED\">"
REFERER=$(echo "$HTTP_REFERER" | sed 's/\// /g' | awk '{print $NF}' | sed 's/\?/-pd-/g' | sed 's/\&/-ee-/g' | sed 's/\=/-ug-/g')
echo "<input type=\"hidden\" name=\"REFERER\" value=\"$REFERER\">
<input type=\"submit\" name=\"AGGIORNA\" class=\"bottonelinea\" value=\"$L_MODIFY\"></form>"
if [ -z "$SEARCH" ];then
	echo "<form action=\"$HTTP_REFERER\" method=\"POST\">
	<input type=\"hidden\" name=\"LETTER\" value=\"$LETTER\">
	<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\">
	</form><br>&nbsp;"
else
	echo "<form action=\"$HTTP_REFERER\" method=\"POST\">
	<input type=\"hidden\" name=\"SEARCH\" value=\"yes\">
	<input type=\"hidden\" name=\"N_S\" value=\"$N_S\">
	<input type=\"hidden\" name=\"USERNAME_RIC\" value=\"$USERNAME_RIC\">
	<input type=\"hidden\" name=\"NAME_RIC\" value=\"$NAME_RIC\">
	<input type=\"hidden\" name=\"LAST_NAME_RIC\" value=\"$LAST_NAME_RIC\">
	<input type=\"hidden\" name=\"CLASS_RIC\" value=\"$CLASS_RIC\">
	<input type=\"hidden\" name=\"ROOM_RIC\" value=\"$ROOM_RIC\">
	<input type=\"hidden\" name=\"PHONE_RIC\" value=\"$PHONE_RIC\">
	<input type=\"hidden\" name=\"EMAIL_RIC\" value=\"$EMAIL_RIC\">
	<input type=\"hidden\" name=\"EXPIRE_RIC\" value=\"$EXPIRE_RIC\">
	<input type=\"hidden\" name=\"OWNER_RIC\" value=\"$OWNER_RIC\">
	<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\">
	</form><br>&nbsp;"
fi
./footer.sh

