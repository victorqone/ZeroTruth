#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

INTCP="$(cat $C_CP_DIR/Interface)"
$C_ZT_BIN_DIR/zt "Salva" "$INTCP" "$C_CLASSES_DIR/DEFAULT/InterfacesClass"

if [ -n "$CLASS_DELETE" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_CLASSES</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	wait "750"
	$C_ZT_BIN_DIR/zt "DisconnettiClass" "$CLASS_DELETE"
	$C_ZT_BIN_DIR/zt "Cancella" "$C_CLASSES_DIR/$CLASS_DELETE"
	if [ -n "$(ls $C_ZT_CONF_DIR/cbqconf | grep "\.$CLASS_DELETE$")" ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/*.$CLASS_DELETE"
	fi
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}STOP-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}STOP-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}START-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}STOPSEC-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}STOPSEC-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${CLASS_DELETE}STARTSEC-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -n "$CONTROL_CRON" ];then
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
#	for NUMBER in $(seq 1 6);do
#		USER_CLASSES="C_CLASS_USER$NUMBER"
#		eval USER_CLASSES="\$$USER_CLASSES"
#		USER_CLASSES="$(echo $USER_CLASSES | sed "s/$CLASS_DELETE//g" | sed "s/^ *//g")"
#		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CLASS_USER$NUMBER" "$USER_CLASSES"
#		if [ -z $(cat $C_ZT_CONF_DIR/zt.config | grep "C_CLASS_USER$NUMBER" | cut -d'"' -f2) ];then
#			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CLASS_USER$NUMBER" "DEFAULT"
#		fi
#	done
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETED $L_CLASS $CLASS_DELETE"
	fi
	CLASSES=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn)
	USERSCLASS=$(echo "$CLASSES" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USER_CLASS in $USERSCLASS;do
		LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER_CLASS radiusUserCategory)
		CLASS=$( echo "$LINE" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
		if [ "$CLASS" == "$CLASS_DELETE" ];then
			MOD="dn: cn=$USER_CLASS,ou=Radius,$C_LDAPBASE\nradiusUserCategory: DEFAULT"
			echo -e "$MOD" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			MODP="dn: uid=$USER_CLASS,ou=People,$C_LDAPBASE\nclass: DEFAULT"
			echo -e "$MODP" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			$C_ZT_BIN_DIR/zt "ChangeClass" "DEFAULT" "$USER_CLASS"
		fi
	done
	$C_ZT_BIN_DIR/zt "ShaperRestart"
	if [ -n "$C_NOT_SMS_DELETE_CLASS" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_DELETED_CLASS $CLASS_DELETE $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN"
	fi
	if [ -n "$C_NOT_EMAIL_DELETE_CLASS" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_DELETED_CLASS $CLASS_DELETE\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_DELETED_CLASS" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		UpdateClassRemote
	fi
	if [ "$CLASS_DELETE" == "$C_AR_CLASS" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_AR_CLASS" "DEFAULT"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ChargePayPal"
	fi
	return_page "classes.sh"
	exit
fi
if [ -n "$UPDATE1" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_CLASSES</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	wait "750"
	$C_ZT_BIN_DIR/zt "DisconnettiClass" "$CLASSNAME"
	if [ -z $COSTM ] || [ $COSTM != $(echo "$COSTM" | awk '{print strtonum ($1)}') ] || [ -z "$TYPE" ];then
		 COSTM=""
	fi
	if [ -z $COSTH ] || [ $COSTH != $(echo "$COSTH" | awk '{print strtonum ($1)}') ] || [ -z "$TYPE" ];then
		 COSTH=""
	fi
	if [[ -z $MB || $MB != $(echo "$MB" | awk '{print strtonum ($1)}') || -n $(echo "$MB" | cut -sd'.' -f1) || -n $(echo "$MB" | cut -sd',' -f1) ]];then
		 MB=""
	fi
	if [[ "$TYPE" != "pre" || -z $FREE_TIME || $FREE_TIME != $(echo "$FREE_TIME" | awk '{print strtonum ($1)}') || -n $(echo "$FREE_TIME" | cut -sd'.' -f1) || -n $(echo "$FREE_TIME" | cut -sd',' -f1) ]];then
		 FREE_TIME=""
	fi
	if [[ -z $HOURS || $HOURS != $(echo "$HOURS" | awk '{print strtonum ($1)}') || -n $(echo "$HOURS" | cut -sd'.' -f1) || -n $(echo "$HOURS" | cut -sd',' -f1) ]] ;then
		 HOURS=""
	fi
	if [[ "$C_SHAPER" == "on" && "$(cat $C_CLASSES_DIR/$CLASSNAME/ShaperType)" != "user" ]] && [ "$CLASSNAME" != "DEFAULT" ];then
		NUM_CLASS=$(cat $C_CLASSES_DIR/$CLASSNAME/NumClass )
		if [ -z $MBITS ] || [ $MBITS != $(echo "$MBITS" | awk '{print strtonum ($1)}') ];then
			MBITS=""
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASSNAME"
		else
			$C_ZT_BIN_DIR/zt "SaveBandwidth" "$NUM_CLASS.$CLASSNAME" "$MBITS"
		fi
		NUM_CLASS_UP=$(($NUM_CLASS+100))
		if [ -z $MBITSU ] || [ $MBITSU != $(echo "$MBITSU" | awk '{print strtonum ($1)}') ];then
			MBITSU=""
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS_UP.$CLASSNAME"
		else
			$C_ZT_BIN_DIR/zt "SaveBandwidthUp" "$NUM_CLASS_UP.$CLASSNAME" "$MBITSU"
		fi
		$C_ZT_BIN_DIR/zt "ShaperRestart"
	fi
	N_CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface | wc -w | awk '{print $1}')"
	if [ "$N_CP_INTERFACES" -gt 1 ];then
		CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface)"
		for ICP in $CP_INTERFACES;do
			AICPV="$(echo "$ICP" | sed 's/\.//g')"
			AICP=\$$AICPV
			eval AICP=$AICP
			if [ -n "$AICP" ];then
				CLASSINT="$CLASSINT $ICP"
			fi
		done
	else
		CLASSINT="$(cat $C_SYSTEM/cp/Interface)"
	fi
	CLASSINT="$(echo "$CLASSINT" | sed 's/^ *//g')"
	for CRON_DAYS in "LUN 1" "MAR 2" "MER 3" "GIO 4" "VEN 5" "SAB 6" "DOM 0";do
		set -- $CRON_DAYS
		eval CRON_DAY=\$$1
		if [ "$CRON_DAY" == "on" ];then
			DAYS_CRON="$DAYS_CRON+$2"
			[ $2 == $DAYS ] && CONTROLGS="ok"
		fi
	done
	if [[ -n "$HOUR_START" && -n "$MINUTES_START" && -n "$HOUR_STOP" && -n "$MINUTES_STOP" ]];then
		RANGE1="$HOUR_START:$MINUTES_START-$HOUR_STOP:$MINUTES_STOP"
	else
		RANGE1=""
	fi
	if [[ -n "$HOUR_START_SEC" && -n "$MINUTES_START_SEC" && -n "$HOUR_STOP_SEC" && -n "$MINUTES_STOP_SEC" ]];then
		RANGE2="$HOUR_START_SEC:$MINUTES_START_SEC-$HOUR_STOP_SEC:$MINUTES_STOP_SEC"
	else
		RANGE2=""
	fi
	$C_ZT_BIN_DIR/zt "UpdateClass" "$CLASSNAME" "$COSTM" "$COSTH" "$MB" "$HOURS" "$MBITS" "$MBITSU" "$TYPE" "$NUM_CLASS" "$FREE_TIME" "$CLASSINT" "$TYPE_SHAPER" "$DAYS_CRON" "$RANGE1" "$RANGE2" "$HOURS_DAY" "$HOURS_MONTH" "$MB_DAY" "$MB_MONTH-$SIM_CON-$BLOCK"
	if [[ "$TYPE" == "pre" && -n "$C_ACTIVE_PP" && "$CLASSNAME" == "$C_AR_CLASS" ]];then
		$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ChargePayPal"
	fi
	if [[ "$TYPE" != "pre" && -n "$C_ACTIVE_PP" && "$CLASSNAME" == "$C_AR_CLASS" ]];then
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_CP_DIR/Auth/Custom/ChargePayPal"
	fi
	if [ -n "$C_NOT_EMAIL_UPDATE_CLASS" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n "$C_EMAIL_ABI" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n\n$L_CLASS_UPDATE\n$CLASSNAME\n$L_BY $UTENTEC\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_CLASS_UPDATE" "$TEXT_EMAIL" "$C_ADMIN_EMAIL"
	fi
	if [ -n "$C_NOT_SMS_UPDATE_CLASS" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n "$C_SMS_ABIL" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$C_HOTSPOT_NAME $L_CLASS_UPDATE $CLASSNAME $L_BY $UTENTEC"
	fi
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		UpdateClassRemote
	fi
	UPDATE=""
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UPDATED $L_CLASS $CLASSNAME"
	fi
	return_page "classes.sh"
	exit
fi
if [ -n "$SAVE" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_CLASSES</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	if [ -z "$CLASSNAME" ];then
		$C_ZT_BIN_DIR/zt "Errore" "$L_EMPTY_CLASS_NAME" "classes.sh"
		exit
		./footer.sh
	fi
	CLASSNAME=$( echo $CLASSNAME | sed 's/\(.*\)/\U\1/' | sed '/\+/s//_/g' | sed 's/\-/_/g')
	if [[ -d $C_CLASSES_DIR/$CLASSNAME || "$CLASSNAME" == "DEFAULT" ]];then
		$C_ZT_BIN_DIR/zt "Errore" "$L_EXISTING_CLASS" "classes.sh"
		exit
		./footer.sh
	fi
	wait "750"
	if [ -z $COSTM ] || [ $COSTM != $(echo "$COSTM" | awk '{print strtonum ($1)}') ];then
		 COSTM=""
	fi
	if [ -z $COSTH ] || [ $COSTH != $(echo "$COSTH" | awk '{print strtonum ($1)}') ];then
		 COSTH=""
	fi
	if [[ -z $MB || $MB != $(echo "$MB" | awk '{print strtonum ($1)}') || -n $(echo "$MB" | cut -sd'.' -f1) || -n $(echo "$MB" | cut -sd',' -f1) ]];then
		 MB=""
	fi
	if [[ -z $HOURS || $HOURS != $(echo "$HOURS" | awk '{print strtonum ($1)}') || -n $(echo "$HOURS" | cut -sd'.' -f1) || -n $(echo "$HOURS" | cut -sd',' -f1) ]] ;then
		 HOURS=""
	fi
	if [[ "$TYPE" != "pre" || -z $FREE_TIME || $FREE_TIME != $(echo "$FREE_TIME" | awk '{print strtonum ($1)}') || -n $(echo "$FREE_TIME" | cut -sd'.' -f1) || -n $(echo "$FREE_TIME" | cut -sd',' -f1) ]];then
		 FREE_TIME=""
	fi
	if [ "$C_SHAPER" == "on" ];then
		NUM_CLASS=$(cat $C_CLASSES_DIR/*/NumClass | sort -n | tail -1)
		NUM_CLASS=$(($NUM_CLASS+1))
		if [ -z $MBITS ] || [ $MBITS != $(echo "$MBITS" | awk '{print strtonum ($1)}') ];then
			MBITS=""
		else
			$C_ZT_BIN_DIR/zt "SaveBandwidth" "$NUM_CLASS.$CLASSNAME" "$MBITS"
		fi
		if [ -z $MBITSU ] || [ $MBITSU != $(echo "$MBITSU" | awk '{print strtonum ($1)}') ];then
			MBITSU=""
		else
			NUM_CLASS_UP=$(($NUM_CLASS+100))
			$C_ZT_BIN_DIR/zt "SaveBandwidthUp" "$NUM_CLASS_UP.$CLASSNAME" "$MBITSU"
		fi

	fi
	N_CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface | wc -w | awk '{print $1}')"
	if [ "$N_CP_INTERFACES" -gt 1 ];then
		CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface)"
		for ICP in $CP_INTERFACES;do
			AICPV="$(echo "$ICP" | sed 's/\.//g')"
			AICP=\$$AICPV
			eval AICP=$AICP
			if [ -n "$AICP" ];then
				CLASSINT="$CLASSINT $ICP"
			fi
		done
	else
		CLASSINT="$(cat $C_SYSTEM/cp/Interface)"
	fi
	CLASSINT="$(echo "$CLASSINT" | sed 's/^ *//g')"
	for CRON_DAYS in "LUN 1" "MAR 2" "MER 3" "GIO 4" "VEN 5" "SAB 6" "DOM 0";do
		set -- $CRON_DAYS
		eval CRON_DAY=\$$1
		if [ "$CRON_DAY" == "on" ];then
			DAYS_CRON="$DAYS_CRON+$2"
			[ $2 == $DAYS ] && CONTROLGS="ok"
		fi
	done
	if [[ -n "$HOUR_START" && -n "$MINUTES_START" && -n "$HOUR_STOP" && -n "$MINUTES_STOP" ]];then
		RANGE1="$HOUR_START:$MINUTES_START-$HOUR_STOP:$MINUTES_STOP"
	else
		RANGE1=""
	fi
	if [[ -n "$HOUR_START_SEC" && -n "$MINUTES_START_SEC" && -n "$HOUR_STOP_SEC" && -n "$MINUTES_STOP_SEC" ]];then
		RANGE2="$HOUR_START_SEC:$MINUTES_START_SEC-$HOUR_STOP_SEC:$MINUTES_STOP_SEC"
	else
		RANGE2=""
	fi
	$C_ZT_BIN_DIR/zt "SaveClass" "$CLASSNAME" "$COSTM" "$COSTH" "$MB" "$HOURS" "$MBITS" "$MBITSU" "$TYPE" "$NUM_CLASS" "$FREE_TIME" "$CLASSINT" "$TYPE_SHAPER" "$DAYS_CRON" "$RANGE1" "$RANGE2" "$HOURS_DAY" "$HOURS_MONTH" "$MB_DAY" "$MB_MONTH-$SIM_CON-$BLOCK"
	if [[ "$TYPE" == "pre" && -n "$C_ACTIVE_PP" ]];then
		$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ChargePayPal"
	fi
	if [ -n "$C_NOT_EMAIL_ADD_CLASS" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n "$C_EMAIL_ABIL" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n\n$L_CLASSADD\n$CLASSNAME\n$L_BY $UTENTEC\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME: $L_CLASSADD" "$TEXT_EMAIL" "$C_ADMIN_EMAIL"
	fi
	if [ -n "$C_NOT_SMS_UPDATE_CLASS" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n "$C_SMS_ABIL" ] && [ "$UTENTEC" != "$C_ADMIN" ];then
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$C_HOTSPOT_NAME $L_CLASSADD $CLASSNAME $L_BY $UTENTEC"
	fi
	 if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		UpdateClassRemote
	 fi
	 if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_SAVED $L_CLASS $CLASSNAME"
	fi
	return_page "classes.sh"
	exit
fi
if [[ -z "$UPDATE" && -z "$NEWCLASS" ]];then
	[ "$( cat $C_SYSTEM/cp/Multi | wc -w)" -gt "1" ] && CMCP="yes"
	DEF="DEFAULT"
	[ -n "$CMCP" ] && DEF="DEFAULT&nbsp;&nbsp;&nbsp;Int: $( cat $C_SYSTEM/cp/Multi)"
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_CLASSES</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	echo "<table class=\"tabellain\" width=\"700\" border=\"1\">
	<tr><td class=\"intesta\" colspan=\"4\">$L_CLASS: $DEF</td></tr>
	<tr><td>&nbsp;$L_TIME Max $L_HOURS:</td><td>&nbsp;$L_NO_LIMIT</td><td>&nbsp;$L_TRAFFIC Max MB:</td><td>&nbsp;$L_NO_LIMIT</td></tr>
	<tr BGCOLOR=\"white\"><td>&nbsp;$L_DAYS:</td><td colspan=\"3\">&nbsp;$L_ALL</td></tr>
	<tr><td>&nbsp;$L_HOURS Range1:</td><td>&nbsp;$L_NO_LIMIT</td><td>&nbsp;$L_HOURS Range2:</td><td>&nbsp;$L_NO_LIMIT</td></tr>
	<tr BGCOLOR=\"white\"><td>&nbsp;$L_LIMIT ($L_HOURS $L_FOR_DAY):</td><td>&nbsp;$L_NO_LIMIT</td><td>&nbsp;$L_LIMIT ($L_HOURS $L_FOR_MONTH):</td><td>&nbsp;$L_NO_LIMIT</td></tr>
	<tr><td>&nbsp;$L_LIMIT (MB $L_FOR_DAY):</td><td>&nbsp;$L_NO_LIMIT</td><td>&nbsp;$L_LIMIT (MB $L_FOR_MONTH):</td><td>&nbsp;$L_NO_LIMIT</td></tr>
	<tr BGCOLOR=\"white\"><td>&nbsp;$L_TYPE_PAYMENT:</td><td>&nbsp;$L_NOPAID</td><td>&nbsp;$L_FREE_FOR:</td><td>&nbsp;$L_NOPAID</td></tr>
	<tr><td>&nbsp;$L_COSTH:</td><td>&nbsp;$L_NOPAID</td><td>&nbsp;$L_COSTMB:</td><td>&nbsp;$L_NOPAID</td></tr>
	<tr BGCOLOR=\"white\"><td>&nbsp;Shaper:</td><td>&nbsp;$L_NOT_ACTIVE</td><td>&nbsp;Shaper $L_WG_TYPE:</td><td>&nbsp;$L_NOPAID</td></tr>
	<tr><td>&nbsp;$L_BANDWIDTH Download:</td><td>&nbsp;$L_NO_LIMIT</td><td>&nbsp;$L_BANDWIDTH Upload:</td><td>&nbsp;$L_NO_LIMIT</td></tr>
	<tr BGCOLOR=\"white\"><td>&nbsp;$L_BLOCKED:</td><td>&nbsp;$L_NO</td>"
	if [ -n "$C_SIM_CONN_CLASSES" ];then
		echo "<td>&nbsp;$L_SIM_CONNECTION</td><td>&nbsp;$L_NO</td></tr>"
	else
		echo "<td></td><td></td></tr>"
	fi
	echo "</table>"
	CP_INTERFACES="$(cat $C_CLASSES_DIR/$CL/InterfacesClass)"
	for CL in $(ls $C_CLASSES_DIR);do
		CP_INTERFACES="$(cat $C_CLASSES_DIR/$CL/InterfacesClass)"
		CLT="$CL"
		[ -n "$CMCP" ] && CLT="$CL&nbsp;&nbsp;&nbsp;Int: $CP_INTERFACES"
		if [ "$CL" != "DEFAULT" ];then
			if [ -z $(cat $C_CLASSES_DIR/$CL/CostH) ];then
					COST_HOUR="$L_NOPAID"
			else
				COST_HOUR=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CL/CostH)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
				[ -z $(echo $COST_HOUR | cut -sd'.' -f1) ] && COST_HOUR="0$COST_HOUR"
				COST_HOUR="$COST_HOUR $C_CURRENCY"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/CostM) ];then
				COST_MB="$L_NOPAID"
			else
				COST_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CL/CostM)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
				[ -z $(echo $COST_MB | cut -sd'.' -f1) ] && COST_MB="0$COST_MB"
				COST_MB="$COST_MB $C_CURRENCY"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/MB) ];then
				LIMIT_MB="$L_NO_LIMIT"
			else
				LIMIT_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CL/MB)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
				LIMIT_MB="$LIMIT_MB MB"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/Hours) ];then
				LIMIT_HOUR="$L_NO_LIMIT"
			else
				LIMIT_HOUR="$(cat $C_CLASSES_DIR/$CL/Hours) $L_HOURS"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/Range1) ];then
				LIMIT_RANGE1="$L_NO_LIMIT"
			else
				LIMIT_RANGE1="$(cat $C_CLASSES_DIR/$CL/Range1)"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/Range2) ];then
				LIMIT_RANGE2="$L_NO_LIMIT"
			else
				LIMIT_RANGE2="$(cat $C_CLASSES_DIR/$CL/Range2)"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/HoursDay) ];then
				LIMIT_HOURS_DAY="$L_NO_LIMIT"
			else
				LIMIT_HOURS_DAY="$(cat $C_CLASSES_DIR/$CL/HoursDay)"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/HoursMonth) ];then
				LIMIT_HOURS_MONTH="$L_NO_LIMIT"
			else
				LIMIT_HOURS_MONTH="$(cat $C_CLASSES_DIR/$CL/HoursMonth)"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/MBDay) ];then
				LIMIT_MB_DAY="$L_NO_LIMIT"
			else
				LIMIT_MB_DAY="$(cat $C_CLASSES_DIR/$CL/MBDay)"
			fi
			if [ -z $(cat $C_CLASSES_DIR/$CL/MBMonth) ];then
				LIMIT_MB_MONTH="$L_NO_LIMIT"
			else
				LIMIT_MB_MONTH="$(cat $C_CLASSES_DIR/$CL/MBMonth)"
			fi
			LIMIT_DAYS=""
			if [ -n "$(cat $C_CLASSES_DIR/$CL/Days)" ];then
				for CRON_DAYS in "$L_MONDAY 1" "$L_TUESDAY 2" "$L_WEDNESDAY 3" "$L_THURSDAY 4" "$L_FRIDAY 5" "$L_SATURDAY 6" "$L_SUNDAY 0";do
				set -- $CRON_DAYS
					if [ -n "$(cat $C_CLASSES_DIR/$CL/Days | grep "$2")" ];then
						LIMIT_DAYS="$LIMIT_DAYS $1, "
					fi
				done
				LIMIT_DAYS=$(echo -e "$LIMIT_DAYS" | sed 's/, $//' | sed 's/\\//g')
			else
				LIMIT_DAYS="$L_ALL"
			fi
			ACTIVE="no"
			BW=""
			BWU=""
			ACTIVEBW=""
			BW=$(cat $C_CLASSES_DIR/$CL/Mbits)
			if [ -z $BW ];then
				BW="$L_NO_LIMIT"
			else
				BW=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CL/Mbits)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
				BW="$BW Mbit"
				ACTIVEBW="yes"
			fi
			BWU=$(cat $C_CLASSES_DIR/$CL/MbitsUp)
			if [ -z $BWU ];then
				BWU="$L_NO_LIMIT"
			else
				BWU=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CL/MbitsUp)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
				BWU="$BWU Mbit"
				ACTIVEBW="yes"
			fi
			if [ "$ACTIVEBW" == "yes" ];then
				ACTIVE="$L_ACTIVE"
			else
				ACTIVE="$L_NOT_ACTIVE"
			fi
			PROFILE="$L_NOT_ACTIVE"
			[[ "$(cat $C_CLASSES_DIR/$CL/ShaperType)" == "class" && "$ACTIVE" == "$L_ACTIVE" ]] && PROFILE="$L_CLASS"
			[[ "$(cat $C_CLASSES_DIR/$CL/ShaperType)" == "user" && "$ACTIVE" == "$L_ACTIVE" ]] && PROFILE="User"
			FREETIME=$(cat $C_CLASSES_DIR/$CL/FreeTime)
			[ -z "$FREETIME" ] && FREETIME="$L_NOPAID"
			TYPE=$(cat $C_CLASSES_DIR/$CL/ChargeType)
			BLOCKED=$(cat $C_CLASSES_DIR/$CL/Blocked 2>/dev/null)
			[ -z "$BLOCKED" ] && BLOCKED="no"
			if [ "$BLOCKED" == "yes" ];then
				BLOCKED="$L_YES"
			else
				BLOCKED="$L_NO"
			fi
			SIMCON=$(cat $C_CLASSES_DIR/$CL/Simultaneous 2>/dev/null)
			[ -z "$SIMCON" ] && SIMCON="no"
			if [ "$SIMCON" == "yes" ];then
				SIMCON="$L_YES"
			else
				SIMCON="$L_NO"
			fi
			if [ "$TYPE" == "pre" ];then
				PAYMENT="$L_PREPAID"
			fi
			[ "$TYPE" == "post" ] && PAYMENT="$L_POSTPAID"
			[ -z "$TYPE" ] && PAYMENT="$L_NOPAID"
			echo "<br>&nbsp;<table class=\"tabellain\" width=\"700\" border=\"1\">
			<tr><td class=\"intesta\" colspan=\"4\">$L_CLASS: $CLT</td></tr>
			<tr><td>&nbsp;$L_TIME Max $L_HOURS:</td><td>&nbsp;$LIMIT_HOUR</td><td>&nbsp;$L_TRAFFIC Max MB:</td><td>&nbsp;$LIMIT_MB</td></tr>
			<tr BGCOLOR=\"white\"><td>&nbsp;$L_DAYS:</td><td colspan=\"3\">&nbsp;$LIMIT_DAYS</td></tr>
			<tr><td>&nbsp;$L_HOURS Range1:</td><td>&nbsp;$LIMIT_RANGE1</td><td>&nbsp;$L_HOURS Range2:</td><td>&nbsp;$LIMIT_RANGE2</td></tr>
			<tr BGCOLOR=\"white\"><td>&nbsp;$L_LIMIT ($L_HOURS $L_FOR_DAY):</td><td>&nbsp;$LIMIT_HOURS_DAY</td><td>&nbsp;$L_LIMIT ($L_HOURS $L_FOR_MONTH):</td><td>&nbsp;$LIMIT_HOURS_MONTH</td></tr>
			<tr><td>&nbsp;$L_LIMIT (MB $L_FOR_DAY):</td><td>&nbsp;$LIMIT_MB_DAY</td><td>&nbsp;$L_LIMIT (MB $L_FOR_MONTH):</td><td>&nbsp;$LIMIT_MB_MONTH</td></tr>
			<tr BGCOLOR=\"white\"><td>&nbsp;$L_TYPE_PAYMENT:</td><td>&nbsp;$PAYMENT</td><td>&nbsp;$L_FREE_FOR:</td><td>&nbsp;$FREETIME</td></tr>
			<tr><td>&nbsp;$L_COSTH:</td><td>&nbsp;$COST_HOUR</td><td>&nbsp;$L_COSTMB:</td><td>&nbsp;$COST_MB</td></tr>
			<tr BGCOLOR=\"white\"><td>&nbsp;Shaper:</td><td>&nbsp;$ACTIVE</td><td>&nbsp;Shaper $L_WG_TYPE:</td><td>&nbsp;$PROFILE</td></tr>
			<tr><td>&nbsp;$L_BANDWIDTH Download:</td><td>&nbsp;$BW</td><td>&nbsp;$L_BANDWIDTH Upload:</td><td>&nbsp;$BWU</td></tr>
			<tr BGCOLOR=\"white\"><td>&nbsp;$L_BLOCKED:</td><td>&nbsp;$BLOCKED</td>"
			if [ -n "$C_SIM_CONN_CLASSES" ];then
				[ -z "$SIMCON" ] && SIMCON="no"
				echo "<td>&nbsp;$L_SIM_CONNECTION</td><td>&nbsp;$SIMCON</td></tr>"
			else
				echo "<td></td><td></td></tr>"
			fi
			echo "</table>"
			echo "<br><form action=\"classes.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"CLASS_DELETE\" value=\"$CL\">
			<input type=\"submit\" class=\"bottonelinea\" value=\"$L_DELETE\"
			onClick=\"javascript:return confirm('$L_ALERT_REMOVE_CLASS $CL');\"></form>"
			echo "<form action=\"classes.sh\" method=\"POST\">
			<input type=\"hidden\" name=\"CLASS\" value=\"$CL\">
			<input type=\"hidden\" name=\"UPDATE\" value=\"yes\">
			<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_MODIFY\">
			</form>"
		fi
	done
	if [[ "$UTENTEC" == "$C_ADMIN" || -n "$C_GES_CLASS" ]];then
		echo "&nbsp;<br>&nbsp;<br><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><br>&nbsp;<br>
		<form method=\"POST\" action=\"classes.sh\">
		<input type=\"hidden\" name=\"NEWCLASS\" value=\"OK\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_ADDCLASS\"></form>
		<br>&nbsp;"
	fi
	./footer.sh
	exit
fi
if [[ "$UTENTEC" == "$C_ADMIN" || -n "$C_GES_CLASS" ]];then
	if [[ -n "$UPDATE" || -n "$NEWCLASS" ]];then
		NAME_CLASS=""
		COST_HOUR=""
		COST_MB=""
		LIMIT_MB=""
		LIMIT_HOUR=""
		BW=""
		BWU=""
		TITLE="$L_ADDCLASS"
		if [ "$UPDATE" == "yes" ];then
			TITLE="$L_CLASS_UPDATE: $CLASS"
			NAME_CLASS="$CLASS"
			TYPE=$(cat $C_CLASSES_DIR/$CLASS/ChargeType)
			TYPE_SHAPER=$(cat $C_CLASSES_DIR/$CLASS/ShaperType)
			COST_HOUR=$(cat $C_CLASSES_DIR/$CLASS/CostH)
			COST_MB=$(cat $C_CLASSES_DIR/$CLASS/CostM)
			LIMIT_MB=$(cat $C_CLASSES_DIR/$CLASS/MB)
			LIMIT_HOURS=$(cat $C_CLASSES_DIR/$CLASS/Hours)
			LIMIT_HOURS_DAY=$(cat $C_CLASSES_DIR/$CLASS/HoursDay)
			LIMIT_HOURS_MONTH=$(cat $C_CLASSES_DIR/$CLASS/HoursMonth)
			LIMIT_MB_DAY=$(cat $C_CLASSES_DIR/$CLASS/MBDay)
			LIMIT_MB_MONTH=$(cat $C_CLASSES_DIR/$CLASS/MBMonth)
			LIMIT_DAYS=$(cat $C_CLASSES_DIR/$CLASS/Days)
			LIMIT_RANGE1=$(cat $C_CLASSES_DIR/$CLASS/Range1)
			HOUR_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f1)"
			MINUTES_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f2 | cut -d'-' -f1)"
			HOUR_STOP="$(echo "$LIMIT_RANGE1" | cut -d'-' -f2 | cut -d':' -f1 )"
			MINUTES_STOP="$(echo "$LIMIT_RANGE1" | cut -d':' -f3 )"
			LIMIT_RANGE2=$(cat $C_CLASSES_DIR/$CLASS/Range2)
			HOUR_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f1)"
			MINUTES_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f2 | cut -d'-' -f1)"
			HOUR_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d'-' -f2 | cut -d':' -f1 )"
			MINUTES_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f3 )"
			BW=$(cat $C_CLASSES_DIR/$CLASS/Mbits)
			BWU=$(cat $C_CLASSES_DIR/$CLASS/MbitsUp)
			FREE_TIME=$(cat $C_CLASSES_DIR/$CLASS/FreeTime)
			INT_CLASS=$(cat $C_CLASSES_DIR/$CLASS/InterfacesClass)
			SIM_CON=$(cat $C_CLASSES_DIR/$CLASS/Simultaneous)
			BLOCKED=$(cat $C_CLASSES_DIR/$CLASS/Blocked)
			[ -z "$INT_CLASS" ] && INT_CLASS="$(cat $C_SYSTEM/cp/Interface)"
		fi
		echo "<br><font color=\"#0000FF\" size=\"5\">$TITLE</font>
		<p><img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>
		<form name=\"ADD_CLASS\" action=\"classes.sh\" method=\"POST\">"
		echo "<table width=\"55%\"><tr>"
		if [ -n "$UPDATE" ];then
			echo "<input type=\"hidden\" name=\"CLASSNAME\" value=\"$NAME_CLASS\">"
		else
			echo "<td align=\"center\">$L_NAME_CLASS<br>
			<input type=\"text\" style=\"text-align: center\" name=\"CLASSNAME\" value=\"\" maxlength=\"15\">
			</td></tr><tr><td>&nbsp;"
		fi
		echo "</td></tr></table>
		<table width=\"650\" align=\"center\">
		<tr><td width=\"200px\"></td><td width=\"100px\"></td><td width=\"120px\"><td width=\"50px\"></td><td width=\"210px\"></td><td width=\"100px\"></td></tr>
		<tr><td  height=\"30\" >&nbsp;$L_TYPE_PAYMENT:</td>
		<td align=\"left\">"
		echo "<select name=\"TYPE\" onchange=\"freetime(this.options[this.selectedIndex].value,'ftchange','row2')\">"
		if [ -n "$UPDATE" ];then
			if [ "$TYPE" == "pre" ];then
				echo "<option value=\"post\">$L_POSTPAID</option>
				<option value=\"\">$L_NOPAID</option>
				<option value=\"pre\" selected=\"selected\">$L_PREPAID</option></select>"
			fi
			if [ "$TYPE" == "post" ];then
				echo "<option value=\"pre\">$L_PREPAID</option>
				<option value=\"\">$L_NOPAID</option>
				<option value=\"post\" selected=\"selected\">$L_POSTPAID</option></select>"
			fi
			if [ -z "$TYPE" ] ;then
				echo "<option value=\"pre\">$L_PREPAID</option>
				<option value=\"post\">$L_POSTPAID</option>
				<option value=\"\" selected=\"selected\">$L_NOPAID</option></select>"
			fi
		else
			echo "<option value=\"\" selected=\"selected\">$L_NOPAID</option>
			<option value=\"pre\">$L_PREPAID</option>
			<option value=\"post\">$L_POSTPAID</option>
			</select>"
		fi
		if [ "$TYPE" != "pre" ];then
			echo "<td></td><td colspan=\"2\">&nbsp;$L_FREE_FOR:</td><td align=\"right\">
			<div id=\"ftchange\" style=\"display: none;\"><input type=\"text\" name=\"FREE_TIME\" value=\"$FREE_TIME\" size=\"6\"></div></td></tr>"
		else
			echo "<td></td><td colspan=\"2\">&nbsp;$L_FREE_FOR:</td><td align=\"right\">
			<div id=\"ftchange\" style=\"display: block;\"><input type=\"text\" name=\"FREE_TIME\" value=\"$FREE_TIME\" size=\"6\"></div></td></tr>"
		fi
		if [ -z "$TYPE" ];then
			echo "<tr id=\"row2\" style=\"display: none;\"><td height=\"30\">&nbsp;$L_COSTH1 $C_CURRENCY:</td>
			<td align=\"left\"><input type=\"text\" name=\"COSTH\" value=\"$COST_HOUR\" size=\"6\"></td>
			<td></td><td colspan=\"2\">&nbsp;$L_COSTMB1 $C_CURRENCY:</td>
			<td align=\"right\"><input type=\"text\" name=\"COSTM\" value=\"$COST_MB\" size=\"6\"></td>
			</tr>"
		else
			echo "<tr id=\"row2\" style=\"display: ;\"><td height=\"30\">&nbsp;$L_COSTH1 $C_CURRENCY:</td>
			<td align=\"left\"><input type=\"text\" name=\"COSTH\" value=\"$COST_HOUR\" size=\"6\"></td>
			<td></td><td colspan=\"2\">&nbsp;$L_COSTMB1 $C_CURRENCY:</td>
			<td align=\"right\"><input type=\"text\" name=\"COSTM\" value=\"$COST_MB\" size=\"6\"></td>
			</tr>"
		fi
		echo "<tr><td height=\"30\">&nbsp;$L_TIME MAX $L_HOURS:</td>
		<td align=\"left\"><input type=\"text\" name=\"HOURS\" value=\"$LIMIT_HOURS\" size=\"6\"></td>
		<td><td colspan=\"2\">&nbsp;$L_TRAFFIC MAX MB:</td>
		<td  align=\"right\"><input type=\"text\" name=\"MB\" value=\"$LIMIT_MB\" size=\"6\"></td>
		</tr>"
#		###################àààà
#		echo "<tr>
#		<td height=\"30\">&nbsp;$L_COST $L_DAY $C_CURRENCY:</td>
#		<td align=\"left\"><input type=\"text\" name=\"COSTDAY\" value=\"$LIMIT_HOURS\" size=\"6\"></td>
#		<td></td><td colspan=\"2\">&nbsp;$L_COST $L_WEEK $C_CURRENCY:</td>
#		<td align=\"right\"><input type=\"text\" name=\"COSTWEEK\" value=\"$COST_MB\" size=\"6\"></td>
#		</tr>"
#		echo "<tr>
#		<td height=\"30\">&nbsp;$L_COST $L_MONTH $C_CURRENCY:</td>
#		<td align=\"left\"><input type=\"text\" name=\"COSTMONTH\" value=\"$LIMIT_HOURS\" size=\"6\"></td>
#		<td></td><td colspan=\"2\">&nbsp;$L_COST $L_YEAR $C_CURRENCY:</td>
#		<td align=\"right\"><input type=\"text\" name=\"COSTYEAR\" value=\"$COST_MB\" size=\"6\"></td>
#		</tr>"
#		################################à
		echo "<tr><td height=\"30\">&nbsp;$L_DAYS:</td><td colspan=\"5\">"
		if [ $(echo $LIMIT_DAYS | grep 1) ];then
			echo "$L_MON<input name=\"LUN\" type=\"checkbox\" checked>&nbsp;"
		else
			echo "$L_MON<input name=\"LUN\" type=\"checkbox\">&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 2) ];then
			echo "$L_TUES<input name=\"MAR\" type=\"checkbox\" checked>&nbsp;"
		else
			echo "$L_TUES<input name=\"MAR\" type=\"checkbox\">&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 3) ];then
			echo "$L_WEDNES<input name=\"MER\" type=\"checkbox\" checked>&nbsp;"
		else
			echo "$L_WEDNES<input name=\"MER\" type=\"checkbox\">&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 4) ];then
			echo "$L_THURS<input name=\"GIO\" type=\"checkbox\" checked>&nbsp;&nbsp;&nbsp;"
		else
			echo "$L_THURS<input name=\"GIO\" type=\"checkbox\">&nbsp;&nbsp;&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 5) ];then
			echo "$L_FRI<input name=\"VEN\" type=\"checkbox\" checked>&nbsp;&nbsp;&nbsp;"
		else
			echo "$L_FRI<input name=\"VEN\" type=\"checkbox\">&nbsp;&nbsp;&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 6) ];then
			echo "$L_SATUR<input name=\"SAB\" type=\"checkbox\" checked>&nbsp;&nbsp;&nbsp;"
		else
			echo "$L_SATUR<input name=\"SAB\" type=\"checkbox\">&nbsp;&nbsp;&nbsp;"
		fi
		if [ $(echo $LIMIT_DAYS | grep 0) ];then
			echo "$L_SUN<input name=\"DOM\" type=\"checkbox\" checked>"
		else
			echo "$L_SUN<input name=\"DOM\" type=\"checkbox\">"
		fi
		echo "</td></tr>"
		echo " <tr><td height=\"30\">&nbsp;$L_TIME Range1:</td><td colspan=\"2\">
		<select name=\"HOUR_START\">"
		for OS in $(seq 0 23);do
			echo "<option value=\"$OS\" selected>$OS</option>"
		done
		if [ -n "$HOUR_START" ];then
			echo "<option value=\"\"></option>
			<option value=\"$HOUR_START\" selected>$L_FROM: $HOUR_START</option></select>"
		else
			echo "<option value=\"\" selected>$L_FROM_HOUR</option></select>"
		fi
		echo "<select name=\"MINUTES_START\">"
		for MS in $(seq 0 5 55);do
			[ "$MS" -lt "10" ] && MS="0$MS"
			echo "<option value=\"$MS\" selected>$MS</option>"
		done
		if [ -n "$MINUTES_START" ];then
			echo "<option value=\"\"></option>
			<option value=\"$MINUTES_START\" selected>$MINUTES_START</option></select>"
		else
			echo "<option value=\"\" selected>$L_MINUTES</option></select>"
		fi
		echo "</td><td colspan=\"3\" align=\"right\">
		<select name=\"HOUR_STOP\">"
		for OS in $(seq 0 23);do
			echo "<option value=\"$OS\" selected>$OS</option>"
		done
		if [ -n "$HOUR_STOP" ];then
			echo "<option value=\"\"></option>
			<option value=\"$HOUR_STOP\" selected>$L_TO: $HOUR_STOP</option></select>"
		else
			echo "<option value=\"\" selected>$L_TO_HOUR</option></select>"
		fi
		echo "<select name=\"MINUTES_STOP\">"
		for MS in $(seq 0 5 55);do
			[ "$MS" -lt "10" ] && MS="0$MS"
			echo "<option value=\"$MS\" selected>$MS</option>"
		done
		if [ -n "$MINUTES_STOP" ];then
			echo "<option value=\"\" selected></option>
			<option value=\"$MINUTES_STOP\" selected>$MINUTES_STOP</option></select>"
		else
			echo "<option value=\"\" selected>$L_MINUTES</option></select>"
		fi
		echo "</td></tr>
		<tr><td height=\"30\">&nbsp;$L_TIME Range2:</td><td colspan=\"2\">
		<select name=\"HOUR_START_SEC\">"
		for OS in $(seq 0 23);do
			echo "<option value=\"$OS\" selected>$OS</option>"
		done
		if [ -n "$HOUR_START_SEC" ];then
			echo "<option value=\"\"></option>
			<option value=\"$HOUR_START_SEC\" selected>$L_FROM: $HOUR_START_SEC</option></select>"
		else
			echo "<option value=\"\" selected>$L_FROM_HOUR</option></select>"
		fi
		echo "<select name=\"MINUTES_START_SEC\">"
		for MS in $(seq 0 5 55);do
			[ "$MS" -lt "10" ] && MS="0$MS"
			echo "<option value=\"$MS\" selected>$MS</option>"
		done
		if [ -n "$MINUTES_START_SEC" ];then
			echo "<option value=\"\"></option>
			<option value=\"$MINUTES_START_SEC\" selected>$MINUTES_START_SEC</option></select>"
		else
			echo "<option value=\"\" selected>$L_MINUTES</option></select>"
		fi
		echo "</td><td colspan=\"3\" align=\"right\">
		<select name=\"HOUR_STOP_SEC\">"
		for OS in $(seq 0 23);do
			echo "<option value=\"$OS\" selected>$OS</option>"
		done
		if [ -n "$HOUR_STOP_SEC" ];then
			echo "<option value=\"\"></option>
			<option value=\"$HOUR_STOP_SEC\" selected>$L_TO: $HOUR_STOP_SEC</option></select>"
		else
			echo "<option value=\"\" selected>$L_TO_HOUR</option></select>"
		fi
		echo "<select name=\"MINUTES_STOP_SEC\">"
		for MS in $(seq 0 5 55);do
			[ "$MS" -lt "10" ] && MS="0$MS"
			echo "<option value=\"$MS\" selected>$MS</option>"
		done
		if [ -n "$MINUTES_STOP_SEC" ];then
			echo "<option value=\"\" selected></option>
			<option value=\"$MINUTES_STOP_SEC\" selected>$MINUTES_STOP_SEC</option></select>"
		else
			echo "<option value=\"\" selected>$L_MINUTES</option></select>"
		fi
		echo "</td></tr>"
		echo "<tr><td height=\"30\">&nbsp;$L_LIMIT:</td><td colspan=\"3\">"
		echo "$L_HOURS: <select name=\"HOURS_DAY\">"
		for DOMAX in $(seq 0 23);do
			echo "<option value=\"$DOMAX\" selected>$DOMAX</option>"
		done
		if [ -n "$LIMIT_HOURS_DAY" ];then
			echo "<option value=\"\"></option>
			<option value=\"$LIMIT_HOURS_DAY\" selected>$L_FOR_DAY: $LIMIT_HOURS_DAY</option>"
		else
			echo "<option value=\"\" selected>$L_FOR_DAY</option>"
		fi
		echo "</select></td><td colspan=\"4\" align=\"right\"> $L_HOURS:"
		echo "<select name=\"HOURS_MONTH\">"
		for MOMAX in $(seq 0 10 750);do
			echo "<option value=\"$MOMAX\" selected>$MOMAX</option>"
		done
		if [ -n "$LIMIT_HOURS_MONTH" ];then
			echo "<option value=\"\"></option>
			<option value=\"$LIMIT_HOURS_MONTH\" selected>$L_FOR_MONTH: $LIMIT_HOURS_MONTH</option>"
		else
			echo "<option value=\"\" selected>$L_FOR_MONTH</option>"
		fi
		echo "</select></td></tr>
		<tr><td height=\"30\"></td><td colspan=\"3\" align=\"left\">MB:
		<select name=\"MB_DAY\">"
		for DMBMAX in $(seq 0 10 5000);do
			echo "<option value=\"$DMBMAX\" selected>$DMBMAX</option>"
		done
		if [ -n "$LIMIT_MB_DAY" ];then
			echo "<option value=\"\"></option>
			<option value=\"$LIMIT_MB_DAY\" selected>$L_FOR_DAY: $LIMIT_MB_DAY</option>"
		else
			echo "<option value=\"\" selected>$L_FOR_DAY</option>"
		fi
		echo "</select>
		</td><td align=\"right\" colspan=\"2\">MB: <select name=\"MB_MONTH\">"
		for MMBMAX in $(seq 0 50 50000);do
			echo "<option value=\"$MMBMAX\" selected>$MMBMAX</option>"
		done
		if [ -n "$LIMIT_MB_MONTH" ];then
			echo "<option value=\"\"></option>
			<option value=\"$LIMIT_MB_MONTH\" selected>$L_FOR_MONTH:$LIMIT_MB_MONTH</option>"
		else
			echo "<option value=\"\" selected>$L_FOR_MONTH</option>"
		fi
		echo "</select></td><tr>"
		echo "<tr><td height=\"30\">&nbsp;$L_BLOCKED:</td><td colspan=\"2\">"
		if [ "$BLOCKED" == "yes" ];then
			echo "<input name=\"BLOCK\" type=\"checkbox\" checked=\"checked\">"
		else
			echo "<input name=\"BLOCK\" type=\"checkbox\">"
		fi
		echo "</td><td colspan=\"3\" align=\"right\">"
		if [ -n "$C_SIM_CONN_CLASSES" ];then
			echo "$L_SIM_CONNECTION:&nbsp;&nbsp;"
			if [ "$SIM_CON" == "yes" ];then
				echo "<input name=\"SIM_CON\" type=\"checkbox\" checked=\"checked\">"
			else
				echo "<input name=\"SIM_CON\" type=\"checkbox\">"
			fi
		fi
		echo "</td></tr>"
		echo "<tr><td colspan=\"6\">&nbsp;</td></tr>"
		echo "<tr><td colspan=\"6\" align=\"center\">$L_BANDWIDTH (Mbit/s)</td></tr>"
		echo "<tr><td colspan=\"6\">&nbsp;</td></tr>"
		echo "<tr><td>&nbsp;$L_WG_TYPE: <select name=\"TYPE_SHAPER\">"
		if [[ "$TYPE_SHAPER" == "class" || -z "$TYPE_SHAPER" ]];then
			echo "<option value=\"user\">$L_USER</option>
			<option value=\"class\" selected>$L_CLASS</option></select>"
		fi
		if [ "$TYPE_SHAPER" == "user" ];then
			echo "<option value=\"class\">$L_CLASS</option>
			<option value=\"user\" selected>$L_USER</option></select>"
		fi
		echo "</td><td colspan=\"3\"align=\"right\">Download Mbit:
		<input type=\"text\" name=\"MBITS\" value=\"$BW\" size=\"6\"></td>"
		echo "<td colspan=\"2\" align=\"right\">Upload Mbit:
		<input type=\"text\" name=\"MBITSU\" value=\"$BWU\" size=\"6\"></td></tr>"
		echo "</table>"
		N_CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface | wc -w | awk '{print $1}')"
		if [ "$N_CP_INTERFACES" -gt 1 ];then
			echo "<br>$L_INTERFACES:&nbsp;&nbsp;&nbsp;&nbsp;"
			CP_INTERFACES="$(cat $C_SYSTEM/cp/Interface)"
			if [ -n "$NEWCLASS" ];then
				for CPI in $CP_INTERFACES;do
					CPIV="$(echo $CPI | sed '/.//g')"
					echo "$CPI <input name=\"$CPIV\" type=\"checkbox\" checked=\"checked\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				done
			else
				for CPI in $CP_INTERFACES;do
					CPIV="$(echo $CPI | sed 's/\.//g')"
					if [ -n "$(echo "$INT_CLASS" | grep $CPI)" ];then
						echo "$CPI <input name=\"$CPIV\" type=\"checkbox\" checked=\"checked\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
					else
						echo "$CPI <input name=\"$CPIV\" type=\"checkbox\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
					fi
				done
			fi
		fi
		echo "<br><p>
		<img src=\"$APACHE_BASEDIR/images/barra.png\" alt=\"barra\"><p>"
		if [ -n "$UPDATE" ];then
			echo "<p><input type=\"submit\" name=\"UPDATE1\" class=\"bottonelinea\" value=\"$L_MODIFY\"></form>"
		else
			echo "<input type=\"submit\" name=\"SAVE\" class=\"bottonelinea\" value=\"$L_SAVE\"></form>"
		fi
		echo "<form method=\"POST\" action=\"classes.sh\">
		<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><p><br>&nbsp;"
	fi
fi
./footer.sh
