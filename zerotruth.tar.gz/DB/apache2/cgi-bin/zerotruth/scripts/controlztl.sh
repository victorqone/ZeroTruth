#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
PAGE="$1"
LANGUAGE="$2"
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
cd $C_HTDOCS_ZT_DIR/msg/$LANGUAGE
if [ "$PAGE" == "login" ];then
	ACCESS="$(cat NetworkAccess)"
	DOMAIN="$(cat DOMAIN)"
	FORGOT="$(cat ForgotPassword)"
	FORGOTAST="$(cat ForgotPassword)"
	PASSWORD="$(cat PASSWORD)"
	PAYPAL="$(cat ChargePayPal)"
	REGISTRATION="$(cat Registration)"
	REGISTRATIONAST="$(cat Registration)"
	USERNAME="$(cat USERNAME)"
	UNNE="$(cat UserNameNoEmpty)"
	PNE="$(cat PwNoEmpty)"
	WEL="$(cat WELCOME)"
	LANG="$(cat Language)"
	echo "$ACCESS#$DOMAIN#$FORGOT#$FORGOTAST#$PASSWORD#$PAYPAL#$REGISTRATION#$REGISTRATIONAST#$USERNAME#$UNNE#$PNE#$WEL#$LANG"
	exit
fi

if [ "$PAGE" == "nocp" ];then
	OFFLINE="$(cat InfoOffLine)"
	NOINTERNET="$(cat NoInternet)"
	TRYAGAIN="$(cat TryAgain)"
	LANG="$(cat Language)"
	echo "$OFFLINE#$NOINTERNET#$TRYAGAIN#$LANG"
	exit
fi

if [ "$PAGE" == "clientctrl" ];then
	RA="$(cat RenewAuth)"
	DNC="$(cat DoNotClose)"
	CP="$(cat ChangePassword)"
	US="$(cat UserDetails)"
	CPP="$(cat ChargePayPal)"
	NETAC="$(cat NetworkAccess)"
	REF="$(cat Refresh)"
	DIS="$(cat Disconnect)"
	WEL="$(cat WELCOME)"
	GB="$(cat Goodbye)"
	ALDIS="$(cat DisconnectionAlert)"
	echo "$RA#$DNC#$CP#$US#$CPP#$NETAC#$REF#$DIS#$WEL#$GB#$ALDIS#$L_CLOSE"
	exit
fi

if [ "$PAGE" == "renew" ];then
	COST="$(cat Cost)"
	TIME="$(cat Time)"
	TRAF="$(cat Traffic)"
	CON="$(cat Connected)"
	NCON="$(cat NotConnected)"
	REF="$(cat Refresh)"
	CRE="$(cat Credit)"
	DISMIN="$(cat DisconnectMinutes)"
	DISMB="$(cat DisconnectMB)"
	DISCR="$(cat Credit)"
	for CONF in "TIMEDIST" "TIMEDIS" "TIMEDISD" "TIMEDISM" "MBDISD" "MBDISM" "TIMEDIST" "MBDIST";do
		eval "$CONF"="no"
	done
	USERNAME="$3"
	MN=$(date +%m | sed 's/^0//')
	DN=$(date +%d | sed 's/^0//')
	IP="$4"
	CLASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME radiusUserCategory | grep -e '^radiusUserCategory: ' | awk '{print $2}')
	### time #########
	if [ -n "$C_SHOW_TIME_DISCONNECT" ];then
		LIMIT=$(($C_SHOW_TIME_DISCONNECT*60))
		RANGE1A="$(cat $C_CLASSES_DIR/$CLASS/Range1 2>/dev/null | cut -d'-' -f1 | awk -F: '{ print ($1 * 3600) + ($2 * 60)}')"
		[ "$RANGE1A" == "0" ] && RANGE1A=""
		RANGE1B="$(cat $C_CLASSES_DIR/$CLASS/Range1 2>/dev/null | cut -d'-' -f2 | awk -F: '{ print ($1 * 3600) + ($2 * 60)}')"
		[ "$RANGE1B" == "0" ] && RANGE1B=""
		RANGE2A="$(cat $C_CLASSES_DIR/$CLASS/Range2 2>/dev/null | cut -d'-' -f1 | awk -F: '{ print ($1 * 3600) + ($2 * 60)}')"
		[ "$RANGE2A" == "0" ] && RANGE2A=""
		RANGE2B="$(cat $C_CLASSES_DIR/$CLASS/Range2 2>/dev/null | cut -d'-' -f2 | awk -F: '{ print ($1 * 3600) + ($2 * 60)}')"
		[ "$RANGE2B" == "0" ] && RANGE2B=""
		NOW="$( date +%H:%M | awk -F: '{ print ($1 * 3600) + ($2 * 60)}')"
		if [[ -n "$RANGE1B" && -n "$RANGE2B" ]];then
			if [[ "$NOW" -gt  "$RANGE1A" && "$NOW" -lt "$RANGE2A" ]];then
				if [ $(($RANGE1B-$NOW)) -lt $LIMIT ];then
					TIMEDIS=$(($RANGE1B-$NOW))
					TIMEDIS=$(($TIMEDIS/60))
					CF="yes"
				fi
			fi
			if [[ "$NOW" -gt "RANGE2A" &&  -z "$CF" ]];then
				if [ $(($RANGE2B-$NOW)) -lt $LIMIT ];then
					TIMEDIS=$(($RANGE2B-$NOW))
					TIMEDIS=$(($TIMEDIS/60))
					CF="yes"
				fi
			fi
			CR2="yes"
		fi
		if [[ -n "$RANGE1B" && -z "$CR2" ]];then
			if [ "$NOW" -gt  "$RANGE1A" ];then
				if [ $(($RANGE1B-$NOW)) -lt $LIMIT ];then
					TIMEDIS=$(($RANGE1B-$NOW))
					TIMEDIS=$(($TIMEDIS/60))
					CF="yes"
				fi
			fi
		fi
		HOURSDAY="$(cat $C_CLASSES_DIR/$CLASS/HoursDay 2>/dev/null)"
		[ -n "$HOURSDAY" ] && HOURSDAYS=$(($HOURSDAY*3600))
		if [[ -z "$CF" && -n "$HOURSDAYS" ]];then
			TIMED="$(cat $C_ACCT_DIR/entries/$USERNAME/TimeD$DN 2>/dev/null)"
			if [ -n "$TIMED" ];then
				if [ $(($HOURSDAYS-$TIMED)) -lt $LIMIT ];then
					TIME="$(($HOURSDAYS-$TIMED))"
					if [ $TIME -ge 60 ];then
						MINUTI=$(($TIME/60))
						TIME1=$(($MINUTI*60))
						TIME=$(($TIME-$TIME1))
						CF="yes"
					else
						MINUTI="1"
						CF="yes"
					fi
					TIMEDISD="$MINUTI"
				fi
			fi
		fi
		HOURSMONTH="$(cat $C_CLASSES_DIR/$CLASS/HoursMonth 2>/dev/null)"
		[ -n "$HOURSMONTH" ] && HOURSMONTHS=$(($HOURSMONTH*3600))
		if [[ -z "$CF" && -n "$HOURSMONTHS" ]];then
			TIMEM="$(cat $C_ACCT_DIR/entries/$USERNAME/TimeM$MN 2>/dev/null)"
			if [ -n "$TIMEM" ];then
				if [ $(($HOURSMONTHS-$TIMEM)) -lt $LIMIT ];then
					TIME="$(($HOURSMONTHS-$TIMEM))"
					if [ $TIME -ge 60 ];then
						MINUTI=$(($TIME/60))
						TIME1=$(($MINUTI*60))
						TIME=$(($TIME-$TIME1))
					else
						MINUTI="1"
					fi
					TIMEDISM="$MINUTI"
					CF="yes"
				fi
			fi
		fi
		HOURSTOT="$(cat $C_CLASSES_DIR/$CLASS/Hours 2>/dev/null)"
		[ -n "$HOURSTOT" ] && HOURSTOTS=$(($HOURSTOT*3600))
		if [[ -z "$CF" && -n "$HOURSTOTS" ]];then
			TIMET="$(cat $C_ACCT_DIR/entries/$USERNAME/Time 2>/dev/null)"
			if [ -n "$TIMET" ];then
				if [ $(($HOURSTOTS-$TIMET)) -lt $LIMIT ];then
					TIME="$(($HOURSTOTS-$TIMET))"
					if [ $TIME -ge 60 ];then
						MINUTI=$(($TIME/60))
						TIME1=$(($MINUTI*60))
						TIME=$(($TIME-$TIME1))
					else
						MINUTI="1"
					fi
					TIMEDIST="$MINUTI"
					CF="yes"
				fi
			fi
		fi
	fi
	### traffic #########
	if [ -n "$C_SHOW_MB_DISCONNECT" ];then
		LIMITMB=$(($C_SHOW_MB_DISCONNECT*1048576))
		MBDAY="$(cat $C_CLASSES_DIR/$CLASS/MBDay 2>/dev/null)"
		[ -n "$MBDAY" ] && MBDAYK=$((MBDAY*1048576))
		if [[ -z "$CF" && -n "$MBDAYK" ]];then
			MBD="$(cat $C_ACCT_DIR/entries/$USERNAME/MBD$DN 2>/dev/null)"
			if [ -n "$MBD" ];then
				if [ $(($MBDAYK-$MBD)) -lt $LIMITMB ];then
					MB="$(($MBDAYK-$MBD))"
					MBDISD=$( echo "$MB/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
					[ "$(echo $MBDISD | grep '^-')" ] && MBDISD="down"
					CF="yes"
				fi
			fi
		fi
		MBMONTH="$(cat $C_CLASSES_DIR/$CLASS/MBMonth 2>/dev/null )"
		[ -n "$MBMONTH" ] && MBMONTHK=$((MBMONTH*1048576))
		if [[ -z "$CF" && -n "$MBMONTHK" ]];then
			MBM="$(cat $C_ACCT_DIR/entries/$USERNAME/MBM$MN 2>/dev/null)"
			if [ -n "$MBM" ];then
				if [ $(($MBMONTHK-$MBM)) -lt $LIMITMB ];then
					MB="$(($MBMONTHK-$MBM))"
					MBDISM=$( echo "$MB/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
					[ "$(echo $MBDISM | grep '^-')" ] && MBDISM="down"
					CF="yes"
				fi
			fi
		fi
		MBTOT="$(cat $C_CLASSES_DIR/$CLASS/MB 2>/dev/null)"
		[ -n "$MBTOT" ] && MBTOTK=$(($MBTOT*1048576))
		if [[ -z "$CF" && -n "$MBTOTK" ]];then
			MBT="$(cat $C_ACCT_DIR/entries/$USERNAME/MB 2>/dev/null)"
			if [ -n "$MBT" ];then
				if [ $(($MBTOTK-$MBT)) -lt $LIMITMB ];then
					MB="$(($MBTOTK-$MBT))"
					MBDIST=$( echo "$MB/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
					[ "$(echo $MBDIST | grep '^-')" ] && MBDIST="down"
					CF="yes"
				fi
			fi
		fi
	fi
	
	echo "$COST#$TIME#$TRAF#$CON#$NCON#$REF#$CRE#$DISMIN#$TIMEDIS#$TIMEDISD#$TIMEDISM#$DISMB#$MBDISD#$MBDISM#$TIMEDIST#$MBDIST#$L_HOUR_LIMIT_REACHED#$L_MB_LIMIT_REACHED"
	exit
fi


