#!/bin/bash

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
echo ""
echo "Create new template"
echo ""
echo -n "Template Name: "
read NAME
NAME="$(echo "$NAME" | sed 's/ //g')"
if [ -z "$NAME" ];then
	echo ""
	echo "The Template Name cannot be empty. Try again."
	echo ""
	exit
fi
for TEMP in $(ls -A $C_HTDOCS_ZT_DIR/templates);do
	if [ "$NAME" == "$TEMP" ];then
		echo ""
		echo "The Template is already present. Try again"
		echo ""
		exit
	fi
done
echo ""
echo "Create new template"
cp -a $C_HTDOCS_ZT_DIR/templates/default/ $C_HTDOCS_ZT_DIR/templates/$NAME/
sed -i "s/ default / $NAME /g" $C_HTDOCS_ZT_DIR/templates/$NAME/preview.html
echo ""
echo "Done!"
echo ""
exit
