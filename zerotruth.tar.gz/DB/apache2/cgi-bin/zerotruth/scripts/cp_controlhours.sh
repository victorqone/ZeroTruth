#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
if [ "$C_CP_LOCAL_TYPE" != "Client" ] || [[ "$C_CP_LOCAL_TYPE" != "Client" && "$C_CP_LOCAL_AUTO" == "down" ]];then
	USERC="$1"
	[ "$USERC" == "$C_ADMIN" ] && exit
	IP="$2"
	TODAY=$(date +%d | sed 's/^0//')
	MONTH=$(date +%m | sed 's/^0//')
	CLASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE"  cn=$USERC radiusUserCategory | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
	PASSWORD=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE"  cn=$USERC sn | grep -e '^sn: ' | sed 's/^sn: //g')
	HD=$(cat $C_CLASSES_DIR/$CLASS/HoursDay 2>/dev/null)
	HM=$(cat $C_CLASSES_DIR/$CLASS/HoursMonth 2>/dev/null)
	MBD=$(cat $C_CLASSES_DIR/$CLASS/MBDay 2>/dev/null)
	MBM=$(cat $C_CLASSES_DIR/$CLASS/MBMonth 2>/dev/null)
	if [ -n "$HD" ];then
		if [ -f  $C_ACCT_DIR/entries/$USERC/TimeD$TODAY ];then
			HOURS_MAX=$(($HD*3600))
			TIME_TODAY=$(cat $C_ACCT_DIR/entries/$USERC/TimeD$TODAY)
			if [ $TIME_TODAY -ge $HOURS_MAX ];then
				LOCK="LOCKORED"
				CONTROL_HOURS_MAX="ok"
			fi
		fi
	fi
	if [ -n "$HM" ];then
		if [ -z "$CONTROL_HOURS_MAX" ];then
			if [ -f  $C_ACCT_DIR/entries/$USERC/TimeM$MONTH ];then
				HOURS_MAX=$(($HM*3600))
				TIME_MONTH=$(cat $C_ACCT_DIR/entries/$USERC/TimeM$MONTH)
				if [ $TIME_MONTH -ge $HOURS_MAX ];then
					LOCK="LOCKOREM"
					CONTROL_HOURS_MAX="ok"
				fi
			fi
		fi
	fi
	if [ -n "$MBD" ];then
		if [ -z "$CONTROL_HOURS_MAX" ];then
			if [ -f  $C_ACCT_DIR/entries/$USERC/MBD$TODAY ];then
				MAXMBD=$(($MBD*1048576))
				MBD=$(cat $C_ACCT_DIR/entries/$USERC/MBD$TODAY)
				if [ $MBD -ge $MAXMBD ];then
					LOCK="LOCKMBD"
					CONTROL_MB_MAX="ok"
				fi
			fi
		fi
	fi
	if [ -n "$MBM" ];then
		if [[ -z "$CONTROL_HOURS_MAX" && -z "$CONTROL_MB_MAX" ]];then
			if [ -f  $C_ACCT_DIR/entries/$USERC/MBM$MONTH ];then
				MAXMBM=$(($MBM*1048576))
				MBM=$(cat $C_ACCT_DIR/entries/$USERC/MBM$MONTH)
				if [ $MBM -ge $MAXMBM ];then
					LOCK="LOCKMBM"
					CONTROL_MB_MAX="ok"
				fi
			fi
		fi
	fi
	if [[ -n "$CONTROL_HOURS_MAX" || -n "$CONTROL_MB_MAX" ]];then
		RADIUSPW=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE"  cn=$USERC sn )
		PASSWORD=$(echo "$RADIUSPW" | grep -e '^sn: ' | sed 's/^sn: //g')
		PASSLOCK="$PASSWORD-$RANDOM$LOCK"
		DATA="dn: cn=$USERC,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		if [ -n "$IP" ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERC"
		else
			$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERC"
		fi
		if [ -n "$CONTROL_HOURS_MAX" ];then
			CONTROL="Hours Max"
		else
			CONTROL="MB Max"
		fi
		/usr/bin/logger -t ZT.system "Blocked $USERC $IP $CONTROL"
	fi
fi
exit
