#!/bin/bash

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
echo ""
echo "Delete template"
echo ""
echo "Templates:"
for TEMP in $(ls -A $C_HTDOCS_ZT_DIR/templates);do
	if [ "$TEMP" != "default" ];then
		echo "- $TEMP"
		CT="yes"
	fi
done
echo ""
if [ -z "$CT" ];then
	echo "Templates not present."
	echo ""
	exit
fi
echo ""
echo -n "Template Name: "
read NAME
if [[ -n "$NAME" && "$NAME" != "default" && -d $C_HTDOCS_ZT_DIR/templates/$NAME ]];then
	for TEMP in $(ls -A $C_HTDOCS_ZT_DIR/templates);do
		if [ "$NAME" == "$TEMP" ];then
			TP="yes"
			echo -n "Are you shure [NO/yes]: "
			read SCELTA
			if [ "$SCELTA" == "yes" ];then
				echo ""
				echo "Delete Template $NAME"
				rm -rf $C_HTDOCS_ZT_DIR/templates/$NAME
				$C_ZT_BIN_DIR/zt "Salva" "default" "$C_CP_DIR/Auth/Custom/Template"
				$C_ZT_BIN_DIR/zt "ConfigTemplate" "default"
				echo "Done!"
				echo ""
				exit
			fi
		fi
	done
else
	if [ -z "$NAME" ];then
		echo ""
		echo "The Template Name cannot be empty. Try again."
		echo ""
		exit
	else
		echo ""
		echo "The Template $NAME is not present. Try again"
		echo ""
		exit
	
	fi
fi
