#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

echo "0 $(echo $1 | cut -d'-' -f2)" > $C_ZT_CONF_DIR/keys.conf
echo "1 $(echo $1 | cut -d'-' -f3)" >> $C_ZT_CONF_DIR/keys.conf
echo "2 $(echo $1 | cut -d'-' -f4)" >> $C_ZT_CONF_DIR/keys.conf
echo "3 $(echo $1 | cut -d'-' -f5)" >> $C_ZT_CONF_DIR/keys.conf
echo "4 $(echo $1 | cut -d'-' -f6)" >> $C_ZT_CONF_DIR/keys.conf
echo "5 $(echo $1 | cut -d'-' -f7)" >> $C_ZT_CONF_DIR/keys.conf
echo "6 $(echo $1 | cut -d'-' -f8)" >> $C_ZT_CONF_DIR/keys.conf
echo "7 $(echo $1 | cut -d'-' -f9)" >> $C_ZT_CONF_DIR/keys.conf
echo "8 $(echo $1 | cut -d'-' -f10)" >> $C_ZT_CONF_DIR/keys.conf
echo "9 $(echo $1 | cut -d'-' -f11)" >> $C_ZT_CONF_DIR/keys.conf
echo "+ $(echo $1 | cut -d'-' -f12)" >> $C_ZT_CONF_DIR/keys.conf
echo "- $(echo $1 | cut -d'-' -f13)" >> $C_ZT_CONF_DIR/keys.conf
echo "* $(echo $1 | cut -d'-' -f14)" >> $C_ZT_CONF_DIR/keys.conf
echo "/ $(echo $1 | cut -d'-' -f15)" >> $C_ZT_CONF_DIR/keys.conf
echo "$(echo $1 | cut -d'-' -f16)" >> $C_ZT_CONF_DIR/keys.conf
echo ""
echo "Key.conf saved"
echo ""
exit
