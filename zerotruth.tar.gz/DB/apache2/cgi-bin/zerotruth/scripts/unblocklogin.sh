#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:      GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

[ -z "$1" ] && exit
/usr/local/sbin/iptables -D INPUT -m mac --mac-source $1 -j DROP 2>/dev/null
MACS="$(echo $1 | sed 's/\://g')"
rm -rf $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron 2>/dev/null > /dev/null
$C_ZT_BIN_DIR/zt "RestartCron"
sed -i "s/^$MACS.*//g" $C_ZT_LOG_DIR/controllogin/control
sed -i "/^$/d" $C_ZT_LOG_DIR/controllogin/control
exit
