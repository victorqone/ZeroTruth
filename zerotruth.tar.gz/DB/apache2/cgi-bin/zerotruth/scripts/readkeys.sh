#!/bin/bash
#********ll***************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2015 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/mudc/conf/mudc.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh

[ -z "$CM_MUDC" ] && exit

NC="$(echo $1 | sed 's/-/ /g' | wc -w | awk '{print $1}')"
[ "$NC" == "0" ] && exit
CODE=""
for N in $(seq 2 $(($NC+1)));do
	PC="$(echo $1 | cut -d'-' -f$N)"
	PC="$(cat $C_ZT_CONF_DIR/keys.conf | grep " $PC" | cut -d' ' -f1)"
	CODE="${CODE}${PC}"
done
if [ "$CODE" == "$CM_CODEKEY" ];then
	$CM_MUDC_DIR/scripts/doorOpener.sh $CODE
	exit
fi

R="$(cat $CM_MUDC_DIR/conf/FreeTel | wc -l | awk '{print $1}')"
for C in $(seq 1 $R);do
	RIG="$(cat $CM_MUDC_DIR/conf/FreeTel | sed -n ${C}p)"
	KEYDOOR="$(echo "$RIG" | cut -d'|' -f2)"
	if [ "$CODE" == "$KEYDOOR" ];then
		$CM_MUDC_DIR/scripts/doorOpener.sh $CODE
	exit
	fi
done

if [ "$(echo $CODE | cut -d'-' -f1)" == "$CM_KEYSCRIPT" ];then
	CODE="$(echo "$CODE" | sed "s/$CM_KEYSCRIPT\-//g")"
	$CM_MUDC_DIR/scripts/scriptkeypad.sh $CODE
	exit
fi

if [ "$CODE" == "$CM_KEYRELAY1" ];then
	$CM_MUDC_DIR/scripts/mudckeypad.sh $CODE
	exit
fi


for CONF in "CM_KEYRELAY2" "CM_KEYRELAY4" "CM_KEYRELAY5" "CM_KEYRELAY6" "CM_KEYRELAY7" "CM_KEYRELAY8" "CM_KEYRELAY9" "CM_KEYCCTV" "CM_ALLARMK";do
	if [[ "${!CONF}1" == "$CODE" || "${!CONF}0" == "$CODE" ]];then
		$CM_MUDC_DIR/scripts/mudckeypad.sh $CODE
		exit
	fi
done
exit

