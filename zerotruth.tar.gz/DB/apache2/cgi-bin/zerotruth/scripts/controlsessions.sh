#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:      GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
SECNOW=$(date +%s)
SECMAX=$(($SECNOW-87000))
for USER in $(ls $C_ACCT_DIR/entries);do
	for USERSESSION in $(ls $C_ACCT_DIR/entries/$USER/sessions);do
		if [ ! -f $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/stop ];then
			SECSTART=$(stat -c "%Y" $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/start)
			if [ "$SECSTART" -lt "$SECMAX" ];then
				SECSTOP=$(($SECSTART+120))
				echo "$SECSTOP" > $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/stop
				echo "120" > $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/Time
				DATASTOP=$(date -d "1970-01-01 $SECSTOP sec" +%Y%m%d%H%M)
				/bin/touch -t $DATASTOP $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/stop
				/bin/touch -t $DATASTOP $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION/Time
				/bin/touch -t $DATASTOP $C_ACCT_DIR/entries/$USER/sessions/$USERSESSION
			fi
		fi
	done
done
exit
