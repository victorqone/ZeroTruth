#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh



CONTROL_LDAP_EMAIL=$(cat $C_CRON_SCRIPTS_DIR/ZTSyncRemote$1-Cron/Description | grep " on ")
IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$1/IP)
PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$1/PASSWORD)
CLIENT="$1"

CONTROL_NC=$( `/usr/local/bin/nc -z -w 4 $IP_REMOTE 8088  2> /dev/null` || echo "down")
if [ -z "$CONTROL_NC" ];then
	$C_ZT_BIN_DIR/zt "TgzLDAP"
	/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=UpdateLDAP" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
	if [ "$(ls $C_ACCT_DIR/credits/ | wc -l | awk '{print $1}')"  -gt "0" ];then
		$C_ZT_BIN_DIR/zt "TgzCredits"
		/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=UpdateCredits" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
	fi
	$C_ZT_BIN_DIR/zt "TgzClasses"
	/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=GetClass" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
fi
/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=DataSync" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
if [[ -n "$TEXT_EMAIL" && -n "$CONTROL_LDAP_EMAIL" ]];then
	TEXT_EMAIL="UPDATE REMOTE LDAP ERROR\n\nUSERS: $TEXT_EMAIL"
	$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL" "$C_ADMIN_EMAIL"
fi
