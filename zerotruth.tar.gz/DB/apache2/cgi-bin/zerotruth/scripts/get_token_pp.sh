#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#**********************************************/DB	na**************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh

TOKEN=$(curl -k https://api.sandbox.paypal.com/v1/oauth2/token \
 -H "Accept: application/json" \
 -H "Accept-Language: en_US" \
 -u "$C_PP_CLIENT_ID:$C_PP_SECRET" \
 -d "grant_type=client_credentials" |  awk '{split ($0, a, "access_token");print a[2]}' | cut -d'"' -f3)
 
$C_ZT_BIN_DIR/zt "SalvaConfig" "C_PP_TOKEN" "$TOKEN"
sed -i 's/total.*/total\"\:\"$1\"\,/g' /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
/DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh










