#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh

rm -r -f $C_ZT_DIR/tmp/* 2> /dev/null >/dev/null
if [ "$C_FORM_DATE" == "ita" ];then
	TODAY=$(date +%d%m%Y_%H%M%S)
else
	TODAY=$(date +%Y%m%d_%H%M%S)
fi
$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY"
$C_ZT_BIN_DIR/zt "Copia" "$C_ZT_CONF_DIR/version" "$C_ZT_DIR/tmp/backup_$TODAY/version"
if [ "$C_BK_USERS" == "on" ];then
	/usr/local/sbin/slapcat -b "$C_LDAPBASE" > $C_ZT_DIR/tmp/backup_$TODAY/ldap_ldif
	BKLOG="$L_USERS"
fi
if [ "$C_BK_PROG" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/prog"
	cp -a $C_CRON_SCRIPTS_DIR/ZT* $C_ZT_DIR/tmp/backup_$TODAY/prog/
	rm -rf $C_ZT_DIR/tmp/backup_$TODAY/prog/ZTMUDC* 2>/dev/null
	BKLOG="$BKLOG $L_PROGRAMMING"
fi
if [ "$C_BK_CONFIG" == "on" ];then
	cp -a $C_ZT_DIR/conf $C_ZT_DIR/tmp/backup_$TODAY/
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/Custom"
	for confcustom in  "GeneralInfo" "Description" "PostRegistration" "UserBlocked" "RedirectFree" \
		"LoginML" "DomainVisible" "CpFree" "Popup" "WalledGarden" "RePass" "ShowMB" \
		"ShowCost" "ShowImgLogin"  "RegisterSocial" "RegisterAsterisk" "ChargePayPal" \
		"Registered" "SRVWalledGarden" "TypeWalledGarden" "RedUrlWalledGaeden" "IpUrlWalledGarden" "PopupActive" "EnforcePopup" "RePass";do
		cp -a $C_CP_DIR/Auth/Custom/$confcustom $C_ZT_DIR/tmp/backup_$TODAY/Custom/ 2>/dev/null
	done
	BKLOG="$BKLOG $L_CONFIG1"
fi
if [ "$C_BK_SESSIONS" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/sessions"
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/sessions/deleted"
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/sessions/expired"
	cp -a $C_ZT_DIR/deleted/* $C_ZT_DIR/tmp/backup_$TODAY/sessions/deleted/ 2>/dev/null
	cp -a $C_ZT_DIR/expired/* $C_ZT_DIR/tmp/backup_$TODAY/sessions/expired/ 2>/dev/null
	for DIRUSER in $( ls $C_ACCT_DIR/entries );do
		mkdir $C_ZT_DIR/tmp/backup_$TODAY/sessions/$DIRUSER
		cp -a $C_ACCT_DIR/entries/$DIRUSER/sessions $C_ZT_DIR/tmp/backup_$TODAY/sessions/$DIRUSER
	done
	BKLOG="$BKLOG $L_SESSIONS"
fi
if [ "$C_BK_CLASSES" == "on" ];then
	cp -a $C_CLASSES_DIR $C_ZT_DIR/tmp/backup_$TODAY/
	BKLOG="$BKLOG $L_CLASSES"
fi

if [ "$C_BK_FREECLIENTS" == "on" ];then
	cp -a $C_CP_DIR/FreeClients $C_ZT_DIR/tmp/backup_$TODAY/
	BKLOG="$BKLOG FreeClients"
fi

if [ "$C_BK_FREESERVICES" == "on" ];then
	cp -a $C_CP_DIR/FreeServices $C_ZT_DIR/tmp/backup_$TODAY/
	BKLOG="$BKLOG FreeServices"
fi

if [ "$C_BK_SLAPCAT" == "on" ];then
	slapcat -l $C_ZT_DIR/tmp/backup_$TODAY/Slapcat
	BKLOG="$BKLOG Slapcat"
fi

if [ "$C_BK_LOGS" == "on" ];then
	cp -a  /Database/LOG $C_ZT_DIR/tmp/backup_$TODAY/
	BKLOG="$BKLOG Log"
fi

if [ "$C_BK_CONFMUDC" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/mudcconf"
	cp -a  $C_ZT_DIR/mudc/conf/* $C_ZT_DIR/tmp/backup_$TODAY/mudcconf/
fi

if [ "$C_BK_PROGMUDC" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/mudcprog"
	cp -a  $C_ZT_DIR/mudc/data/Prog/* $C_ZT_DIR/tmp/backup_$TODAY/mudcprog/
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/mudccron"
	cp -a $C_CRON_SCRIPTS_DIR/ZTMUDC* $C_ZT_DIR/tmp/backup_$TODAY/mudccron/
fi

if [ "$C_BK_GRAPHSMUDC" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/mudcgraphs"
	cp -a  $C_ZT_DIR/mudc/data/Graphs/* $C_ZT_DIR/tmp/backup_$TODAY/mudcgraphs/
fi

if [ "$C_BK_SESSIONSMUDC" == "on" ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/backup_$TODAY/mudcsessions"
	cp -a  $C_ZT_DIR/mudc/data/Sessions/* $C_ZT_DIR/tmp/backup_$TODAY/mudcsessions/
fi

mkdir $C_ZT_DIR/tmp/backup_$TODAY/images
cp $C_HTDOCS_DIR/images/imguser.png $C_ZT_DIR/tmp/backup_$TODAY/images/
cp $C_HTDOCS_DIR/images/base.png $C_ZT_DIR/tmp/backup_$TODAY/images/
cp -a $C_HTDOCS_DIR/images/imglogin $C_ZT_DIR/tmp/backup_$TODAY/images/
cp -a $C_HTDOCS_DIR/images/popup $C_ZT_DIR/tmp/backup_$TODAY/images/
cp -a $C_HTDOCS_DIR/images/wg $C_ZT_DIR/tmp/backup_$TODAY/images/

BKLOG="$BKLOG - via "
cd $C_ZT_DIR/tmp
NOMEFILE=$(echo "$C_HOTSPOT_NAME" |  sed '/ /s//_/g')
tar -czvf $NOMEFILE-$TODAY.tgz backup_$TODAY
if [ -n "$C_BK_EMAIL" ];then
$C_ZT_BIN_DIR/mutt -e "set realname=$NOMEFILE" -F $C_ZT_CONF_DIR/Muttrc -s "$L_BACKUP" \
-a $C_ZT_DIR/tmp/$NOMEFILE-$TODAY.tgz $C_ADMIN_EMAIL < $C_HTDOCS_ZT_DIR/msg/$C_LANGUAGE/BackupInfo && CONTROL_EMAIL="yes"
BKLOG="$BKLOG Email"
fi
if [[ -n "$C_BK_FTP" && -n "$C_SERVER_FTP" ]];then
	echo -e "user $C_USER_FTP $C_PASSWORD_FTP\nbinary\ncd $C_DIR_FTP\nput $NOMEFILE-$TODAY.tgz\nbye" | ftp -n "$C_SERVER_FTP"
	CONTROL=$(echo -e "user $C_USER_FTP $C_PASSWORD_FTP\nbinary\ncd $C_DIR_FTP\nls $NOMEFILE-$TODAY.tgz\nbye" | ftp -n "$C_SERVER_FTP")
	CONTROL_FTP=$(echo "$CONTROL" | grep "$NOMEFILE-$TODAY.tgz")
	BKLOG="$BKLOG FTP"
fi
if [[ -n "$C_BK_DB" && -n "$C_APP_KEY_DB"  && "$C_APP_SECRET_DB" ]];then
	function urlencode
	{
		echo "${1}" | sed -f /DB/apache2/cgi-bin/zerotruth/conf/url_escape
	}
	/usr/local/bin/curl -k  -i --globoff -o /tmp/risdropbox --upload-file ./$NOMEFILE-$TODAY.tgz "https://api-content.dropbox.com/1/files_put/$C_ACCESS_LEVEL_DB/$(urlencode "/$C_REMOTE_DIR_DB/$NOMEFILE-$TODAY.tgz")?oauth_consumer_key=$C_APP_KEY_DB&oauth_token=$C_TOKEN_DB&oauth_signature_method=PLAINTEXT&oauth_signature=$C_APP_SECRET_DB%26$C_TOKEN_SECRET_DB&oauth_nonce=$RANDOM"
	sleep 1
	/usr/local/bin/curl -k --show-error --globoff -i -o /tmp/listdb "https://api.dropbox.com/1/metadata/dropbox/$(urlencode "/$C_REMOTE_DIR_DB")?oauth_consumer_key=$C_APP_KEY_DB&oauth_token=$C_TOKEN_DB&oauth_signature_method=PLAINTEXT&oauth_signature=$C_APP_SECRET_DB%26$C_TOKEN_SECRET_DB&oauth_nonce=$RANDOM"
	CONTROL=$(cat /tmp/listdb | sed 's/\"path\": \"/\\n/g' | sed -n '/is_dir\"\: false/p')
	CONTROL=$(echo -e "$CONTROL" | sed -n '/is_dir\"\: false/p' | sed -n '/tgz/p' | grep "$NOMEFILE-$TODAY.tgz")
	if [ -n "$CONTROL" ];then
		CONTROL_DB="ok"
	fi
	rm -rf /tmp/listdb
	BKLOG="$BKLOG DropBox"
fi
if [[ -n "$C_BK_SCP" && -n "$C_IP_SCP_REMOTE" && -n "$C_DIR_SCP_REMOTE" ]];then
	tar -czvf $NOMEFILE-SCP-$TODAY.tgz backup_$TODAY
	scp -i /root/.ssh/id_rsa $NOMEFILE-SCP-$TODAY.tgz $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE:$C_DIR_SCP_REMOTE || CSCP="no"
	[ -z "$CSCP" ] && CONTROL_SCP="ok"
	BKLOG="$BKLOG scp"
fi
logger -t backup "$BKLOG"
if [[ -n "$CONTROL_EMAIL" || -n "$CONTROL_FTP" || -n "$CONTROL_DB" || -n "$CONTROL_SCP" ]];then
	rm -rf $C_ZT_DIR/tmp/backup_$TODAY
	rm -rf $C_ZT_DIR/tmp/$NOMEFILE-$TODAY.tgz
	if [[ "$C_BK_DELETE_LOGS" == "on" && "$C_BK_LOGS" == "on" ]];then
		echo "" > $C_ZT_PROXY_DIR/var/logs/access.log 2>/dev/null
		echo "" > $C_ZT_PROXY_DIR/var/logs/cache.log 2>/dev/null
		echo "" > $C_ZT_PROXY_DIR/var/log/dansguardian/access.log 2>/dev/null
		echo "" > /var/log/havp/access.log 2>/dev/null
		echo "" > /var/log/havp/error.log 2>/dev/null
		rm -rf  /Database/LOG/ 2>/dev/null

	fi
	if [[ "$C_BK_DELETED_USERS" == "on" &&  "$C_BK_DELETE_USERS" == "on" ]];then
		rm -rf  $C_ZT_DIR/deleted/*
	fi

fi








