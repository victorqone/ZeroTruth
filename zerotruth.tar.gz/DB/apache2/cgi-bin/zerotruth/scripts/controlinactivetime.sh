#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#************************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
[[ -z "$C_DISCONNECT_TIME" || -z $(ls $C_CP_DIR/Connected) ]] && exit
if [ ! -d $C_ZT_CONF_DIR/Connected ];then
	$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_CONF_DIR/Connected"
fi
IPCONN=$(ls $C_CP_DIR/Connected)
NAMECON=$(cat $C_CP_DIR/Connected/*/User | cut -sd'@' -f1)
for NAME in $(ls $C_ZT_CONF_DIR/Connected) ;do
	if [ -z $(echo "$NAMECON" | grep "^$NAME ") ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/Connected/$NAME"
	fi
done
for IP in $IPCONN;do
	CONNECT=$(cat $C_CP_DIR/Connected/$IP/User | cut -sd'@' -f1)
	RXTX=$(/root/kerbynet.cgi/scripts/cp_getRXTX "$IP")
	RX=$(echo "$RXTX" | cut -d ' ' -f 2)
	TX=$(echo $RXTX|cut -d ' ' -f 4)
	TRAFFIC=$((RX+TX))
	if [ ! -f $C_ZT_CONF_DIR/Connected/$CONNECT ];then
		echo "$(date +%s) $TRAFFIC" > $C_ZT_CONF_DIR/Connected/$CONNECT
	else
		SECCON=$(cat $C_ZT_CONF_DIR/Connected/$CONNECT | awk '{print $1}')
		SECMAX=$(($SECCON+$C_DISCONNECT_TIME))
		if [ "$(date +%s)" -gt "$SECMAX" ];then
			if [ $(cat $C_ZT_CONF_DIR/Connected/$CONNECT | awk '{print $2}') == $TRAFFIC ];then
				$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
				$C_ZT_BIN_DIR/zt "Cancella" "/$C_ZT_CONF_DIR/Connected/$CONNECT"
			else
				echo "$(date +%s) $TRAFFIC" > $C_ZT_CONF_DIR/Connected/$CONNECT
			fi
		fi
	fi
done
