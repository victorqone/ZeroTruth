#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
IP="$1"
[ -z "$IP" ] && exit
INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
for CONF in $(ls $C_ZT_CONF_DIR/cbqconf);do
	if [ -n "$(echo "$CONF" | grep "$IP" | grep '\-UP$')" ];then
		CONFIGUP="$CONF"
	fi
	if [ -n "$(echo "$CONF" | grep "$IP" | grep -v '\-UP$')" ];then
		CONFIGDOWN="$CONF"
	fi
done
if [[ -n "$CONFIGUSER" || -n "$CONFIGDOWN" ]];then
	if [ -n "$CONFIGUP" ];then
		MARK="$(echo "$CONFIGUP" | cut -d'-' -f5)"
		/usr/local/sbin/iptables --table mangle -D POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK 2>/dev/null >/dev/null
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/$CONFIGUP" 2>/dev/null > /dev/null
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/$CONFIGDOWN" 2>/dev/null > /dev/null
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq.init" 2>/dev/null > /dev/null
	$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
else
	for RULE in $(ls $C_ZT_CONF_DIR/cbqconf/cbq-*);do
		CONTROLRULE="$(cat $RULE | grep "$IP")"
		if [ -n "$CONTROLRULE" ];then
			sed -i "/$IP/d" $RULE
			sed -i "/^$/d" $RULE
			MARK=$(cat $RULE | grep  'MARK' | cut -d'=' -f2)
			if [ -n "$MARK" ];then
				/usr/local/sbin/iptables --table mangle -D POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK 2>/dev/null >/dev/null
			fi
		fi
	done
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq.init" 2>/dev/null > /dev/null
	$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
fi
exit
