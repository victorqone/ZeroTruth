#!/bin/bash
sed -i "s/^C_ADMIN_LOCK=.*/C_ADMIN_LOCK=\"\"/g" /DB/apache2/cgi-bin/zerotruth/conf/zt.config
exit
