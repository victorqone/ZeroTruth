#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh

TODAY=$(date +%s)
TODAY=$(($TODAY/86400))
QUERYP=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" '(!(uid=admin))' uid )
USERS=$(echo "$QUERYP" |  grep -e '^uid: ' | awk '{print $2}')
NR=1
for USER in $USERS;do
	NORADIUS=""
	ERROR=""
	CONTROLMODIFY=""
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USER  uid givenName sn mail telephoneNumber shadowExpire roomName hoursDay hoursMonth mbDay mbMonth hidden validity ownerUser MCpInterfaces maxDays loginRemote class sessions)
	USERNAME=$(echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
	QUERYR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER)
	[ -z "$QUERYR" ] && NORADIUS="yes"
	NAME=$(echo "$QUERY" | grep -e '^givenName:')
	[[ -z "$NAME" || -n "$(echo $NAME | grep '\:\:')" ]] && ERROR="NAME"
	[ -z "$NAME" ] && ERROR="NAME"
	LAST_NAME=$(echo "$QUERY" | grep -e '^sn:')
	[[ -z "$LAST_NAME" || -n "$(echo $LAST_NAME | grep '\:\:')" ]] && ERROR="$ERROR LAST_NAME"
	EMAIL=$(echo "$QUERY" | grep -e '^mail:')
	[[ -z "$EMAIL" || -n "$(echo $EMAIL | grep '\:\:')" ]] && ERROR="$ERROR EMAIL"
	PHONE=$(echo "$QUERY" | grep -e '^telephoneNumber:')
	[[ -z "$PHONE" || -n "$(echo $PHONE | grep '\:\:')" ]] && ERROR="$ERROR PHONE"
	EXPIRE=$(echo "$QUERY" | grep -e '^shadowExpire:')
	[[ -z "$EXPIRE" || -n "$(echo $EXPIRE | grep '\:\:')" ]] && ERROR="$ERROR EXPIRE"
	ROOM=$(echo "$QUERY" | grep -e '^roomName:')
	[[ -z "$ROOM" || -n "$(echo $ROOM | grep '\:\:')" ]] && ERROR="$ERROR ROOM"
	HIDDEN=$(echo "$QUERY" | grep -e '^hidden:')
	[[ -z "$HIDDEN" || -n "$(echo $HIDDEN | grep '\:\:')" ]] || [[ "$(echo -e "$QUERY" | grep -e '^hidden:' | awk '{print $2}')" != "yes" && "$(echo "$QUERY" | grep -e '^hidden:' | awk '{print $2}')" != "no" ]] && ERROR="$ERROR HIDDEN"
	VALIDITY=$(echo "$QUERY" | grep -e '^validity:')
	[[ -z "$VALIDITY" || -n "$(echo $VALIDITY | grep '\:\:')" ]] || [[ "$(echo -e "$QUERY" | grep -e '^validity:' | awk '{print $2}')" != "yes" && "$(echo "$QUERY" | grep -e '^validity:' | awk '{print $2}')" != "no" ]] && ERROR="$ERROR VALIDITY"
	OWNER=$(echo "$QUERY" | grep -e '^ownerUser:')
	[[ -z "$OWNER" || -n "$(echo $OWNER | grep '\:\:')" ]] || [ "$(echo -e "$QUERY" | grep -e '^ownerUser:' | awk '{print $2}')" == "?" ] && ERROR="$ERROR OWNER"
	MCPI=$(echo "$QUERY" | grep -e '^MCpInterfaces:')
	[[ -z "$MCPI" || -n "$(echo $MCPI | grep '\:\:')" ]] && ERROR="$ERROR MCPI"
	MAXDAYS=$(echo "$QUERY" | grep -e '^maxDays:')
	[[ -z "$MAXDAYS" || -n "$(echo $MAXDAYS | grep '\:\:')" ]] && ERROR="$ERROR MAXDAYS"
	LOGINREMOTE=$(echo "$QUERY" | grep -e '^loginRemote:')
	[[ -z "$LOGINREMOTE" || -n "$(echo $LOGINREMOTE | grep '\:\:')" ]] && ERROR="$ERROR LOGINREMOTE"
	EXPIRE=$(echo "$QUERY" | grep -e '^shadowExpire:')
	[[ -z "$EXPIRE" || -n "$(echo $EXPIRE | grep '\:\:')" ]] && ERROR="$ERROR EXPIRE"
	CLASS=$(echo "$QUERY" | grep -e '^class:')
	[[ -z "$CLASS" || -n "$(echo $CLASS | grep '\:\:')" ]] && ERROR="$ERROR CLASS"
	SESSIONS=$(echo "$QUERY" | grep -e '^sessions:')
	[[ -z "$SESSIONS" || -n "$(echo $SESSIONS | grep '\:\:')" ]] && ERROR="$ERROR SESSIONS"
	if [[ -n "$NORADIUS" || -n "$ERROR" ]];then
		DATA="dn: uid=$USER,ou=People,$C_LDAPBASE"
		for ATT in $ERROR;do
			[ "$ATT" == "NAME" ] && DATA="$DATA\ngivenName: $L_ANONYMOUS"
			[ "$ATT" == "LAST_NAME" ] && DATA="$DATA\nsn: $L_ANONYMOUS"
			[ "$ATT" == "EMAIL" ] && DATA="$DATA\nmail: ?"
			[ "$ATT" == "INFO" ] && DATA="$DATA\ngecos: ?"
			[ "$ATT" == "HIDDEN" ] && DATA="$DATA\nhidden: no"
			[ "$ATT" == "PHONE" ] && DATA="$DATA\ntelephoneNumber: ?"
			[ "$ATT" == "MAXDAYS" ] && DATA="$DATA\nmaxDays: ?"
			[ "$ATT" == "VALIDITY" ] && DATA="$DATA\nvalidity: yes"
			[ "$ATT" == "ROOM" ] && DATA="$DATA\nroomName: ?"
			[ "$ATT" == "MCPI" ] && DATA="$DATA\nMCpInterfaces: ?"
			[ "$ATT" == "OWNER" ] && DATA="$DATA\nownerUser: $C_ADMIN"
			[ "$ATT" == "EXPIRE" ] && DATA="$DATA\nshadowExpire: 24836"
			[ "$ATT" == "CLASS" ] && DATA="$DATA\nclass: DEFAULT"
			[ "$ATT" == "SESSIONS" ] && DATA="$DATA\nsessions: 0"
			[ "$ATT" == "LOGINREMOTE" ] && DATA="$DATA\nloginRemote: ?"
		done
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
	fi
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn radiusUserCategory)
	CLASS=$(echo "$QUERY" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
	PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
	if [ -z "$CLASS" ];then
		CLASS="DEFAULT"
	fi
	if [ -d $C_ACCT_DIR/entries/$USER/sessions ];then
		NSESSIONS=`ls $C_ACCT_DIR/entries/$USER/sessions/ | wc -l`
		if [ -d $C_ZT_DIR/expired/$USER/$USER/sessions ];then
			NSESSIONS_EXP=`ls $C_ZT_DIR/expired/$USER/$USER/sessions/ | wc -l`
		else
			NSESSIONS_EXP=0
		fi
		NSESSIONS=$(($NSESSIONS+$NSESSIONS_EXP))
	else
		NSESSIONS=0
	fi
	VALIDITY="yes"
	CONTROL_EX=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USER shadowExpire  | grep -e '^shadowExpire: ' | sed 's/^shadowExpire: //g')
	if [[ -n "$CONTROL_EX" && $TODAY -gt $CONTROL_EX ]];then
		VALIDITY="E"
	fi
	CL=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER radiusUserCategory  | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
	if [ -f $C_ACCT_DIR/classes/$CL/ChargeType ];then
		if [ "$(cat $C_ACCT_DIR/classes/$CL/ChargeType)" == "pre" ];then
			CREDIT=$(cat $C_ACCT_DIR/credits/$USER/Credit)
			CHARGETYPE=$(cat $C_ACCT_DIR/classes/$CL/ChargeType)
			FREETIME=$(cat $C_ACCT_DIR/classes/$CL/FreeTime)
			if [[  -z "$CREDIT" || "$CREDIT" == "0.00" || $(echo "$CREDIT" | grep '^-') ]] && [ "$CREDIT" != "freetime" ];then
				VALIDITY="C"
			fi
		fi
	fi
	if [ -f $C_ACCT_DIR/entries/$USER/Time ] && [ -f $C_ACCT_DIR/classes/$CL/Hours ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/Hours)" ];then
		TIME=$(cat $C_ACCT_DIR/entries/$USER/Time)
		LIMITH=$(cat $C_ACCT_DIR/classes/$CL/Hours)
		LIMITH=$(($LIMITH*3600))
		if [ $TIME -gt $LIMITH ];then
			VALIDITY="T"
		fi
	fi
	if [ -f $C_ACCT_DIR/entries/$USER/MB ] && [ -f $C_ACCT_DIR/classes/$CL/MB ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/MB)" ];then
		TRAFFIC=$(cat $C_ACCT_DIR/entries/$USER/MB)
		LIMITMB=$(cat $C_ACCT_DIR/classes/$CL/MB)
		LIMITMB=$((LIMITMB*1048576))
		if [ $TRAFFIC -gt $LIMITMB ];then
			VALIDITY="M"
		fi
	fi
	DATA="dn: uid=$USER,ou=PEOPLE,$C_LDAPBASE\nsessions: $NSESSIONS\nclass: $CLASS\nvalidity: $VALIDITY"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
	if [ -z "$CONTROLMODIFY" ];then
		/usr/bin/logger -t ZT.system "Updated $USER"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$NORADIUS" ]];then
		/usr/bin/logger -t ZT.system "ERROR Update $USER"
	fi
done
exit
