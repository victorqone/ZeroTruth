#!/bin/bash
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
# $C_MY_CODE My code
# $1 Command1
# $2 Command2
# $3 Command3 ...
# For reply: $C_ZT_BIN_DIR/zt "SendSms" "Text" "NUN. PHONE"
#

