#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh

[ -z "$C_ACTIVE_AD" ] && exit

/usr/local/bin/curl -s -l http://someonewhocares.org/hosts/ |  sed -n "/\;wiki-spam-sites/,/\/wiki-spam-sites/p"  > /tmp/blockhosts
sed -i "/#./d" /tmp/blockhosts
sed -i "/^$/d" /tmp/blockhosts
sed -i "1 i ##### BLOCKED HOSTS #####" /tmp/blockhosts
echo "##### END BLOCKED HOSTS #####" >> /tmp/blockhosts

if [ -n "$(cat /etc/hosts | grep 'END')" ];then
	cat /etc/hosts | sed -n "/END/,//p" | sed "/END/d" >> /tmp/blockhosts
else
	cat /etc/hosts >> /tmp/blockhosts
fi
mv /tmp/blockhosts /etc/hosts
NOW=$(date +%s)
$C_ZT_BIN_DIR/zt "SalvaConfig" "C_UPDATES_AD" "$NOW"
exit
