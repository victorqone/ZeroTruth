#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
export LC_ALL=C
TC=/usr/sbin/tc
IP=/usr/sbin/ip
MP=/bin/modprobe
PRIO_RULE_DEFAULT=${PRIO_RULE:-100}
PRIO_MARK_DEFAULT=${PRIO_MARK:-200}
PRIO_REALM_DEFAULT=${PRIO_REALM:-300}
CBQ_PATH=${CBQ_PATH:-/DB/apache2/cgi-bin/zerotruth/conf/cbqconf}
CBQ_CACHE=${CBQ_CACHE:-/DB/apache2/cgi-bin/zerotruth/conf/cbqconf/cbq.init}
CBQ_PROBE="sch_cbq sch_tbf sch_sfq sch_prio"
CBQ_PROBE="$CBQ_PROBE cls_fw cls_u32 cls_route"
CBQ_WORDS="DEVICE|RATE|WEIGHT|PRIO|PARENT|LEAF|BOUNDED|ISOLATED"
CBQ_WORDS="$CBQ_WORDS|PRIO_MARK|PRIO_RULE|PRIO_REALM|BUFFER"
CBQ_WORDS="$CBQ_WORDS|LIMIT|PEAK|MTU|QUANTUM|PERTURB"
cbq_device_list () {
	ip link show| sed -n "/^[0-9]/ \
		{ s/^[0-9]\+: \([a-z0-9._]\+\)[:@].*/\1/; p; }"
}
cbq_device_off () {
	tc qdisc del dev $1 root 2> /dev/null
}
cbq_off () {
	for dev in `cbq_device_list`; do
		cbq_device_off $dev
	done
}
cbq_message () {
	echo -e "**CBQ: $@"
}
cbq_failure () {
	cbq_message "$@"
	exit 1
}
cbq_fail_off () {
	cbq_message "$@"
	cbq_off
	exit 1
}
cbq_time2abs () {
	local min=${1##*:}; min=${min##0}
	local hrs=${1%%:*}; hrs=${hrs##0}
	echo $[hrs*60 + min]
}
cbq_show () {
	for dev in `cbq_device_list`; do
		[ `tc qdisc show dev $dev| wc -l` -eq 0 ] && continue
		echo -e "### $dev: queueing disciplines\n"
		tc $1 qdisc show dev $dev; echo

		[ `tc class show dev $dev| wc -l` -eq 0 ] && continue
		echo -e "### $dev: traffic classes\n"
		tc $1 class show dev $dev; echo

		[ `tc filter show dev $dev| wc -l` -eq 0 ] && continue
		echo -e "### $dev: filtering rules\n"
		tc $1 filter show dev $dev; echo
	done
}
cbq_init () {
	CLASSLIST=`find $1 \( -type f -or -type l \) -name 'cbq-*' \
		-not -name '*~' -maxdepth 1 -printf "%f\n"| sort`
	[ -z "$CLASSLIST" ] &&
		cbq_failure "no configuration files found in $1!"
	DEVFIELDS=`find $1 \( -type f -or -type l \) -name 'cbq-*' \
		  -not -name '*~' -maxdepth 1| xargs sed -n 's/#.*//; \
		  s/[[:space:]]//g; /^DEVICE=[^,]*,[^,]*\(,[^,]*\)\?/ \
		  { s/.*=//; p; }'| sort -u`
	[ -z "$DEVFIELDS" ] &&
		cbq_failure "no DEVICE field found in $1/cbq-*!"
	DEVICES=`echo "$DEVFIELDS"| sed 's/,.*//'| sort -u`
	[ `echo "$DEVICES"| wc -l` -ne `echo "$DEVFIELDS"| wc -l` ] &&
		cbq_failure "different DEVICE fields for single device!\n$DEVFIELDS"
}
cbq_load_class () {
	CLASS=`echo $2| sed 's/^cbq-0*//; s/^\([0-9a-fA-F]\+\).*/\1/'`
	CFILE=`sed -n 's/#.*//; s/[[:space:]]//g; /^[[:alnum:]_]\+=[[:alnum:].,:;/*@-_]\+$/ p' $1/$2`
	IDVAL=`/usr/bin/printf "%d" 0x$CLASS 2> /dev/null`
	[ $? -ne 0 -o $IDVAL -lt 2 -o $IDVAL -gt 65535 ] &&
		cbq_fail_off "class ID of $2 must be in range <0002-FFFF>!"
	RATE=""; WEIGHT=""; PARENT=""; PRIO=5
	LEAF=tbf; BOUNDED=yes; ISOLATED=no
	BUFFER=10Kb/8; LIMIT=15Kb; MTU=1500
	PEAK=""; PERTURB=10; QUANTUM=""
	PRIO_RULE=$PRIO_RULE_DEFAULT
	PRIO_MARK=$PRIO_MARK_DEFAULT
	PRIO_REALM=$PRIO_REALM_DEFAULT
	eval `echo "$CFILE"| grep -E "^($CBQ_WORDS)="`
	[ -z "$RATE" -o -z "$WEIGHT" ] &&
		cbq_fail_off "missing RATE or WEIGHT in $2!"
	DEVICE=${DEVICE%%,*}
	[ -z "$DEVICE" ] && cbq_fail_off "missing DEVICE field in $2!"
	BANDWIDTH=`echo "$DEVFIELDS"| sed -n "/^$DEVICE,/ \
		  { s/[^,]*,\([^,]*\).*/\1/; p; q; }"`
	PEAK=${PEAK:+peakrate $PEAK}
	PERTURB=${PERTURB:+perturb $PERTURB}
	QUANTUM=${QUANTUM:+quantum $QUANTUM}
	[ "$BOUNDED" = "no" ] && BOUNDED="" || BOUNDED="bounded"
	[ "$ISOLATED" = "yes" ] && ISOLATED="isolated" || ISOLATED=""
}
[ -x $TC -a -x $IP ] ||
	cbq_failure "ip-route2 utilities not installed or executable!"
if [ "$1" = "compile" ]; then
	CBQ_PROBE=""
	ip () {
		$IP "$@"
	}
	tc () {
		echo "$TC $@"
	}
elif [ -n "$CBQ_DEBUG" ]; then
	echo -e "# `date`" > $CBQ_DEBUG
	ip () {
		echo -e "\n# ip $@" >> $CBQ_DEBUG
		$IP "$@" 2>&1 | tee -a $CBQ_DEBUG
	} 
	tc () {
		echo -e "\n# tc $@" >> $CBQ_DEBUG
		$TC "$@" 2>&1 | tee -a $CBQ_DEBUG
	}
else
	ip () {
		$IP "$@"
	}
	tc () {
		$TC "$@"
	}
fi
case "$1" in
start|compile)
for module in $CBQ_PROBE; do
	$MP $module || cbq_failure "failed to load module $module"
done
if [ "$1" != "compile" -a "$2" != "nocache" -a -z "$CBQ_DEBUG" ]; then
	VALID=1
	[ "$2" = "invalidate" -o ! -f $CBQ_CACHE ] && VALID=0
	if [ $VALID -eq 1 ]; then
		[ `find $CBQ_PATH -maxdepth 1 -newer $CBQ_CACHE| \
		  wc -l` -gt 0 ] && VALID=0
	fi
	if [ $VALID -ne 1 ]; then
		$0 compile > $CBQ_CACHE ||
			cbq_fail_off "failed to compile CBQ configuration!"
	fi
	exec /bin/sh $CBQ_CACHE 2> /dev/null
fi
cbq_init $CBQ_PATH
for dev in $DEVICES; do
	DEVTEMP=`echo "$DEVFIELDS"| sed -n "/^$dev,/ { s/$dev,//; p; q; }"`
	DEVBWDT=${DEVTEMP%%,*};	DEVWGHT=${DEVTEMP##*,}
	[ "$DEVBWDT" = "$DEVWGHT" ] && DEVWGHT=""
	if [ -z "$DEVBWDT" ]; then
		cbq_message "could not determine bandwidth for device $dev!"
		cbq_failure "please set up the DEVICE fields properly!"
	fi
	ip link show $dev &> /dev/null ||
		cbq_fail_off "device $dev not found!"
	cbq_device_off $dev
	tc qdisc add dev $dev root handle 1 cbq \
	bandwidth $DEVBWDT avpkt 1000 cell 8
	[ -n "$DEVWGHT" ] &&
		tc class change dev $dev root cbq weight $DEVWGHT allot 1514

	[ "$1" = "compile" ] && echo
done
for classfile in $CLASSLIST; do
	cbq_load_class $CBQ_PATH $classfile
	tc class add dev $DEVICE parent 1:$PARENT classid 1:$CLASS cbq \
	bandwidth $BANDWIDTH rate $RATE weight $WEIGHT prio $PRIO \
	allot 1514 cell 8 maxburst 20 avpkt 1000 $BOUNDED $ISOLATED ||
		cbq_fail_off "failed to add class $CLASS with parent $PARENT on $DEVICE!"
	if [ "$LEAF" = "tbf" ]; then
		tc qdisc add dev $DEVICE parent 1:$CLASS handle $CLASS tbf \
		rate $RATE buffer $BUFFER limit $LIMIT mtu $MTU $PEAK
	elif [ "$LEAF" = "sfq" ]; then
		tc qdisc add dev $DEVICE parent 1:$CLASS handle $CLASS sfq \
		$PERTURB $QUANTUM
	fi
	for mark in `echo "$CFILE"| sed -n '/^MARK/ { s/.*=//; p; }'`; do
		tc filter add dev $DEVICE parent 1:0 protocol ip \
		prio $PRIO_MARK handle $mark fw classid 1:$CLASS
	done
	for realm in `echo "$CFILE"| sed -n '/^REALM/ { s/.*=//; p; }'`; do
		SREALM=${realm%%,*}; DREALM=${realm##*,}
		[ "$SREALM" = "$DREALM" ] && SREALM=""
		SREALM=${SREALM#\*}; DREALM=${DREALM#\*}
		tc filter add dev $DEVICE parent 1:0 protocol ip \
		prio $PRIO_REALM route ${SREALM:+from $SREALM} \
		${DREALM:+to $DREALM} classid 1:$CLASS
	done
	for rule in `echo "$CFILE"| sed -n '/^RULE/ { s/.*=//; p; }'`; do
		SRC=${rule%%,*}; DST=${rule##*,}
		[ "$SRC" = "$rule" ] && SRC=""
		DADDR=${DST%%:*}; DTEMP=${DST##*:}
		[ "$DADDR" = "$DST" ] && DTEMP=""

		DPORT=${DTEMP%%/*}; DMASK=${DTEMP##*/}
		[ "$DPORT" = "$DTEMP" ] && DMASK="0xffff"
		SADDR=""; SPORT=""
		if [ -n "$SRC" ]; then
			SADDR=${SRC%%:*}; STEMP=${SRC##*:}
			[ "$SADDR" = "$SRC" ] && STEMP=""

			SPORT=${STEMP%%/*}; SMASK=${STEMP##*/}
			[ "$SPORT" = "$STEMP" ] && SMASK="0xffff"
		fi
		SADDR=${SADDR#\*}; DADDR=${DADDR#\*}
		u32_s="${SPORT:+match ip sport $SPORT $SMASK}"
		u32_s="${SADDR:+match ip src $SADDR} $u32_s"
		u32_d="${DPORT:+match ip dport $DPORT $DMASK}"
		u32_d="${DADDR:+match ip dst $DADDR} $u32_d"
		tc filter add dev $DEVICE parent 1:0 protocol ip \
		prio $PRIO_RULE u32 $u32_s $u32_d classid 1:$CLASS
	done
	[ "$1" = "compile" ] && echo
done
;;
timecheck)
TIME_TMP=`date +%w/%k:%M`
TIME_DOW=${TIME_TMP%%/*}
TIME_NOW=${TIME_TMP##*/}
cbq_init $CBQ_PATH
for classfile in $CLASSLIST; do
	TIMESET=`sed -n 's/#.*//; s/[[:space:]]//g; /^TIME/ { s/.*=//; p; }' \
		$CBQ_PATH/$classfile`
	[ -z "$TIMESET" ] && continue
	MATCH=0; CHANGE=0
	for timerule in $TIMESET; do
		TIME_ABS=`cbq_time2abs $TIME_NOW`
		TIMESPEC=${timerule%%;*}; PARAMS=${timerule##*;}
		WEEKDAYS=${TIMESPEC%%/*}; INTERVAL=${TIMESPEC##*/}
		BEG_TIME=${INTERVAL%%-*}; END_TIME=${INTERVAL##*-}
		[ "$WEEKDAYS" != "$INTERVAL" -a \
		  -n "${WEEKDAYS##*$TIME_DOW*}" ] && continue
		BEG_ABS=`cbq_time2abs $BEG_TIME`
		END_ABS=`cbq_time2abs $END_TIME`
		if [ $BEG_ABS -gt $END_ABS ]; then
			[ $TIME_ABS -le $END_ABS ] &&
				TIME_ABS=$[TIME_ABS + 24*60]

			END_ABS=$[END_ABS + 24*60]
		fi
		if [ $TIME_ABS -ge $BEG_ABS -a $TIME_ABS -lt $END_ABS ]; then
			TMP_RATE=${PARAMS%%/*}; PARAMS=${PARAMS#*/}
			TMP_WGHT=${PARAMS%%/*}; TMP_PEAK=${PARAMS##*/}

			[ "$TMP_PEAK" = "$TMP_WGHT" ] && TMP_PEAK=""
			TMP_PEAK=${TMP_PEAK:+peakrate $TMP_PEAK}

			MATCH=1
		fi
	done
	cbq_load_class $CBQ_PATH $classfile
	RATE_NOW=`tc class show dev $DEVICE| sed -n \
		 "/cbq 1:$CLASS / { s/.*rate //; s/ .*//; p; q; }"`
	[ -z "$RATE_NOW" ] && continue
	if [ $MATCH -ne 0 ]; then
		if [ "$RATE_NOW" != "$TMP_RATE" ]; then
			NEW_RATE="$TMP_RATE"
			NEW_WGHT="$TMP_WGHT"
			NEW_PEAK="$TMP_PEAK"
			CHANGE=1
		fi
	elif [ "$RATE_NOW" != "$RATE" ]; then
		NEW_WGHT="$WEIGHT"
		NEW_RATE="$RATE"
		NEW_PEAK="$PEAK"
		CHANGE=1
	fi
	[ $CHANGE -eq 0 ] && continue
	tc class replace dev $DEVICE classid 1:$CLASS cbq \
	bandwidth $BANDWIDTH rate $NEW_RATE weight $NEW_WGHT prio $PRIO \
	allot 1514 cell 8 maxburst 20 avpkt 1000 $BOUNDED $ISOLATED
	if [ "$LEAF" = "tbf" ]; then
		tc qdisc replace dev $DEVICE handle $CLASS tbf \
		rate $NEW_RATE buffer $BUFFER limit $LIMIT mtu $MTU $NEW_PEAK
	fi
	cbq_message "$TIME_NOW: class $CLASS on $DEVICE changed rate ($RATE_NOW -> $NEW_RATE)"
done
;;
stop)
	cbq_off
	;;

list)
	cbq_show
	;;

stats)
	cbq_show -s
	;;

restart)
	shift
	$0 stop
	$0 start "$@"
	;;

*)
	echo "Usage: `basename $0` {start|compile|stop|restart|timecheck|list|stats}"
esac
