#!/bin/bash
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
# $1 Phone numbers
# $2 Text SMS
# $3 Number SMS
# user="$C_SMS_USER"
# password="$C_SMS_PASSWORD"
# sender="$C_SMS_SENDER"
# Your code here:
