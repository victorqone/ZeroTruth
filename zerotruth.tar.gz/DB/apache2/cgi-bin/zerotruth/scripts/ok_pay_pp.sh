#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details...
#************************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
UTENTE="aaaaa"
PP_URL=$(cat $C_ZT_CONF_DIR/conf_pp | grep PAYMENT | awk '{print $2}')
COD_PAY=$(cat $C_ZT_DIR/tmp/$UTENTE | grep P_RET | awk '{print $2}')

R_CURL=$(curl -v -k $PP_URL/$COD_PAY/execute/ \
-H 'Content-Type:application/json' \
-H 'Authorization:Bearer 602DZ8a3cAVCF8' \
-d '{ "payer_id":"XGULWK5F" }' )

STATE=$(echo "$R_CURL" | awk '{split ($0, a, "state\"\:\"");print a[2]}' | cut -d'"' -f1 )
DATACOM=$(echo "$R_CURL" | awk '{split ($0, a, "update_time\"\:\"");print a[2]}' | cut -d'"' -f1 )
DATAD=$(echo "$DATACOM" | cut -d'T' -f1)
DATAH=$(echo "$DATACOM" | cut -d'T' -f2 | cut -d'Z' -f1)
IDTRAN=$(echo "$R_CURL" | awk '{split ($0, a, "sale\/");print a[2]}' | cut -d'"' -f1 )
MONEY=$(echo "$R_CURL" | awk '{split ($0, a, "total\"\:\"");print a[2]}' | cut -d'"' -f1 )
 
$C_ZT_BIN_DIR/zt "Aggiungi" "P_STATE $STATE" "$C_ZT_DIR/tmp/$UTENTE"
$C_ZT_BIN_DIR/zt "Aggiungi" "P_DATAD $DATAD" "$C_ZT_DIR/tmp/$UTENTE"
$C_ZT_BIN_DIR/zt "Aggiungi" "P_DATAH $DATAH" "$C_ZT_DIR/tmp/$UTENTE"
$C_ZT_BIN_DIR/zt "Aggiungi" "P_IDTRAN $IDTRAN" "$C_ZT_DIR/tmp/$UTENTE"
$C_ZT_BIN_DIR/zt "Aggiungi" "P_MONEY $MONEY" "$C_ZT_DIR/tmp/$UTENTE"

exit







