#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:      GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

[ "$C_DISK_NOTIFY" != "on" ] && exit
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
if [ -n "$C_DISK_LIMIT" ];then
	AVAILABLE=$(df -h | grep "Database" | awk '{ print $4 }')
	DIS=$( echo "$AVAILABLE" | sed '/[A-Z]/s///g' )
	MILLE="000"
	[ $(echo "$AVAILABLE" | grep "G") ] && DIS=$(echo $DIS$MILLE | sed '/\./s///g')
	if [ "$DIS" -lt  "$C_DISK_LIMIT" ];then
		if [ "$C_DISK_SEND" == "SMS" ];then
			$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$C_HOTSPOT_NAME - $L_DISK_FULL - $L_AVAILABLE $AVAILABLE"
		else
			$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME" "$L_DISK_FULL - $L_AVAILABLE $AVAILABLE" "$C_ADMIN_EMAIL"
		fi
		sed -i "s/^C_DISK_NOTIFY=.*/C_DISK_NOTIFY=\"\"/g" $C_ZT_CONF_DIR/zt.config
		if [ "$C_DISK_DELETE_CACHE" == "on" ];then
			if [ -f $C_ZT_LOG_DIR/logs/squid.pid ];then
				$C_ZT_BIN_DIR/squid -k shutdown 2>/dev/null > /dev/null
				rm -rf  $C_ZT_LOG_DIR/cache/* 2>/dev/null > /dev/null
				if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
					$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
				fi
			else
				rm -rf  $C_ZT_LOG_DIR/cache/* 2>/dev/null > /dev/null
				$C_ZT_BIN_DIR/squid -z  2>/dev/null > /dev/null
			fi
		fi
		if [ "$C_DISK_DELETE_ZS_LOG" == "on" ];then
			rm -rf  /Database/LOG/
		fi
	fi
fi


