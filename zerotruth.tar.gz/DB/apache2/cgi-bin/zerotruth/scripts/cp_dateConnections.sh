#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

[ -z "$1" ] && exit
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
USERNAME="$1"
NOW="$(date +%s)"
if [ -z "$( cat $C_ACCT_DIR/entries/$USERNAME/FirstConnection 2>/dev/null)" ];then
	echo "$NOW" > $C_ACCT_DIR/entries/$USERNAME/FirstConnection
	echo "$(date +%Y-%m-%d)" > $C_ACCT_DIR/entries/$USERNAME/DateFirstConnection
fi
echo "$((($NOW - $(cat $C_ACCT_DIR/entries/$USERNAME/FirstConnection))/60/60/24))" > $C_ACCT_DIR/entries/$USERNAME/DaysConnection
echo "$(( $(cat $C_ACCT_DIR/entries/$USERNAME/DaysConnection)/7))" > $C_ACCT_DIR/entries/$USERNAME/DaysConnection
if [ -z "$(cat $C_ACCT_DIR/entries/$USERNAME/MonthConnection 2>/dev/null)" ];then
	echo "0" > $C_ACCT_DIR/entries/$USERNAME/MonthConnection
fi
for M in $(seq $(cat $C_ACCT_DIR/entries/$USERNAME/MonthConnection) $(($(cat $C_ACCT_DIR/entries/$USERNAME/MonthConnection)+24)));do
	FM="$(date -d "$(cat $C_ACCT_DIR/entries/$USERNAME/DateFirstConnection) $M month" +%s)"
	NM=$(($M+1))
	FNM="$(date -d "$(cat $C_ACCT_DIR/entries/$USERNAME/DateFirstConnection) $NM month" +%s)"
	if [[ "$NOW" -gt $FM && "$NOW" -lt $FNM ]];then
		echo "$M" > $C_ACCT_DIR/entries/$USERNAME/MonthConnection
		break
	fi
done
if [ -z "$(cat $C_ACCT_DIR/entries/$USERNAME/YearsConnection 2>/dev/null)" ];then
	echo "0" > $C_ACCT_DIR/entries/$USERNAME/YearsConnection
fi
for Y in $(seq $(cat $C_ACCT_DIR/entries/$USERNAME/YearsConnection) $(($(cat $C_ACCT_DIR/entries/$USERNAME/YearsConnection)+2)));do
	FY="$(date -d "$(cat $C_ACCT_DIR/entries/$USERNAME/DateFirstConnection) $Y year" +%s)"
	NY=$(($Y+1))
	FNY="$(date -d "$(cat $C_ACCT_DIR/entries/$USERNAME/DateFirstConnection) $NY year" +%s)"
	if [[ "$NOW" -gt $FY && "$NOW" -lt $FNY ]];then
		echo "$Y" > $C_ACCT_DIR/entries/$USERNAME/YearsConnection
		break
	fi
done

exit




