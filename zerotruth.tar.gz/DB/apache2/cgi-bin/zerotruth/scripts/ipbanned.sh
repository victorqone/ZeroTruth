#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:      GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

if [ -n "$C_IPBLOCKED" ];then
	NUM_BAN=$(cat $C_ZT_CONF_DIR/ipbanned | wc -l | awk '{print $1}')
	if [ "$NUM_BAN" -gt "0" ];then
		for N in $(seq 1 $NUM_BAN);do
			RIGA="$(cat $C_ZT_CONF_DIR/ipbanned | sed -n "${N}p")"
			IP="$(echo "$RIGA" |  grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')"
			iptables -D INPUT -s $IP/32 -j DROP 2>/dev/null
			iptables -I INPUT 1 -s $IP/32 -j DROP
		done
	fi
fi
exit
