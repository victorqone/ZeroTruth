#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh

if [ "$1" == "SaveClass" ]; then
	if [ ! -d $C_CLASSES_DIR/$2 ];then
		mkdir $C_CLASSES_DIR/$2
	fi
	echo "$3" > $C_CLASSES_DIR/$2/CostM
	echo "$4" > $C_CLASSES_DIR/$2/CostH
	echo "$5" > $C_CLASSES_DIR/$2/MB
	echo "$6" > $C_CLASSES_DIR/$2/Hours
	echo "$7" > $C_CLASSES_DIR/$2/Mbits
	echo "$8" > $C_CLASSES_DIR/$2/MbitsUp
	echo "$9" > $C_CLASSES_DIR/$2/ChargeType
	echo "${10}" > $C_CLASSES_DIR/$2/NumClass
	echo "${11}" > $C_CLASSES_DIR/$2/FreeTime
	echo "${12}" > $C_CLASSES_DIR/$2/InterfacesClass
	echo "${13}" > $C_CLASSES_DIR/$2/ShaperType
	echo "${14}" > $C_CLASSES_DIR/$2/Days
	echo "${15}" > $C_CLASSES_DIR/$2/Range1
	echo "${16}" > $C_CLASSES_DIR/$2/Range2
	echo "${17}" > $C_CLASSES_DIR/$2/HoursDay
	echo "${18}" > $C_CLASSES_DIR/$2/HoursMonth
	echo "${19}" > $C_CLASSES_DIR/$2/MBDay
	echo "$(echo ${20} | cut -d'-' -f1)" > $C_CLASSES_DIR/$2/MBMonth
	if [ -n "$C_SIM_CONN_CLASSES" ];then
		CONSIM=$(echo ${20} | cut -d'-' -f2)
		if [ -n "$CONSIM" ];then
			CONSIM="yes"
		else
			CONSIM="no"
		fi
		echo "$CONSIM" > $C_CLASSES_DIR/$2/Simultaneous
	fi
	BLOCKED=$(echo ${20} | cut -d'-' -f3)
	if [ -n "$BLOCKED" ];then
		BLOCKED="yes"
	else
		BLOCKED="no"
	fi
	echo "$BLOCKED" > $C_CLASSES_DIR/$2/Blocked
	if [ -n "${14}" ];then
		DAYS="$( echo ${14} | sed 's/\+/ /g' | sed 's/^[ \t]*//' | sed  's/[ \t]*$//' | sed 's/ /,/g')"
		CC="yes"
	fi
	if [ -n "${15}" ];then
		LIMIT_RANGE1="${15}"
		HOUR_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f2 | cut -d'-' -f1 | $C_ZT_BIN_DIR/bc)"
		HOUR_STOP="$(echo "$LIMIT_RANGE1" | cut -d'-' -f2 | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_STOP="$(echo "$LIMIT_RANGE1" | cut -d':' -f3 | $C_ZT_BIN_DIR/bc)"
		CC="yes"
	fi
	if [[ -n "${14}" && -z "${15}" ]];then
		HOUR_START=0
		MINUTES_START=0
		HOUR_STOP=23
		MINUTES_STOP=59
		CC="yes"
	fi
	if [ -n "$CC" ];then
		$C_ZT_BIN_DIR/zt "ClassCron" "$2" "$DAYS" "$HOUR_START" "$MINUTES_START" "$HOUR_STOP" "$MINUTES_STOP"
	fi
	if [ -n "${16}" ];then
		LIMIT_RANGE2="${16}"
		HOUR_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f2 | cut -d'-' -f1 | $C_ZT_BIN_DIR/bc)"
		HOUR_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d'-' -f2 | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f3 | $C_ZT_BIN_DIR/bc)"
		$C_ZT_BIN_DIR/zt "ClassCron" "$2" "$DAYS" "$HOUR_START_SEC" "$MINUTES_START_SEC" "$HOUR_STOP_SEC" "$MINUTES_STOP_SEC" "SEC"
	fi
	exit
fi

if [ "$1" == "UpdateClass" ]; then
	CLASS="$2"
	echo "$3" > $C_CLASSES_DIR/$CLASS/CostM
	echo "$4" > $C_CLASSES_DIR/$CLASS/CostH
	echo "$5" > $C_CLASSES_DIR/$CLASS/MB
	echo "$6" > $C_CLASSES_DIR/$CLASS/Hours
	echo "$7" > $C_CLASSES_DIR/$CLASS/Mbits
	echo "$8" > $C_CLASSES_DIR/$CLASS/MbitsUp
	echo "$9" > $C_CLASSES_DIR/$CLASS/ChargeType
	echo "${10}" > $C_CLASSES_DIR/$CLASS/NumClass
	echo "${11}" > $C_CLASSES_DIR/$CLASS/FreeTime
	echo "${12}" > $C_CLASSES_DIR/$CLASS/InterfacesClass
	echo "${13}" > $C_CLASSES_DIR/$CLASS/ShaperType
	echo "${14}" > $C_CLASSES_DIR/$CLASS/Days
	echo "${15}" > $C_CLASSES_DIR/$CLASS/Range1
	echo "${16}" > $C_CLASSES_DIR/$CLASS/Range2
	echo "${17}" > $C_CLASSES_DIR/$CLASS/HoursDay
	echo "${18}" > $C_CLASSES_DIR/$CLASS/HoursMonth
	echo "${19}" > $C_CLASSES_DIR/$CLASS/MBDay
	echo "$(echo ${20} | cut -d'-' -f1)" > $C_CLASSES_DIR/$2/MBMonth
	if [ -n "$C_SIM_CONN_CLASSES" ];then
		CONSIM=$(echo ${20} | cut -d'-' -f2)
		if [ -n "$CONSIM" ];then
			CONSIM="yes"
		else
			CONSIM="no"
		fi
		echo "$CONSIM" > $C_CLASSES_DIR/$CLASS/Simultaneous
	fi
	BLOCKED=$(echo ${20} | cut -d'-' -f3)
	if [ -n "$BLOCKED" ];then
		BLOCKED="yes"
	else
		BLOCKED="no"
	fi
	echo "$BLOCKED" > $C_CLASSES_DIR/$CLASS/Blocked
	USERSCLASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=RADIUS,$C_LDAPBASE" radiusUserCategory=$CLASS cn | grep -e '^cn: ' | sed 's/^cn: //g')
	for USERNAME in $USERSCLASS;do
		LCODE=""
		if [ -d $C_ACCT_DIR/entries/$USERNAME ];then
			if [ -f $C_ACCT_DIR/entries/$USERNAME/MB ] && [ -n "$(cat $C_ACCT_DIR/classes/$CLASS/MB)" ];then
				TRAFFIC="$(cat $C_ACCT_DIR/entries/$USERNAME/MB)"
				LIMITMB="$(cat $C_ACCT_DIR/classes/$CLASS/MB)"
				LIMITMB=$((LIMITMB*1048576))
				if [ $TRAFFIC -gt $LIMITMB ];then
					LCODE="M"
				fi
			fi
			if [ -f $C_ACCT_DIR/entries/$USERNAME/Time ] && [ -n "$(cat $C_ACCT_DIR/classes/$CLASS/Hours)" ];then
				TIME="$(cat $C_ACCT_DIR/entries/$USERNAME/Time)"
				LIMITH="$(cat $C_ACCT_DIR/classes/$CLASS/Hours)"
				LIMITH=$(($LIMITH*3600))
				if [ $TIME -gt $LIMITH ];then
					LCODE="T"
				fi
			fi
			if [ -f $C_ACCT_DIR/credits/$USERNAME/Credit ];then
				CREDIT="$(cat $C_ACCT_DIR/credits/$USERNAME/Credit)"
				[ "$CREDIT" != "freetime" ] && CREDIT=$(echo "$CREDIT"  | awk '{printf("%.2f\n", $0)}')
				CHARGETYPE="$(cat $C_ACCT_DIR/classes/$CLASS/ChargeType)"
				FREETIME="$(cat $C_ACCT_DIR/classes/$CLASS/FreeTime)"
				if [[  -z "$CREDIT" || "$CREDIT" == "0.00" || $(echo "$CREDIT" | grep '^-') ]] && [[ "$CHARGETYPE" == "pre" && "$CREDIT" != "freetime" ]];then
					LCODE="C"
				fi
			fi
		fi
		if [ -n "$LCODE" ];then
			$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "$LCODE"
			CONNECTED=$(ls $C_CP_DIR/Connected )
			for IP in "$CONNECTED";do
				if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERNAME" ];then
					$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERNAME"
				fi
			done
		else
			$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "yes" ""
		fi
		$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	done
	if [ -n "${14}" ];then
		DAYS="$( echo ${14} | sed 's/\+/ /g' | sed 's/\+/ /g' | sed 's/^[ \t]*//' | sed  's/[ \t]*$//' | sed 's/ /,/g')"
		CC="yes"
	fi
	if [ -n "${15}" ];then
		LIMIT_RANGE1="${15}"
		HOUR_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_START="$(echo "$LIMIT_RANGE1" | cut -d':' -f2 | cut -d'-' -f1 | $C_ZT_BIN_DIR/bc)"
		HOUR_STOP="$(echo "$LIMIT_RANGE1" | cut -d'-' -f2 | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_STOP="$(echo "$LIMIT_RANGE1" | cut -d':' -f3 | $C_ZT_BIN_DIR/bc)"
		CC="yes"
	fi
	if [[ -n "${14}" && -z "${15}" ]];then
		HOUR_START=0
		MINUTES_START=0
		HOUR_STOP=23
		MINUTES_STOP=59
		CC="yes"
	fi
	if [ -n "$CC" ];then
		$C_ZT_BIN_DIR/zt "ClassCron" "$2" "$DAYS" "$HOUR_START" "$MINUTES_START" "$HOUR_STOP" "$MINUTES_STOP"
	else
		CLASS="$2"
		if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}START-Cron ];then
			rm -rf  $C_CRON_SCRIPTS_DIR/ZT${CLASS}START-Cron
			CONTROLDEL="yes"
		fi
		if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP-Cron ];then
			rm -rf  $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP-Cron
			CONTROLDEL="yes"
		fi
	fi
	if [ -n "${16}" ];then
		LIMIT_RANGE2="${16}"
		HOUR_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_START_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f2 | cut -d'-' -f1 | $C_ZT_BIN_DIR/bc)"
		HOUR_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d'-' -f2 | cut -d':' -f1 | $C_ZT_BIN_DIR/bc)"
		MINUTES_STOP_SEC="$(echo "$LIMIT_RANGE2" | cut -d':' -f3 | $C_ZT_BIN_DIR/bc)"
		$C_ZT_BIN_DIR/zt "ClassCron" "$2" "$DAYS" "$HOUR_START_SEC" "$MINUTES_START_SEC" "$HOUR_STOP_SEC" "$MINUTES_STOP_SEC" "SEC"
	else
		CLASS="$2"
		if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}STARTSEC-Cron ];then
			rm -rf  $C_CRON_SCRIPTS_DIR/ZT${CLASS}STARTSEC-Cron
			CONTROLDEL="yes"
		fi
		if [ -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOPSEC-Cron ];then
			rm -rf  $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOPSEC-Cron
			CONTROLDEL="yes"
		fi
	fi
	if [ -n "$CONTROLDEL" ];then
		$C_ZT_BIN_DIR/zt  "KillProg" "cron"
		rm -f /var/run/cron.pid
		/etc/init.d/crond start > /dev/null
	fi
	exit
fi

if [ "$1" == "Start" ];then
	CLASS="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" radiusUserCategory=$CLASS cn )
	USERS=$(echo "$QUERY" | sed -n '/cn:/p' | awk '{print $2}')
	for USER in $USERS;do
		WAIT_AS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE" uid=$USER gecos | grep '^gecos' | awk '{print $2}')
		if [ "$WAIT_AS" != "wait_asterisk" ];then
			PASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn | grep '^sn' | awk '{print $NF}')
			CONTROL_LOCK=$(echo "$PASS" | cut -sd'-' -f2)
			CONTROL_LOCKORE=$(echo "$CONTROL_LOCK" | grep "LOCKORE")
			if [ -n "$CONTROL_LOCK" ] && [ -z "$CONTROL_LOCKORE" ];then
				PASS_FREE=$(echo "$PASS" | cut -d'-' -f1)
				DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS_FREE"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT >/dev/null
			fi
			/usr/bin/logger -t ZT.system "UnBlocked $USER - Cron"
		fi
	done
fi

if [ "$1" == "Stop" ];then
	CLASS="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" radiusUserCategory=$CLASS cn )
	USERS=$(echo "$QUERY" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USER in $USERS;do
		WAIT_AS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE" uid=$USER gecos | grep '^gecos' | awk '{print $NF}')
		if [ "$WAIT_AS" != "wait_asterisk" ];then
			for IP in $(ls $C_CP_DIR/Connected );do
				if [ $(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1 ) == "$USER" ];then
					$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USER"
				fi
			done
			PASS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn | grep '^sn' | awk '{print $NF}')
			CONTROL_LOCK=$(echo "$PASS" | cut -sd'-' -f2)
			if [ -z "$CONTROL_LOCK" ] ;then
				PASS_LOCK="$PASS-$RANDOM"
				DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS_LOCK"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT >/dev/null
			fi
			/usr/bin/logger -t ZT.system "Blocked $USER - Cron"
		fi
	done
fi

if [ "$1" == "StartPopup" ];then
	$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/PopupActive"
fi

if [ "$1" == "StopPopup" ];then
	$C_ZT_BIN_DIR/zt "Salva" "no" "$C_CP_DIR/Auth/Custom/PopupActive"
fi

if [ "$1" == "CronAD" ]; then
	rm -rf $C_CRON_SCRIPTS_DIR/ZTcronad-Cron 2>/dev/null > /dev/null
	if [ -n "$2" ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTcronad-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron
		echo "Cron ZTcronad" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/Description
		echo "yes" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/Enabled
		echo "$C_ZT_SCRIPTS_DIR/blockhosts.sh" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/File
		chmod 755 $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/File
		if [ "$2" == "1" ];then
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoW
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoM
		fi
		if [ "$2" == "2" ];then
			echo "1" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoW
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoM
		fi
		if [ "$2" == "3" ];then
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoW
			echo "1" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/DoM
		fi
		echo "0" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/Hour
		echo "10" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/Minute
		echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/Month
		echo "" > $C_CRON_SCRIPTS_DIR/ZTcronad-Cron/cron/Step
		chown -R root:root $C_CRON_SCRIPTS_DIR/ZTcronad-Cron
	else
		if [ -n "$(cat /etc/hosts | grep 'END BLOCKED HOSTS')" ];then
			cat /etc/hosts | sed  -n "/END BLOCKED HOSTS/,//p"  > /tmp/blockhosts
			sed -i "/END BLOCKED HOSTS/d" /tmp/blockhosts
			mv -f /tmp/blockhosts /etc/hosts
			sed -i "s/^C_UPDATES_AD.*/C_UPDATES_AD=\"\"/g" $C_ZT_CONF_DIR/zt.config
		fi
	fi
fi

if [ "$1" == "CronBk" ]; then
	rm -r -f $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron 2>/dev/null > /dev/null
	if [ -n "$2" ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron
		echo "Cron ZTcronbk" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/Description
		echo "yes" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/Enabled
		echo "$C_ZT_SCRIPTS_DIR/startbk.sh" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/File
		chmod 755 $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/File
		if [ "$2" == "1" ];then
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoW
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoM
		fi
		if [ "$2" == "2" ];then
			echo "1" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoW
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoM
		fi
		if [ "$2" == "3" ];then
			echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoW
			echo "1" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/DoM
		fi
		echo "0" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/Hour
		echo "1" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/Minute
		echo "*" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/Month
		echo "" > $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron/cron/Step
		chown -R root:root $C_CRON_SCRIPTS_DIR/ZTcronbk-Cron
	fi
fi

if [ "$1" == "CronSyncRemote" ]; then
	rm -r -f $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron 2>/dev/null > /dev/null
	if [ -n "$3" ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron
		echo "Cron ZTSyncRemote$2" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/Description
		echo "yes" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/Enabled
		echo "$C_ZT_SCRIPTS_DIR/SyncRemote.sh $2" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/File
		chmod 755 $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/File
		echo "*" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/DoW
		echo "*" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/DoM
		echo "$3" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/Hour
		echo "$4" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/Minute
		echo "*" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/Month
		echo "" > $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron/cron/Step
		chown -R root:root $C_CRON_SCRIPTS_DIR/ZTSyncRemote$2-Cron
	fi
fi

if [ "$1" == "BkNow" ]; then
	$C_ZT_SCRIPTS_DIR/startbk.sh  "now" 2>/dev/null > /dev/null
fi

if [ "$1" == "BkDownload" ]; then
	$C_ZT_SCRIPTS_DIR/startbknow.sh "$2" 2>/dev/null > /dev/null
fi

if [ "$1" == "DownloadSessions" ]; then
	$C_ZT_SCRIPTS_DIR/downloadsessions.sh  2>/dev/null > /dev/null
fi

if [ "$1" == "ClassCron" ]; then
	CLASS="$2"
	SEC="$8"
	if [ ! -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron
	fi
	DOW="$3"
	[ -z "$DOW" ] && DOW="*"
	HSTART="$4"
	[ -z "$HSTART" ] && HSTART="*"
	MSTART="$5"
	[ -z "$MSTART" ] && MSTART="*"
	HSTOP="$6"
	[ -z "$HSTOP" ] && HSTOP="*"
	MSTOP="$7"
	[ -z "$MSTOP" ] && MSTOP="*"
	echo "Cron ZT${CLASS}START$SEC" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt Start $CLASS" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/File
	echo "$DOW" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/DoM
	echo "$HSTART" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/Hour
	echo "$MSTART" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron/cron/Step
	if [ ! -d $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron
	fi
	echo "Cron ZT${CLASS}STOP$SEC" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt Stop $CLASS" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/File
	echo "$DOW" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/DoM
	echo "$HSTOP" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/Hour
	echo "$MSTOP" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron/cron/Step
	chown -R root:root $C_CRON_SCRIPTS_DIR/ZT${CLASS}START$SEC-Cron
	chown -R root:root $C_CRON_SCRIPTS_DIR/ZT${CLASS}STOP$SEC-Cron
	$C_ZT_BIN_DIR/zt  "KillProg" "cron"
	rm -f /var/run/cron.pid
	/etc/init.d/crond start > /dev/nulll
fi

if [ "$1" == "AggiornaCronPopup" ]; then
	if [ ! -d $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron
	fi
	DOW="$3"
	[ "$3" == "ALL" ] && DOW="*"
	echo "Cron ZTPOPUPSTART" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt StartPopup $2" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/File
	echo "$DOW" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/DoM
	echo "$4" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Hour
	echo "$5" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron/cron/Step
	if [ ! -d $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron
	fi
	echo "Cron ZTPOPUPSTOP" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt StopPopup $2" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/File
	echo "$DOW" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/DoM
	echo "$6" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Hour
	echo "$7" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron/cron/Step
	chown -R root:root $C_CRON_SCRIPTS_DIR/ZTPOPUPSTART-Cron
	chown -R root:root $C_CRON_SCRIPTS_DIR/ZTPOPUPSTOP-Cron
fi

if [ "$1" == "RestartCron" ];then
	rm -f $C_CRON_TEMP_DIR
	echo "15 * * * * /root/kerbynet.cgi/scripts/cleantmp" >> $C_CRON_TEMP_DIR
	for C in $( ls $C_CRON_SCRIPTS_DIR );do
		if [ $( echo $C | grep Cron) ];then
			ENABLED=$( cat $C_CRON_SCRIPTS_DIR/$C/Enabled )
			if [ "$ENABLED" = "yes" ];then
				STEP="`cat $C_CRON_SCRIPTS_DIR/$C/cron/Step 2>/dev/null`"
				if [ -z "$STEP" ] ; then
					MINUTE=$( cat $C_CRON_SCRIPTS_DIR/$C/cron/Minute )
					HOUR=$( cat $C_CRON_SCRIPTS_DIR/$C/cron/Hour)
					DOM=$( cat $C_CRON_SCRIPTS_DIR/$C/cron/DoM)
					MONTH=$( cat $C_CRON_SCRIPTS_DIR/$C/cron/Month)
					DOW=$( cat $C_CRON_SCRIPTS_DIR/$C/cron/DoW)
					echo "$MINUTE $HOUR $DOM $MONTH $DOW $C_ZS_CRON_SCRIPT $C" >> $C_CRON_TEMP_DIR
				else
					UNIT=`echo $STEP | awk '{print $2}'`
					STEP=`echo $STEP | awk '{print $1}'`
					if [ "$UNIT" = m ] ; then
						echo "0-59/$STEP * * * * $C_ZS_SCRIPTS_DIR/runscript $C" >> $C_CRON_TEMP_DIR
					else
						if [ "$UNIT" = h ] ; then
							echo "0 0-23/$STEP * * * $C_ZS_SCRIPTS_DIR/runscript $C" >> $C_CRON_TEMP_DIR
						else
							echo "5 0 * * 0-6/$STEP $C_ZS_SCRIPTS_DIR/runscript $C" >> $C_CRON_TEMP_DIR
						fi
					fi
				fi
			fi
		fi
	done
	`chown root:root $C_CRON_TEMP_DIR`
	`chmod 666 $C_CRON_TEMP_DIR`
	`cat $C_CRON_TEMP_DIR > /var/cron/tabs/root`
	`crontab -u root /var/cron/tabs/root`
	`/root/kerbynet.cgi/scripts/terminate cron`
	`rm -f /var/run/cron.pid`
	cron
	rm -f $C_CRON_TEMP_DIR
fi

if [ "$1" == "SLink" ];then
	ln -f -s "$2"  "$3"
	chown root:root $3
	chmod 755 $3
fi

if [ "$1" == "Salva" ];then
	echo "$2" > /tmp/zttemp
	tr -d '\015' < /tmp/zttemp > "$3"
	chown root:root $3
	chmod 755 $3
fi

if [ "$1" == "Cancella" ];then
	rm -rf $2 2>/dev/null
fi

if [ "$1" == "TmpSlap" ];then
	/usr/local/sbin/slapcat -b "$C_LDAPBASE" > /tmp/ldap_ldif
	echo "$(du -h /tmp/ldap_ldif | awk '{print $1}')"
	rm -f /tmp/ldap_ldif
fi

if [ "$1" == "CreaCartella" ];then
	mkdir $2
	chown root:root $2
	chmod 755 $2
fi

if [ "$1" == "Email" ];then
	echo "$3" > /tmp/emailtext.html
	lynx -dump /tmp/emailtext.html > /tmp/emailtextsend
	TEXT=$(echo $(cat /tmp/emailtextsend))
	echo -e "$TEXT" | $C_ZT_BIN_DIR/mutt -e "set realname=\"$C_HOTSPOT_NAME\"" -F $C_ZT_CONF_DIR/Muttrc -s "$2" "$4" 2>/tmp/erroremail >/dev/null
	rm -rf /tmp/emailtext.html
	rm -rf /tmp/emailtextsend
fi

if [ "$1" == "CloseConnectPP" ];then
	IP="$2"
	MAC="$3"
	FILTER="-s $IP -m mac --mac-source $MAC"
	echo "$FILTER" > /DB/filter
	/usr/local/sbin/iptables -D CapPortWL $FILTER -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapPortOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyIn -s $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTPS $FILTER -j ACCEPT 2>/dev/null
	exit
fi

if [ "$1" == "KillCP" ];then
	kill -9 $(cat $C_ZT_DIR/tmp/CcpPid_$2)
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/CcpPid_$2"
	exit
fi

if [ "$1" == "ConnectPP" ];then
	IP="$2"
	MAC="$3"
	CONTROL="$4"
	if [[ -z "$(cat $C_ZT_CONF_DIR/banmac | grep $MAC)" && "$CONTROL" == yes ]];then
		$C_ZT_BIN_DIR/zt "Aggiungi" "$MAC" "$C_ZT_CONF_DIR/tmp_banmac"
	fi
	if [ $(cat $C_ZT_CONF_DIR/tmp_banmac | grep -n $MAC | wc -l | awk '{print $1}') -gt $C_TIMES_PP ];then
		$C_ZT_BIN_DIR/zt "Aggiungi" "$MAC" "$C_ZT_CONF_DIR/banmac"
		$C_ZT_BIN_DIR/zt "RimuoviRiga" "$MAC" "$C_ZT_CONF_DIR/tmp_banmac"
	fi
	[ -n "$(cat $C_ZT_CONF_DIR/banmac | grep $MAC)" ] && CONTROL="no"
	[[ -z "$IP" || -z "$MAC" ]] && exit
	FILTER="-s $IP -m mac --mac-source $MAC"
	/usr/local/sbin/iptables -D CapPortWL $FILTER -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapPortOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyIn -s $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTPS $FILTER -j ACCEPT 2>/dev/null
	if [ "$CONTROL" == yes ];then
		/usr/local/sbin/iptables -I CapPortWL 1 $FILTER -j ACCEPT
		/usr/local/sbin/iptables -I CapPortOut 1 -d $IP -j ACCEPT
		/usr/local/sbin/iptables -I CapProxyIn 1 -s $IP -j ACCEPT
		/usr/local/sbin/iptables -I CapProxyOut 1 -d $IP -j ACCEPT
		/usr/local/sbin/iptables -t nat -I CapPortHTTPS 1 $FILTER -j ACCEPT
		$C_ZT_SCRIPTS_DIR/controlconnectpp.sh $IP $MAC &
	fi
	exit
fi

if [ "$1" == "DisconnettiClass" ];then
	CLASS="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" radiusUserCategory=$CLASS cn)
	USERS=$(echo "$QUERY" | grep -e '^cn: ' | sed 's/^cn: //g')
	for USER in $USERS;do
		$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USER"
	done
fi

if [ "$1" == "DisconnettiUsername" ];then
	USERNAME="$2"
	[ -z "$USERNAME" ] && exit
	if [ -n "$(ls $C_CP_DIR/Connected/)" ];then
		CONNECTED=$(ls $C_CP_DIR/Connected )
		for IP in "$CONNECTED";do
			if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERNAME" ];then
				$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERNAME"
			fi
		done
	fi
	if [ -n "$C_CP_LOCAL_TYPE" ];then
		LR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote:' | awk '{print $2}')
		if [ "$LR" != "?" ];then
			IPREMOTE="$(echo "$LR" | cut -d'-' -f2)"
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IPREMOTE" "$USERNAME"
		fi
	fi
fi

if [ "$1" == "Disconnetti" ];then
	IP="$2"
	USERNAME="$3"
	[ -z "$IP" ] && exit 1
	if [ -z "$USERNAME" ];then
		USERNAME="$(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1)"
	fi
	if [[ -n "$C_CP_REMOTE" && -z "$C_CP_LOCAL_AUTO" && "$3" != "NOREMOTE" ]];then
		$C_ZT_BIN_DIR/zt "LoginRemote" "no" "$IP" "$USERNAME"
	fi
	ACCT="`cat $C_SYSTEM/acct/Enabled 2>/dev/null`"
	cd $C_SYSTEM/cp/Connected || exit 2
	USER=`cat $IP/User 2>/dev/null`
	MAC=`cat $IP/MAC 2>/dev/null`
	# [ -z "$MAC" ] && MAC=$(arp -a | grep $IP | awk '{split ($0, a, " ");print a['4']}')
	# MAC=$(echo "$MAC" | sed 's/\(.*\)/\U\1/')
	[ "$IP" != "" ] && FILTER="-s $IP"
	[ "$MAC" != "" ] && FILTER="$FILTER -m mac --mac-source $MAC"
	/usr/local/sbin/iptables -D CapPortWL $FILTER -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapPortOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyIn -s $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapProxyOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -D CapPortOut -d $IP -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTP $FILTER -j CapPortProxy 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTPS $FILTER -j ACCEPT 2>/dev/null
	mkdir -p "$C_SYSTEM/cp/Disconnected/$IP"
	$C_ZS_SCRIPTS_DIR/cp_getaccounting "$USER" "" "$IP" noupdates > "$C_SYSTEM/cp/Disconnected/$IP/Accounting"
	echo "$LCODE" > "$C_SYSTEM/cp/Disconnected/$IP/LCode"
	RXP=`$C_ZS_SCRIPTS_DIR/cp_getRXTX "$IP"|cut -d ' ' -f 1`
	RX=`$C_ZS_SCRIPTS_DIR/cp_getRXTX "$IP"|cut -d ' ' -f 2`
	TXP=`$C_ZS_SCRIPTS_DIR/cp_getRXTX "$IP"|cut -d ' ' -f 3`
	TX=`$C_ZS_SCRIPTS_DIR/cp_getRXTX "$IP"|cut -d ' ' -f 4`
	UUID=`cat $IP/UUID 2>/dev/null`
	NOW=`date +%s`
	STARTED=`cat $IP/Started 2>/dev/null`
	UPDATED=`cat $IP/Updated 2>/dev/null`
	TIMEOUT=`cat $C_SYSTEM/cp/Timeout 2>/dev/null`
	TIMEOUT=$((TIMEOUT*60))
	if [ "$((NOW-UPDATED))" -gt "$TIMEOUT" ] ; then
		NOW=$((UPDATED+TIMEOUT))
	fi
	TIME=$((NOW-STARTED-1))
	[ "$ACCT" = yes ] && $C_ZS_SCRIPTS_DIR/acct_enqueue_stop "$UUID" "$USER" "$MAC" "$TX" "$RX" "$TXP" "$RXP" "$TIME" "NAS-Request"
	rm -rf "$IP"
	logger -t "CaptivePortal" "GW: Success: user $USER (IP: $IP MAC: $MAC) disconnected"
	$C_ZT_BIN_DIR/zt "DelShaperUser" "$IP"
	DATA="dn: uid=$USERNAME,ou=PEOPLE,$C_LDAPBASE\nconnected: no"
	echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
fi

if [ "$1" == "Aggiungi" ];then
	echo "$2" >> $3
	chown root:root $3
	chmod 755 $3
fi

if [ "$1" == "StopUser" ];then
	$C_ZT_BIN_DIR/zt stop $2
fi

if [ "$1" == "SalvaConfig" ];then
	VAL=$(echo "$3" | sed '/\&/s//\\\&/g' | sed '/\//s//\//g')
	if [ -z "$(cat $C_ZT_CONF_DIR/zt.config | grep "^$2=" 2>/dev/null)" ];then
		$C_ZT_BIN_DIR/zt "Aggiungi" "# ADDED" "$C_ZT_CONF_DIR/zt.config"
		$C_ZT_BIN_DIR/zt "Aggiungi" "$2=\"\"" "$C_ZT_CONF_DIR/zt.config"
	fi
	sed -i "s/^$2=.*/$2=\"$VAL\"/g" $C_ZT_CONF_DIR/zt.config
	chown root:root $C_ZT_CONF_DIR/zt.config
	chmod 755 $C_ZT_CONF_DIR/zt.config
fi

if [ "$1" == "AddMuttrc" ];then
	sed -i "s/^set from=.*/set from=\"$2\"/g" $C_ZT_CONF_DIR/Muttrc
	chown root:root $C_ZT_CONF_DIR/Muttrc
	chmod 755 $C_ZT_CONF_DIR/zt.config
fi

if [ "$1" == "CambiaRiga" ];then
	sed -i "s/$2.*/$3/g" $4
	chown root:root $4
	chmod 755 $4
fi

if [ "$1" == "ConfGammu" ];then
	sed -i "s/^port.*/port = $2/g" $C_ZT_CONF_DIR/gammu.conf
	sed -i "s/^connection.*/connection = $3/g" $C_ZT_CONF_DIR/gammu.conf
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SEND_SMS_GAMMU" "$4"
	sed -i "s/%2F/\//g" $C_ZT_CONF_DIR/gammu.conf
	chown root:root $C_ZT_CONF_DIR/gammu.conf
	chmod 666 $C_ZT_CONF_DIR/gammu.conf
	if [ -n "$(ps -A | grep 'gammu')" ];then
		PIDGAMMU="$(ps -A | grep 'gammu' | awk '{print $1}')"
		kill -9 $PIDGAMMU 2>/dev/null
		kill -9 $PIDGAMMU 2>/dev/null
		kill -9 $PIDGAMMU 2>/dev/null
	fi
	if [ -n "$5" ];then
		$C_ZT_BIN_DIR/gammu-smsd -c $C_ZT_CONF_DIR/gammu.conf --pid=/var/run/gammu &
	fi
fi

if [ "$1" == "StartGammu" ];then
	$C_ZT_BIN_DIR/gammu-smsd -c $C_ZT_CONF_DIR/gammu.conf --pid=/var/run/gammu &
fi

if [ "$1" == "ControlGammu" ];then
	sleep 10
	NAMEHOST="$(echo $HOSTNAME | cut -d'.' -f1)"
	LASTRUN=$(cat /Database/LOG/*/*/*/$NAMEHOST/gammu-smsd | grep "$(cat /var/run/gammu)")
	if [  "$(echo -e "$LASTRUN" | grep 'Error at init connection')" ] || [ -z "$(ps -A | grep 'gammu')"];then
		echo "<br>Status:&nbsp;<img src=\"/images/disabilita.png\">"
		if [ -n "$(ps -A | grep 'gammu')" ];then
			PIDGAMMU="$(ps -A | grep 'gammu' | awk '{print $1}')"
			kill -9 $PIDGAMMU 2>/dev/null
			kill -9 $PIDGAMMU 2>/dev/null
			kill -9 $PIDGAMMU 2>/dev/null
		fi
	else
		echo "<br>Status:&nbsp;<img src=\"/images/abilita.png\">"
	fi
fi

if [ "$1" == "CambiaURL" ];then
	sed -i "s/$2/$3/g" $4
	chown root:root $4
	chmod 755 $4
fi

if [ "$1" == "GetToken" ];then
	CP_INT=$(cat $C_CP_DIR/Auth/Custom/IP)
	PP_URL=$(cat $C_ZT_CONF_DIR/conf_pp | grep TOKEN | awk '{print $2}')
	TOKEN=$(curl -k $PP_URL \
	-H "Accept: application/json" \
	-H "Accept-Language: en_US" \
	-u "$C_PP_CLIENT_ID:$C_PP_SECRET" \
	-d "grant_type=client_credentials" |  awk '{split ($0, a, "access_token");print a[2]}' | cut -d'"' -f3)
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_PP_TOKEN" "$TOKEN"
	sed -i "s/total.*/total\"\:\"$2\"\,/g" /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	sed -i "s/return_url.*/return_url\"\:\"http\:\/\/$CP_INT\:8089\/cgi-bin\/register.sh\?CONTROL_PAY=$3\&CREDIT\=$2\"\,/g" /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	sed -i "s/cancel_url.*/cancel_url\"\:\"http\:\/\/$CP_INT\:8089\/cgi-bin\/register.sh\"/g" /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	sed -i "s/tmp.*/tmp\/$3\"/g" /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	chown root:root /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	chmod 755 /DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
	/DB/apache2/cgi-bin/zerotruth/scripts/send_pay_pp.sh
fi

if [ "$1" == "OkPay" ];then
	sed -i "s/Bearer.*/Bearer $C_PP_TOKEN\' \\\/g" /DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
	sed -i "s/payer_id.*/payer_id\"\:\"$2\" \}\' \)/g" /DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
	sed -i "s/^UTENTE.*/UTENTE\=\"$3\"/g" /DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
	chown root:root /DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
	chmod 755 /DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
	/DB/apache2/cgi-bin/zerotruth/scripts/ok_pay_pp.sh
fi

if [ "$1" == "Control" ];then
	if [ "$C_CP_LOCAL_TYPE" == "Client" ];then
		CONTROL_NC=$( `/usr/local/bin/nc -z -w 8 $C_CP_REMOTE_IP 8088  2> /dev/null` || echo "down")
		if [ "$CONTROL_NC" == "down" ];then
			if [ "$C_CP_LOCAL_AUTO" !="down" ];then
				CONNECTED=$(ls $C_CP_DIR/Connected )
				for IP in $CONNECTED;do
					$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
				done
				if [ "$C_CP_LOCAL_AUTO" == "on" ];then
					for dir in $( ls $C_SYSTEM/radius/proxy/realms/ );do
						for dirn in $( ls $C_SYSTEM/radius/proxy/realms/$dir/ );do
							CONTROL_IP=$(cat $C_SYSTEM/radius/proxy/realms/$dir/$dirn/Server)
							if [ "$CONTROL_IP" == "$C_CP_REMOTE_IP" ];then
								rm -rf $C_ZT_DIR/tmp/radius
								cp -a $C_SYSTEM/radius/proxy/realms/$dir/$dirn $C_ZT_DIR/tmp/radius
								echo "$dir" > $C_ZT_DIR/tmp/radius/RealM
								/root/kerbynet.cgi/scripts/radius_proxydel "$dir" "$dirn"
							fi
						done
					done
					for dir in $( ls $C_SYSTEM/net/router/PAT/ );do
							CONTROL_IP=$(cat $C_SYSTEM/net/router/PAT/$dir/RemoteIP)
							if [ "$CONTROL_IP" == "$C_CP_REMOTE_IP" ];then
								rm -rf $C_ZT_DIR/tmp/pat
								cp -a $C_SYSTEM/net/router/PAT/$dir $C_ZT_DIR/tmp/pat
								/root/kerbynet.cgi/scripts/router_delpat $dir
							fi
					done
					$C_ZT_BIN_DIR/zt "SalvaConfig"  "C_CP_LOCAL_AUTO" "down"
				fi
			fi
		else
			if [[ -n "$C_CP_LOCAL_AUTO" && "$C_CP_LOCAL_AUTO" != "on" ]];then
				REALM="$(cat $C_ZT_DIR/tmp/radius/RealM)"
				SERVER="$(cat $C_ZT_DIR/tmp/radius/Server)"
				AUTHPORT="$(cat $C_ZT_DIR/tmp/radius/AuthPort)"
				ACCTPORT="$(cat $C_ZT_DIR/tmp/radius/AcctPort)"
				SECRET="$(cat $C_ZT_DIR/tmp/radius/Secret)"
				NOSTRIP="$(cat $C_ZT_DIR/tmp/radius/NoStrip)"
				LB="yes"
				TYPE="Remote"
				ACCOUNTING="yes"
				rm -rf $C_ZT_DIR/tmp/radius
				/root/kerbynet.cgi/scripts/radius_proxyadd "$REALM" "$SERVER" "$AUTHPORT" "$ACCTPORT" "$SECRET" "$NOSTRIP" "$LB" "$TYPE" "$ACCOUNTING"
				INTERFACE="$(cat $C_ZT_DIR/tmp/pat/Interface)"
				VIRTUALIP="$(cat $C_ZT_DIR/tmp/pat/VirtualIP)"
				PROTOCOL="$(cat $C_ZT_DIR/tmp/pat/Protocol)"
				LOCALPORT="$(cat $C_ZT_DIR/tmp/pat/LocalPort)"
				REMOTEIP="$(cat $C_ZT_DIR/tmp/pat/RemoteIP)"
				REMOTEPORT="$(cat $C_ZT_DIR/tmp/pat/RemotePort)"
				rm -rf $C_ZT_DIR/tmp/pat
				/root/kerbynet.cgi/scripts/router_addpat "$INTERFACE" "$VIRTUALIP" "$PROTOCOL" "$LOCALPORT" "$REMOTEIP" "$REMOTEPORT"
				$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CP_LOCAL_AUTO" "on"
			fi
		fi
	fi
	if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
		for CLIENT in $(ls $C_ZT_CONF_DIR/RemoteClients);do
			IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$CLIENT/IP)
			CONTROL_NC=$( `nc -z -w 8 $IP_REMOTE 8088 2> /dev/null` || echo "down")
			if [ -n "$CONTROL_NC" ];then
				USERS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" loginRemote="$CLIENT-*" uid | grep '^uid:' | awk '{print $2}')
				for USER in $USERS;do
					for SESSION in $(ls -t $C_ACCT_DIR/entries/$USER/sessions/ );do
						STOP=$(cat $C_ACCT_DIR/entries/$USER/sessions/$SESSION/stop)
						if [ -z "$STOP" ];then
							SEC_NOW=$(date +%s)
							$C_ZT_BIN_DIR/zt "Salva" "$SEC_NOW" "$C_ACCT_DIR/entries/$USER_DET/sessions/$SESSION/stop"
							break
						fi
					done
				done
			fi
		done
	fi
	if [ -n "$C_DISCONNECT_TIME" ];then
		$C_ZT_SCRIPTS_DIR/controlinactivetime.sh
	fi
	if [ -n "$C_IPBLOCKED" ];then
		$C_ZT_BIN_DIR/zt "FailBan"
	fi
	if [ -d $C_ZT_DIR/mudc ];then
		$C_ZT_BIN_DIR/zt "mudc" "Control"
	fi
	$C_ZT_SCRIPTS_DIR/diskfull.sh
	if [ -f $C_CP_DIR/Auth/Custom/RegisterAsterisk ];then
		if [ "$(cat $C_CP_DIR/Auth/Custom/RegisterAsterisk)" == "yes" ];then
			NOW=$(date +%s)
			USERAST=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" gecos=wait_asterisk uid)
			USERASTERISK=$(echo "$USERAST" | sed -n '/uid:/p' | awk '{ print $2 }')
			for USERDEL in $USERASTERISK;do
				QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERDEL sn radiusUserCategory)
				PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
				TL="$(echo "$PASSWORD" | cut -d'-' -f2)"
				if [ "$TL" -eq "$TL" ];then
					if [ $TL -lt $NOW ];then
						deleteuser "$USERDEL"
					fi
				fi
			done
		fi
	fi
	if [ -n "$C_SHOW_NOT_INTERNET" ];then
		CONTROLDOWN=$( `/usr/local/bin/nc -z -w 4 8.8.8.8 53  2> /dev/null` || echo "down")
		if [[ -n "$CONTROLDOWN" && $(cat $C_CP_DIR/Auth/Custom/NoInternet) != "yes" ]];then
			IPCP=$(cat $C_CP_DIR/Auth/Custom/IP)
			cp -f $C_ZT_CONF_DIR/fakedns-ori $C_ZT_CONF_DIR/fakedns
			sed -i "s/IPCP/$IPCP/g" $C_ZT_CONF_DIR/fakedns
			cp -f $C_ZS_SCRIPTS_DIR/dns_zoneconfig $C_HTDOCS_SCRIPTS_DIR/dns_zoneconfig
			sed -i 's/IN//g' $C_ZS_SCRIPTS_DIR/dns_zoneconfig
			sed -i 's/type hint/type master/g' $C_ZS_SCRIPTS_DIR/dns_zoneconfig
			sed -i 's/root.cache/\/DB\/apache2\/cgi-bin\/zerotruth\/conf\/fakedns/g' $C_ZS_SCRIPTS_DIR/dns_zoneconfig
			/etc/init.d/dns restart
			echo "yes" > $C_CP_DIR/Auth/Custom/NoInternet
			OLDCPLINK=$(ls -lia $C_CP_DIR/Auth/Template/cp* | grep 'lrwx' | cut -d'/' -f15)
			echo "$OLDCPLINK" > $C_ZT_CONF_DIR/OldCplink
			ln -sf $C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-off $C_CP_DIR/Auth/Template/cp_showauth_custom
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_INTERNET_DOWN" "on"
			if [ "$C_SMS_PROVIDER" == "Gammu" ];then
				TEXT_SMS="$C_HOTSPOT_NAME: Internet Down"
				$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS"
			fi
		fi
		if [[ -z "$CONTROLDOWN"  && $(cat $C_CP_DIR/Auth/Custom/NoInternet) == "yes" ]];then
			echo "no" > $C_CP_DIR/Auth/Custom/NoInternet
			OLDCPLINK=$(cat $C_ZT_CONF_DIR/OldCplink)
			ln -sf $C_HTDOCS_TEMPLATE_DIR/$OLDCPLINK $C_CP_DIR/Auth/Template/cp_showauth_custom
			mv -f $C_HTDOCS_SCRIPTS_DIR/dns_zoneconfig $C_ZS_SCRIPTS_DIR/dns_zoneconfig
			rm -f  $C_ZT_CONF_DIR/fakedns
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_INTERNET_DOWN" ""
			/etc/init.d/dns restart
		fi
	fi
	if [ -n "$(ls $C_CP_DIR/Connected)" ];then
		CONNMOB="$(ls $C_CP_DIR/Connected)"
		for IP in $CONNMOB;do
			if [ -f $C_CP_DIR/Connected/$IP/Now ];then
				VALIDITY_MOBILE=$(($C_AUTH_VALIDITY_MOBILE*60))
				USERMOBILE="$(cat $C_CP_DIR/Connected/$IP/User) | cut -d'@' -f1)"
				TIMEMOBILE="$(cat $C_CP_DIR/Connected/$IP/Now)"
				NOW=$(date +%s)
				CTIME=$(($NOW-$TIMEMOBILE))
				if [ "$CTIME" -gt "$VALIDITY_MOBILE" ];then
					$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERMOBILE"
				fi
			fi
		done
	fi
	if [ -f /opt/asterisk/var/run/asterisk/asterisk.pid ];then
		if [ -z "$(/opt/asterisk/sbin/asterisk -r -x "sip show peers" | sed -n 2p | awk '{print $6}' | grep 'OK')" ];then
			$C_ZT_BIN_DIR/zt "AsteriskRestart"
		fi
	fi
fi

if [ "$1" == "RestoreDns" ];then
	echo "no" > $C_CP_DIR/Auth/Custom/NoInternet
	if [ -f $C_ZT_CONF_DIR/OldCplink ];then
		OLDCPLINK=$(cat $C_ZT_CONF_DIR/OldCplink)
	else
		OLDCPLINK="cp_showauth_custom-on"
	fi
	ln -sf $C_HTDOCS_TEMPLATE_DIR/$OLDCPLINK $C_CP_DIR/Auth/Template/cp_showauth_custom
	if [ -f $C_HTDOCS_SCRIPTS_DIR/dns_zoneconfig ];then
		mv -f $C_HTDOCS_SCRIPTS_DIR/dns_zoneconfig $C_ZS_SCRIPTS_DIR/dns_zoneconfig
	fi
	/etc/init.d/dns restart
fi

if [ "$1" == "UnlockClientDay" ];then
	PASSRADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn="*LOCKORED" cn  )
	USERSLOCK=$(echo "$PASSRADIUS" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USERRO in $USERSLOCK;do
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn="$USERRO" sn )
		PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1 )
		DATA="dn: cn=$USERRO,ou=Radius,$C_LDAPBASE\nsn: $PASSWORD"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		/usr/bin/logger -t ZT.system "UnBlocked $USERRO Hours per Day"
	done
	PASSRADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn="*LOCKMBD" cn  )
	USERSLOCK=$(echo "$PASSRADIUS" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USERRO in $USERSLOCK;do
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn="$USERRO" sn )
		PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1 )
		DATA="dn: cn=$USERRO,ou=Radius,$C_LDAPBASE\nsn: $PASSWORD"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		/usr/bin/logger -t ZT.system "UnBlocked $USERRO MB per Day"
	done
	$C_ZT_BIN_DIR/zt "CONTROL_EXPIRED"
	$C_ZT_BIN_DIR/zt "UPDATE_GRAPHS"
	### control for details users ###
	cd $C_ACCT_DIR/entries
	ENTRIES=$(ls  2>/dev/null)
	[ -z "$ENTRIES" ] && exit
	for USER_NAME in $ENTRIES;do
		DN=$(date +%d | sed 's/^0//')
		MN=$(date +%m | sed 's/^0//')
		YN=$(date +%Y)
		rm -rf  $(ls $USER_NAME/MBD* | grep -v "MBD$DN") 2>/dev/null
		rm -rf  $(ls $USER_NAME/MBM* | grep -v "MBM$MN") 2>/dev/null
		rm -rf  $(ls $USER_NAME/MBY* | grep -v "MBY$YN") 2>/dev/null
		rm -rf  $(ls $USER_NAME/TimeD* | grep -v "TimeD$DN") 2>/dev/null
		rm -rf  $(ls $USER_NAME/TimeM* | grep -v "TimeM$MN") 2>/dev/null
		rm -rf  $(ls $USER_NAME/TimeY* | grep -v "TimeY$YN") 2>/dev/null
	done
	###############
fi

if [ "$1" == "CONTROL_EXPIRED" ];then
	TODAY=$(date +%s)
	TODAY=$(($TODAY/86400))
	PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid)
	USERPEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
	for USERNAME in $USERPEOPLE;do
		if [ "$USERNAME" != "admin" ];then
			CONTROL_EX=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME shadowExpire  | grep -e '^shadowExpire: ' | sed 's/^shadowExpire: //g')
			if [ $TODAY -gt $CONTROL_EX ];then
				if [ -d /Database/var/register/system/acct/entries/$USERNAME ];then
					$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "E"
				fi
				if [ -n "$(ls $C_CP_DIR/Connected)" ];then
					CONNECTED=$(ls $C_CP_DIR/Connected)
					for IP in $CONNECTED;do
						if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERNAME" ];then
							$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
						fi
					done
				fi
			fi
		fi
	done
fi

if [ "$1" == "ControlAcct" ];then
	USERNAME="$2"
	if [ "$3" == "NEWREG" ];then
		$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "yes"
		exit
	fi
	TODAY=$(date +%s)
	TODAY=$(($TODAY/86400))
	CONTROL_EX=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME shadowExpire  | grep -e '^shadowExpire: ' | sed 's/^shadowExpire: //g')
	if [ $TODAY -gt $CONTROL_EX ];then
		$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "E"
		$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERNAME"
		exit
	else
		[ "$3" == "UPDATE" ] && VU="1"
	fi
	CL=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME radiusUserCategory  | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
	if [ "$(cat $C_ACCT_DIR/classes/$CL/ChargeType)" == "pre" ];then
		CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit)
		CHARGETYPE=$(cat $C_ACCT_DIR/classes/$CL/ChargeType)
		FREETIME=$(cat $C_ACCT_DIR/classes/$CL/FreeTime)
		if [[  -z "$CREDIT" || "$CREDIT" == "0.00" || $(echo "$CREDIT" | grep '^-') ]] && [ "$CREDIT" != "freetime" ] ;then
			$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "C"
			$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERNAME"
			exit
		fi
		if [[  -n "$CREDIT" && "$CREDIT" != "0.00" && -z $(echo "$CREDIT" | grep '^-') ]];then
			[ "$3" == "UPDATE" ] && VU="$(($VU+1))"
		fi
	else
		VU="$(($VU+1))"
	fi
	if [ -f $C_ACCT_DIR/entries/$USERNAME/Time ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/Hours)" ];then
		TIME=$(cat $C_ACCT_DIR/entries/$USERNAME/Time)
		LIMITH=$(cat $C_ACCT_DIR/classes/$CL/Hours)
		LIMITH=$(($LIMITH*3600))
		if [ $TIME -gt $LIMITH ] && [ -z "$VC" ];then
			$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "T"
			$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERNAME"
			exit
		else
			[ "$3" == "UPDATE" ] && VU="$(($VU+1))"
		fi
	else
		VU="$(($VU+1))"
	fi
	if [ -f $C_ACCT_DIR/entries/$USERNAME/MB ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/MB)" ];then
		TRAFFIC=$(cat $C_ACCT_DIR/entries/$USERNAME/MB)
		LIMITMB=$(cat $C_ACCT_DIR/classes/$CL/MB)
		LIMITMB=$((LIMITMB*1048576))
		if [ $TRAFFIC -gt $LIMITMB ];then
			$C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "no" "M"
			$C_ZT_BIN_DIR/zt "DisconnettiUsername" "$USERNAME"
			exit
		else
			[ "$3" == "UPDATE" ] && VU="$(($VU+1))"
		fi
	else
		VU="$(($VU+1))"
	fi
	[[ "$3" == "UPDATE" && "$VU" == "4" ]] && $C_ZT_SCRIPTS_DIR/cp_validity.sh "$USERNAME" "yes"
fi

if [ "$1" == "UPDATE_GRAPHS" ];then
	if ! [ -d $C_ZT_DIR/log/graphs ];then
		$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/log/graphs"
	fi
	rm -rf $C_ZT_DIR/log/graphs/*
	for CONF in "GRAPH_DATA_IN" "GRAPH_DATA_OUT";do
			$C_ZT_BIN_DIR/zt "SalvaConfig" "C_$CONF" ""
	done
	for USER_GRAPHS in $(ls $C_ACCT_DIR/entries/);do
		TIME_TOT=0
		TRAFFIC_TOT=0
		for SESSION in $(ls $C_ACCT_DIR/entries/$USER_GRAPHS/sessions);do
			if [ -f $C_ACCT_DIR/entries/$USER_GRAPHS/sessions/$SESSION/stop ];then
				SECSTART=$(stat -c "%Y" $C_ACCT_DIR/entries/$USER_GRAPHS/sessions/$SESSION/start)
				ANNO=$(date -d "1970-01-01 $SECSTART sec" +%Y)
				MESE=$(date -d "1970-01-01 $SECSTART sec" +%m)
				GIORNO=$(date -d "1970-01-01 $SECSTART sec" +%d)
				GIORNOSETT=$(date -d "1970-01-01 $SECSTART sec" +%a)
				GIORNOSETTNUM=$(date -d "1970-01-01 $SECSTART sec" +%w)
				ORA=$(date -d "1970-01-01 $SECSTART sec" +%H)
				TIME=$(cat  $C_ACCT_DIR/entries/$USER_GRAPHS/sessions/$SESSION/Time)
				TIME_TOT=$(($TIME_TOT+$TIME))
				TRAFFIC=$(cat  $C_ACCT_DIR/entries/$USER_GRAPHS/sessions/$SESSION/Traffic)
				TRAFFIC_TOT=$(($TRAFFIC_TOT+$TRAFFIC))
				$C_ZT_BIN_DIR/zt "Aggiungi" "$SECSTART anno-$ANNO mese-$MESE giorno-$GIORNO giornosett-$GIORNOSETT ora-$ORA tempo-$TIME traffico-$TRAFFIC giornosettnum-$GIORNOSETTNUM user-$USER_GRAPHS" "$C_ZT_DIR/log/graphs/graphs"
			fi
		done
	done
	/usr/bin/logger -t ZT.system "Update Graphs"
fi

if [ "$1" == "UnlockClientMonth" ];then
	PASSRADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn="*LOCKOREM" cn  )
	USERSLOCK=$(echo "$PASSRADIUS" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USERRO in $USERSLOCK;do
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn="$USERRO" sn )
		PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1 )
		DATA="dn: cn=$USERRO,ou=Radius,$C_LDAPBASE\nsn: $PASSWORD"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		/usr/bin/logger -t ZT.system "UnBlocked $USERRO Hours per Month"
	done
	PASSRADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn="*LOCKMBM" cn  )
	USERSLOCK=$(echo "$PASSRADIUS" | sed -n '/cn:/p' | awk '{ print $2 }')
	for USERRO in $USERSLOCK;do
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn="$USERRO" sn )
		PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1 )
		DATA="dn: cn=$USERRO,ou=Radius,$C_LDAPBASE\nsn: $PASSWORD"
		echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		/usr/bin/logger -t ZT.system "UnBlocked $USERRO MB per Month"
	done
fi

if [ "$1" == "Scarica" ];then
	BG="$C_BG"
	[ $(expr $5 % 2 ) -eq 0 ] && BG="$C_BG1"
	if `wget -N -P $2 $3 2>/dev/null`;then
		FILE="$4"
		if [ $(echo "$FILE" | cut -d'.' -f2) == "tar" ];then
			tar zxfv $2/$FILE -C $2  > /dev/null
			FILE=$(echo "$4" | sed 's/\.tar\.gz//g')
		fi
		echo "<tr BGCOLOR=\"$BG\"><td align=\"center\">$2</td><td align=\"center\">$FILE</td><td align=\"center\">$L_UPDATED</td></tr>"
		chown root:root $2/$FILE
		chmod 755 $2/$FILE
		if [ "$FILE" == "zt" ];then
			chmod 4755 $2/$FILE
		fi
		logger -t ZT.update "Update $FILE"
	else
		echo "<tr BGCOLOR=\"$BG\"><td>$2</td><td>$FILE</td><td align=\"center\"><font color=\"red\">$L_NOT $L_UPDATED</font></td></tr>"
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_FIX_ERROR" "on"
		logger -t ZT.update "Update $FILE error"
	fi
fi

if [ "$1" == "ControlCode" ];then
	$C_ZT_BIN_DIR/binzt "ControlCode" "$2"
fi

if [ "$1" == "RegisterCode" ];then
	$C_ZT_BIN_DIR/binzt "RegisterCode" "$2"
fi

if [ "$1" == "DeleteCode" ];then
	$C_ZT_BIN_DIR/binzt "DeleteCode"
fi

if [ "$1" == "ControlUpdate" ];then
	$C_ZT_BIN_DIR/binzt "ControlUpdate"
fi

if [ "$1" == "Stat" ];then
	stat -c "%Y" "$2"
fi

if [ "$1" == "StatSession" ];then
	stat -c "%y" $2
fi

if [ "$1" == "Copia" ];then
	cp $2 $3
fi

if [ "$1" == "CopiaTutto" ];then
	cp -a $2 $3
fi

if [ "$1" == "Errore" ];then
	echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">$2</font><p>
	<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form action=\"$3\" method=\"POST\">
	<input type=\"hidden\" name=\"$4\" value=\"$5\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	echo "<p>&nbsp;<p>"
	./footer.sh
fi

if [ "$1" == "ControlOk" ];then
	echo "<font color=\"blue\" size=\"4\">$2</font><p>
	<br><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form action=\"$3\" method=\"POST\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form>"
	echo "<p>&nbsp;<p>"
	./footer.sh
fi

if [ "$1" == "AggOrologio" ];then
	SUNDAY=$(echo "$L_SUNDAY" | sed 's/&/\\&/g')
	MONDAY=$(echo "$L_MONDAY" | sed 's/&/\\&/g')
	TUESDAY=$(echo "$L_TUESDAY" | sed 's/&/\\&/g')
	WEDNESDAY=$(echo "$L_WEDNESDAY" | sed 's/&/\\&/g')
	THURSDAY=$(echo "$L_THURSDAY" | sed 's/&/\\&/g')
	FRIDAY=$(echo "$L_FRIDAY" | sed 's/&/\\&/g')
	SATURDAY=$(echo "$L_SATURDAY" | sed 's/&/\\&/g')
	JANUARY=$(echo "$L_JANUARY" | sed 's/&/\\&/g')
	FEBRAURY=$(echo "$L_FEBRAURY" | sed 's/&/\\&/g')
	MARCH=$(echo "$L_MARCH" | sed 's/&/\\&/g')
	APRIL=$(echo "$L_APRIL" | sed 's/&/\\&/g')
	MAY=$(echo "$L_MAY" | sed 's/&/\\&/g')
	JUNE=$(echo "$L_JUNE" | sed 's/&/\\&/g')
	JULY=$(echo "$L_JULY" | sed 's/&/\\&/g')
	AUGUST=$(echo "$L_AUGUST" | sed 's/&/\\&/g')
	SEPTEMBER=$(echo "$L_SEPTEMBER" | sed 's/&/\\&/g')
	OCTOBER=$(echo "$L_OCTOBER" | sed 's/&/\\&/g')
	NOVEMBER=$(echo "$L_NOVEMBER" | sed 's/&/\\&/g')
	DECEMBER=$(echo "$L_DECEMBER" | sed 's/&/\\&/g')
	sed -i "s/DaysOfWeek\[0\].*/DaysOfWeek\[0\] = \"$SUNDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[1\].*/DaysOfWeek\[1\] = \"$MONDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[2\].*/DaysOfWeek\[2\] = \"$TUESDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[3\].*/DaysOfWeek\[3\] = \"$WEDNESDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[4\].*/DaysOfWeek\[4\] = \"$THURSDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[5\].*/DaysOfWeek\[5\] = \"$FRIDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/DaysOfWeek\[6\].*/DaysOfWeek\[6\] = \"$SATURDAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[0\].*/MonthsOfYear\[0\] = \"$JANUARY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[1\].*/MonthsOfYear\[1\] = \"$FEBRAURY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[2\].*/MonthsOfYear\[2\] = \"$MARCH\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[3\].*/MonthsOfYear\[3\] = \"$APRIL\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[4\].*/MonthsOfYear\[4\] = \"$MAY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[5\].*/MonthsOfYear\[5\] = \"$JUNE\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[6\].*/MonthsOfYear\[6\] = \"$JULY\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[7\].*/MonthsOfYear\[7\] = \"$AUGUST\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[8\].*/MonthsOfYear\[8\] = \"$SEPTEMBER\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[9\].*/MonthsOfYear\[9\] = \"$OCTOBER\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[10\].*/MonthsOfYear\[10\] = \"$NOVEMBER\"/g" $C_HTDOCS_DIR/js/liveclock.js
	sed -i "s/MonthsOfYear\[11\].*/MonthsOfYear\[11\] = \"$DECEMBER\"/g" $C_HTDOCS_DIR/js/liveclock.js
fi

if [ "$1" == "AggCalendario" ];then
	sed -i "s/^lang.*/lang\:\'$L_LANG\'\,/g" $C_HTDOCS_DIR/js/zt.js
fi

if [ "$1" == "AddK5" ];then
	kadmin.local -q "addprinc -pw $2 $3" 2>/dev/null > /dev/null
	kadmin.local -q "modprinc -expire $4 $3" 2>/dev/null > /dev/null
fi

if [ "$1" == "UpdateK5" ];then
	kadmin.local -q "change_password -pw $2 $3" 2>/dev/null > /dev/null
	kadmin.local -q "modprinc -expire $4 $3" 2>/dev/null > /dev/null
fi

if [ "$1" == "DelK5" ];then
	kadmin.local -q "delprinc -force $2" 2>/dev/null > /dev/null
fi

if [ "$1" == "InviaSms" ];then
	TESTO_LOG="$4"
	TESTO=$(urlencode "$4")
	if [[ "$2" == "Gammu" || "$2" == "aimon" ]];then
		TESTO=$($C_ZT_BIN_DIR/convplain "$TESTO")
	fi
	if [ "$2" == "aimon" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		TESTO=$(echo "$TESTO" | $C_ZT_BIN_DIR/base64)
		SENDER=$(echo "$C_SMS_SENDER" | $C_ZT_BIN_DIR/base64)
		echo "$SENDER $TESTO" > /DB/aimon
		`curl -k --data "authlogin=$C_SMS_USER&authpasswd=$C_SMS_PASSWORD&sender=$SENDER&destination=$NUMERI&body=$TESTO&id_api=59" https://secure.apisms.it/http/send_sms` 2>/dev/null >/dev/null
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "skebby" ];then
		NUMERI=$(echo "$3" | sed '/ /s//\&recipients[]=/g')
		`curl --data "method=send_sms_classic&username=$C_SMS_USER&password=$C_SMS_PASSWORD&recipients[]=$NUMERI&sender_string=$C_SMS_SENDER&text=$TESTO" http://gateway.skebby.it/api/send/smseasy/advanced/http.php ` 2>/dev/null >/dev/null
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "smsglobal" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		`curl --data "action=sendsms&user=$C_SMS_USER&password=$C_SMS_PASSWORD&&from=$C_SMS_SENDER&to=$NUMERI&text=$TESTO" http://www.smsglobal.com/http-api.php`
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "subitosms" ];then
		NUMERI=$(echo "$3" | sed 's/^  //g' | sed 's/ /,%2B/g')
		NUMERI="%2B$NUMERI"
		`curl --data "username=$C_SMS_USER&password=$C_SMS_PASSWORD&dest=$NUMERI&tipo=1&mitt=$C_SMS_SENDER&testo=$TESTO" http://www.subitosms.it/gateway.php`
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "smsbiz" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		`curl --data "login=$C_SMS_USER&password=$C_SMS_PASSWORD&dest=$NUMERI&tipo=1&mitt=$C_SMS_SENDER&testo=$TESTO" http://www.nsgateway.net/smsscript/sendsms.php`
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "my_SMS_script" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		[ "$6" == "credito" ] && CREDIT="yes"
		N_SMS=$5
		$C_ZT_SCRIPTS_DIR/my_SMS_script.sh "$NUMERI" "$TESTO" "$5" "$CREDIT"
	fi
	if [ "$2" == "mobyt_old" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		RCPTARRAY=$(echo "")
		ARR_TEMP=$(echo $NUMERI | tr "," "\n")
		for x in $ARR_TEMP;do
			RCPTARRAY=$(echo "$RCPTARRAY%2b$x,")
		done
		RCPTARRAY=$(echo "${RCPTARRAY/%,/}")
		if [[ "$RCPTARRAY" != *,* ]];then
			`curl --data "id=$C_SMS_USER&password=$C_SMS_PASSWORD&rcpt=$RCPTARRAY&from=$C_SMS_SENDER&data=$TESTO&qty=h&operation=TEXT" http://smsweb.mobyt.it/sms-gw/sendsmart`
		fi
		if [[ "$RCPTARRAY" == *,* ]];then
			`curl --data "id=$C_SMS_USER&password=$C_SMS_PASSWORD&rcptbatch=$RCPTARRAY&from=$C_SMS_SENDER&data=$TESTO&qty=h&operation=TEXT" http://smsweb.mobyt.it/sms-gw/sendsmart`
        fi
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "mobyt_new" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g' | sed '/ /s//,/g')
		RCPTARRAY=$(echo "")
		ARR_TEMP=$(echo $NUMERI | tr "," "\n")
		for x in $ARR_TEMP;do
			RCPTARRAY=$(echo "$RCPTARRAY%2b$x,")
        done
		RCPTARRAY=$(echo "${RCPTARRAY/%,/}")
		if [[ "$RCPTARRAY" != *,* ]];then
			`curl --data "user=$C_SMS_USER&pass=$C_SMS_PASSWORD&rcpt=$RCPTARRAY&sender=$C_SMS_SENDER&data=$TESTO&qty=h&operation=TEXT" http://client.mobyt.it/sms/send.php`
		fi
		if [[ "$RCPTARRAY" == *,* ]];then
			`curl --data "user=$C_SMS_USER&pass=$C_SMS_PASSWORD&rcpt=$RCPTARRAY&sender=$C_SMS_SENDER&data=$TESTO&qty=h&operation=TEXT" http://client.mobyt.it/sms/batch.php`
		fi
		if [ "$6" == "credito" ];then
			$C_ZT_BIN_DIR/zt "UpdateCreditSms" "$2"
		fi
	fi
	if [ "$2" == "Gammu" ];then
		NUMERI=$(echo "$3" | sed '/^  /s///g')
		for NUM in $NUMERI;do
			echo "$TESTO" | $C_ZT_BIN_DIR/gammu-smsd-inject -c $C_ZT_CONF_DIR/gammu.conf TEXT +$NUM >/dev/null 2>/dev/null
		done
	fi
	/usr/bin/logger -t sms "$NUMERI $TESTO"
fi

if [ "$1" == "SendSms" ];then
	echo "$2" | $C_ZT_BIN_DIR/gammu-smsd-inject -c $C_ZT_CONF_DIR/gammu.conf TEXT +$3 >/dev/null 2>/dev/null
fi

if [ "$1" == "UpdateCreditSms" ];then
	if [ "$2" == "skebby" ];then
		CREDITO=$(curl --data "method=get_credit&username=$C_SMS_USER&password=$C_SMS_PASSWORD" http://gateway.skebby.it/api/send/smseasy/advanced/http.php)
		CREDITOVAL=$(echo $CREDITO | cut -d'=' -f3  | cut -d'&' -f1)
		CREDITONUM=$(echo $CREDITO | cut -d'=' -f4  | cut -d'&' -f1)
		CREDITNOW="$CREDITOVAL $C_CURRENCY - Num: $CREDITONUM"
	fi
	if [ "$2" == "smsglobal" ];then
		IP_WAN="$(dig -4 @resolver1.opendns.com -t a myip.opendns.com +short)"
		NATION_PAGE="$(curl --data "id=query&ip=$IP_WAN" http://ipinfodb.com/ip_locator.php)"
		NATION=$(echo -e "$NATION_PAGE" | grep 'Country :' | cut -d':' -f2 | cut -d'<' -f1 | sed 's/ //g')
		[ -z "$NATION" ] && NATION="IT"
		CREDITONUM=$(curl --data "user=$C_SMS_USER&password=$C_SMS_PASSWORD&country=$NATION" http://www.smsglobal.com/credit-api.php)
		CREDIT=$(echo "$CREDITONUM" | cut -d':' -f2 | cut -d';' -f1 )
		SMS=$(echo "$CREDITONUM" | cut -d':' -f4 | cut -d';' -f1 )
		CREDITNOW="$CREDIT - SMS: $SMS"
	fi
	if [ "$2" == "smsbiz" ];then
		CREDITONUM=$(curl --data "login=$C_SMS_USER&password=$C_SMS_PASSWORD&tipo=2" http://www.nsgateway.net/smsscript/sendsms.php)
		CREDITONUM=$(echo "$CREDITONUM" | cut -d' ' -f2 )
		CREDITONUM=$(echo "$CREDITONUM" | sed 's/\r//g')
		CREDITNOW="Num: $CREDITONUM"
	fi
	if [ "$2" == "subitosms" ];then
		CREDITONUM=`curl --data "username=$C_SMS_USER&password=$C_SMS_PASSWORD" http://www.subitosms.it/gateway.php`
		CREDITONUM=$(echo "$CREDITONUM" | cut -d':' -f2 )
		CREDITNOW="Num: $CREDITONUM"
	fi
	if [ "$2" == "mobyt_old" ];then
		CREDITONUM=$(curl --data "id=$C_SMS_USER&password=$C_SMS_PASSWORD&operation=GETMESS" http://smsweb.mobyt.it/sms-gw/sendsmart)
		CREDITONUM=$(echo "${CREDITONUM:3}")
		CREDITNOW="SMS Residui HQ: $CREDITONUM"
	fi
	if [ "$2" == "mobyt_new" ];then
		CREDITONUM=$(curl --data "user=$C_SMS_USER&pass=$C_SMS_PASSWORD&type=hqs" http://client.mobyt.it/sms/credit.php)
		CREDITONUM=$(echo "${CREDITONUM:3}")
		CREDITNOW="SMS Residui HQ: $CREDITONUM"
	fi
	if [ "$2" == "aimon" ];then
		CREDITNOW=$(curl -k --data "authlogin=$C_SMS_USER&authpasswd=$C_SMS_PASSWORD" https://secure.apisms.it/http/get_credit)
	fi
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_SMS_CREDIT" "$CREDITNOW"
fi

if [ "$1" == "Reboot" ];then
	reboot
fi

if [ "$1" == "Shutdown" ];then
	halt
fi

if [ "$1" == "SaveBandwidth" ];then
	RATE=$( echo "$3*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)
	RATEKB=$(echo $RATE""Kbit)
	WEIGHT=$( echo "$RATE/10" | $C_ZT_BIN_DIR/bc )
	WEIGHTKB=$(echo $WEIGHT""Kbit)
	if [ -f $C_ZT_CONF_DIR/cbqconf/cbq-$2 ];then
		sed -i "s/^RATE=.*/RATE=$RATEKB/g" $C_ZT_CONF_DIR/cbqconf/cbq-$2
		sed -i "s/^WEIGHT=.*/WEIGHT=$WEIGHTKB/g" $C_ZT_CONF_DIR/cbqconf/cbq-$2
	else
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		file="# Bandwidth class: $2"
		file="$file\nDEVICE=$INTERFACECP,1000Mbit,100Mbit"
		file="$file\nRATE=$RATEKB"
		file="$file\nWEIGHT=$WEIGHTKB"
		file="$file\nPRIO=5"
		echo -e "$file" > $C_ZT_CONF_DIR/cbqconf/cbq-$2
		chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$2
		chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$2
	fi
fi

if [ "$1" == "SaveBandwidthUp" ];then
	RATE=$( echo "$3*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)
	RATEKB=$(echo $RATE""Kbit)
	WEIGHT=$( echo "$RATE/10" | $C_ZT_BIN_DIR/bc )
	WEIGHTKB=$(echo $WEIGHT""Kbit)
	if [ -f $C_ZT_CONF_DIR/cbqconf/cbq-$2 ];then
		sed -i "s/^RATE=.*/RATE=$RATEKB/g" $C_ZT_CONF_DIR/cbqconf/cbq-$2
		sed -i "s/^WEIGHT=.*/WEIGHT=$WEIGHTKB/g" $C_ZT_CONF_DIR/cbqconf/cbq-$2
	else
		INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
		MARK=$(echo "$2" | cut -d'.' -f1)
		file="# Bandwidth upload class: $2"
		file="$file\nDEVICE=$INTERFACEWAN,1000Mbit,100Mbit"
		file="$file\nRATE=$RATEKB\nWEIGHT=$WEIGHTKB"
		file="$file\nPRIO=5\nMARK=$MARK"
		echo -e "$file" > $C_ZT_CONF_DIR/cbqconf/cbq-$2
		chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$2
		chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$2
	fi
fi

if [[ "$1" == "SaveBandwidth" || "$1" == "SaveBandwidthUp" ]];then
	$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/cbq.init 2>/dev/null > /dev/null
	$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
fi

if [ "$1" == "ShaperRestart" ];then
	$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/cbq.init 2>/dev/null > /dev/null
	$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
fi

if [ "$1" == "DelShaperUser" ];then
	$C_ZT_SCRIPTS_DIR/delshaperuser.sh "$2"

fi

if [ "$1" == "ShaperUser" ];then
	$C_ZT_SCRIPTS_DIR/shaperuser.sh "$2" "$3"

fi

if [ "$1" == "Shaper" ];then
	if [ "$2" == "on" ];then
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
		rm -rf $C_CLASSES_DIR/*/NumClass 2>/dev/null
		echo "2" > $C_CLASSES_DIR/DEFAULT/NumClass
		NUM=3
			for CL in $(ls $C_CLASSES_DIR);do
			if [ $CL != "DEFAULT" ];then
				echo "$NUM" > $C_CLASSES_DIR/$CL/NumClass
				NUM=$(($NUM+1))
			fi
		done
		for CL in $(ls $C_CLASSES_DIR);do
			if [ "$CL" != "DEFAULT" ];then
				RATE=$(cat $C_CLASSES_DIR/$CL/Mbits)
				RATEU=$(cat $C_CLASSES_DIR/$CL/MbitsUp)
				NUM=$(cat $C_CLASSES_DIR/$CL/NumClass)
				SHAPER=$(cat $C_CLASSES_DIR/$CL/ShaperType)
				if [[ "$RATE" != "" && "$SHAPER" == "class" ]];then
					RATE=$( echo "$RATE*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)
					RATEKB=$(echo $RATE""Kbit)
					WEIGHT=$( echo "$RATE/10" | $C_ZT_BIN_DIR/bc )
					WEIGHTKB=$(echo $WEIGHT""Kbit)
					file="# Bandwidth class: $CL"
					file="$file\nDEVICE=$INTERFACECP,1000Mbit,100Mbit"
					file="$file\nRATE=$RATEKB"
					file="$file\nWEIGHT=$WEIGHTKB"
					file="$file\nPRIO=5"
					echo -e "$file" > $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
					chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
					chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
				fi
				if [[ "$RATEU" != "" && "$SHAPER" == "class" ]];then
					NUM=$(($NUM+100))
					RATEU=$( echo "$RATEU*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)
					RATEKB=$(echo $RATEU""Kbit)
					WEIGHT=$( echo "$RATEU/10" | $C_ZT_BIN_DIR/bc )
					WEIGHTKB=$(echo $WEIGHT""Kbit)
					file="# Bandwidth upload class: $CL"
					file="$file\nDEVICE=$INTERFACEWAN,1000Mbit,100Mbit"
					file="$file\nRATE=$RATEKB\nWEIGHT=$WEIGHTKB"
					file="$file\nPRIO=5\nMARK=$NUM"
					echo -e "$file" > $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
					chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
					chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$NUM.$CL
				fi
			fi
		done
		for IP in $(ls $C_SYSTEM/cp/Connected );do
			USER_CON=$( cat $C_SYSTEM/cp/Connected/$IP/User | cut -d'@' -f1)
			CLASS_US=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER_CON radiusUserCategory)
			CLASS_USER=$( echo "$CLASS_US" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
			NUM_CLASS=$(cat $C_CLASSES_DIR/$CLASS_USER/NumClass)
			if [ -f  $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS_USER ];then
				echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS_USER
			fi
			NUM_CLASS_U=$(($NUM_CLASS+100))
			if [ -f  $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS_U.$CLASS_USER ];then
				echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS_U.$CLASS_USER
			fi
		done
		$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/cbq.init 2>/dev/null > /dev/null
		$C_ZT_SCRIPTS_DIR/cbq.sh start 2>/dev/null > /dev/null
	else
		$C_ZT_SCRIPTS_DIR/cbq.sh stop 2>/dev/null > /dev/null
		$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/cbq.init 2>/dev/null > /dev/null
		rm -rf $C_CLASSES_DIR/*/NumClass 2>/dev/null
		rm -rf $C_ZT_CONF_DIR/cbqconf/* 2>/dev/null > /dev/null
	fi
fi

if [ "$1" == "Proxy" ];then
	$C_ZT_BIN_DIR/zt "ConfigProxy"
	chmod -R 777 $C_ZT_LOG_DIR
	$C_ZS_SCRIPTS_DIR/proxy_stop 2>/dev/null >/dev/null
	if [ -n "$($C_ZT_BIN_DIR/zt ControlActive squid)" ]; then
		$C_ZT_PROXY_DIR/sbin/squid -k shutdown
		$C_ZS_SCRIPTS_DIR/terminate squid
		$C_ZS_SCRIPTS_DIR/terminate squid
		rm -f $C_ZT_PROXY_DIR/var/run/squid.pid
		/usr/bin/logger -t squid "Squid terminate"
	fi
	if [ -n "$($C_ZT_BIN_DIR/zt ControlActive dansguardian)" ]; then
		$C_ZT_PROXY_DIR/sbin/dansguardian -q
		rm -rf $C_ZT_PROXY_DIR/var/run/dansguardian.pid
		/usr/bin/logger -t dansguardian "Dansguardian terminate"
	fi
	echo "" > $C_SYSTEM/havp/Enabled
	$C_ZS_SCRIPTS_DIR/proxy_fw_reset
	$C_ZS_SCRIPTS_DIR/terminate dansguardian
	$C_ZS_SCRIPTS_DIR/terminate havp
	$C_ZS_SCRIPTS_DIR/terminate freshclam
	rm -rf $SYSTEM/havp/clamav.tmp/* $SYSTEM/havp/tmp/*
	if [ "$2" == "on-on" ];then
		echo "yes" > $C_SYSTEM/havp/Enabled
		rm -f $C_ZT_CONF_DIR/squid.conf
		if [ -n "$C_DANSGUARDIAN" ];then
			SQUIDCONF="squid-dg-havp.conf"
			CONTROL_DANS="yes"
			HAVPCONF="havp-dg-squid.conf"
		else
			SQUIDCONF="squid-havp.conf"
			HAVPCONF="havp-squid.conf"
		fi
		cp -f $C_ZT_PROXY_DIR/etc/squid/$SQUIDCONF $C_ZT_PROXY_DIR/etc/squid.conf
		cp -f $C_ZT_PROXY_DIR/etc/havp/$HAVPCONF $C_ZT_PROXY_DIR/etc/havp.conf
		if [ -z "$C_SQ_LOG"];then
			sed -i "s/^#access_log/access_log none/g" $C_ZT_PROXY_DIR/etc/squid.conf
		else
			sed -i "s/^#access_log/access_log syslog:daemon/g" $C_ZT_PROXY_DIR/etc/squid.conf
		fi
		if [ "$(cat $C_SYSTEM/havp/BlackList)" == "no" ];then
			sed -i "s/^BLACKLIST.*/BLACKLIST \/dev\/null/g" $C_ZT_PROXY_DIR/etc/havp.conf
		fi
		if [ "$(cat $C_SYSTEM/havp/WhiteList)" == "no" ];then
			sed -i "s/^WHITELIST.*/WHITELIST \/dev\/null/g" $C_ZT_PROXY_DIR/etc/havp.conf
		fi
		$C_ZT_BIN_DIR/zt "InterSquid"
		if [ -z $(ls -d $C_ZT_PROXY_DIR/var/cache/squid/00) ];then
			$C_ZT_PROXY_DIR/sbin/squid -z 2>/dev/null >/dev/null
		fi
		$C_ZT_PROXY_DIR/sbin/squid -s 2>/dev/null >/dev/null
		chown -R havp /var/log/havp
		if havp -c $C_ZT_PROXY_DIR/etc/havp.conf >/dev/null 2>/dev/null ; then
			if [ -n "$CONTROL_DANS" ];then
				$C_ZT_PROXY_DIR/sbin/dansguardian
			fi
			$C_ZS_SCRIPTS_DIR/proxy_fw
			if ! ls $C_SYSTEM/havp/redirects/* 2>/dev/null >/dev/null ; then
				/usr/bin/logger -t proxy "WARNING: No HTTP capturing rules defined."
			fi
		else
			logger -t proxy "RESETTING VIRUS DATABASE."
			rm -rf $C_SYSTEM/ClamAV/db/
			mkdir -p $C_SYSTEM/ClamAV/db
			if ! cp /usr/local/share/clamav/main.cvd $C_SYSTEM/ClamAV/db ; then
				logger -t proxy "ERROR: Virus database corrupted. Check the profile disk space."
			fi
			chown -R havp $C_SYSTEM/ClamAV/db
			if havp -c $C_ZT_PROXY_DIR/etc/havp.conf >/dev/null 2>/dev/null ; then
				$C_ZS_SCRIPTS_DIR/proxy_fw
				if ! ls $C_SYSTEM/havp/redirects/* 2>/dev/null >/dev/null ; then
					/usr/bin/logger  -t proxy "WARNING: No HTTP capturing rules defined."
				fi
			fi
		fi
	fi
	if [ "$2" == "on-" ];then
		rm -f $C_ZT_CONF_DIR/squid.conf
		if [ -n "$C_DANSGUARDIAN" ];then
			SQUIDCONF="squid-dg.conf"
			CONTROL_DANS="yes"
		else
			SQUIDCONF="squid-only.conf"
		fi
		cp -f $C_ZT_PROXY_DIR/etc/squid/$SQUIDCONF $C_ZT_PROXY_DIR/etc/squid.conf
		$C_ZT_BIN_DIR/zt "InterSquid"
		if [ -z "$C_SQ_LOG"];then
			sed -i "s/^access_log/access_log none/g" $C_ZT_PROXY_DIR/etc/squid.conf
		else
			sed -i "s/^access_log/access_log syslog:daemon/g" $C_ZT_PROXY_DIR/etc/squid.conf
		fi
		if [[ "$(cat $C_SYSTEM/havp/WhiteList)" == "yes" && -n "$(cat /Database/var/register/system/havp/WhiteList.txt)" ]];then
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "acl blacklist" "$C_ZT_PROXY_DIR/etc/squid.conf"
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "http_access deny blacklist" "$C_ZT_PROXY_DIR/etc/squid.conf"
		fi
		if [[ "$(cat $C_SYSTEM/havp/WhiteList)" == "no" || -z "$(cat /Database/var/register/system/havp/WhiteList.txt)" ]];then
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "acl whitelist" "$C_ZT_PROXY_DIR/etc/squid.conf"
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "http_access deny !whitelist" "$C_ZT_PROXY_DIR/etc/squid.conf"
		fi
		if [ "$(cat $C_SYSTEM/havp/BlackList)" == "no" ];then
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "acl blacklist" "$C_ZT_PROXY_DIR/etc/squid.conf"
			$C_ZT_BIN_DIR/zt "RimuoviRiga" "http_access deny blacklist" "$C_ZT_PROXY_DIR/etc/squid.conf"
		fi
		if [ -z $(ls -d $C_ZT_PROXY_DIR/var/cache/squid/00) ];then
			$C_ZT_PROXY_DIR/sbin/squid -z 2>/dev/null >/dev/null
		fi
		$C_ZT_PROXY_DIR/sbin/squid -s >/dev/null 2>/dev/null
		if [[ -n "$CONTROL_DANS" && -n $(ps -A | grep squid) ]];then
			$C_ZT_PROXY_DIR/sbin/dansguardian
		fi
		$C_ZT_BIN_DIR/zt "Proxy_fw"
	fi
	if [ "$2" == "-on" ];then
		echo "yes" > $C_SYSTEM/havp/Enabled
		if [ -n "$C_DANSGUARDIAN" ];then
			$C_ZT_PROXY_DIR/sbin/dansguardian
			HAVPCONF="havp-dg.conf"
		else
			HAVPCONF="havp-only.conf"
		fi
		cp -f $C_ZT_PROXY_DIR/etc/havp/$HAVPCONF $C_ZT_PROXY_DIR/etc/havp.conf
		if [ "$(cat $C_SYSTEM/havp/BlackList)" == "no" ];then
			sed -i "s/^BLACKLIST.*/BLACKLIST \/dev\/null/g" $C_ZT_PROXY_DIR/etc/havp.conf
			echo ""
		fi
		if [ "$(cat $C_SYSTEM/havp/WhiteList)" == "no" ];then
			sed -i "s/^WHITELIST.*/WHITELIST \/dev\/null/g" $C_ZT_PROXY_DIR/etc/havp.conf
			echo ""
		fi
		if havp -c $C_ZT_PROXY_DIR/etc/havp.conf >/dev/null 2>/dev/null ; then
			$C_ZS_SCRIPTS_DIR/proxy_fw
			if ! ls $C_SYSTEM/havp/redirects/* 2>/dev/null >/dev/null ; then
				/usr/bin/logger -t proxy "WARNING: No HTTP capturing rules defined."
			fi
		else
			logger -t proxy "RESETTING VIRUS DATABASE."
			rm -rf $C_SYSTEM/ClamAV/db/
			mkdir -p $C_SYSTEM/ClamAV/db
			if ! cp /usr/local/share/clamav/main.cvd $C_SYSTEM/ClamAV/db ; then
				logger -t proxy "ERROR: Virus database corrupted. Check the profile disk space."
			fi
			chown -R havp $C_SYSTEM/ClamAV/db
			if havp -c $C_ZT_PROXY_DIR/etc/havp.conf >/dev/null 2>/dev/null ; then
				$C_ZS_SCRIPTS_DIR/proxy_fw
				if ! ls $C_SYSTEM/havp/redirects/* 2>/dev/null >/dev/null ; then
					/usr/bin/logger  -t proxy "WARNING: No HTTP capturing rules defined."
				fi
			fi
		fi
	fi
fi

if [ "$1" == "ConfigProxy" ];then
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
		rm -rf $C_ZT_PROXY_DIR/languages/havp/template
		cp -a $C_ZT_PROXY_DIR/languages/havp/$C_LANGUAGE $C_ZT_PROXY_DIR/languages/havp/template
		sed -i "s/ipcp/$IPCP/g" $C_ZT_PROXY_DIR/languages/havp/template/*.html
		sed -i "s/zerotruth/$C_HOTSPOT_NAME/g" $C_ZT_PROXY_DIR/languages/havp/template/*.html

		if [ -d $C_ZT_PROXY_DIR/languages/squid ];then
			rm -rf $C_ZT_PROXY_DIR/languages/squid/template
			cp -a $C_ZT_PROXY_DIR/languages/squid/$C_LANGUAGE $C_ZT_PROXY_DIR/languages/squid/template
			sed -i "s/ipcp/$IPCP/g" $C_ZT_PROXY_DIR/languages/squid/template/*
			sed -i "s/zerotruth/$C_HOTSPOT_NAME/g" $C_ZT_PROXY_DIR/languages/squid/template/*
		fi
		if [ -d $C_ZT_PROXY_DIR/languages/dansguardian ];then
			rm -rf $C_ZT_PROXY_DIR/languages/dansguardian/template
			cp -a $C_ZT_PROXY_DIR/languages/dansguardian/$C_LANGUAGE $C_ZT_PROXY_DIR/languages/dansguardian/template
			sed -i "s/ipcp/$IPCP/g" $C_ZT_PROXY_DIR/languages/dansguardian/template/template.html
			sed -i "s/zerotruth/$C_HOTSPOT_NAME/g" $C_ZT_PROXY_DIR/languages/dansguardian/template/template.html
		fi
fi

if [ "$1" == "RimuoviRiga" ];then
	sed -i "/^$2/d" $3
	sed -i "/^$/d" $3
fi
if [ "$1" == "RimuoviNumRiga" ];then
	sed -i "$2d" $3
	sed -i "/^$/d" $3
fi

if [ "$1" == "DelConnesso" ];then
	sed -i "/$2/d" $3
	sed -i "/^$/d" $3
fi

if [ "$1" == "UpdateClamav" ];then
	$C_ZS_SCRIPTS_DIR/ClamAV-Update
fi

if [ "$1" == "Esegui" ];then
	$2 "$3" "$4"
fi

if [ "$1" == "Bash" ];then
	COMAND=$(echo -e "$2" | sed 's/%2F/\//g' | sed 's/%22/\"/g' | sed 's/%7C/\|/g' | sed 's/%5C/\\/g'| sed 's/%3D/\=/g' | sed 's/%2C/\,/g' | sed 's/%3B/\;/g' | sed 's/%24/\$/g')
	HOSTN=$(echo $HOSTNAME | cut -d'.' -f1)
	DIR=$(cat /tmp/dirbash | sed 's/%2F/\//g' | sed 's/%22/\"/g' | sed 's/%7C/\|/g' | sed 's/%5C/\\/g'| sed 's/%3D/\=/g' | sed 's/%2C/\,/g' | sed 's/%3B/\;/g')
	if [[ -d "$DIR" && -z $(echo "$DIR" | grep '\.\.') ]];then
		DIRLINE=$(echo $DIR |  sed 's/\// /g' | awk '{print $NF}')
		echo -en "root@$HOSTN $DIRLINE>"
		if [ "$(echo "$COMAND" | awk '{print $1}')" != "cd" ];then
			echo " $COMAND"
		fi
		cd $DIR
		RESULT=$(echo -e "$(eval "$COMAND" | sed 's/</\&lt;/g' | sed 's/>/\&gt;/g' | sed 's/\\n/\&\#92;n/g' )")
		echo -e "$RESULT"
	else
		DIRORI=$(cat /tmp/dirbashori | sed 's/%2F/\//g' | sed 's/%22/\"/g' | sed 's/%7C/\|/g' | sed 's/%5C/\\/g'| sed 's/%3D/\=/g' | sed 's/%2C/\,/g' | sed 's/%3B/\;/g')
		DIRORI=$(echo $DIRORI |  sed 's/\// /g' | awk '{print $NF}')
		echo "root@$HOSTN $DIRORI>"
		echo "$(cat /tmp/dirbashori)" > /tmp/dirbash
		echo "No such directory ff"
	fi
fi

if [ "$1" == "PerFile" ];then
	chown $2:$2 $4
	chmod $3 $4
fi

if [ "$1" == "UpdateBlockHosts" ];then
	[ -z "$C_ACTIVE_AD" ] && exit
	/usr/local/bin/curl -l http://someonewhocares.org/hosts/ |  sed -n "/\;wiki-spam-sites/,/\/wiki-spam-sites/p"  > /tmp/blockhosts
	sed -i "/#./d" /tmp/blockhosts
	sed -i "/^$/d" /tmp/blockhosts
	sed -i "1 i ##### BLOCKED HOSTS #####" /tmp/blockhosts
	echo "##### END BLOCKED HOSTS #####" >> /tmp/blockhosts
	if [ -n "$(cat /etc/hosts | grep 'END')" ];then
		cat /etc/hosts | sed -n "/END/,//p" | sed "/END/d" >> /tmp/blockhosts
	else
		cat /etc/hosts >> /tmp/blockhosts
	fi
	mv /tmp/blockhosts /etc/hosts
	if [ -z "$(cat $C_ZT_CONF_DIR/zt.config | grep "C_UPDATES_AD")" ];then
		$C_ZT_BIN_DIR/zt "Aggiungi" "C_UPDATES_AD=\"\"" "$C_ZT_CONF_DIR/zt.config"
	fi
	TD=$(date '+%s')
	sed -i "s/^C_UPDATES_AD=.*/C_UPDATES_AD=\"$TD\"/g" $C_ZT_CONF_DIR/zt.config
	exit
fi

if [ "$1" == "CreaCartellaBk" ];then
	mkdir $2
	chown root:root $2
	chmod -R 777 $C_ZT_DIR/tmp
	exit
fi

if [ "$1" == "OpenBk" ];then
	cd $C_ZT_DIR/tmp/restorebk
	FILE_BK="$(ls *.tgz)"
	tar zxvf $FILE_BK 2> /dev/null >/dev/null
	rm -rf $FILE_BK
	DIRBK="$(ls)"
	DATEBK="$(ls | cut -d'_' -f2)"
	mv $DIRBK backup_$DATEBK
	exit
fi

if [ "$1" == "DeleteDataBk" ];then
	if [ "$2" == "yes" ];then
		PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid )
		USERPEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
		START="START"
		STOP="STOP"
		for USERDEL in $USERPEOPLE;do
			if [ "$USERDEL" != "admin" ];then
				if [ -d $C_CRON_SCRIPTS_DIR/ZT$USERDEL$STOP-Cron ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT$USERDEL$STOP-Cron"
					$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT$USERDEL$START-Cron"
				fi
				LINE=$(/usr/local/bin/ldapsearch  -xLLL  -b  "ou=People,$C_LDAPBASE"  uid=$USERDEL givenName sn)
				NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g' | sed 's/ /_/g')
				LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g'  | sed 's/ /_/g')
				/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERDEL,ou=People,$C_LDAPBASE" 2> /dev/null >/dev/null
				/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERDEL,ou=Radius,$C_LDAPBASE" 2> /dev/null >/dev/null
				CONNECTED=$(ls $C_CP_DIR/Connected )
				if [ -n "$CONNECTED" ];then
					for IP in "$CONNECTED";do
						if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERDEL" ];then
							$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDEL"
						fi
					done
				fi
				if [ -d $C_ACCT_DIR/entries/$USERDEL/sessions  ];then
					TODAY=$(date +%d%m%Y)
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"

					$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERDEL" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
					if [ -n $(ls $C_ZT_DIR/expired/$USER_EX/sessions 2> /dev/null) ];then
						if ! [ -d $C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY ];then
							$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"
						fi
						$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ZT_DIR/expired/$USERDEL" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"
						if  [ -d $C_ZT_DIR/expired/$USERDEL ];then
							$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USERDEL"
						fi
					fi
					if [ -f $C_ACCT_DIR/credits/$USERDEL/Credit ];then
						$C_ZT_BIN_DIR/zt "Copia" "$C_ACCT_DIR/credits/$USERDEL/Credit" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY/Credit"
					fi
				fi
				if [ -d $C_ACCT_DIR/entries/$USERDEL ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
				fi
				if [ -d $C_ACCT_DIR/credits/$USERDEL ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERDEL"
				fi
				$C_ZT_BIN_DIR/zt "DelK5" "$USERDEL" 2> /dev/null >/dev/null
			fi
		done
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
	if [ "$3" == "yes" ];then
		for PROGDIR in $(ls $C_SYSTEM/startup/scripts/);do
			if [[ "$PROGDIR" != "ZTcontrol-Cron" && "$PROGDIR" != "ZTunlockclientday-Cron" && "$PROGDIR" != "ZTunlockclientmonth-Cron" && "$PROGDIR" != "postboot" ]];then
				rm -rf $C_SYSTEM/startup/scripts/$PROGDIR
			fi
		done
	fi
	if [ "$4" == "yes" ];then
		for SESSDIR in $(ls $C_ACCT_DIR/entries/);do
			rm -rf $C_ACCT_DIR/entries/$SESSDIR
		done
	fi
	if [ "$5" == "yes" ];then
		for CLASSDIR in $(ls $C_CLASSES_DIR/);do
			rm -rf $C_CLASSES_DIR/$CLASSDIR
		done
	fi
	if [ "$6" == "yes" ];then
		for CLIENTDIR in $(ls $C_CP_DIR/FreeClients/);do
			$C_ZT_BIN_DIR/zt "RemoveFreeClient" "$CLIENTDIR"
			rm -rf $C_CP_DIR/FreeClients/$CLIENTDIR
		done
	fi
	if [ "$7" == "yes" ];then
		for SERVICESDIR in $(ls $C_CP_DIR/FreeServices/);do
			$C_ZT_BIN_DIR/zt "RemoveFreeService" "$SERVICESDIR"
			rm -rf $C_CP_DIR/FreeServices/$SERVICESDIR
		done
	fi
fi

if [ "$1" == "RestoreUsers" ];then
	sed -i "s/dn: uid=admin/rOl9jhyYtgbvCF/g" $C_ZT_DIR/tmp/restorebk/$2/ldap_ldif
	sed -i "s/^$/## END/g" $C_ZT_DIR/tmp/restorebk/$2/ldap_ldif
	echo "ENDFILE" >> $C_ZT_DIR/tmp/restorebk/$2/ldap_ldif
	cat $C_ZT_DIR/tmp/restorebk/$2/ldap_ldif | sed -n "/^dn: uid=/,/^ENDFILE/p"  >  /tmp/LDAP_FILE
	sed -i "/^ENDFILE/d" /tmp/LDAP_FILE
	sed -i "/^$/d" /tmp/LDAP_FILE
	BASE=$(cat /tmp/LDAP_FILE | grep  "dn: uid" | tail -1)
	LDAPBASE="$(echo "$BASE" | cut -d',' -f3),$(echo "$BASE" | cut -d',' -f4)"
	if [ "$LDAPBASE" != "$C_LDAPBASE" ];then
		sed -i "s/$LDAPBASE/$C_LDAPBASE/g" /tmp/LDAP_FILE
	fi
	N_USERS=$(cat /tmp/LDAP_FILE | grep 'dn: uid' | wc -l)
	for NR in $(seq 1 $N_USERS);do
		USER="$(cat /tmp/LDAP_FILE | grep 'dn: uid' | cut -d'=' -f2 | cut -d',' -f1 | /bin/sed -n "${NR}p")"
		LINE=$(/usr/local/bin/ldapsearch  -xLLL  -b  "ou=People,$C_LDAPBASE"  uid=$USER uid )
		USERLOCAL=$( echo "$LINE" | grep -e '^uid: ' | sed 's/^uid: //g' )
		cat /tmp/LDAP_FILE | sed -n "/^dn: uid=$USER\,/,/^## END/p"  > /tmp/LDAP_PEOPLE_$USER
		sed -i "/^## /d" /tmp/LDAP_PEOPLE_$USER
		NAME=$( cat /tmp/LDAP_PEOPLE_$USER | grep -e '^givenName: ' | sed 's/^givenName: //g' )
		LAST_NAME=$( cat /tmp/LDAP_PEOPLE_$USER | grep -e '^sn: ' | sed 's/^sn: //g' )
		cat /tmp/LDAP_FILE | sed -n "/^dn: cn=$USER\,/,/^## END/p"  > /tmp/LDAP_RADIUS_$USER
		sed -i "/^## /d" /tmp/LDAP_RADIUS_$USER
		if [ -n "$USERLOCAL" ];then
			for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp" "uidNumber" "gidNumber" "objectClass" \
				"cn" "o" "uidNumber" "homeDirectory" "loginShell" "entryCSN" "modifiersName" "modifyTimestamp";do
				sed -i "/^$RR\:/d" /tmp/LDAP_PEOPLE_$USER
			done
			sed -i "/^$/d" /tmp/LDAP_PEOPLE_$USER
			cat /tmp/LDAP_PEOPLE_$USER | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 2>/dev/null >/dev/null ||  CONTROL_ERROR="yes"
			for RR in "structuralObjectClass" "objectClass" "entryUUID" "creatorsName" "createTimestamp" "dialupAccess" \
				"entryCSN" "modifiersName" "modifyTimestamp";do
				sed -i "/^$RR\:/d" /tmp/LDAP_RADIUS_$USER
			done
			sed -i "/^$/d" /tmp/LDAP_RADIUS_$USER
			cat /tmp/LDAP_RADIUS_$USER | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 2>/dev/null >/dev/null || CONTROL_ERROR="yes"
			echo "<tr><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td>&nbsp;$NAME</td><td>&nbsp;$LAST_NAME</td><td>"
			if [ "$CONTROL_ERROR" != "yes" ];then
				PASSWORD=$(cat /tmp/LDAP_RADIUS_$USER | grep "sn:" | cut -d' ' -f2 | cut -d'-' -f1)
				SHADOWEXPIRE=$(cat /tmp/LDAP_PEOPLE_$USER | grep "shadowExpire:" | cut -d' ' -f2 )
				EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y-%m-%d)
				$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USER" "$EXPIRE" > /dev/null
				echo "&nbsp;$L_UPDATED"
			else
				echo "<font color=\"red\">$L_NOT_UPDATED $CONTROL_ERROR</font>"

			fi
			echo "</td></tr>"
		else
			for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp"  \
				"entryCSN" "modifiersName" "modifyTimestamp" "uidNumber" ;do
				sed -i "/^$RR\:/d" /tmp/LDAP_PEOPLE_$USER
			done
			sed -i "/^$/d" /tmp/LDAP_PEOPLE_$USER
			UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE"  uidNumber |  sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n |  tail -1 )
			UIDNUMBER=$(($UIDN+1))
			echo "uidNumber: $UIDNUMBER" >> /tmp/LDAP_PEOPLE_$USER
			cat /tmp/LDAP_PEOPLE_$USER | /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 2>/dev/null >/dev/null || CONTROL_ERROR="yes"
			for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp"  \
				"entryCSN" "modifiersName" "modifyTimestamp";do
				sed -i "/^$RR\:/d" /tmp/LDAP_RADIUS_$USER
			done
			sed -i "/^$/d" /tmp/LDAP_RADIUS_$USER
			cat /tmp/LDAP_RADIUS_$USER | /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 2>/dev/null >/dev/null || CONTROL_ERROR="yes"
			echo "<tr><td align=\"center\">$NR</td><td>&nbsp;$USER</td><td>&nbsp;$NAME</td><td>&nbsp;$LAST_NAME</td><td>"
			if [ "$CONTROL_ERROR" != "yes" ];then
				PASSWORD=$(cat /tmp/LDAP_RADIUS_$USER | grep "sn:" | cut -d' ' -f2 | cut -d'-' -f1)
				SHADOWEXPIRE=$(cat /tmp/LDAP_PEOPLE_$USER | grep "shadowExpire:" | cut -d' ' -f2 )
				EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y-%m-%d)
				$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USER" "$EXPIRE" > /dev/null
				echo "&nbsp;$L_ADDED"
			else
				echo "&nbsp;<font color=\"red\">$L_NOT_ADDED</font>"
			fi
			echo "</td></tr>"
		fi
		rm -rf /tmp/LDAP_PEOPLE_$USER
		rm -rf /tmp/LDAP_RADIUS_$USER
		CONTROL_ERROR=""
		NR=$(($NR+1))
	done
	rm -rf /tmp/LDAP_FILE
	exit
fi

if [ "$1" == "RestoreClasses" ];then
	NC=1
	for CLASSDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/classes/);do
		[ -d $C_CLASSES_DIR/$CLASSDIR ] && CONTROL="yes"
			cp -a $C_ZT_DIR/tmp/restorebk/$2/classes/$CLASSDIR $C_CLASSES_DIR/$CLASSDIR
			echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$CLASSDIR</td><td>"
			if [ "$CONTROL" != "yes" ];then
				echo "&nbsp;$L_ADDED"
			else
				echo "&nbsp;$L_UPDATED"
			fi
			echo "</td></tr>"
			NC=$(($NC+1))
	done
	exit
fi
if [ "$1" == "RestoreLogMudc" ];then
	N=0
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudclog/);do
		if [ -n "$DATAFILE" ];then
			if [[ "$DATAFILE" != "Graphs" && "$DATAFILE" != "Sessions" ]];then
				N=$(($N + 1))
				cp -f $C_ZT_DIR/tmp/restorebk/$2/mudclog/$DATAFILE $C_ZT_DIR/mudc/log/
				echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
			fi
		fi
	done
	exit
fi

if [ "$1" == "RestoreConfigMudc" ];then
	N=0
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudcconf);do
		if [ -n "$DATAFILE" ];then
			if [ "$DATAFILE" != "ssh" ];then
				N=$(($N + 1))
				cp -f $C_ZT_DIR/tmp/restorebk/$2/mudcconf/conf/$DATAFILE $C_ZT_DIR/mudc/conf/
				echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
			fi
		fi
	done
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudcconf/mudcconf/ssh/);do
		if [ -n "$DATAFILE" ];then
			[ ! -d  $C_ZT_DIR/mudc/conf/ssh ] && mkdir $C_ZT_DIR/mudc/conf/ssh
			N=$(($N + 1))
			cp -f $C_ZT_DIR/tmp/restorebk/$2/mudcconf/ssh/$DATAFILE $C_ZT_DIR/mudc/conf/ssh/
			echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
	done
fi
if [ "$1" == "RestoreGraphsMudc" ];then
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudcgraphs/);do
		if [ -n "$DATAFILE" ];then
			cp -f $C_ZT_DIR/tmp/restorebk/$2/mudcgraphs/$DATAFILE $C_ZT_DIR/mudc/data/Graphs/$DATAFILE
			echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
	done
fi
if [ "$1" == "RestoreSessionsMudc" ];then
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudcsessions/);do
		if [ -n "$DATAFILE" ];then
			N=$(($N + 1))
			cp -a -f $C_ZT_DIR/tmp/restorebk/$2/mudcsessions/$DATAFILE $C_ZT_DIR/mudc/data/Sessions/
			echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
	done
fi
if [ "$1" == "RestoreProgMudc" ];then
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudcprog/);do
		if [ -n "$DATAFILE" ];then
			N=$(($N + 1))
			cp -a -f $C_ZT_DIR/tmp/restorebk/$2/mudcprog/$DATAFILE $C_ZT_DIR/mudc/data/Prog/
			echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
	done
	for DATAFILE in $(ls -A $C_ZT_DIR/tmp/restorebk/$2/mudccron/);do
		if [ -n "$DATAFILE" ];then
			N=$(($N + 1))
			cp -a -f $C_ZT_DIR/tmp/restorebk/$2/mudccron/$DATAFILE $C_CRON_SCRIPTS_DIR/
			echo "<tr><td>$N</td><td>$DATAFILE</td><td>&nbsp;$L_UPDATED</td></tr>"
			CONTROLCRON="yes"
		fi
	done			
	if [ -n "$CONTROLCRON" ];then
		$C_ZT_BIN_DIR/zt  "KillProg" "cron"
		rm -f /var/run/cron.pid
		/etc/init.d/crond start >/dev/null
	fi	
fi

if [ "$1" == "RestoreFreeClients" ];then
	ND=0
	for CLIENTDIR in $(ls $C_CP_DIR/FreeClients/);do
		NEWDIR="$(echo $((1000+$ND)))"
		IPCLIENT="$(cat $C_CP_DIR/FreeClients/$CLIENTDIR/IP)"
		MACCLIENT="$(cat $C_CP_DIR/FreeClients/$CLIENTDIR/MAC)"
		CONTROLIP="$CONTROLIP+$IPCLIENT-$MACCLIENT+"
		mv $C_CP_DIR/FreeClients/$CLIENTDIR $C_CP_DIR/FreeClients/$NEWDIR
		ND="$(($ND+1))"
	done
	for CLIENTDIR in $(ls $C_CP_DIR/FreeClients/);do
		NEWDIR="$( echo $CLIENTDIR | sed 's/^1//g')"
		mv $C_CP_DIR/FreeClients/$CLIENTDIR $C_CP_DIR/FreeClients/$NEWDIR
	done
	NC=1
	for CLIENTDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/FreeClients/);do
		IPCLIENT="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeClients/$CLIENTDIR/IP)"
		MACCLIENT="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeClients/$CLIENTDIR/MAC)"
		DESC="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeClients/$CLIENTDIR/Desc)"
		CONTROLIPMAC="$IPCLIENT-$MACCLIENT"
		if [ -z "$(echo "$CONTROLIP" | grep "+$CONTROLIPMAC+")" ];then
			$C_ZT_BIN_DIR/zt "AddFreeClient" "$DESC" "$IPCLIENT" "$MACCLIENT"
			echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$DESC</td><td>&nbsp;$L_ADDED</td></tr>"
		else
			echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$DESC</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
		NC=$(($NC+1))
	done
	exit
fi

if [ "$1" == "RestoreFreeServices" ];then
	ND=0
	for SERVICEDIR in $(ls $C_CP_DIR/FreeServices/);do
		NEWDIR="$(echo $((100+$ND)))"
		IPSERVICE="$(cat $C_CP_DIR/FreeServices/$SERVICEDIR/IP)"
		PORTSERVICE="$(cat $C_CP_DIR/FreeServices/$SERVICEDIR/Port)"
		PROTOSERVICE="$(cat $C_CP_DIR/FreeServices/$SERVICEDIR/Proto)"
		CONTROLIP="$CONTROLIP+$IPSERVICE-$PORTSERVICE-$PROTOSERVICE+"
		mv $C_CP_DIR/FreeServices/$SERVICEDIR $C_CP_DIR/FreeServices/$NEWDIR
		ND=$(($ND+1))
	done
	for SERVICEDIR in $(ls $C_CP_DIR/FreeServices/);do
		NEWDIR="$(echo $SERVICEDIR | sed 's/^1//g')"
		mv $C_CP_DIR/FreeServices/$SERVICEDIR $C_CP_DIR/FreeServices/$NEWDIR
	done
	NC=1
	for SERVICEDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/FreeServices);do
		IPSERVICE="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeServices/$SERVICEDIR/IP)"
		PORTSERVICE="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeServices/$SERVICEDIR/Port)"
		PROTOSERVICE="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeServices/$SERVICEDIR/Proto)"
		DESC="$(cat $C_ZT_DIR/tmp/restorebk/$2/FreeServices/$SERVICEDIR/Desc)"
		CONTROL="$IPSERVICE-$PORTSERVICE-$PROTOSERVICE"
		if [ -z "$(echo "$CONTROLIP" | grep "+$CONTROL+")" ];then
			$C_ZT_BIN_DIR/zt "AddFreeService" "$DESC" "$IPSERVICE" "$PORTSERVICE" "$PROTOSERVICE"
			echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$DESC</td><td>&nbsp;$L_ADDED</td></tr>"
		else
			echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$DESC</td><td>&nbsp;$L_UPDATED</td></tr>"
		fi
		NC=$(($NC+1))
	done
	exit
fi

if [ "$1" == "RestoreProg" ];then
	NP=1
	for PROGDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/prog/);do
		if [[ "$PROGDIR" != "ZTcontrol-Cron" && "$PROGDIR" != "ZTunlockclientday-Cron" && "$PROGDIR" != "ZTunlockclientmonth-Cron" && "$PROGDIR" != "postboot" ]];then
			[ -d $C_SYSTEM/startup/scripts/$PROGDIR ] && CONTROL="yes"
			cp -a $C_ZT_DIR/tmp/restorebk/$2/prog/$PROGDIR  $C_SYSTEM/startup/scripts/$PROGDIR
			echo "<tr><td align=\"center\">$NP</td><td>&nbsp;$PROGDIR</td><td>"
			if [ "$CONTROL" != "yes" ];then
				echo "&nbsp;$L_ADDED"
			else
				echo "&nbsp;$L_UPDATED"
			fi
			echo "</td></tr>"
			NP=$(($NP+1))
			CONTROL=""
		fi
	done
	$C_ZT_BIN_DIR/zt "RestartCron"
	exit
fi

if [ "$1" == "RestoreSessions" ];then
	NS=1
	for SESSDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/sessions/);do
		if [[ "$SESSDIR" != "deleted" && "$SESSDIR" != "expired" ]];then
			if ! [ -d $C_ACCT_DIR/entries/$SESSDIR ];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/entries/$SESSDIR"
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/entries/$SESSDIR/sessions"
			fi
			for SESSIONDIR in $(ls $C_ZT_DIR/tmp/restorebk/$2/sessions/$SESSDIR/sessions/ );do
				[ -d $C_ACCT_DIR/entries/$SESSDIR/sessions/$SESSIONDIR ] && CONTROL="yes"
				cp -a $C_ZT_DIR/tmp/restorebk/$2/sessions/$SESSDIR/sessions/$SESSIONDIR $C_ACCT_DIR/entries/$SESSDIR/sessions/$SESSIONDIR
				echo "<tr><td align=\"center\">$NS</td><td>&nbsp;$SESSDIR</td><td>&nbsp;$SESSIONDIR</td><td>"
				if [ "$CONTROL" != "yes" ];then
					echo "&nbsp;$L_ADDED"
				else
					echo "&nbsp;$L_UPDATED"
				fi
				echo "</td></tr>"
				NS=$(($NS+1))
				CONTROL=""
			done
		fi
	done
	exit
fi

if [ "$1" == "RestoreConfig" ];then
	NC=1
	for CONFBK in "emailh" "msmtprc" "ppnotice" "banmac" "cbqconf" "emailf" "infoTicket" "ppbutton" "privacy" "tmp_banmac" "zt.config";do
		cp -f $C_ZT_DIR/tmp/restorebk/$2/conf/$CONFBK $C_ZT_CONF_DIR/$CONFBK
		chmod 666 $C_ZT_CONF_DIR/$CONFBK
		echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$CONFBK</td><td>&nbsp;$L_UPDATED</td></tr>"
		NC=$(($NC+1))
	done
	for CONFBKCUSTOM in $(ls $C_ZT_DIR/tmp/restorebk/$2/Custom);do
		cp -f $C_ZT_DIR/tmp/restorebk/$2/Custom/$CONFBKCUSTOM $C_CP_DIR/Auth/Custom/
		chmod 666 $C_CP_DIR/Auth/Custom/$CONFBKCUSTOM
		echo "<tr><td align=\"center\">$NC</td><td>&nbsp;$CONFBKCUSTOM</td><td>&nbsp;$L_UPDATED</td></tr>"
		NC=$(($NC+1))
	done
	sed -i "s/^C_ADMIN_COOKIE=.*/C_ADMIN_COOKIE=\"$C_ADMIN_COOKIE\"/g" $C_ZT_CONF_DIR/zt.config
	CC="$($C_ZT_BIN_DIR/cc)"
	if [ "$CC" == "yes" ];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CODE" "$C_CODE"	
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_CODE_LOCAL" "$C_CODE_LOCAL"
		cp -f $C_ZT_DIR/tmp/restorebk/$2/images/imguser.png $C_HTDOCS_DIR/images/imguser.png
		chmod 666 $C_HTDOCS_DIR/images/imguser.png
		cp -f $C_ZT_DIR/tmp/restorebk/$2/images/base.png $C_HTDOCS_DIR/images/base.png
		chmod 666 $C_HTDOCS_DIR/images/base.png
		rm -rf $C_HTDOCS_DIR/images/popup
		rm -rf $C_HTDOCS_DIR/images/wg
		rm -rf $C_HTDOCS_DIR/images/imglogin
		cp -a $C_ZT_DIR/tmp/restorebk/$2/images/popup $C_HTDOCS_DIR/images/
		chmod 666 $C_HTDOCS_DIR/images/popup/*
		cp -a $C_ZT_DIR/tmp/restorebk/$2/images/wg $C_HTDOCS_DIR/images/
		chmod 666 $C_HTDOCS_DIR/images/wg/*
		cp -a $C_ZT_DIR/tmp/restorebk/$2/images/imglogin $C_HTDOCS_DIR/images/
		chmod 666 $C_HTDOCS_DIR/images/imglogin/*
	fi
	source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
	$C_ZT_BIN_DIR/zt "AggOrologio"
	$C_ZT_BIN_DIR/zt "Cancella" "$C_CP_DIR/msg/custom/*"
	$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_ZT_DIR/msg/$C_LANGUAGE/*" "$C_CP_DIR/msg/custom/"
	$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_ZT_DIR/havp/$C_LANGUAGE/*" "$C_HTDOCS_ZT_DIR/havp/template/"
	$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_ZT_DIR/squid/$C_LANGUAGE/*" "$C_HTDOCS_ZT_DIR/squid/template/"
	$C_ZT_BIN_DIR/zt "ConfigProxy" "ipcp"
	for dc in $(ls $C_CLASSES_DIR);do
		if [[ $(cat $C_CLASSES_DIR/$dc/ChargeType) == "pre" && -n "$C_ACTIVE_PP" ]];then
			$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/ChargePayPal"
			CONTROLPRE="ok"
		fi
	done
	if [ -z "$CONTROLPRE" ];then
		$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/ChargePayPal"
	fi
	if [ -n "$AUTO_REGISTER" ];then
		$C_ZT_BIN_DIR/zt "Salva" "yes" "$C_CP_DIR/Auth/Custom/Registered"
	else
		$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/Registered"
	fi
	if [[ $(cat $C_CLASSES_DIR/$AR_CLASS/ChargeType) == "pre" && -z "$C_ACTIVE_PP" ]];then
		$C_ZT_BIN_DIR/zt "Salva" " " "$C_CP_DIR/Auth/Custom/Registered"
	fi
	if [ "$C_ACTIVE_CP" == "on" ];then
		$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-on" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
	else
		$C_ZT_BIN_DIR/zt "Copia" "$C_HTDOCS_TEMPLATE_DIR/cp_showauth_custom-off" "$C_CP_DIR/Auth/Template/cp_showauth_custom"
	fi
	INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
	CONTROLV=$(echo "$INTERFACECP" | cut -sd'.' -f2)
	if [ -n "$CONTROLV" ];then
		INTERFACE=$(echo "$INTERFACECP" | cut -d'.' -f1)
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP)
		$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
	else
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
		$C_ZT_BIN_DIR/zt "SLink" "$C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP" "$C_CP_DIR/Auth/Custom/IP"
	fi
	$C_ZT_BIN_DIR/zt "BottonCp" "$IPCP"
	exit
fi

if [ "$1" == "PermCartella" ];then
	chmod "$2" "$3"
	chown root:root "$3"
	exit
fi

if [ "$1" == "PermFiles" ];then
	chmod "$2" "$3"
	exit
fi

if [ "$1" == "ProFile" ];then
	chown "$2" "$3"
	exit
fi

if [ "$1" == "CreaLog" ];then
	if ! [ -d $C_ZT_LOG_DIR/users ];then
		mkdir $C_ZT_LOG_DIR/users
		chown -R root:root $C_ZT_LOG_DIR/users
		chmod -R 777 $C_ZT_LOG_DIR/users
	fi
	if ! [ -d $C_ZT_LOG_DIR/users/$2 ];then
		mkdir $C_ZT_LOG_DIR/users/$2
	fi
	if ! [ -f $C_ZT_LOG_DIR/users/$2/$2_log ];then
		touch $C_ZT_LOG_DIR/users/$2/$2_log
	fi
	chown -R root:root $C_ZT_LOG_DIR/users/$2
	chmod -R 777 $C_ZT_LOG_DIR/users/$2
	exit
fi

if [ "$1" == "AddLog" ];then
	USERLOG="$2"
	if [ "$2" == "$C_ADMIN" ];then
		USERLOG="admin"
	fi
	if [ -f $C_ZT_LOG_DIR/users/$USERLOG/${USERLOG}_log ];then
		echo "$(date +%s)-$3" >> $C_ZT_LOG_DIR/users/$USERLOG/${USERLOG}_log
	fi
	sed -i "/^$/d" $C_ZT_LOG_DIR/users/$USERLOG/${USERLOG}_log
	chown -R root:root $C_ZT_LOG_DIR/users/$USERLOG
	chmod -R 777 $C_ZT_LOG_DIR/users/$USERLOG
	logger -t "ZT.$2" "$3"
	exit
fi

if [ "$1" == "ScaricaChecksum" ];then
	if `wget -N -P $2 $3 2>/dev/null` ;then
		echo ""
	else
		rm -rf $2
		echo "<script language=\"JavaScript\" type=\"text/javascript\">
		setTimeout('top.location.href=(window.location.href=\"config.sh?SECTION=UPGRADE_ZT_ERROR\")',\"50\")
		</script>"
		exit
	fi
	exit
fi

if [ "$1" == "ScaricaUpgrade" ];then
	if `wget -N -P $2 $3 2>/dev/null`;then
		chown root:root $2/$4
		chmod 755 $2/$4
		CONTROL_CHECKSUM=$(md5sum $2/$4)
		CONTROL_CHECKSUM=$( echo $CONTROL_CHECKSUM | awk '{print $1}')
		CONTROL_CHECKSUM_DOWN=$(cat $2/checksum |  awk '{print $1}')
		if [ "$CONTROL_CHECKSUM_DOWN" != "$CONTROL_CHECKSUM" ];then
			rm -rf $2
			echo "error" > /tmp/checksum
			exit
		fi
		echo "$C_CODE" > /tmp/CODE
		[ -d /tmp/oldzt ] && rm -rf /tmp/oldzt
		mkdir /tmp/oldzt
		cp -a $C_ZT_DIR/conf /tmp/oldzt
		cp -a $C_ZT_DIR/proxy /tmp/oldzt
		[ -d $C_ZT_DIR/expired ] && cp -a $C_ZT_DIR/expired /tmp/oldzt
		cp -a $C_HTDOCS_DIR/images /tmp/oldzt
		cp $C_HTDOCS_DIR/walledgarden.html /tmp/oldzt
		cp $C_HTDOCS_DIR/popup.html /tmp/oldzt
		tar zxvf $2/$4 -C $2 >/dev/null
		NEWZT=$(echo $4 | sed 's/.tar.gz//g')
		[ -d /DB/$NEWZT ] && rm -rf /DB/$NEWZT
		mkdir /DB/$NEWZT
		cp -a $2/$NEWZT/uninstall.sh /DB/$NEWZT
		tar zxvf $2/$NEWZT/zerotruth.tar.gz -C / >/dev/null
		tar zxvf $2/$(echo zerotruth-2.0.tar.gz | sed 's/.tar.gz//g')/zerotruth.tar.gz -C / >/dev/null

		cp -f /tmp/oldzt/images/imguser.png $C_HTDOCS_DIR/images/imguser.png
		cp -f /tmp/oldzt/images/base.png $C_HTDOCS_DIR/images/base.png
		cp -a -f /tmp/oldzt/images/wg $C_HTDOCS_DIR/images
		cp -a -f /tmp/oldzt/images/popup $C_HTDOCS_DIR/images
		cp -a -f /tmp/oldzt/images/imglogin $C_HTDOCS_DIR/images
		cp -a -f /tmp/oldzt/proxy $C_ZT_DIR

		rm -rf $2/$4
		rm -rf $2/checksum

		if [ -z "$5" ];then
			sed -i "/^#/d" /tmp/oldzt/conf/zt.config
			sed -i "/^$/d" /tmp/oldzt/conf/zt.config
			RIGHE=$(cat /tmp/oldzt/conf/zt.config | wc -l | awk '{print $1}')
			for R in $(seq 1 $RIGHE);do
				RIGA="$(cat /tmp/oldzt/conf/zt.config | sed -n "${R}p")"
				VAR=$(echo "$RIGA" | cut -d'=' -f1)
				if [ "$VAR" != "C_CURRENCY" ];then
					sed -i "s/^$VAR\=.*/$RIGA/g" $C_ZT_CONF_DIR/zt.config
				fi
			done
			for CONF in $(ls /tmp/oldzt/conf);do
				if [[ "$CONF" != "version" && "$CONF" != "zt.config" ]];then
					cp -a /tmp/oldzt/conf/$CONF /DB/apache2/cgi-bin/zerotruth/conf/$CONF
				fi
			done
		fi
		rm -rf /tmp/oldzt
		source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
		chown root:root $C_ZT_BIN_DIR/*
		chmod 755 $C_ZT_BIN_DIR/*
		chmod 4755 $C_ZT_BIN_DIR/zt
		chmod 4755 $C_ZT_BIN_DIR/zt
		chmod 777 $ZT_DIR/tmp
		ln -f -s $C_ZT_DIR/registerasterisk.sh $C_HTDOCS_ZT_DIR/cgi-bin/registerasterisk.sh
		ln -f -s $C_ZT_DIR/unlockasterisk.sh $C_HTDOCS_ZT_DIR/cgi-bin/unlockasterisk.sh
		ln -f -s $C_ZT_DIR/forgotasterisk.sh $C_HTDOCS_ZT_DIR/cgi-bin/forgotasterisk.sh
		if [ -n "$6" ];then
			PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid)
			USERPEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
			for USERDEL in $USERPEOPLE;do
				if [ "$USERDEL" != "admin" ];then
					LINE=$(/usr/local/bin/ldapsearch  -xLLL  -b  "ou=People,$C_LDAPBASE"  uid="$USERP" givenName sn)
					NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g' )
					LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g' )
					if [ -d $C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron ];then
						$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron"
						$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}START-Cron"
						CONTROL_CRON="yes"
					fi
					/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERDEL,ou=People,$C_LDAPBASE" > /dev/null
					/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERDEL,ou=Radius,$C_LDAPBASE" > /dev/null
					CONNECTED=$(ls $C_CP_DIR/Connected )
					for IP in "$CONNECTED";do
						if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERDEL" ];then
							$C_ZT_BIN_DIR/zt "Disconnetti" "$IP" "$USERDEL"
						fi
					done
					if [ -n $(ls $C_ACCT_DIR/entries/$USERDEL/sessions 2> /dev/null) ];then
						NAME=$(echo "$NAME" | sed '/ /s///g' | sed 's/ /_/g')
						LAST_NAME=$(echo "$LAST_NAME" | sed '/ /s///g' |  sed 's/ /_/g')
						TODAY=$(date +%d%m%Y)
						$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"
						$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERDEL" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY"
						$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
						$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERDEL"
						$C_ZT_BIN_DIR/zt "DelK5" "$USERDEL"
						[ -n "$CONTROL_CRON" ] && $C_ZT_BIN_DIR/zt "RestartCron"
					fi
				fi
			done
		fi
		#da 2.0 a 2.1 nuovo ldap
		/etc/init.d/ldap restart
		TODAY=$(date +%s)
		TODAY=$(($TODAY/86400))
		PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE"  uid )
		USERPEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
		for USERNAME in $USERPEOPLE;do
			QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME sn radiusUserCategory)
			CLASS=$(echo "$QUERY" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
			PASSWORD=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
			if [ -z "$CLASS" ];then
				CLASS="DEFAULT"
			fi
			if [ -d $C_ACCT_DIR/entries/$USERNAME/sessions ];then
				NSESSIONS=`ls $C_ACCT_DIR/entries/$USERNAME/sessions/ | wc -l`
				if [ -d $C_ZT_DIR/expired/$USER/$USERNAME/sessions ];then
					NSESSIONS_EXP=`ls $C_ZT_DIR/expired/$USER/$USERNAME/sessions/ | wc -l`
				else
					NSESSIONS_EXP=0
				fi
				NSESSIONS=$(($NSESSIONS+$NSESSIONS_EXP))
			else
				NSESSIONS=0
			fi
			VALIDITY="yes"
			CONTROL_EX=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME shadowExpire  | grep -e '^shadowExpire: ' | sed 's/^shadowExpire: //g')
			if [[ -n "$CONTROL_EX" && $TODAY -gt $CONTROL_EX ]];then
				VALIDITY="E"
			fi
			CL=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME radiusUserCategory  | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')
			if [ -f $C_ACCT_DIR/classes/$CL/ChargeType ];then
				if [ "$(cat $C_ACCT_DIR/classes/$CL/ChargeType)" == "pre" ];then
					CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit)
					CHARGETYPE=$(cat $C_ACCT_DIR/classes/$CL/ChargeType)
					FREETIME=$(cat $C_ACCT_DIR/classes/$CL/FreeTime)
					if [[  -z "$CREDIT" || "$CREDIT" == "0.00" || $(echo "$CREDIT" | grep '^-') ]] && [ "$CREDIT" != "freetime" ];then
						VALIDITY="C"
					fi
				fi
			fi
			if [ -f $C_ACCT_DIR/entries/$USERNAME/Time ] && [ -f $C_ACCT_DIR/classes/$CL/Hours ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/Hours)" ];then
				TIME=$(cat $C_ACCT_DIR/entries/$USERNAME/Time)
				LIMITH=$(cat $C_ACCT_DIR/classes/$CL/Hours)
				LIMITH=$(($LIMITH*3600))
				if [ $TIME -gt $LIMITH ];then
					VALIDITY="T"
				fi
			fi
			if [ -f $C_ACCT_DIR/entries/$USERNAME/MB ] && [ -f $C_ACCT_DIR/classes/$CL/MB ] && [ -n "$(cat $C_ACCT_DIR/classes/$CL/MB)" ];then
				TRAFFIC=$(cat $C_ACCT_DIR/entries/$USERNAME/MB)
				LIMITMB=$(cat $C_ACCT_DIR/classes/$CL/MB)
				LIMITMB=$((LIMITMB*1048576))
				if [ $TRAFFIC -gt $LIMITMB ];then
					VALIDITY="M"
				fi
			fi
			DATA="dn: uid=$USERNAME,ou=PEOPLE,$C_LDAPBASE\nsessions: $NSESSIONS\nclass: $CLASS\nvalidity: $VALIDITY"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		done
		#### end
		if [ -n "$C_SHAPER" ];then
			$C_ZT_BIN_DIR/zt "Shaper"
			$C_ZT_BIN_DIR/zt "Shaper" "on"
		fi
		$C_ZT_BIN_DIR/binzt "RegisterCode" "$(cat /tmp/CODE)"
		$C_ZT_BIN_DIR/zt "Cancella" "/tmp/CODE"
		$C_ZT_BIN_DIR/zt "Cancella" "/tmp/upgrade"
		return_page "config.sh?SECTION=UPGRADE_ZT_COMPLETE"
	else
		echo "<p>&nbsp;<p><font color=\"red\" size=\"4\">$L_NO_SERVER</font><p>
		<form action=\"$3\" method=\"POST\">
		<input type=\"hidden\" name=\"SECTION\" value=\"UPDATE_ZT\">
		<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
		</form>"
	fi
	exit
fi

if [ "$1" == "ControlSlash" ];then
	sed -i 's/\%2F/\//g' $C_ZT_CONF_DIR/zt.config
	exit
fi

if [ "$1" == "AddFreeService" ];then
	DESC="$2"
	IP="$3"
	[ "$IP" == Any ] && IP=""
	PORT="$4"
	PROTO="$5"
	CONFIG=$C_CP_DIR
	cd $CONFIG/FreeServices
	LAST=`ls -d * 2>/dev/null |tail -1`
	if [ -z "$LAST" ] ; then
		NEW=00
	else
		if [ "${LAST:0:1}" == 0 ] ; then
			LAST="${LAST:1:1}"
		fi
		NEW="$((LAST+1))"
		if [ "$NEW" -lt 10 ] ; then
			NEW=0$NEW
		fi
	fi
	mkdir $NEW
	echo "$DESC" > $CONFIG/FreeServices/$NEW/Desc
	echo "$IP" > $CONFIG/FreeServices/$NEW/IP
	echo "$PROTO" > $CONFIG/FreeServices/$NEW/Proto
	echo "$PORT" > $CONFIG/FreeServices/$NEW/Port
	if [ -z "$IP" ] ; then
		DEST=""
	else
		DEST="-d $IP"
	fi
	/usr/local/sbin/iptables -A CapPortFS $DEST -p $PROTO --dport $PORT -j ACCEPT
	if [ "$PROTO" == "tcp" ] ; then
		if [ "$PORT" == 80 ] ; then
			/usr/local/sbin/iptables -t nat -I CapPortHTTP 1 $DEST -p $PROTO --dport $PORT -j CapPortProxy
		fi
		if [ "$PORT" == 443 ] ; then
			/usr/local/sbin/iptables -t nat -I CapPortHTTPS 1 $DEST -p $PROTO --dport $PORT -j ACCEPT
		fi
	fi
	if [ "$6" == "SRVWalledGarden" ];then
		echo "$NEW" > $C_CP_DIR/Auth/Custom/SRVWalledGarden
	fi

fi

if [ "$1" == "RemoveMacBlocked" ];then
	/bin/sed -i "/^$2/d" $C_ZT_CONF_DIR/macblocked
	/bin/sed -i "/^$/d" $C_ZT_CONF_DIR/macblocked
fi

if [ "$1" == "RemoveFreeService" ];then
	SRV="$2"
	[ -z "$SRV" ] && exit 1
	CONFIG=$C_CP_DIR/FreeServices
	IP=`cat $CONFIG/$SRV/IP`
	PORT=`cat $CONFIG/$SRV/Port`
	PROTO=`cat $CONFIG/$SRV/Proto`
	if [ -z "$IP" ];then
		DEST=""
	else
		DEST="-d $IP"
	fi
	/usr/local/sbin/iptables -D CapPortFS $DEST -p $PROTO --dport $PORT -j ACCEPT
	if [ "$PROTO" == "tcp" ];then
		if [ "$PORT" == 80 ];then
			/usr/local/sbin/iptables -t nat -D CapPortHTTP $DEST -p $PROTO --dport $PORT -j CapPortProxy
		fi
		if [ "$PORT" == 443 ];then
			/usr/local/sbin/iptables -t nat -D CapPortHTTPS $DEST -p $PROTO --dport $PORT -j ACCEPT
		fi
		rm -rf $CONFIG/$SRV
	fi
	rm -rf $CONFIG/$SRV
fi

if [ "$1" == "AddFreeClient" ];then
	DESC="$2"
	IP="$3"
	[ "$IP" == Any ] && IP=""
	MAC="$4"
	[ "$MAC" == Any ] && MAC=""
	CONFIG=$C_CP_DIR
	cd $CONFIG/FreeClients
	LAST=`ls -d * 2>/dev/null | sort -n | tail -1`
	if [ -z "$LAST" ] ; then
		NEW=0000
	else
		LAST=$(echo $LAST | sed 's/^0*//')
		[ -z "$LAST" ] && LAST=0
		NEW=$(printf "%04d" $((LAST+1)))
	fi
	mkdir $NEW
	echo "$DESC" > $CONFIG/FreeClients/$NEW/Desc
	echo "$IP" > $CONFIG/FreeClients/$NEW/IP
	echo "$MAC" > $CONFIG/FreeClients/$NEW/MAC
	if ! [ -z "$IP" ] ; then
		SOURCE="-s $IP"
	fi
	if ! [ -z "$MAC" ] ; then
		SOURCE="$SOURCE -m mac --mac-source $MAC"
	fi
	/usr/local/sbin/iptables -A CapPortFC $SOURCE -j ACCEPT
	/usr/local/sbin/iptables -t nat -D CapPortHTTP $SOURCE -j CapPortProxy 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTPS $SOURCE -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortGW $SOURCE -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -I CapPortHTTP 1 $SOURCE -j CapPortProxy
	/usr/local/sbin/iptables -t nat -I CapPortHTTPS 1 $SOURCE -j ACCEPT
	/usr/local/sbin/iptables -t nat -I CapPortGW 1 $SOURCE -j ACCEPT
fi

if [ "$1" == "RemoveFreeClient" ];then
	CLT="$2"
	[ -z "$CLT" ] && exit 1
	CONFIG=$C_CP_DIR/FreeClients
	IP=`cat $CONFIG/$CLT/IP`
	MAC=`cat $CONFIG/$CLT/MAC`
	[ "$IP" == Any ] && IP=""
	[ "$MAC" == Any ] && MAC=""
	if ! [ -z "$IP" ] ; then
		SOURCE="-s $IP"
	fi
	if ! [ -z "$MAC" ] ; then
		SOURCE="$SOURCE -m mac --mac-source $MAC"
	fi
	/usr/local/sbin/iptables -D CapPortFC $SOURCE -j ACCEPT
	/usr/local/sbin/iptables -t nat -D CapPortHTTP $SOURCE -j CapPortProxy 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortHTTPS $SOURCE -j ACCEPT 2>/dev/null
	/usr/local/sbin/iptables -t nat -D CapPortGW $SOURCE -j ACCEPT 2>/dev/null
	rm -rf "$CONFIG/$CLT"
fi

if [ "$1" == "ChangeProtUrl" ];then
	/root/kerbynet.cgi/scripts/cp_auth_start
fi

if [ "$1" == "ControlConnection" ];then
	[ -z "$2" ] && exit
	[ ! -d $C_ACCT_DIR/entries ] && $C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/entries"
	USERNAME=$(cat $C_CP_DIR/Connected/$2/User | cut -d'@' -f1)
	ldap_search_people "uid=$USERNAME"
	if [ -n "$MAXDAYS" ];then
		YEAR_EXPIRE=$(date +%Y --date="+$MAXDAYS days")
		MONTH_EXPIRE=$(date +%m --date="+$MAXDAYS days")
		DAY_EXPIRE=$(date +%d --date="+$MAXDAYS days")
		SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
		MAXDAYS="?"
		ldap_modify_people "shadowExpire maxDays"
		kadmin.local -q "modprinc -expire $YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE $USERNAME" > /dev/null
	fi
	if [ -d $C_ACCT_DIR/entries/$USERNAME/sessions ];then
		NSESSIONS=`ls $C_ACCT_DIR/entries/$USERNAME/sessions/ | wc -l`
		NSESSIONS_EXP=`ls $C_ZT_DIR/expired/$USER/$USERNAME/sessions/ | wc -l`
		NSESSIONS=$(($NSESSIONS+$NSESSIONS_EXP+1))
	else
		NSESSIONS=1
	fi
	DATA="dn: uid=$USERNAME,ou=PEOPLE,$C_LDAPBASE\nsessions: $NSESSIONS"
	echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
fi

if [ "$1" == "TokenDb" ];then
	curl -k -s --show-error --globoff -i -o /tmp/tokendb --data "oauth_consumer_key=$C_APP_KEY_DB&oauth_signature_method=PLAINTEXT&oauth_signature=$C_APP_SECRET_DB%26&oauth_nonce=$RANDOM" https://api.dropbox.com/1/oauth/request_token 2>/dev/null
fi

if [ "$1" == "TokenAccessDb" ];then
	TMPTOKEN="$(cat /tmp/tokendb | tail -1 | cut -d'=' -f3 )"
	TMPSECRETTOKEN="$(cat /tmp/tokendb | tail -1 | cut -d'=' -f2 | cut -d'&' -f1)"
	curl -k --show-error --globoff -i -o /tmp/tokendb --data "oauth_consumer_key=$C_APP_KEY_DB&oauth_token=$TMPTOKEN&oauth_signature_method=PLAINTEXT&oauth_signature=$C_APP_SECRET_DB%26$TMPSECRETTOKEN&oauth_nonce=$RANDOM" https://api.dropbox.com/1/oauth/access_token 2>/dev/null
    $C_ZT_BIN_DIR/zt "SalvaConfig" "C_TOKEN_DB" "$(cat /tmp/tokendb | tail -1 | cut -d'=' -f3 | cut -d'&' -f1)"
	$C_ZT_BIN_DIR/zt "SalvaConfig" "C_TOKEN_SECRET_DB" "$(cat /tmp/tokendb | tail -1 | cut -d'=' -f2 | cut -d'&' -f1)"
	rm -rf /tmp/tokendb
fi

if [ "$1" ==  "ConfClam" ];then
	if [ "$2" == "yes" ];then
		VAL="true"
	else
		VAL="false"
	fi
	sed -i "s/^SCANIMAGES.*/SCANIMAGES $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-squid.conf
	sed -i "s/^SCANIMAGES.*/SCANIMAGES $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-only.conf
	sed -i "s/^SCANIMAGES.*/SCANIMAGES $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg.conf
	sed -i "s/^SCANIMAGES.*/SCANIMAGES $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg-squid.conf
	if [ "$3" ==  "AnyAccess" ];then
		VAL="true"
	else
		VAL="false"
	fi
	sed -i "s/^LOG_OKS.*/LOG_OKS $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-squid.conf
	sed -i "s/^LOG_OKS.*/LOG_OKS $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-only.conf
	sed -i "s/^LOG_OKS.*/LOG_OKS $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg.conf
	sed -i "s/^LOG_OKS.*/LOG_OKS $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg-squid.conf
	if [ "$4" ==  "Enabled" ];then
		VAL="5000000"
	else
		VAL="1"
	fi
	sed -i "s/^MAXSCANSIZE.*/MAXSCANSIZE $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-squid.conf
	sed -i "s/^MAXSCANSIZE.*/MAXSCANSIZE $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-only.conf
	sed -i "s/^MAXSCANSIZE.*/MAXSCANSIZE $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg.conf
	sed -i "s/^MAXSCANSIZE.*/MAXSCANSIZE $VAL/g" $C_ZT_PROXY_DIR/etc/havp/havp-dg-squid.conf
	if [ $(cat $C_SYSTEM/havp/WhiteList) == "yes" ] ; then
		sed -i "s/^WHITELIST.*/WHITELIST $C_SYSTEM/havp/WhiteList.txt/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^WHITELIST.*/WHITELIST $C_SYSTEM/havp/WhiteList.txt/g" $C_ZT_CONF_DIR/havp-only.conf
	else
		sed -i "s/^WHITELIST.*/WHITELIST \/dev\/null/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^WHITELIST.*/WHITELIST \/dev\/null/g" $C_ZT_CONF_DIR/havp-only.conf
	fi
	if [ $(cat $C_SYSTEM/havp/BlackList) == "yes" ] ; then
		sed -i "s/^BLACKLIST.*/BLACKLIST $C_SYSTEM/havp/BlackList.txt/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^BLACKLIST.*/BLACKLIST $C_SYSTEM/havp/BlackList.txt/g" $C_ZT_CONF_DIR/havp-only.conf
	else
		sed -i "s/^BLACKLIST.*/BLACKLIST \/dev\/null/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^BLACKLIST.*/BLACKLIST \/dev\/null/g" $C_ZT_CONF_DIR/havp-only.conf
	fi
	MEMORY=$(cat /proc/meminfo |grep ^MemTotal: | awk '{print $2}')
	SERVERNUMBER=$((MEMORY/20000))
	sed -i "s/^SERVERNUMBER.*/SERVERNUMBER $SERVERNUMBER/g" $C_ZT_CONF_DIR/havp-squid.conf
	sed -i "s/^SERVERNUMBER.*/SERVERNUMBER $SERVERNUMBER/g" $C_ZT_CONF_DIR/havp-only.conf
	if [ "$SERVERNUMBER" -lt 8 ];then
		sed -i "s/^SERVERNUMBER.*/SERVERNUMBER 8/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^SERVERNUMBER.*/SERVERNUMBER 8/g" $C_ZT_CONF_DIR/havp-only.conf
	fi
	if [ "$SERVERNUMBER" -gt 120 ];then
		sed -i "s/^SERVERNUMBER.*/SERVERNUMBER 120/g" $C_ZT_CONF_DIR/havp-squid.conf
		sed -i "s/^SERVERNUMBER.*/SERVERNUMBER 120/g" $C_ZT_CONF_DIR/havp-only.conf
	fi
	chown -R havp $C_ZT_PROXY_DIR/log/dansguardian/access.log 2>/dev/null
fi

if [ "$1" == "Proxy_fw" ];then
	CONFIG=$C_SYSTEM/havp/redirects
	cd "$CONFIG" || exit 0
	$C_ZS_SCRIPTS_DIR/proxy_fw_reset
	PORT="55559"
	if ! /usr/local/sbin/iptables -t nat -L Proxy -n >/dev/null 2>/dev/null ; then
		/usr/local/sbin/iptables -t nat -N Proxy
		/usr/local/sbin/iptables -N Proxy
		/usr/local/sbin/iptables -t nat -I CapPortProxy 1 -p tcp --dport 80 -j Proxy 2>/dev/null
	fi
	/usr/local/sbin/iptables -t nat -F Proxy
	/usr/local/sbin/iptables -t nat -D PREROUTING -p tcp --dport 80 -j Proxy 2>/dev/null
	/usr/local/sbin/iptables -t nat -A PREROUTING -p tcp --dport 80 -j Proxy
	/usr/local/sbin/iptables -F Proxy
	/usr/local/sbin/iptables -A Proxy -j DROP
	/usr/local/sbin/iptables -D INPUT -p tcp --dport $PORT -j Proxy 2>/dev/null
	/usr/local/sbin/iptables -A INPUT -p tcp --dport $PORT -j Proxy
	OBJECTS=`ls -d * 2>/dev/null`
	for O in $OBJECTS ; do
		ACTION=`cat $O/Action`
		INTERFACE=`cat $O/Interface`
		DESTINATIONIP=`cat $O/DestinationIP`
		SOURCEIP=`cat $O/SourceIP`
		if [ "$ACTION" == Capture ] ; then
			IPT="iptables -t nat -A Proxy -p tcp"
			TARGET="REDIRECT --to-ports $PORT"
			TARGET2="ACCEPT"
		else
			IPT="iptables -t nat -I Proxy 1 -p tcp"
			TARGET="ACCEPT"
			TARGET2="DROP"
		fi
		IF=""
		if [ -n "$INTERFACE" ] ; then
			if [ -f $C_SYSTEM/net/interfaces/$INTERFACE/Bridge/Name ] ; then
				IF="-m physdev --physdev-in $INTERFACE"
			else
				IF="-i $INTERFACE"
			fi
		fi
		SRC=""
		if [ -n "$SOURCEIP" ] ; then
			if echo "$SOURCEIP" | grep -q  '-' ; then
				SRC="-m iprange --src-range $SOURCEIP"
				echo $SRC
			else
				SRC="-s $SOURCEIP"
			fi
		fi
		DST=""
		if [ -n "$DESTINATIONIP" ] ; then
			if echo "$DESTINATIONIP" | grep -q  '-' ; then
				DST="-m iprange --dst-range $DESTINATIONIP"
			else
				DST="-d $DESTINATIONIP"
			fi
		fi
		$IPT $IF $SRC $DST -j $TARGET
		iptables -I Proxy 1 $IF $SRC $DST -j $TARGET2
	done
fi

if [ "$1" == "CreaFile" ];then
	touch $2
	chown root:root $2
fi

if [ "$1" == "SetDansguardian" ];then
	sed -i "s/^naughtynesslimit.*/naughtynesslimit \= $2/g" $C_ZT_PROXY_DIR/etc/dansguardian/dansguardianf1.conf
	sed -i "s/^groupmode.*/groupmode \= $3/g" $C_ZT_PROXY_DIR/etc/dansguardian/dansguardianf1.conf
	sed -i "s/^loglevel.*/loglevel \= $4/g" $C_ZT_PROXY_DIR/etc/dansguardian/dansguardian.conf
	sed -i "s/^logexceptionhits.*/logexceptionhits \= $5/g" $C_ZT_PROXY_DIR/etc/dansguardian/dansguardian.conf
	chown root:root $C_ZT_PROXY_DIR/etc/dansguardian/dansguardian*
fi

if [ "$1" == "InterSquid" ];then
	INTERFACE_PROXY=$(ls $C_SYSTEM/havp/redirects )
	INTSQUID=""
	for INTP in $INTERFACE_PROXY;do
		ACTION="$(cat $C_SYSTEM/havp/redirects/$INTP/Action)"
		if [ "$ACTION" == "Capture" ];then
			DIP="$(cat $C_SYSTEM/havp/redirects/$INTP/DestinationIP)"
			SIP="$(cat $C_SYSTEM/havp/redirects/$INTP/SourceIP)"
			INT="$(cat $C_SYSTEM/havp/redirects/$INTP/Interface)"
			IFCONFIG=$(ifconfig)
			NETINT=$(echo $IFCONFIG |  /bin/awk '{split ($0, a, "'${INT}':");print a['2'];}' | /bin/awk '{split ($0, a, "Mask:");print a['2'];}' | awk '{print $1}')
			#NETINT=$(addressprefix "$NETINT")
			IFCINT=$(echo $IFCONFIG |  /bin/awk '{split ($0, a, "'${INT}':");print a['2'];}' | /bin/awk '{split ($0, a, "addr:");print a['2'];}' | awk '{print $1}')
			#IFCINT=$(echo "$IFCINT" | awk '{split ($0, a, ".");print a['1']"."a['2']"."a['3']".0";}')
			NETWORK="$(ipcalc $IFCINT/$NETINT | grep 'Network' | awk '{print $2}')"
			INTSQUID="$INTSQUID $NETWORK"
		fi
	done
	INTSQUID=$(echo "$INTSQUID" | sed 's/\//\\\//g')
	sed -i "s/^#localnet/acl localnet src $INTSQUID/g" $C_ZT_PROXY_DIR/etc/squid.conf
fi

if [ "$1" == "ControlActive" ];then
	[ -z "$2" ] && exit
	ps -A | grep "$2"
fi

if [ "$1" == "PreInstallSquid" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	if `wget -o wgetlog -S --spider http://zerotruth.net/download/squid-3.3.11.2.tar.gz 2>/dev/null`;then
		DIMORI=$(cat wgetlog | grep ' Content-Length' | awk '{print $3}')
		echo "squid-3.3.11.2.tar.gz $DIMORI ./config.sh?SECTION=PROXY&SUB_SECTION=INSTALLSQUID" > file
		chmod -R 777 /tmp/download
		`wget -b http://www.zerotruth.net/controldl.php?file=squid-3.3.11.2.tar.gz 2>/dev/null`
		echo "<p><font color=\"blue\">Download squid.3.3.11</font><p>"
		echo "<p><table width=\"502\" border=\"0\"><tr><td>"
		cat $C_HTDOCS_DIR/svg/download.svg
		echo "</td></tr></table>"
		echo "<p>&nbsp;<p>"
		./footer.sh
	else
		echo "<br><font color=\"red\">Downlod error</font>"
		./footer.sh
	fi
fi

if [ "$1" == "InstallSquid" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	`wget http://www.zerotruth.net/controldl.php?file=squid-3.3.11.2.tar.gz 2>/dev/null`
	cd $C_ZT_PROXY_DIR
	if [ -f /tmp/download/squid-3.3.11.2.tar.gz ];then
		tar zxvf /tmp/download/squid-3.3.11.2.tar.gz  > /dev/null
		chmod -R 777 $C_ZT_PROXY_DIR/var/logs
		chmod -R 777 $C_ZT_PROXY_DIR/var/cache
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
		rm -rf $C_ZT_PROXY_DIR/languages/squid/template 2>/dev/null
		cp -a $C_ZT_PROXY_DIR/languages/squid/$C_LANGUAGE $C_ZT_PROXY_DIR/languages/squid/template
		sed -i "s/ipcp/$IPCP/g" $C_ZT_PROXY_DIR/languages/squid/template/*
		rm -rf /tmp/download 2>/dev/null
	fi
fi

if [ "$1" == "InstallGammu" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	`wget http://www.zerotruth.net/controldl.php?file=gammu-1.33.0.tar.gz 2>/dev/null`
	cd $C_ZT_DIR
	if [ -f /tmp/download/gammu-1.33.0.tar.gz ];then
		tar zxvf /tmp/download/gammu-1.33.0.tar.gz  > /dev/null
		chmod 755 $C_ZT_BIN_DIR/gammu*
		chmod -R 777 $C_ZT_DIR/log/gammu
		chown root:root $C_ZT_BIN_DIR/gammu*
		chmod -R 666 $C_ZT_CONF_DIR/gammu.conf
		chown root:root $C_ZT_CONF_DIR/gammu.conf
		rm -rf /tmp/download 2>/dev/null
	fi
fi

if [ "$1" == "InstallSocial" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	`wget http://www.zerotruth.net/controldl.php?file=loginsocial30.tar.gz 2>/dev/null`
	cd /
	if [ -f /tmp/download/loginsocial30.tar.gz ];then
		tar zxvf /tmp/download/loginsocial30.tar.gz  > /dev/null
		ln -f -s $C_ZT_DIR/registersocial.sh $C_HTDOCS_ZT_DIR/cgi-bin/registersocial.sh
		chmod 755 $C_ZT_DIR/registersocial.sh
		ln -f -s $C_HTDOCS_DIR/images/googlelogo.png $C_HTDOCS_ZT_DIR/images/googlelogo
		ln -f -s $C_HTDOCS_DIR/images/facebooklogo.png $C_HTDOCS_ZT_DIR/images/facebooklogo
		ln -f -s $C_HTDOCS_DIR/images/twitterlogo.png $C_HTDOCS_ZT_DIR/images/twitterlogo
		ln -f -s $C_HTDOCS_DIR/images/google.png $C_HTDOCS_ZT_DIR/images/google
		ln -f -s $C_HTDOCS_DIR/images/facebook.png $C_HTDOCS_ZT_DIR/images/facebook
		ln -f -s $C_HTDOCS_DIR/images/twitter.png $C_HTDOCS_ZT_DIR/images/twitter
		rm -rf /tmp/download 2>/dev/null
	fi
fi

if [ "$1" == "PreInstallDG" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	if `wget -o wgetlog -S --spider http://zerotruth.net/download/dansguardian-2.12.0.3.tar.gz 2>/dev/null`;then
		DIMORI=$(cat wgetlog | grep ' Content-Length' | awk '{print $3}')
		echo "dansguardian-2.12.0.3.tar.gz $DIMORI ./config.sh?SECTION=PROXY&SUB_SECTION=INSTALLDG" > file
		chmod -R 777 /tmp/download
		`wget -b http://www.zerotruth.net/controldl.php?file=dansguardian-2.12.0.3.tar.gz 2>/dev/null`
		echo "<p><font color=\"blue\">Download dansguardian-2.12.0.3</font><p>"
		echo "<p><table width=\"502\" border=\"0\"><tr><td>"
		cat $C_HTDOCS_DIR/svg/download.svg
		echo "</td></tr></table>"
		echo "<p>&nbsp;<p>"
		./footer.sh
	else
		echo "<br><font color=\"red\">Downlod error</font>"
		./footer.sh
	fi
fi

if [ "$1" == "InstallDG" ];then
	rm -rf /tmp/download 2>/dev/null
	mkdir /tmp/download
	cd /tmp/download
	`wget  http://www.zerotruth.net/controldl.php?file=dansguardian-2.12.0.3.tar.gz 2>/dev/null`
	cd $C_ZT_PROXY_DIR
	if [ -f /tmp/download/dansguardian-2.12.0.3.tar.gz ];then
		tar  zxvf /tmp/download/dansguardian-2.12.0.3.tar.gz  > /dev/null
		chmod -R 777 $C_ZT_PROXY_DIR/var/log/dansguardian
		ln -s /DB /db
		INTERFACECP=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}' )
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
		rm -rf $C_ZT_PROXY_DIR/languages/dansguardian/template 2>/dev/null
		cp -a $C_ZT_PROXY_DIR/languages/dansguardian/$C_LANGUAGE $C_ZT_PROXY_DIR/languages/dansguardian/template
		sed -i "s/ipcp/$IPCP/g" $C_ZT_PROXY_DIR/languages/dansguardian/template/template.html
		rm -rf /tmp/download 2>/dev/null
	fi
fi

if [ "$1" == "SetSquid" ];then
	sed -i "s/^cache_dir.*/cache_dir ufs \/DB\/apache2\/cgi-bin\/zerotruth\/proxy\/var\/cache\/squid $2 16 256/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^cache_mem.*/cache_mem $3 MB/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^cache_swap_high.*/cache_swap_high $4/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^cache_swap_low.*/cache_swap_low $5/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^maximum_object_size .*/maximum_object_size $6 MB/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^minimum_object_size.*/minimum_object_size $7 KB/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	sed -i "s/^maximum_object_size_in_memory.*/maximum_object_size_in_memory $8 KB/g" $C_ZT_PROXY_DIR/etc/squid/squid*
	chown root:root $C_ZT_PROXY_DIR/etc/squid/squid*
fi

if [ "$1" == "AutoUpdate" ];then
	[ -z "$C_AUTO_UPDATE" ] && exit
	NEWFILES=$(curl -s http://www.zerotruth.net/download/updates/$VERSION/elencafiles.php?code=$C_CODE | sed '/<br>/s//\n/g' | sed '/\.\//s//\//g' | sed '/^$/d')
	if [ -n "$C_UPDATE_ZT" ];then
		NEWFILES=$(echo -e "$NEWFILES" | awk -v lu="$C_UPDATE_ZT" '{if ($1 > lu ) print}')
	fi
	if [ ! -f $C_ZT_CONF_DIR/updates ];then
		$C_ZT_BIN_DIR/zt "Salva" "$NEWFILES" "$C_ZT_CONF_DIR/updates"
	else
		$C_ZT_BIN_DIR/zt "Salva" "$NEWFILES" "$C_ZT_CONF_DIR/newupdates"
	fi
	RIGHE=$(echo "$NEWFILES" | wc -l )
	DATE_UPDATE=$(echo "$NEWFILES" | tail -1 | cut -d' ' -f1)
	if [[ -z "$C_UPDATE_ZT" || "$C_UPDATE_ZT" -lt "$DATE_UPDATE" ]];then
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_UPDATE_SERVER" "$DATE_UPDATE"
		for I in $(seq 1 $RIGHE);do
			RIGA="$(echo -e "$NEWFILES" | sed -n "${I}p")"
			NAMEFILE=$(echo "$RIGA" | awk '{ print $2 }')
			FILE=$(echo $NAMEFILE | awk '{n=split ($0, a, "/");print a[n]'})
			DIR=$(echo $NAMEFILE | sed '/'${FILE}'/s///g')
			TIMEFILE=$(echo "$RIGA" | awk '{ print $1 }')
			TIMEFILELOC=$($C_ZT_BIN_DIR/zt "Stat" "/$NAMEFILE")
			if [ $TIMEFILELOC -lt $TIMEFILE ] && [ -f /$NAMEFILE ];then
				wget -N -P "$DIR" "http://www.zerotruth.net/download/updates/$VERSION/$NAMEFILE"
				NAMEFILES="$NAMEFILES\n$NAMEFILE"
			else
				if [ ! -e /$NAMEFILE ];then
					if [ ! -d /$DIR ];then
						$C_ZT_BIN_DIR/zt "CreaCartella" "/$DIR"
					fi
					wget -N -P "$DIR" "http://www.zerotruth.net/download/updates/$VERSION/$NAMEFILE"
					NAMEFILES="$NAMEFILES\n$NAMEFILE"
				fi
			fi
		done
	fi
	if [ -n "$NAMEFILES" ];then
		if [[ -n "$C_ADMIN_EMAIL" && -n "$C_AUTO_UPDATE_EMAIL" ]];then
			TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n\n\n$NAMEFILES\n\n\n$(cat $C_ZT_CONF_DIR/emailf)"
			echo -e "$TEXT_EMAIL" | $C_ZT_BIN_DIR/mutt -e "set realname=\"$C_HOTSPOT_NAME\"" -F $C_ZT_CONF_DIR/Muttrc -s "$C_HOTSPOT_NAME Auto Update " "$C_ADMIN_EMAIL"
		fi
	fi
	/usr/bin/logger -t ZT.system "AutoUpdate $NAMEFILES"
fi

if [ "$1" == "InfoZT" ];then
	UPTIME="$(awk '{Days=$1/86400; Sec=$1%86400; Hours=Sec/3600; Sec=Sec%3600 ; Minutes=Sec/60; printf "%d days, %d:%d",Days,Hours,Minutes }' < /proc/uptime)"
	DAYSUP=$(echo "$UPTIME" | cut -d' ' -f1)
	MINUTES=$(echo "$UPTIME" | cut -d':' -f2)
	if [ $MINUTES -lt 10 ];then
		UPTIME=$(echo "$UPTIME" | sed "s/:$MINUTES/:0$MINUTES/g")
	fi
	if [ "$DAYSUP" == "1" ];then
		UPTIME=$(echo "$UPTIME" | sed "s/days/$L_DAY/g")
	else
		UPTIME=$(echo "$UPTIME" | sed "s/days/$L_DAYS/g")
	fi
	echo "<p><font color=\"blue\">&nbsp;&nbsp;&nbsp;Uptime: $UPTIME $L_HOURS&nbsp;&nbsp;&nbsp;<br>"
	echo "Zeroshell $($C_ZS_SCRIPTS_DIR/release).$($C_ZS_SCRIPTS_DIR/patchlevel)"
	echo "<br>"
	echo "Linux Kernel $(uname -r)"
	echo "</font>"
fi

if [ "$1" == "DisableCp443" ];then
	if [ -n "$2" ];then
		`/usr/local/sbin/iptables -C CapPortHTTPS -t nat -p tcp --dport 443 -j RETURN > /dev/null 2>&1`
		if [ $? -eq 1 ]; then
			pos=`/usr/local/sbin/iptables -S CapPortHTTPS -t nat  | wc -l 2>/dev/null`
			pos=`expr $pos - 3`
			if [ $pos -ge 2 ]; then
				`/usr/local/sbin/iptables -I CapPortHTTPS $pos -t nat -p tcp --dport 443 -j RETURN > /dev/null`
			fi
		fi
	else
		`/usr/local/sbin/iptables -C CapPortHTTPS -t nat -p tcp --dport 443 -j RETURN > /dev/null 2>&1`
		if [ $? -eq 0 ]; then
			`/usr/local/sbin/iptables -D CapPortHTTPS -t nat -p tcp --dport 443 -j RETURN > /dev/null`
		fi
	fi
fi

if [ "$1" == "ControlCp443" ];then
	`/usr/local/sbin/iptables -C CapPortHTTPS -t nat -p tcp --dport 443 -j RETURN > /dev/null 2>&1`
	if [ $? -eq 0 ];then
		echo "<input name=\"DISABLE_CP_443\" type=\"checkbox\" checked=\"checked\">"
	else
		echo "<input name=\"DISABLE_CP_443\" type=\"checkbox\">"
	fi
fi

if [ "$1" == "CompExport" ];then
	tar -czvf /tmp/exportuser.$2.tgz /tmp/exportuser.$2 >/dev/null
	mkdir $C_HTDOCS_DIR/$3
	echo "$3" > /DB/bks
	mv /tmp/exportuser.$2.tgz $C_HTDOCS_DIR/$3/exportuser.$2.tgz >/dev/null
	$C_ZT_SCRIPTS_DIR/RemoveTgz.sh "$C_HTDOCS_DIR/$3" &
fi


if [ "$1" == "HttpdConf" ];then
	echo "$2" > $C_SYSTEM/httpd/HTTP
	echo "$2" > $C_SYSTEM/httpd/NEWHTTP
	echo "$3" > $C_SYSTEM/httpd/HTTPS
	echo "$3" > $C_SYSTEM/httpd/NEWHTTPS
	cp -f $C_HTDOCS_CONF_DIR/httpd $C_HTDOCS_CONF_DIR/httpd.conf
	sed -i "s/HTTP_PORT/$2/g" $C_HTDOCS_CONF_DIR/httpd.conf
	cp -f $C_HTDOCS_CONF_DIR/ssl $C_HTDOCS_CONF_DIR/ssl.conf
	sed -i "s/HTTPS_PORT/$3/g" $C_HTDOCS_CONF_DIR/ssl.conf
	#CN=`openssl x509 -in $C_CP_DIR/Auth/TLS/cert.pem  -noout -subject |awk -F"CN=" '{print $2}' | awk -F"/" '{print $1}'`
	#[ -n "$(cat $C_CP_DIR/Auth/URLrid)" ] && CN="$(cat $C_CP_DIR/Auth/URLrid)"
	#sed -i "s/www.example.com/$CN/g" $C_HTDOCS_CONF_DIR/ssl.conf
	#chown apache:apache $C_HTDOCS_CONF_DIR/ssl.conf
	#chown apache:apache $C_HTDOCS_CONF_DIR/httpd.conf
	#/etc/init.d/httpd restart
fi

if [ "$1" == "ConfigLanCp" ];then
	if [[ -n "$2" && -n "$3" ]];then
		echo "yes" > $C_SYSTEM/cp/Enabled
	else
		echo "no" > $C_SYSTEM/cp/Enabled
	fi
	echo "$3" > $C_SYSTEM/cp/Interface
	echo "$3" > $C_SYSTEM/cp/Multi
	INTERFACECP=$(echo "$3" | awk '{print $1}')
	CONTROLV=$(echo "$INTERFACECP" | cut -sd'.' -f2)
	if [ -n "$CONTROLV" ];then
		INTERFACE=$(echo "$INTERFACECP" | cut -d'.' -f1)
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP)
		rm -f $C_SYSTEM/cp/Auth/Custom/IP
		ln -f -s $C_SYSTEM/net/interfaces/$INTERFACE/VLAN/$CONTROLV/IP/00/IP $C_SYSTEM/cp/Auth/Custom/IP
	else
		IPCP=$(cat $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP)
		rm -f $C_SYSTEM/cp/Auth/Custom/IP
		ln -f -s $C_SYSTEM/net/interfaces/$INTERFACECP/IP/00/IP $C_SYSTEM/cp/Auth/Custom/IP
	fi
	CLASSES=$(ls $C_ACCT_DIR/classes)
	for CLASS in $CLASSES;do
		INTCLASS="$(cat $C_ACCT_DIR/classes/$CLASS/InterfacesClass)"
		for INTCP in $INTCLASS;do
			if [ -z "$(cat $C_SYSTEM/cp/Interface | grep $INTCP)" ];then
				sed -i "s/$INTCP//g" $C_ACCT_DIR/classes/$CLASS/InterfacesClass
			fi
		done
		INTCLASS="$(cat $C_ACCT_DIR/classes/$CLASS/InterfacesClass)"
		if [ -z $INTCLASS ];then
			FIRSTINT="$(cat $C_SYSTEM/cp/Interface | awk '{print $1}')"
			echo "$FIRSTINT" > $C_ACCT_DIR/classes/$CLASS/InterfacesClass
		fi
	done
	$C_ZS_SCRIPTS_DIR/cp_start
fi

if [ "$1" == "x509_user" ];then
	USERNAME="$2"
	NBIT="$(cat $REGISTER/system/ssl/ca/keysize)"
	DAYS="$(cat $REGISTER/system/ssl/ca/days)"
	[ -z "$NBIT" ] && NBIT=1024
	[ -z "$DAYS" ] && DAYS=365
	/usr/local/ssl/bin/openssl req -new -batch -newkey rsa:$NBIT -nodes -out /tmp/x509default.req -keyout /tmp/x509default.key -days $DAYS -subj "/OU=Users/CN=$1"
	/usr/local/ssl/bin/openssl ca -batch -days $DAYS -in /tmp/x509default.req -out /tmp/x509default.cert -extfile /etc/ssl/extensions -extensions user
	/usr/local/ssl/bin/openssl x509 -in /tmp/x509default.cert -out "/etc/ssl/certs/${USERNAME}_user.pem"
	mv /tmp/x509default.key "/etc/ssl/private/${USERNAME}_user.pem"
	rm -f /tmp/x509default.req /tmp/x509default.cert
fi

if [ "$1" == "Logger" ];then
	logger -t "ZT.$2" "$3"
fi

if [ "$1" == "FailBan" ];then
	if [ -n "$C_IPBLOCKED" ];then
		NUM_LIMIT=2
		if [ "$C_FORM_DATE" == "ita" ];then
			DATA_TODAY=$(date  "+%d/%m/%Y %T")
		else
			DATA_TODAY=$(date "+%Y/%m/%d %T")
		fi
		NAMEHOST="$(echo $HOSTNAME | cut -d'.' -f1)"
		ATTACK=""
		if [ -n "$(ls /Database/LOG/$(date +%Y)/$(date +%b)/$(date +%d)/$NAMEHOST | grep 'sshd')" ];then
			ATTACK="$(cat /Database/LOG/*/*/*/$NAMEHOST/sshd | grep 'Failed password' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort | uniq -c | sort -nr )"
		fi
		if [ -n "$ATTACK" ];then
			NUM_TOT="$(echo -e "$ATTACK" | wc -l | awk '{print $1}')"
			for NUM in $(seq 1 $NUM_TOT); do
				PR="$(echo -e "$ATTACK" | sed -n "${NUM}p" | awk '{print $1}')"
				if [ "$PR" -gt "$C_NUM_FAIL" ];then
					IP="$(echo -e "$ATTACK" | sed -n "${NUM}p" | awk '{print $2}')"
					INSERTED="$(cat $C_ZT_CONF_DIR/ipbanned | grep "$IP")"
					CONTROL_SIC="$(cat $C_ZT_CONF_DIR/ipfree | grep "$IP")"
					if [[ -z "$INSERTED"  && -z "$CONTROL_SIC" ]];then
						echo "$IP # ssh - $PR Failed Login # $DATA_TODAY"  >> $C_ZT_CONF_DIR/ipbanned
						/usr/local/sbin/iptables -D INPUT -s $IP/32 -j DROP 2>/dev/null
						/usr/local/sbin/iptables -I INPUT 1 -s $IP/32 -j DROP
					fi
				fi
			done
		fi
		ATTACK=""
		if [ -n "$(ls /Database/LOG/*/*/*/$NAMEHOST | grep 'ZT.LoginError')" ];then
			ATTACK="$(cat /Database/LOG/*/*/*/$NAMEHOST/ZT.LoginError | grep 'Failed for' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort | uniq -c | sort -nr )"
		fi
		if [ -n "$ATTACK" ];then
			NUM_TOT="$(echo -e "$ATTACK" | wc -l | awk '{print $1}')"
			for NUM in $(seq 1 $NUM_TOT); do
				PR="$(echo -e "$ATTACK" | sed -n "${NUM}p" | awk '{print $1}')"
				if [ "$PR" -gt "$C_NUM_FAIL" ];then
					IP="$(echo -e "$ATTACK" | sed -n "${NUM}p" | awk '{print $2}')"
					INSERTED="$(cat $C_ZT_CONF_DIR/ipbanned | grep "$IP")"
					CONTROL_SIC="$(cat $C_ZT_CONF_DIR/ipfree | grep "$IP")"
					if [[ -z "$INSERTED"  && -z "$CONTROL_SIC" ]];then
						echo "$IP # ZT - $PR Failed Login # $DATA_TODAY"  >> $C_ZT_CONF_DIR/ipbanned
						/usr/local/sbin/iptables -D INPUT -s $IP/32 -j DROP 2>/dev/null
						/usr/local/sbin/iptables -I INPUT 1 -s $IP/32 -j DROP
					fi
				fi
			done
		fi
		sed -i "/^$/d" $C_ZT_CONF_DIR/ipbanned
	fi
fi

if [ "$1" == "IpTablesIPBan" ];then
	/usr/local/sbin/iptables -D INPUT -s $2/32 -j DROP 2>/dev/null
	if [ "$3" == "BAN" ];then
		/usr/local/sbin/iptables -I INPUT 1 -s $2/32 -j DROP
	fi
fi

if [ "$1" == "ControlBan" ];then
	echo "$(iptables-save | grep 'INPUT' | grep DROP | grep -Eo "([0-9]{1,3}[\.]){3}[0-9]{1,3}")" > /tmp/ipbanned
fi

if [ "$1" == "RimuoviLogBan" ];then
	SSH_LOG="$(ls /Database/LOG/*/*/*/*/sshd)"
	LOGIN_LOG="$(ls /Database/LOG/*/*/*/*/ZT.LoginError)"
	for SSHL in $SSH_LOG;do
		sed -i "/Failed password for .*. from $2/d" $SSHL
		sed -i "/^$/d" $SSHL
	done
	for LOGINL in $LOGIN_LOG;do
		sed -i "/$2/d" $LOGINL
		sed -i "/^$/d" $LOGINL
	done
fi

if [ "$1" == "ExecSms" ];then
	MYCODE="$(echo "$SMS_1_TEXT" | cut -sd' ' -f1)"
	MYCOMMAND="$(echo "$SMS_1_TEXT" | cut -sd' ' -f2)"
	if [[ "$MYCODE" != "$C_MY_CODE" && -z "$MYCOMMAND" ]];then
		SENDER=$(echo "$SMS_1_NUMBER" | sed 's/\+//g')
		PASSWORD=$(echo "$SMS_1_TEXT" | sed 's/ //g')
		QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$SENDER uid)
		USERN=$(echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
		if [ "$USERN" == "$SENDER" ];then
			QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$SENDER sn radiusUserCategory)
			PASSWORD_ORI=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')
			if [ -n "$(echo "$PASSWORD_ORI" | cut -sd'-' -f2)" ];then
				PASSWORD="$PASSWORD-$RANDOM"
			fi
			DATA="dn: cn=$SENDER,ou=Radius,$C_LDAPBASE\ncn: $SENDER\nsn: $PASSWORD"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null || CONTROLMODIFY="no"
			if [ -z "$CONTROLMODIFY" ];then
				echo "$SENDER $MSG" >> $C_ZT_LOG_DIR/gammu/registration/$SENDER
				logger -t "ZT.sms" "Received registration or new password from user - $SMS_1_NUMBER - $SMS_1_TEXT"
			else
				echo "$SENDER $MSG ERROR" >> $C_ZT_LOG_DIR/gammu/registration/$SENDER
				logger -t "ZT.sms" "Error - Received registration or new password from user - $SMS_1_NUMBER - $SMS_1_TEXT"
			fi
		else
			if [ -n "$C_AR_ONLY_SMS" ];then
				USERNAME=$(echo "$SMS_1_NUMBER" | sed 's/\+//g')
				PASSWORD=$(echo "$SMS_1_TEXT" | sed 's/ //g')
				PHONE="$USERNAME"
				UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uidNumber | sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n | tail -1 )
				UIDNUMBER=$(($UIDN+1))
				TODAY=$(dateDiff -d "1970-01-01" "$(date +%Y)-$(date +%m)-$(date +%d)")
				if [ -z "$C_AR_EXPIRE" ];then
					C_AR_EXPIRE=24836
				else
					SHADOWEXPIRE=$C_AR_EXPIRE
					DIFF_DATE=$(($SHADOWEXPIRE-$TODAY))
					AR_YEAR=$(date +%Y --date="+$DIFF_DATE days")
					AR_MONTH=$(date +%m --date="+$DIFF_DATE days")
					AR_DAY=$(date +%d --date="+$DIFF_DATE days")
					DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
				fi
				if [ -n "$C_AR_EXPIRE_DAYS" ];then
					AR_YEAR=$(date +%Y --date="+$C_AR_EXPIRE_DAYS days")
					AR_MONTH=$(date +%m --date="+$C_AR_EXPIRE_DAYS days")
					AR_DAY=$(date +%d --date="+$C_AR_EXPIRE_DAYS days")
					SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$AR_YEAR-$AR_MONTH-$AR_DAY")
					DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
				fi
				PASSWORD_ORI="$PASSWORD"
				CLASS="$C_AR_CLASS"
				UTENTEC="admin"
				INFO="autoregister_gammu"
				ldap_add_people
				if [ -n "$CONTROLADD" ]; then
					error "$L_PROBLEM_INSERTING"
					exit
				fi
				ldap_add_radius
				if [ -n "$CONTROLADD" ]; then
					/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
					error "$L_PROBLEM_INSERTING"
					exit
				fi
				$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
				$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
				$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$DATEK5"
				if [ -z "$CONTROLADD" ];then
					echo "$SMS_1_NUMBER $SMS_1_TEXT" >> $C_ZT_LOG_DIR/gammu/registration/$SMS_1_NUMBER
					logger -t "ZT.sms" "Received registration from user - $SMS_1_NUMBER - $SMS_1_TEXT"
				else
					echo "$SMS_1_NUMBER $SMS_1_TEXT" >> $C_ZT_LOG_DIR/gammu/registration/$SMS_1_NUMBER
					logger -t "ZT.sms" "Error - Received registration from user - $SMS_1_NUMBER - $SMS_1_TEXT"
				fi
			fi
		fi
	fi
	if [[ "$MYCODE" == "$C_MY_CODE" && -n "$MYCOMMAND" ]];then
		$C_ZT_SCRIPTS_DIR/esec_from_sms.sh "$MYCOMMAND"
		echo "$SMS_1_NUMBER $SMS_1_TEXT" >> $C_ZT_LOG_DIR/gammu/mycommands/$SMS_1_NUMBER
		logger -t "ZT.sms" "Received command from admin - $SMS_1_NUMBER - $MYCOMMAND"
	fi
fi

if [ "$1" == "CheckKey" ];then
	KEY_PORT=$(cat $C_ZT_CONF_DIR/gammu.conf | grep '^port' | awk '{print $3}' | cut -d'/' -f3)
	KEY=$(udevadm info --query=property --name=$KEY_PORT)
	MODEL=$(echo -e "$KEY" | grep '^ID_MODEL=' | cut -d'=' -f2)
	TYPE=$(echo -e "$KEY" | grep '^ID_MODEL_FROM_DATABASE=' | cut -d'=' -f2)
	VENDOR=$(echo -e "$KEY" | grep '^ID_VENDOR_ID=' | cut -d'=' -f2)
	MONITOR="$($C_ZT_BIN_DIR/gammu-smsd-monitor -c $C_ZT_CONF_DIR/gammu.conf -d1 -n1)"
	SIGNAL="$(echo -e "$MONITOR" | grep '^NetworkSignal' | awk '{print $2}')"
	BATTERY="$(echo -e "$MONITOR" | grep '^BatterPercent' | awk '{print $2}')"
	if [[ -n "$2" && -z "$MODEL" ]];then
		echo "notconnected"
	else
		if [ -n "$MODEL" ];then
			echo "Device: <font color=\"blue\">$MODEL - $TYPE</font>"
			if [ -n "$SIGNAL" ];then
				echo "<br>&nbsp;<br> Signal: <font color=\"blue\">$SIGNAL %</font>"
			fi
			if [[ -n "$BATTERY" && "$BATTERY" != "0" ]];then
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Battery: <font color=\"blue\">$BATTERY %</font>"
			fi
		else
			echo "Device: <font color=\"red\">$L_NOT_CONNECTED</font>"
		fi
	fi
fi

if [ "$1" == "RegisterSocial" ];then
	PASSWORD="$($C_ZT_BIN_DIR/convplain $4)"
	if [ "$2" == "facebook" ];then
		COOKIE='/tmp/cookiefb'
		USER_AGENT='Firefox'
		for n in $(seq 1 5);do
			curl -s -k -X GET 'https://www.facebook.com' --user-agent $USER_AGENT --cookie $COOKIE --cookie-jar $COOKIE --location >/dev/null
			curl -s -k -X POST 'https://login.facebook.com/login.php' --user-agent $USER_AGENT --data-urlencode "email=$3" --data-urlencode "pass=${PASSWORD}" --cookie $COOKIE --cookie-jar $COOKIE >/dev/null
			if [ -n "$(cat $COOKIE | grep 'c_user' )" ];then
				echo "yes"
				CON="yes"
				break
			fi
		done
		[ -z "$CON" ] && echo "no"
		rm -rf $COOKIE
		exit
	fi
	if [ "$2" == "google" ];then
		GOOGLEPLUS="$(curl -N -k https://www.google.com/accounts/ClientLogin --data-urlencode Email=$3 --data-urlencode Passwd=$PASSWORD -d accountType=GOOGLE -d source=Google-cURL-Example -d service=lh2)"
		if [ "$GOOGLEPLUS" == "Error=BadAuthentication" ];then
			echo "no"
		else
			echo "yes"
		fi
		exit
	fi
	if [ "$2" == "twitter" ];then
		rm -rf /tmp/cookietw 2>/dev/null
		COOKIE='/tmp/cookietw'
		USER_AGENT='Mozilla/5.0'
		init=`curl -k  -s -c "$COOKIE" 'https://twitter.com/'`
		token=`echo "$init" | grep "authenticity_token" | sed -n '1p' | sed -e 's/.*value="//' | cut -d'"' -f1`
		sleep 1
		control=`curl -k  -X POST -s -b "$COOKIE" -c "$COOKIE" -A "$USER_AGENT"  --data "session[username_or_email]=$3&session[password]=$PASSWORD&return_to_ssl=true&scribe_log=&redirect_after_login=&authenticity_token=$token"  'https://twitter.com/sessions'`
		CONTROL_OTOKEN="$(cat $COOKIE | grep 'auth_token')"
		CONTROL_USER="$(cat $COOKIE | grep 'twid')"
		if [[ -n "$CONTROL_OTOKEN"  && -n "$CONTROL_USER"  ]];then
			echo "yes"
		else
			echo "no"
		fi
		rm -rf /tmp/cookietw 2>/dev/null
	fi
fi

if [ "$1" == "AccountingStart" ];then
	$C_ZS_SCRIPTS_DIR/accounting_start
fi

if [ "$1" == "DeleteBlankLine" ];then
	sed -i "/^$/d" "$2"
fi

if [ "$1" == "LockUserWait" ];then
	USERLOCK="$(echo $2 | cut -d'-' -f1)"
	if [ -z $(cat  $C_ZT_CONF_DIR/userswait | grep "^$USERLOCK-") ];then
		sed -i "s/^$USERLOCK/$USERLOCK-$RANDOM/g" "$3"
	fi
fi

if [ "$1" == "UnlockUserWait" ];then
	if [ -n $(cat  $C_ZT_CONF_DIR/userswait | grep "^$2-") ];then
		sed -i "s/^$2.*/$2/g" "$3"
	fi
fi

if [ "$1" == "DeleteUserWait" ];then
	if [ "$2" == "END" ];then
		sed -i "/DELETE/d" "$3"
		sed -i "/^$/d" "$3"
		exit
	fi
	USERDEL="$2"
	sed -i "s/^$USERDEL*/DELETE/g" "$3"
fi

if [ "$1" == "DeleteFirstZero" ];then
	echo "$2" | $C_ZT_BIN_DIR/bc
fi

if [ "$1" == "SortUsersWait" ];then
	echo "$(cat $2 | sort)" > $2
fi

if [ "$1" == "AddNumLogin" ];then
	sed -i "s/^$2.*/$2 $3 $4/g" $C_ZT_LOG_DIR/controllogin/control
	sed -i "/^$/d" $C_ZT_LOG_DIR/controllogin/control
fi

if [ "$1" == "BlockMacLogin" ];then
	/usr/local/sbin/iptables -D INPUT -m mac --mac-source $2 -j DROP 2>/dev/null
	/usr/local/sbin/iptables -I INPUT 1 -m mac --mac-source $2 -j DROP 2>/dev/null
	SEC_NOW=$(date --utc +%s)
	SEC_NOW=$(($SEC_NOW+3600))
	SEC_BLOCK=$(($C_WAIT_LOGIN_TIME*60))
	SEC_UNBLOCK=$(($SEC_NOW+$SEC_BLOCK))
	MIN_UNBLOCK=$(date -d "1970-01-01 $SEC_UNBLOCK sec" +%M | $C_ZT_BIN_DIR/bc)
	HOUR_UNBLOCK=$(date -d "1970-01-01 $SEC_UNBLOCK sec" +%H | $C_ZT_BIN_DIR/bc)
	DAY_UNBLOCK=$(date -d "1970-01-01 $SEC_UNBLOCK sec" +%d | $C_ZT_BIN_DIR/bc)
	MONTH_UNBLOCK=$(date -d "1970-01-01 $SEC_UNBLOCK sec" +%m | $C_ZT_BIN_DIR/bc)
	MACS="$(echo $2 | sed 's/\://g')"
	rm -r -f $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron 2>/dev/null > /dev/null
	mkdir $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron
	mkdir $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron
	echo "Cron ZT${MACS}" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/Enabled
	echo "$C_ZT_SCRIPTS_DIR/unblocklogin.sh $2" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/File
	echo "*" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/DoW
	echo "$DAY_UNBLOCK" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/DoM
	echo "$HOUR_UNBLOCK" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/Hour
	echo "$MIN_UNBLOCK" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/Minute
	echo "$MONTH_UNBLOCK" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron/cron/Step
	chown -R root:root $C_CRON_SCRIPTS_DIR/ZT${MACS}-Cron
	$C_ZT_BIN_DIR/zt "RestartCron"
fi

if [ "$1" == "ConvertFileUsers" ];then
	sed -i 's/$/\n/g' $C_ZT_DIR/tmp/fileusers.txt
	sed -i '/^$/d' $C_ZT_DIR/tmp/fileusers.txt
fi

if [ "$1" == "QrCode" ];then
	if ! [ -d $C_HTDOCS_DIR/images/qrcode ];then
		mkdir $C_HTDOCS_DIR/images/qrcode
	fi
	USER="$2"
	USERNAME="$( echo "$2" | $C_ZT_BIN_DIR/base64)"
	PASSWORD="$( echo "$3" | $C_ZT_BIN_DIR/base64)"
	rm -rf $C_HTDOCS_DIR/images/qrcode/${USER}.png 2>/dev/null
	$C_ZT_BIN_DIR/qrencode -o $C_HTDOCS_DIR/images/qrcode/${USER}.png "http://www.zerotruth.net?OjoKcXJ2YWxpZGl0eQo=OjoK${USERNAME}OjoK${PASSWORD}"
fi

if [ "$1" == "DeleteQrCode" ];then
	USER="$2"
	rm -rf $C_HTDOCS_DIR/images/qrcode/${USER}.png 2>/dev/null
fi

if [ "$1" == "FixUpgrade" ];then
	$C_ZT_BIN_DIR/zt "RegisterCode" "$(cat /tmp/CODE)"
	rm -rf /tmp/CODE
	rm -rf $C_HTDOCS_ZT_DIR/images/wg
	rm -rf $C_HTDOCS_ZT_DIR/images/popup
	ln -s $C_HTDOCS_DIR/images/wg $C_HTDOCS_ZT_DIR/images/wg
	ln -s $C_HTDOCS_DIR/images/popup $C_HTDOCS_ZT_DIR/images/popup
fi

if [ "$1" == "SpeedyTest" ];then
	if [ -z "$3" ];then
		rm -rf $C_ZT_CONF_DIR/speedytest/download 2>/dev/null
		rm -rf $C_ZT_CONF_DIR/speedytest/ping 2>/dev/null
	fi
	if [ -n "$3" ];then
		rm -rf $C_ZT_CONF_DIR/speedytest/upload 2>/dev/null
	fi
	fileName="10mb.test"
	cd /tmp
	if [[ -f ./$filename && -z "$3" ]];then
        rm -rf ./$filename
	fi
	if [ -z "$3" ];then
		DLSPEED=$(curl http://$2/$fileName -w "%{speed_download}" -o $fileName -s | sed "s/\,/\./g")
		echo "$(echo "scale=2;$DLSPEED/1048576" | $C_ZT_BIN_DIR/bc | sed 's/^\./0\./g' )"  > $C_ZT_CONF_DIR/speedytest/download
		echo "$2" > $C_ZT_CONF_DIR/speedytest/server
	else
		ULSPEED=$(echo -n "scale=2; " && curl -F "file=@$fileName" http://$2/webtests/ul.php -w "%{speed_upload}" -s -o /dev/null | sed "s/\,/\./g")
		echo "$(echo "scale=2;$ULSPEED/1048576" | $C_ZT_BIN_DIR/bc | sed 's/^\./0\./g' )"  > $C_ZT_CONF_DIR/speedytest/upload
		ping -q -c5 $2 > $C_ZT_CONF_DIR/speedytest/ping
		if [ -f ./$filename ];then
			rm -rf ./$filename
		fi
	fi
fi

if [ "$1" == "DiskTest" ];then
	cd /tmp
	SPEED="$($C_ZT_BIN_DIR/dd if=/dev/zero of=disktest bs=64k count=16k conv=fdatasync 2>&1 | tail -n 1 | sed 's/s, /\|/g' | cut -d'|' -f2)"
	echo "$SPEED" > $C_ZT_CONF_DIR/disktest
	rm -rf disktest
fi

if [ "$1" == "CPUTest" ];then
	echo "$(cat /proc/cpuinfo | grep "model name" | cut -d ":" -f2 | tr -s " " | head -n 1) $(cat /proc/cpuinfo | grep "model name" | cut -d ":" -f2 | wc -l)" > $C_ZT_CONF_DIR/cputype
	TESTCPU="$((time echo "scale=5000; 4*a(1)" | $C_ZT_BIN_DIR/bc -lq) 2>&1 | grep real | cut -f2 | sed 's/m/ /g' | sed 's/s//g')"
	MINCPU="$(echo $TESTCPU | awk '{print $1}')"
	SECCPU="$(echo $TESTCPU | awk '{print $2}')"
	if [ "$MINCPU" != "0" ];then
		[ "$MINCPU" -lt 10 ] && MINCPU=0$MINCPU
		echo "$MINCPU min $SECCPU sec" > $C_ZT_CONF_DIR/cputest
	else
		echo "sec $SECCPU" > $C_ZT_CONF_DIR/cputest
	fi
fi

if [ "$1" == "CreateImageRandom" ];then
	echo "function BaseURL(protocol,port) {" > $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "  var host = location.hostname;" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "  if (protocol == 'https:') { port = port + 1000 };" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "  return protocol+\"//\"+host+\":\"+port;" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "}" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "var images = [];" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "index = 0;" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	ni=0
	for imgs in $(ls $C_HTDOCS_ZT_DIR/images/template/imglogin );do
		echo "images[$ni] = \"<img id='imgup' src='\"+url+\"/zerotruth/images/template/imglogin/$imgs'>\";" >> $C_HTDOCS_ZT_DIR/js/rimages.js
		ni=$(($ni+1))
	done
	echo "index = Math.floor(Math.random() * images.length);" >> $C_HTDOCS_ZT_DIR/js/rimages.js
	echo "document.write(images[index]);" >> $C_HTDOCS_ZT_DIR/js/rimages.js
fi

if [ "$1" == "UnlockAsterisk" ];then
	QUERY="$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$2 sn)"
	PASSWORD="$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g')"
	PASSWORD="$(echo "$PASSWORD" | cut -d'-' -f1)"
	DATA="dn: cn=$2,ou=Radius,$C_LDAPBASE\nsn: $PASSWORD"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
	DATA="dn: uid=$2,ou=PEOPLE,$C_LDAPBASE\ngecos: autoregister_asterisk"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
fi

if [ "$1" == "HttpdRestart" ];then
	/etc/init.d/httpd restart
fi

#### MultiCP
if [ "$1" == "SyncRemoteDefCron" ];then
	rm -r -f $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron 2>/dev/null > /dev/null
	if [ -n "$2" ];then
		mkdir $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron
		mkdir $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/cron
		echo "Cron ZTSYNCREMOTEDEF" > $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/Description
		echo "yes" > $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/Enabled
		echo "$C_ZT_SCRIPTS_DIR/zt.sh CronSyncDef" > $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/File
		chmod 755 $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/File
		echo "$3 m" > $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron/cron/Step
		chown -R root:root $C_CRON_SCRIPTS_DIR/ZTSyncRemoteDef-Cron
	fi
	$C_ZT_BIN_DIR/zt "RestartCron"
fi	

if [ "$1" == "RemoteSyncDef" ];then
	[ -z "$C_CP_SYNC_DEF" ] && exit
	if [ ! -d $C_ZT_CONF_DIR/RemoteSyncDef ];then
		mkdir $C_ZT_CONF_DIR/RemoteSyncDef
	fi
	ACTION="$2"
	CLIENT="$3"
	IP="$4"
	USER="$5"
	cd $C_ZT_CONF_DIR/RemoteSyncDef
	LAST=`ls -f * 2>/dev/null | sort -n | tail -1`
	if [ -z "$LAST" ] ; then
		NEW=0000
	else
		LAST=$(echo $LAST | sed 's/^0*//')
		[ -z "$LAST" ] && LAST=0
		NEW=$(printf "%04d" $((LAST+1)))
	fi
	echo "ACTION: $ACTION" > $NEW
	echo "CLIENT: $CLIENT" >> $NEW
	echo "IP: $IP" >> $NEW
	echo "PASSWORD: $PASSWORD" >> $NEW
	echo "$USER: $USER" >> $NEW
fi

if [ "$1" == "CronSyncDef" ];then
	[ -z "$C_CP_SYNC_DEF" ] && exit
	if [ -d $C_ZT_CONF_DIR/RemoteSyncDef ];then
		cd $C_ZT_CONF_DIR/RemoteSyncDef
		[ -z "$(ls -f)" ] && exit
		for CR in $(ls -f);do
			ACTION=$(cat "$CR" | grep '^ACTION:' | awk '{print $2}')
			CLIENT=$(cat "$CR" | grep '^CLIENT:' | awk '{print $2}')
			IP=$(cat "$CR" | grep '^IP:' | awk '{print $2}')
			PASSWORD=$(cat "$CR" | grep '^PASSWORD:' | awk '{print $2}')
			USER=$(cat "$CR" | grep '^USER:' | awk '{print $2}')
			if [ -n "$USER" ];then
				/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=$ACTION&USER=$USER" http://$IP:8088/cgi-bin/remotecp.sh >/dev/null
			else
				/usr/local/bin/curl -G -d "CLIENT=$CLIENT&PASS=$PASSWORD&ACTION=$ACTION" http://$IP:8088/cgi-bin/remotecp.sh >/dev/null
			fi
			rm -rf $CR
		done
		NEW="1000"
		for CR in $(ls -f);do
			mv $CR $NEW
			NEW=$(($NEW+1))
		done
		NEW="0000"
		for CR in $(ls -f);do
			mv $CR $NEW
			LAST=$(echo $NEW | sed 's/^0*//')
			NEW=$(printf "%04d" $((LAST+1)))
		done
	fi
fi
##########
if [ "$1" == "KeyRemoteCp" ];then
	if [ ! -d $C_ZT_CONF_DIR/RemoteKey ];then
		mkdir $C_ZT_CONF_DIR/RemoteKey
	fi
	/usr/local/ssl/bin/openssl req -x509 -nodes -days 100000 -newkey rsa:2048  -keyout $C_ZT_CONF_DIR/RemoteKey/privatekey.pem  -out $C_ZT_CONF_DIR/RemoteKey/publickey.pem  -subj '/'
	echo "$(date +%s)" > $C_ZT_CONF_DIR/RemoteKey/controlkey
fi

if [ "$1" == "ModifyKey" ];then
	sed -i 's/+++++/ /g' $C_ZT_CONF_DIR/RemoteKey/privatekey.pem
fi

if [ "$1" == "TgzClasses" ];then
	rm -rf /tmp/classes.tgz 2>/dev/null
	rm -rf /tmp/classes.sec 2>/dev/null
	cd $C_ACCT_DIR/classes
	tar -czvf /tmp/classes.tgz * >/dev/null
	/usr/local/ssl/bin/openssl  smime  -encrypt -aes256  -in  /tmp/classes.tgz  -binary  -outform DEM  -out  /tmp/classes.sec  $C_ZT_CONF_DIR/RemoteKey/publickey.pem
	rm -rf /tmp/classes.tgz
	mv -f /tmp/classes.sec $C_HTDOCS_ZT_DIR/classes.sec
fi

if [ "$1" == "GetRemoteClass" ];then
	cd /tmp
	rm -rf classes.sec 2>/dev/null
	rm -rf classes.tgz 2>/dev/null
	wget  http://$C_CP_REMOTE_IP:8088/classes.sec
	/usr/local/ssl/bin/openssl  smime -decrypt  -in  /tmp/classes.sec  -binary -inform DEM -inkey $C_ZT_CONF_DIR/RemoteKey/privatekey.pem  -out  /tmp/classes.tgz
	rm -rf $C_ACCT_DIR/classes/*
	/bin/tar zxvf /tmp/classes.tgz -C /Database/var/register/system/acct/classes/
	rm -rf classes.sec 2>/dev/null
	#rm -rf classes.tgz 2>/dev/null
fi

if [ "$1" == "TgzLDAP" ];then
	rm -rf /tmp/ldapremote 2>/dev/null
	mkdir /tmp/ldapremote
	cd /tmp/ldapremote
	/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" '(&(uid=*)(!(uid=admin)))' > ldap.people
	/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(&(cn=*)(!(cn=admin)))' > ldap.radius
	tar -czvf ldap.tgz * >/dev/null
	/usr/local/ssl/bin/openssl  smime  -encrypt -aes256  -in  /tmp/ldapremote/ldap.tgz  -binary  -outform DEM  -out  /tmp/ldapremote/ldap.sec  $C_ZT_CONF_DIR/RemoteKey/publickey.pem
	mv -f /tmp/ldapremote/ldap.sec $C_HTDOCS_ZT_DIR/ldap.sec
	rm -rf /tmp/ldapremote 2>/dev/null
fi

if [ "$1" == "GetRemoteLDAP" ];then
	rm -rf /tmp/ldapremote 2>/dev/null
	mkdir /tmp/ldapremote
	cd /tmp/ldapremote
	wget  http://$C_CP_REMOTE_IP:8088/ldap.sec
	/usr/local/ssl/bin/openssl  smime -decrypt  -in  /tmp/ldapremote/ldap.sec  -binary -inform DEM -inkey $C_ZT_CONF_DIR/RemoteKey/privatekey.pem  -out /tmp/ldapremote/ldap.tgz
	/bin/tar zxvf ldap.tgz
	USERS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" '(!(uid=admin))' uid | grep '^uid:' | awk '{print $2}')
	for USER in $USERS;do
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USER,ou=People,$C_LDAPBASE" > /dev/null
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USER,ou=Radius,$C_LDAPBASE" > /dev/null
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USER"
		$C_ZT_BIN_DIR/zt "DelK5" "$USER"
	done
	/etc/init.d/ldap restart
	/usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT -f ldap.people > /dev/null
	/usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT -f ldap.radius > /dev/null
	cd ..
	rm -rf /tmp/ldapremote 2>/dev/null
	/etc/init.d/ldap restart
fi

if [ "$1" == "TgzUser" ];then
	USERNAME="$2"
	UPDATE="$3"
	rm -rf /tmp/userRemote 2>/dev/null
	mkdir /tmp/userRemote
	cd /tmp/userRemote
	/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "uid=$USERNAME" > ldap.people.user
	/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" "cn=$USERNAME" > ldap.radius.user
	if [ -f $C_ACCT_DIR/credits/$USERNAME ];then
		cp $C_ACCT_DIR/credits/$USERNAME ./credit
	fi
	tar -czvf user.tgz * >/dev/null
	/usr/local/ssl/bin/openssl  smime  -encrypt -aes256  -in  /tmp/userRemote/user.tgz  -binary  -outform DEM  -out  /tmp/userRemote/user.sec  $C_ZT_CONF_DIR/RemoteKey/publickey.pem
	mv -f /tmp/userRemote/user.sec $C_HTDOCS_ZT_DIR/user.sec
	rm -rf /tmp/userRemote 2>/dev/null
fi

if [ "$1" == "GetRemoteUser" ];then
	USER="$2"
	rm -rf /tmp/userRemote 2>/dev/null
	mkdir /tmp/userRemote
	cd /tmp/userRemote
	wget  http://$C_CP_REMOTE_IP:8088/user.sec
	/usr/local/ssl/bin/openssl  smime -decrypt  -in  /tmp/userRemote/user.sec  -binary -inform DEM -inkey $C_ZT_CONF_DIR/RemoteKey/privatekey.pem  -out /tmp/userRemote/user.tgz
	/bin/tar zxvf user.tgz
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USER,ou=People,$C_LDAPBASE"  2>/dev/null >/dev/null
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USER,ou=Radius,$C_LDAPBASE" 2>/dev/null >/dev/null
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USER" 2>/dev/null >/dev/null
	$C_ZT_BIN_DIR/zt "DelK5" "$USER" 2>/dev/null >/dev/null
	/usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT -f ldap.people.user > /dev/null
	/usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT -f ldap.radius.user > /dev/null
	if [ -f ./credit ];then
		cp ./credit $C_ACCT_DIR/credits/$USER
	fi
	cd ..
	rm -rf /tmp/userRemote 2>/dev/null
	#/etc/init.d/ldap restart
fi

if [ "$1" == "TgzCredits" ];then
	rm -rf /tmp/credits 2>/dev/null
	mkdir /tmp/credits
	cd $C_ACCT_DIR/credits
	tar -czvf /tmp/credits/credits.tgz * >/dev/null
	/usr/local/ssl/bin/openssl  smime  -encrypt -aes256  -in  /tmp/credits/credits.tgz  -binary  -outform DEM  -out  /tmp/credits/credits.sec  $C_ZT_CONF_DIR/RemoteKey/publickey.pem
	mv -f /tmp/credits/credits.sec $C_HTDOCS_ZT_DIR/credits.sec
	rm -rf /tmp/credits 2>/dev/null
fi

if [ "$1" == "GetRemoteCredits" ];then
	cd /tmp
	rm -rf credits.sec 2>/dev/null
	rm -rf credits.tgz 2>/dev/null
	wget  http://$C_CP_REMOTE_IP:8088/credits.sec
	/usr/local/ssl/bin/openssl  smime -decrypt  -in  /tmp/credits.sec  -binary -inform DEM -inkey $C_ZT_CONF_DIR/RemoteKey/privatekey.pem  -out  /tmp/credits.tgz
	rm -rf $C_ACCT_DIR/credits/*
	/bin/tar zxvf /tmp/credits.tgz -C $C_ACCT_DIR/credits/
	rm -rf credits.sec 2>/dev/null
	rm -rf credits.tgz 2>/dev/null
fi

if [ "$1" == "LoginRemote" ];then
	USERNAME="$4"
	if [ "$C_CP_LOCAL_TYPE" == "Client" ];then
		CONNECT="$2"
		IP="$3"
		sleep 2
		if [ -z "$USERNAME" ];then
			USERNAME=$(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1)
		fi
		if [ -n "$USERNAME" ];then
			/usr/local/bin/curl -G -d "CLIENT=$C_CP_LOCAL_NAME&PASS=$C_CP_REMOTE_PASSWORD&ACTION=ConnectUser&USERNAME=$USERNAME&IP=$IP&CONNECT=$CONNECT" http://$C_CP_REMOTE_IP:8088/cgi-bin/remotecp.sh >/dev/null
		fi
	else
		if [ -n "$USERNAME" ];then
			LR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote:' | awk '{print $2}')
			if [ "$LR" != "?" ];then
				NAS=$(echo "$LR" | cut -d'-' -f1)
				IP=$(echo "$LR" | cut -d'-' -f2)
				IP_REMOTE=$(cat $C_ZT_CONF_DIR/RemoteClients/$NAS/IP)
				PASSWORD=$(cat $C_ZT_CONF_DIR/RemoteClients/$NAS/PASSWORD)
				/usr/local/bin/curl -G -d "CLIENT=$NAS&PASS=$PASSWORD&ACTION=DisconnectUser&USERNAME=$USERNAME&IP=$IP" http://$IP_REMOTE:8088/cgi-bin/remotecp.sh >/dev/null
				DATA="dn: uid=$USERNAME,ou=People,$C_LDAPBASE\nloginRemote: ?"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			fi
		fi
	fi
fi

if [ "$1" == "LockUserClient" ];then
	USER="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn)
	PASS=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1)
	PASSLOCK="$PASS-$RANDOM"
	DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
	DATA="dn: uid=$USER,ou=PEOPLE,$C_LDAPBASE\nlocked: yes"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
fi

if [ "$1" == "UnlockUserClient" ];then
	USER="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn)
	PASS=$(echo "$QUERY" | grep -e '^sn: ' | sed 's/^sn: //g' | cut -d'-' -f1)
	DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
	DATA="dn: uid=$USER,ou=PEOPLE,$C_LDAPBASE\nlocked: no"
	echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
fi

if [ "$1" == "LockAllClient" ];then
	USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(!(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	for USER in $USERLOCK;do
		if [ "$USER" != "admin" ];then
			RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn)
			PASS=$( echo $RADIUS | awk '{print $NF}')
			PASS="$PASS-$RANDOM"
			DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
			echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			DATA="dn: uid=$USER,ou=PEOPLE,$C_LDAPBASE\nlocked: yes"
			echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		fi
	done
fi

if [ "$1" == "UnlockAllClient" ];then
	USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(&(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	for USER in $USERLOCK;do
		RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn)
		PASS=$( echo $RADIUS | awk '{print $NF}' | cut -d'-' -f1)
		DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
		echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		DATA="dn: uid=$USER,ou=PEOPLE,$C_LDAPBASE\nlocked: no"
		echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
	done
fi

if [ "$1" == "ControlLimits" ];then
	USER="$2"
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn radiusUserCategory)
	CLASS=$(echo "$QUERY" | grep -e '^radiusUserCategory: ' | awk '{print $2}')
	PASS=$(echo "$QUERY" | grep -e '^sn: ' | awk '{print $2}')
	if [ "$CLASS" != "DEFAULT" ];then
		LIMIT_HOURS_DAY=$(cat $C_CLASSES_DIR/$CLASS/HoursDay)
		LIMIT_HOURS_MONTH=$(cat $C_CLASSES_DIR/$CLASS/HoursMonth)
		LIMIT_MB_DAY=$(cat $C_CLASSES_DIR/$CLASS/MBDay)
		LIMIT_MB_MONTH=$(cat $C_CLASSES_DIR/$CLASS/MBMonth)
		LIMIT_DAYS=$(cat $C_CLASSES_DIR/$CLASS/Days)
		LIMIT_HOUR_START="$(cat $C_CLASSES_DIR/$CLASS/Range1 | cut -d':' -f1)$(cat $C_CLASSES_DIR/$CLASS/Range1 | cut -d':' -f2 | cut -d'-' -f1)"
		LIMIT_HOUR_START="$(echo "$LIMIT_HOUR_START" | $C_ZT_BIN_DIR/bc)"
		LIMIT_HOUR_STOP="$(cat $C_CLASSES_DIR/$CLASS/Range1 | cut -d'-' -f2 | cut -d':' -f1)$(cat $C_CLASSES_DIR/$CLASS/Range1 | cut -d':' -f3)"
		LIMIT_HOUR_STOP="$(echo "$LIMIT_HOUR_STOP" | $C_ZT_BIN_DIR/bc)"
		LIMIT_HOUR_START_SEC="$(cat $C_CLASSES_DIR/$CLASS/Range2 | cut -d':' -f1)$(cat $C_CLASSES_DIR/$CLASS/Range2 | cut -d':' -f2 | cut -d'-' -f1)"
		LIMIT_HOUR_START_SEC="$(echo "$LIMIT_HOUR_START_SEC" | $C_ZT_BIN_DIR/bc)"
		LIMIT_HOUR_STOP_SEC="$(cat $C_CLASSES_DIR/$CLASS/Range2 | cut -d'-' -f2 | cut -d':' -f1)$(cat $C_CLASSES_DIR/$CLASS/Range2 | cut -d':' -f3)"
		LIMIT_HOUR_STOP_SEC="$(echo "$LIMIT_HOUR_STOP_SEC" | $C_ZT_BIN_DIR/bc)"
		NTODAY="$(date +%w)"
		HOURNOW="$(echo "$(date +%H%M)" | $C_ZT_BIN_DIR/bc)"
		if [ "$CLASS" == "MUDC" ];then
			PASS="$(echo "$PASS" | cut -d'-' -f1)"
			PASS="$PASS-$RANDOM"
			DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			exit
		fi
		if [ -n "$LIMIT_DAYS" ];then
			NTODAY="$(date +%w)"
			[ -z "$(echo "$LIMIT_DAYS" | grep "$NTODAY")" ] && OUTRANGE="yes"
		fi
		if [[ -z "$OUTRANGE" && -n "$LIMIT_HOUR_START" && -n "$LIMIT_HOUR_STOP"  ]];then
			if [ -n "$LIMIT_HOUR_START_SEC" ];then
				[[ "$HOURNOW" -lt "$LIMIT_HOUR_START" || "$HOURNOW" -gt "$LIMIT_HOUR_STOP" ]] && [[ "$HOURNOW" -lt "$LIMIT_HOUR_START_SEC" || "$HOURNOW" -gt "$LIMIT_HOUR_STOP_SEC" ]] && OUTRANGE="yes"
			else
				[[ "$HOURNOW" -lt "$LIMIT_HOUR_START" || "$HOURNOW" -gt "$LIMIT_HOUR_STOP" ]] && OUTRANGE="yes"
			fi
		fi
		if [[ -n "$OUTRANGE" && -z "$(echo "$PASS" | grep '-')" ]];then
			PASS="$PASS-$RANDOM"
			DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		fi
		if [[ -z "$OUTRANGE" && -n "$(echo "$PASS" | grep '-')" ]];then
			PASS="$(echo "$PASS" | cut -d'-' -f1)"
			DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		fi
	else
		if [ -n "$(echo "$PASS" | grep '-')" ];then
			PASS="$(echo "$PASS" | cut -d'-' -f1)"
			DATA="dn: cn=$USER,ou=Radius,$C_LDAPBASE\nsn: $PASS"
			echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
		fi
	fi
fi

if [ "$1" == "CreateKeyScp" ];then
	if [ ! -f /root/.ssh/id_rsa.pub ];then
		cd /root
		ssh-keygen -t rsa -N "" -f /root/.ssh/id_rsa  2>/dev/null >/dev/null
		
		#cat /root/.ssh/id_rsa.pub | ssh $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys"
	fi
fi

if [ "$1" == "RemoveKeyScp" ];then
	if [ -f /root/.ssh/id_rsa ];then
		rm -rf /root/.ssh/id_rsa 2>/dev/null
		rm -rf /root/.ssh/id_rsa.pub 2>/dev/null
		rm -rf /root/.ssh/known_hosts 2>/dev/null
	fi
fi

if [ "$1" == "ViewKeySCP" ];then
	echo "$(cat /root/.ssh/id_rsa.pub)"

fi

if [ "$1" == "Checkidrsa" ];then
	if [ -f /root/.ssh/id_rsa.pub ];then
			echo "yes"
	fi
fi

if [ "$1" == "StatusSSC" ];then
	echo "control connected" > /tmp/control_scp
	scp /tmp/control_scp $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE:$C_DIR_SCP_REMOTE || CONTROL="no"
	if [ -z "$CONTROL" ];then
		echo "yes"
	else
		echo ""
	fi
fi

if [ "$1" == "RemoteBackup" ];then
	NAS=$(echo "$C_HOTSPOT_NAME" |  sed '/ /s//_/g')
	CBKR=`ssh $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE "ls -lht ./$C_DIR_SCP_REMOTE  $NAS-SCP*" || echo "no"`
	if [ "$CBKR" != "no" ];then
		 echo "$CBKR"  | awk '{n=split ($0, a, " ");print a[5]" "a[9]'} | sed 's/ /+/g' | sed '/^+$/d'
	else
		echo "no"
	fi
fi

if [ "$1" == "DeleteBackupScp" ];then
	BACKUP="$2"
	ssh $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE "rm -f ./$C_DIR_SCP_REMOTE/$BACKUP" 2>/dev/null
fi

if [ "$1" == "DownloadBackupScp" ];then
	BACKUP="$2"
	if [ -z "$3" ];then
		rm -rf $C_ZT_DIR/tmp/restorebk 2>/dev/null
		mkdir $C_ZT_DIR/tmp/restorebk
		chmod a+w $C_ZT_DIR/tmp/restorebk
		scp $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE:$C_DIR_SCP_REMOTE/$BACKUP $C_ZT_DIR/tmp/restorebk
	else
		mkdir $C_HTDOCS_DIR/$4
		scp $C_USER_SCP_REMOTE@$C_IP_SCP_REMOTE:$C_DIR_SCP_REMOTE/$BACKUP $C_HTDOCS_DIR/$4
		$C_ZT_SCRIPTS_DIR/RemoveTgz.sh "$C_HTDOCS_DIR/$4" &
	fi
fi

if [ "$1" == "SaveClientctrl" ];then
	rm -f /root/kerbynet.cgi/template/cp_clientctrl
	rm -f /root/kerbynet.cgi/template/cp_clientctrl_renew
	if [ -n "$C_ZT_POPUP" ];then
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl /root/kerbynet.cgi/template/cp_clientctrl
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
	else
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
	fi
fi

if [ "$1" == "RuleCB" ];then
	INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
	INTERFACESCP="$(cat $C_SYSTEM/cp/Interface | sed 's/\./_/g')"
	if [ -n "$3" ];then
		for INTCP in $INTERFACESCP;do
			iptables -D FORWARD -i $INTCP -o $INTERFACEWAN -m connlimit --connlimit-above $2 --connlimit-mask 32 --connlimit-saddr -j DROP
		done
		exit
	else
		for INTCP in $INTERFACESCP;do
			iptables -I FORWARD -i $INTCP -o $INTERFACEWAN -m connlimit --connlimit-above $2 --connlimit-mask 32 --connlimit-saddr -j DROP
		done
	fi
fi

if [ "$1" == "ZtPopup" ];then
	rm -f /root/kerbynet.cgi/template/cp_clientctrl
	rm -f /root/kerbynet.cgi/template/cp_clientctrl_renew
	if [ -n "$2" ];then
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl /root/kerbynet.cgi/template/cp_clientctrl
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
	else
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl
		ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
	fi
fi


if [ "$1" == "ConfigTemplate" ];then
	TEMPLATE="$2"
	rm -rf $C_HTDOCS_TEMPLATE_DIR
	ln -s $C_HTDOCS_ZT_DIR/templates/$TEMPLATE $C_HTDOCS_TEMPLATE_DIR
	rm -f $C_HTDOCS_ZT_DIR/images/template
	ln -s $C_HTDOCS_ZT_DIR/templates/$TEMPLATE/images $C_HTDOCS_ZT_DIR/images/template
	rm -f $C_HTDOCS_DIR/images/template
	ln -s $C_HTDOCS_ZT_DIR/templates/$TEMPLATE/images $C_HTDOCS_DIR/images/template
	rm $C_HTDOCS_ZT_DIR/cgi-bin/template
	ln -s $C_HTDOCS_ZT_DIR/templates/$TEMPLATE/cgi-bin $C_HTDOCS_ZT_DIR/cgi-bin/template
	rm -f $C_HTDOCS_ZT_DIR/css/template
	ln -s $C_HTDOCS_ZT_DIR/templates/$TEMPLATE/css $C_HTDOCS_ZT_DIR/css/template
fi

if [ "$1" == "CreateCpSsl" ];then
	cat $C_HTDOCS_CONF_DIR/listenPort > $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	for ICP in $(cat $C_CP_DIR/Interface);do
		cat $C_HTDOCS_CONF_DIR/virtualPort > $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		IPCP="$(cat $C_SYSTEM/net/interfaces/$ICP/IP/00/IP)"
		URLR="$(cat $C_CP_DIR/Auth/URLrid_$ICP 2>/dev/null)"
		sed -i "s/IPCP/$IPCP/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		if [ -n "$URLR" ];then
			sed -i "s/%{SERVER_ADDR}/$URLR/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		fi
		cat $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp >> $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	done
	cat $C_HTDOCS_CONF_DIR/listenPortSSL >> $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	for ICP in $(cat $C_CP_DIR/Interface);do
		cat $C_HTDOCS_CONF_DIR/virtualPortSSL > $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		IPCP="$(cat $C_SYSTEM/net/interfaces/$ICP/IP/00/IP)"
		URLR="$(cat $C_CP_DIR/Auth/URLrid_$ICP 2>/dev/null)"
		sed -i "s/IPCP/$IPCP/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp 
		if [ -n "$URLR" ];then
			sed -i "s/%{SERVER_ADDR}/$URLR/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		fi
		cat $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp >> $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	done
	cat $C_HTDOCS_CONF_DIR/listenGWPort >> $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	for ICP in $(cat $C_CP_DIR/Interface);do
		cat $C_HTDOCS_CONF_DIR/virtualGWPort > $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		IPCP="$(cat $C_SYSTEM/net/interfaces/$ICP/IP/00/IP)"
		URLR="$(cat $C_CP_DIR/Auth/URLrid_$ICP 2>/dev/null)"
		sed -i "s/IPCP/$IPCP/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp 
		if [ -n "$URLR" ];then
			sed -i "s/%{SERVER_ADDR}/$URLR/g" $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
		fi
		cat $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp >> $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl
	done
	rm -rf $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl-temp
	ln -sf $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl /root/kerbynet.cgi/template/cp_as_URL-httpd.ssl
fi

if [ "$1" == "ConfLibAsterisk" ];then
	echo "/opt/libxml2/lib" >> /etc/ld.so.conf
	echo "/opt/jansson/lib" >> /etc/ld.so.conf
	echo "/opt/sqlite/lib" >> /etc/ld.so.conf
	ldconfig >/dev/null 2>/dev/null
fi

if [ "$1" == "StatusPeer" ];then
	cd /opt/libxml2/lib/
	STATUS="$(/opt/asterisk/sbin/asterisk -r -x "sip show peer $2" | grep 'Status' | awk '{print $3}')"
	if [ "$STATUS" == "OK" ];then
		echo "<img src=\"/images/abilita.png\"></td>"
	else
		echo "<img src=\"/images/disabilita.png\"></td>"
	fi
fi

if [ "$1" == "AsteriskStop" ];then
	/opt/asterisk/sbin/asterisk -r -x "core stop now"
fi

if [ "$1" == "AsteriskStart" ];then
	/opt/asterisk/sbin/asterisk
	sleep 5
fi

if [ "$1" == "AsteriskRestart" ];then
	/opt/asterisk/sbin/asterisk -r -x "core restart now" 
	sleep 5
fi

if [ "$1" == "KillProg" ]; then
	PROCESSNAME="$2"
	RETRY="$3"
	[ -z "$PROCESSNAME" ] && exit 1
	[ -z "$RETRY" ] && RETRY=10
	I=0
	while [ $I -lt $RETRY -a -n "`pidof $PROCESSNAME`" ] ; do
		killall $PROCESSNAME 2>/dev/null
		sleep 0.5
		I=$((I+1)) 
	done
	I=0
	while [ $I -lt $RETRY -a -n "`pidof $PROCESSNAME`" ] ; do
		killall -9 $PROCESSNAME 2>/dev/null
		sleep 0.5
		I=$((I+1)) 
	done
	if [ -z "`pidof $PROCESSNAME`" ] ; then
		exit 0
	else
		exit 2
	fi
fi


if [ "$1" == "mudc" ];then
	/DB/apache2/cgi-bin/zerotruth/mudc/scripts/mudc.sh "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9"
fi

if [ "$1" == "installMUDC" ];then
	cd /DB/apache2/cgi-bin/zerotruth/
	wget http://www.zerotruth.net/controldl.php?file=mudc-1.0.tar.gz
	if [ -f ./mudc-1.0.tar.gz ];then
		tar -zxvf mudc-1.0.tar.gz >/dev/null
		rm -f mudc-1.0.tar.gz
		ln -f -s $C_ZT_DIR/mudc/images /DB/apache2/htdocs/images/mudc
		ln -f -s $C_ZT_DIR/mudc/conf/keys.conf /DB/apache2/cgi-bin/zerotruth/conf/keys.conf
		ln -f -s $C_ZT_DIR/mudc/conf/dev.conf /DB/apache2/cgi-bin/zerotruth/conf/dev.conf
		ln -f -s $C_ZT_DIR/mudc/motion/video1  /DB/apache2/htdocs/video1
		ln -f -s /$C_ZT_DIR/mudc/motion/video2  /DB/apache2/htdocs/video2
		ln -f -s $C_ZT_DIR/mudc/motion/snapshot /DB/apache2/htdocs/images/snapshot
		ln -f -s $C_ZT_DIR/mudc/snapshot.sh /DB/apache2/htdocs/zerotruth/cgi-bin/snapshot.sh
		ln -f -s /DB/apache2/htdocs/images/action_x.png  /DB/apache2/htdocs/zerotruth/template/images/action_x.png
		if [ -z "$(cat $C_ZT_CONF_DIR/zt.config | grep '^C_DIFFGMT' )" ];then
			DATEUTC="$(date -u | awk '{print $4}' | cut -d':' -f1)"
			DATECET="$(date  | awk '{print $4}' | cut -d':' -f1)"
			DIFFSEC="$(echo $(($DATECET-$DATEUTC))*3600 | $C_ZT_DIR/bin/bc)"
			echo "" >> $C_ZT_CONF_DIR/zt.config
			echo "# DIFFSEC" >> $C_ZT_CONF_DIR/zt.config
			echo "C_DIFFGMT=\"$DIFFSEC\"" >> $C_ZT_CONF_DIR/zt.config
		fi
		$C_ZT_BIN_DIR/zt "SalvaConfig" "C_REBOOT" "on"
	fi
fi

if [ "$1" == "deleteMUDC" ];then
	cd /DB/apache2/cgi-bin/zerotruth/
	if [ -d /DB/apache2/cgi-bin/zerotruth/mudc ];then
		rm -f -r /DB/apache2/cgi-bin/zerotruth/mudc
	fi
	rm -f  /DB/apache2/htdocs/images/mudc
	rm -f  $C_ZT_DIR/conf/keys.conf
	rm -f  $C_ZT_DIRh/conf/dev.conf
	rm -f  /DB/apache2/htdocs/video1
	rm -f  /DB/apache2/htdocs/video2
	rm -f  /DB/apache2/htdocs/images/snapshot
	rm -f  $C_ZT_DIR/cgi-bin/snapshot.sh
	rm -f  /DB/apache2/htdocs/zerotruth/template/images/action_x.png
	rm -f -r  $C_CRON_SCRIPTS_DIR/MUDCcontrol-Cron
	$C_ZT_BIN_DIR/zt  "KillProg" "cron"
	rm -f /var/run/cron.pid
	/etc/init.d/crond start > /dev/null
	
fi


if [ "$1" == "KillF2B" ];then
	PIDF2B="$(ps ax | grep fail2ban | grep -v grep | awk '{print $1}')"
	I=0
	while [ $I -lt 10 -a -n "$(ps ax | grep fail2ban)" ] ; do
		killall fail2ban-server 2>/dev/null
		sleep 0.5
		I=$((I+1)) 
	done
	rm -rf /var/run/fail2ban.pid 2>/dev/null
	rm -rf /var/run/fail2ban.sock 2>/dev/null
fi

if [ "$1" == "ControlF2B" ];then
	[ -n "$(ps -A | grep fail2ban)" ] && echo "YES"
fi

if [ "$1" == "StatusF2B" ];then
	cd $C_ZT_DIR/bin/fail2ban
	echo "$(PYTHONPATH=. bin/fail2ban-client status 2>/dev/null | grep 'Jail list')"
fi
if [ "$1" == "StatusF2BP" ];then
	cd $C_ZT_DIR/bin/fail2ban
	STATUS="$(PYTHONPATH=. bin/fail2ban-client status $2 2>/dev/null)"
	CF="$(echo "$STATUS" | grep 'Currently failed' | awk '{print $NF}')"
	TF="$(echo "$STATUS" | grep 'Total failed' | awk '{print $NF}')"
	CB="$(echo "$STATUS" | grep 'Currently banned' | awk '{print $NF}')"
	TB="$(echo "$STATUS" | grep 'Total banned' | awk '{print $NF}')"
	echo "$CF-$TF-$CB-$TB"
fi

if [ "$1" == "ActiveF2B" ];then
	$C_ZT_BIN_DIR/zt  "KillF2B"  2>/dev/null
	if [ -n "$2" ];then
		HOST=$(echo $HOSTNAME | cut -d'.' -f1)
		for LOG in "sshd"  "ZT.LoginError";do
			[ ! -f /Database/LOG/$(date +%Y)/$(date +%b)/$(date +%d)/$HOST/$LOG ] && echo "" > /Database/LOG/$(date +%Y)/$(date +%b)/$(date +%d)/$HOST/$LOG
			ln -sf /Database/LOG/$(date +%Y)/$(date +%b)/$(date +%d)/$HOST/$LOG $C_ZT_DIR/log/$LOG
		done
		cd  $C_ZT_DIR/bin/fail2ban
		sleep 1
		PYTHONPATH=. bin/fail2ban-client start >/dev/null 2>/dev/null
	fi
fi

if [ "$1" == "ConfigF2B" ];then
	NRME="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '^maxretry' | awk '{print $1}' | sed -n '1p')"
	sed -i "${NRME}s/^maxretry.*/maxretry = $(echo $2 | cut -d'-' -f1)/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	NRBT="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '^bantime' | awk '{print $1}' | sed -n '1p')"
	sed -i "${NRBT}s/^bantime.*/bantime = $(echo $2 | cut -d'-' -f2)/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	NRFT="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '^f'ndtime | awk '{print $1}' | sed -n '1p')"
	sed -i "${NRFT}s/^findtime.*/findtime = $(echo $2 | cut -d'-' -f3)/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	NRSSHD="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '\[sshd\]' | awk '{print $1}')"
	NRSSHD=$(($NRSSHD+1))
	NRZTLOGIN="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '\[Zerotruth-login\]' | awk '{print $1}')"
	NRZTLOGIN=$(($NRZTLOGIN+1))
	NRASTERISK="$( nl $C_ZT_DIR/bin/fail2ban/config/jail.conf   | grep '\[asterisk\]' | awk '{print $1}')"
	NRASTERISK=$(($NRASTERISK+1))
	if [ -n "$(echo $2 | cut -d'-' -f4)" ];then
		sed -i "${NRSSHD}s/^enabled.*/enabled = true/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	else
		sed -i "${NRSSHD}s/^enabled.*/enabled = false/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	fi
	if [ -n "$(echo $2 | cut -d'-' -f5)" ];then 
		sed -i "${NRASTERISK}s/^enabled.*/enabled = true/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	else
		sed -i "${NRASTERISK}s/^enabled.*/enabled = false/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	fi
	if [ -n "$(echo $2 | cut -d'-' -f6)" ];then
		sed -i "${NRZTLOGIN}s/^enabled.*/enabled = true/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	else
		sed -i "${NRZTLOGIN}s/^enabled.*/enabled = false/g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	fi
	$C_ZT_BIN_DIR/zt  "ActiveF2B" "ON"
fi

if [ "$1" == "DEL_IPF2B" ];then
	$C_ZT_BIN_DIR/zt  "KillF2B"  2>/dev/null
	IPF="$(echo $2 | sed 's|/|\\/|g')"
	FREEIPF2B="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep '^ignoreip' | cut -d'=' -f2 | sed 's/ //g' )"
	FREEIPF2B="$(echo "$FREEIPF2B" | sed "s|$IPF||g" | sed 's/,,/,/g' | sed "s/,$//g")"
	sed -i "s|^ignoreip.*|ignoreip = $FREEIPF2B|g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	$C_ZT_BIN_DIR/zt  "ActiveF2B"  "ON" 2>/dev/null
fi

if [ "$1" == "ADD_IPF2B" ];then
	$C_ZT_BIN_DIR/zt  "KillF2B"  2>/dev/null
	IPF="$(echo $2 | sed 's|%2F|/|g')"
	FREEIPF2B="$(cat $C_ZT_DIR/bin/fail2ban/config/jail.conf | grep '^ignoreip' | cut -d'=' -f2 | sed 's/ //g' )"
	FREEIPF2B="$FREEIPF2B,$IPF"
	sed -i "s|^ignoreip.*|ignoreip = $FREEIPF2B|g" $C_ZT_DIR/bin/fail2ban/config/jail.conf
	$C_ZT_BIN_DIR/zt  "ActiveF2B"  "ON" 2>/dev/null
fi

if [ "$1" == "SecNow" ];then
	DATEUTC="$(date -u | awk '{print $4}' | cut -d':' -f1)"
	DATECET="$(date  | awk '{print $4}' | cut -d':' -f1)"
	DIFFSEC="$(echo $(($DATECET-$DATEUTC))*3600 | $C_ZT_DIR/bin/bc)"
	echo "$(($(date +%s)+$DIFFSEC))"
fi

if [ "$1" == "SecDiff" ];then
	DATEUTC="$(date -u | awk '{print $4}' | cut -d':' -f1)"
	DATECET="$(date  | awk '{print $4}' | cut -d':' -f1)"
	DIFFSEC="$(echo $(($DATECET-$DATEUTC))*3600 | $C_ZT_DIR/bin/bc)"
	echo "$(($2+DIFFSEC))"
fi
