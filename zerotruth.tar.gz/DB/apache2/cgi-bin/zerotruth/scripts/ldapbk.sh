#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

cat $1 > /tmp/LDAP
sed -i "s/dn: uid=admin/rOl9jhyYtgbvCF/g" /tmp/LDAP
sed -i "s/^$/## END/g" /tmp/LDAP
echo "ENDFILE" >> /tmp/LDAP
cat /tmp/LDAP | sed -n "/^dn: uid=/,/^ENDFILE/p"  >  /tmp/LDAP_FILE
sed -i "/^ENDFILE/d" /tmp/LDAP_FILE
sed -i "/^$/d" /tmp/LDAP_FILE
BASE=$(cat /tmp/LDAP_FILE | grep  "dn: uid" | tail -1)
LDAPBASE="$(echo "$BASE" | cut -d',' -f3),$(echo "$BASE" | cut -d',' -f4)"
if [ "$LDAPBASE" != "$C_LDAPBASE" ];then
	sed -i "s/$LDAPBASE/$C_LDAPBASE/g" /tmp/LDAP_FILE
fi
N_USERS=$(cat /tmp/LDAP_FILE | grep 'dn: uid' | wc -l)
for NR in $(seq 1 $N_USERS);do
	USER="$(cat /tmp/LDAP_FILE | grep 'dn: uid' | cut -d'=' -f2 | cut -d',' -f1 | /bin/sed -n "${NR}p")"
	LINE=$(/usr/local/bin/ldapsearch  -xLLL  -b  "ou=People,$C_LDAPBASE"  uid=$USER uid )
	USERLOCAL=$( echo "$LINE" | grep -e '^uid: ' | sed 's/^uid: //g')
	cat /tmp/LDAP_FILE | sed -n "/^dn: uid=$USER/,/^## END/p"  > /tmp/LDAP_PEOPLE_$USER
	sed -i "/^## /d" /tmp/LDAP_PEOPLE_$USER
	cat /tmp/LDAP_FILE | sed -n "/^dn: cn=$USER/,/^## END/p"  > /tmp/LDAP_RADIUS_$USER
	sed -i "/^## /d" /tmp/LDAP_RADIUS_$USER
	if [ -n "$USERLOCAL" ];then
		for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp" "uidNumber" "gidNumber" "objectClass" \
			"cn" "uidNumber" "homeDirectory" "loginShell" "entryCSN" "modifiersName" "modifyTimestamp";do
			sed -i "/^$RR\:/d" /tmp/LDAP_PEOPLE_$USER
		done
		sed -i "/^$/d" /tmp/LDAP_PEOPLE_$USER
		cat /tmp/LDAP_PEOPLE_$USER | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT
		for RR in "structuralObjectClass" "objectClass" "entryUUID" "creatorsName" "createTimestamp" "dialupAccess" \
			"entryCSN" "modifiersName" "modifyTimestamp";do
			sed -i "/^$RR\:/d" /tmp/LDAP_RADIUS_$USER
		done
		sed -i "/^$/d" /tmp/LDAP_RADIUS_$USER	
		cat /tmp/LDAP_RADIUS_$USER | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT
		PASSWORD=$(cat /tmp/LDAP_RADIUS_$USER | grep "sn:" | cut -d' ' -f2 | cut -d'-' -f1)
		EXPIRE=$(cat /tmp/LDAP_PEOPLE_$USER | grep "shadowExpire:" | cut -d' ' -f2 )
		EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y-%m-%d)
		$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USER" "$EXPIRE" > /dev/null
	else
		for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp"  \
			"entryCSN" "modifiersName" "modifyTimestamp" "uidNumber" ;do
			sed -i "/^$RR\:/d" /tmp/LDAP_PEOPLE_$USER
		done
		sed -i "/^$/d" /tmp/LDAP_PEOPLE_$USER
		cat /tmp/LDAP_PEOPLE_$USER | /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT 
		for RR in "structuralObjectClass" "entryUUID" "creatorsName" "createTimestamp"  \
			"entryCSN" "modifiersName" "modifyTimestamp";do
			sed -i "/^$RR\:/d" /tmp/LDAP_RADIUS_$USER
		done
		sed -i "/^$/d" /tmp/LDAP_RADIUS_$USER
		UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE"  uidNumber |  sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n |  tail -1 )
		UIDNUMBER=$(($UIDN+1))
		echo "uidNumber: $UIDNUMBER" >> /tmp/LDAP_PEOPLE_$USER	
		cat /tmp/LDAP_RADIUS_$USER| /usr/local/bin/ldapadd -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT
		PASSWORD=$(cat /tmp/LDAP_RADIUS_$USER | grep "sn:" | cut -d' ' -f2 | cut -d'-' -f1)
		EXPIRE=$(cat /tmp/LDAP_PEOPLE_$USER | grep "shadowExpire:" | cut -d' ' -f2 )
		EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y-%m-%d)
		$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USER" "$EXPIRE" > /dev/null
		
	fi
	rm -rf /tmp/LDAP_PEOPLE_$USER
	rm -rf /tmp/LDAP_RADIUS_$USER
done
rm -rf /tmp/LDAP_FILE

exit
