#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
if [ "$C_FORM_DATE" == "ita" ];then
	TODAY=$(date +%d%m%Y)
else
	TODAY=$(date +%Y%m%d)
fi
cd /tmp/
NOMEFILE=$(echo "$C_HOTSPOT_NAME" |  sed '/ /s//_/g')
tar -czvf $NOMEFILE-$TODAY-usersSessions.tgz usersSessions
mv $NOMEFILE-$TODAY-usersSessions.tgz /DB/apache2/htdocs/
rm -rf /tmp/usersSessions
logger -t backup "Users Sessions - Download"
exit











