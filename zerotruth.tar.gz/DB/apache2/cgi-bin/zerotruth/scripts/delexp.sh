#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid)
USERNAMEEOPLE=$(echo "$PEOPLE" | sed -n '/uid:/p' | awk '{ print $2 }')
for USERNAME in $USERNAMEEOPLE;do
	ldap_search_people
	ldap_search_radius
	LIMITMB=$(cat $C_ACCT_DIR/classes/$CLASS/MB)
	if [ -z $LIMITMB  ] ;then
		LIMITMB=0
	else
		LIMITMB=$((LIMITMB*1048576))
	fi
	LIMITH=$(cat $C_ACCT_DIR/classes/$CLASS/Hours)
	if [ $LIMITH != "" ] || [ $LIMITH != 0 ];then
		LIMITH=$(($LIMITH*3600))
	else
		LIMITH=0
	fi
	TRAFFIC=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/*/Traffic)
	TRAFFIC=$(echo $TRAFFIC | sed '/ /s//+/g')
	TRAFFIC=$(echo $TRAFFIC |  $C_ZT_BIN_DIR/bc)
	TIME=$(cat $C_ACCT_DIR/entries/$USERNAME/sessions/*/Time)
	TIME=$(echo $TIME | sed '/ /s//+/g')
	TIME=$(echo $TIME |  $C_ZT_BIN_DIR/bc)
	TODAY=$(date +%s)
	TODAY=$(($TODAY/86400))
	TD=$(date +%d%m%Y)
	CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
	CONTROLS=$(echo $CREDIT | awk '{split ($0, a, "-");print a['2']}')
	CHARGETYPE=$(cat $C_ACCT_DIR/classes/$CLASS/ChargeType)
	EXPIRED=""
	[[ $TRAFFIC -gt $LIMITMB  &&  $LIMITMB != 0 ]] && EXPIRED="ok"
	[[ $TIME -gt $LIMITH && $LIMITH != 0 ]] && EXPIRED="ok"
	[ $TODAY -gt $EXPIRE ] && EXPIRED="ok"
	[[ -n "$CONTROLS" ||  -z $CREDIT  &&  "$CHARGETYPE" == "pre" ]] && EXPIRED="ok"
	if [ "$EXPIRED" == "ok" ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}START-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERNAME}STOP-Cron"
		$C_ZT_BIN_DIR/zt "RestartCron"
		if [ -n $(ls $C_ACCT_DIR/entries/$USERNAME/sessions 2> /dev/null) ];then
			if [ ! -d $C_ZT_DIR/deleted ];then
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted"
			fi
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TD"
			$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERNAME" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TD"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERNAME"
			if [ -f $C_ACCT_DIR/credits/$USERNAME/Credit ];then
				$C_ZT_BIN_DIR/zt "Copia" "$C_ACCT_DIR/credits/$USERNAME/Credit" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TD/Credit"
			fi
		fi
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERNAME"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERNAME"
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" > /dev/null
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERNAME,ou=Radius,$C_LDAPBASE" > /dev/null
		$C_ZT_BIN_DIR/zt "DelK5" "$USERNAME"
done








