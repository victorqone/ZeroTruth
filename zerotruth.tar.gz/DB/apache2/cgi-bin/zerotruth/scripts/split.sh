#!/usr/bin/perl

use strict;
use warnings;

while(my $line = <STDIN>) {
    print join(" ", sort(split(/\s+/, $line))) . "\n";
}
