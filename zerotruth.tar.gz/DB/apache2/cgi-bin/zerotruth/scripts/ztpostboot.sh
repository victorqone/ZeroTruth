#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
cp -f /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf-save
ln -s -f $C_HTDOCS_CONF_DIR/httpd.conf /etc/httpd/conf/httpd.conf
cp -f /etc/httpd/conf/ssl.conf /etc/httpd/conf/ssl.conf-save
ln -s -f $C_HTDOCS_CONF_DIR/ssl.conf /etc/httpd/conf/ssl.conf
cp -f /root/kerbynet.cgi/template/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl-save
cp -f /root/kerbynet.cgi/template/cp_clientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew-save
if [ -n "$C_ZT_POPUP" ];then
	ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl /root/kerbynet.cgi/template/cp_clientctrl
	ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_ztclientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
else
	ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl
	ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl_renew /root/kerbynet.cgi/template/cp_clientctrl_renew
fi
cp -f /root/kerbynet.cgi/template/cp_authorize /root/kerbynet.cgi/template/cp_authorize-save
ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_authorize /root/kerbynet.cgi/template/cp_authorize
cp -f /root/kerbynet.cgi/template/cp_clientctrl_failed /root/kerbynet.cgi/template/cp_clientctrl_failed-save
ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl_failed /root/kerbynet.cgi/template/cp_clientctrl_failed
cp -f /root/kerbynet.cgi/template/setup_menu /root/kerbynet.cgi/template/setup_menu-save
ln -s -f $C_HTDOCS_TEMPLATE_DIR/setup_menu /root/kerbynet.cgi/template/setup_menu
cp -f /root/kerbynet.cgi/scripts/cp_authorize_client /root/kerbynet.cgi/scripts/cp_authorize_client-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_authorize_client /root/kerbynet.cgi/scripts/cp_authorize_client
cp -f /root/kerbynet.cgi/scripts/cp_createticket /root/kerbynet.cgi/scripts/cp_createticket-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_createticket /root/kerbynet.cgi/scripts/cp_createticket
cp -f /root/kerbynet.cgi/scripts/cp_connect /root/kerbynet.cgi/scripts/cp_connect-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_connect /root/kerbynet.cgi/scripts/cp_connect
cp -f /root/kerbynet.cgi/scripts/cp_auth_start /root/kerbynet.cgi/scripts/cp_auth_start-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_auth_start /root/kerbynet.cgi/scripts/cp_auth_start
if [ -f $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl ];then
	ln -s  $C_HTDOCS_CONF_DIR/cp_as_URL-httpd.ssl /root/kerbynet.cgi/template/cp_as_URL-httpd.ssl
fi
cp -f /root/kerbynet.cgi/scripts/acct_userlimits /root/kerbynet.cgi/scripts/acct_userlimits-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/acct_userlimits /root/kerbynet.cgi/scripts/acct_userlimits
cp -f /root/kerbynet.cgi/scripts/cp_getaccounting /root/kerbynet.cgi/scripts/cp_getaccounting-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_getaccounting /root/kerbynet.cgi/scripts/cp_getaccounting
cp -f /root/kerbynet.cgi/scripts/acct_interim_update /root/kerbynet.cgi/scripts/acct_interim_update-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/acct_interim_update /root/kerbynet.cgi/scripts/acct_interim_update
cp -f /etc/openldap/schema/inetorgperson.schema /etc/openldap/schema/inetorgperson.schema-save
ln -s -f $C_HTDOCS_CONF_DIR/inetorgperson.schema  /etc/openldap/schema/inetorgperson.schema
ln -s -f $C_HTDOCS_CONF_DIR/sysctl.conf /etc/sysctl.conf
ln -s -f /DB /db
echo "TEMPLATEPATH /DB/apache2/htdocs/proxy/language/havp/template" >> /root/kerbynet.cgi/template/havp.config
echo "/DB/apache2/cgi-bin/zerotruth/lib" >> /etc/ld.so.conf
HTTP_PORT=$(cat $C_SYSTEM/httpd/HTTP)
HTTPS_PORT=$(cat $C_SYSTEM/httpd/HTTPS)
$C_ZT_BIN_DIR/zt "HttpdConf" "$HTTP_PORT" "$HTTPS_PORT"
ldconfig >/dev/null 2>/dev/null
groupadd apache -g 1000 2>/dev/null >/dev/null
/etc/init.d/httpd restart >/dev/null
/root/kerbynet.cgi/scripts/cp_auth_start
/etc/init.d/ldap restart >/dev/null
useradd proxy >/dev/null
sysctl -p >/dev/null
$C_ZT_BIN_DIR/zt "DisableCp443" "$C_DISABLE_CP_443"
if [ -d $C_CP_DIR/Connected ];then
	CONNECTED=$(ls $C_CP_DIR/Connected ) 2>/dev/null
	if [ -n "$CONNECTED" ];then
		for IP in $CONNECTED;do
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		done
	fi
fi

if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
	$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
fi

if [ -n "$C_SHAPER" ];then
	$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/*
	if [ ! -f  /Database/var/register/system/acct/classes/DEFAULT/Mbits ];then
		touch /Database/var/register/system/acct/classes/DEFAULT/Mbits
	fi
	if [ ! -f  /Database/var/register/system/acct/classes/DEFAULT/MbitsUp ];then
		touch /Database/var/register/system/acct/classes/DEFAULT/MbitsUp
	fi
	$C_ZT_BIN_DIR/zt "Shaper" "on"
fi

if [ "$C_NOT_SMS_START_ZT" == "on" ] && [ -n "$C_ADMIN_PHONE" ];then
	TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_START_ZT"
	$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN"
fi

if [ -n "$C_NOT_EMAIL_START_ZT" ] && [ -n "$C_ADMIN_EMAIL" ];then
	TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
	TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_START_ZT"
	TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
fi

if [ -n "$C_IPBLOCKED" ];then
	$C_ZT_BIN_DIR/zt "Esegui" "$C_ZT_SCRIPTS_DIR/ipbanned.sh"
fi

if [[ -n "$C_SMS_ABIL" && "$C_SMS_PROVIDER" == "Gammu" ]];then
	$C_ZT_BIN_DIR/zt "StartGammu"
fi

if [[ -n "$C_SMS_ABIL" && "$C_SMS_PROVIDER" == "Gammu" ]];then
	$C_ZT_BIN_DIR/zt "StartGammu"
fi

if [ -f $C_ZT_CONF_DIR/keyssh.tgz ];then
	tar zxvf $C_ZT_CONF_DIR/keyssh.tgz -C /root
fi

if [ -n "$C_KEYPAD" ];then
	$C_ZT_BIN_DIR/readkeys &
fi

if [ -n "$C_CONN_GLOBAL" ];then
	$C_ZT_BIN_DIR/zt "RuleCB" "$C_CONN_GLOBAL"
fi

if [ -d $C_ZT_DIR/mudc ];then
	$C_ZT_BIN_DIR/zt "mudc" "PostBoot"
fi

if [ -n "$C_FAIL2BAN" ];then
	$C_ZT_BIN_DIR/zt "mudc" "ActiveF2B" "on"
fi

exit
