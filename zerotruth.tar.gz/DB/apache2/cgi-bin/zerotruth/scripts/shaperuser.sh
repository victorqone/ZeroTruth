#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************
source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
IP="$1"
[ -z "$IP" ] && exit
USERNAME="$(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1)"
INTERFACECP="$(cat $C_SYSTEM/cp/Interface | awk '{print $1}')"
INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
if [ "$C_CP_LOCAL_TYPE" == "Client" ];then
	CONTROL_NC=$( `nc -z -w 4 $C_CP_REMOTE_IP1 8089  2> /dev/null` || echo "down")
	if [ -z "$CONTROL_NC" ];then
		CLASS=$(curl http://$C_CP_REMOTE_IP1:8089/cgi-bin/remotecp.sh?NAS=$C_CP_LOCAL_NAME+IP=$C_CP_LOCAL_IP+PASS=$C_CP_REMOTE_PASSWORD1+ACTION=ControlClass+OPTION=$USERNAME)
	fi
else
	RADIUS_CLASS="$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERNAME radiusUserCategory)"
	CLASS="$(echo "$RADIUS_CLASS" | grep -e '^radiusUserCategory: ' | sed 's/^radiusUserCategory: //g')"
fi
[ -z "$CLASS" ] && CLASS="DEFAULT"
if [ "$(cat $C_CLASSES_DIR/$CLASS/ShaperType)" == "user" ];then
	RATE="$(cat $C_CLASSES_DIR/$CLASS/Mbits)"
	[ -z "$RATE" ] && RATE="open"
	RATEU="$(cat $C_CLASSES_DIR/$CLASS/MbitsUp)"
	[ -z "$RATEU" ] && RATEU="open"
	if [[ "$RATE" != "open" || "$RATEU" != "open" ]];then
		if [ "$RATE" != "open" ];then
			NID="$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME uidNumber | grep -e '^uidNumber: ' | sed 's/^uidNumber: //g')"
			NID="4$NID"
			RATE="$(echo "$RATE*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)"
			RATEKB="$(echo $RATE""Kbit)"
			WEIGHT="$(echo "$RATE/10" | $C_ZT_BIN_DIR/bc )"
			WEIGHTKB="$(echo $WEIGHT""Kbit)"
			DATACONF="# Bandwidth user: $USERNAME class: $CLASS"
			DATACONF="$DATACONF\nDEVICE=$INTERFACECP,1000Mbit,100Mbit"
			DATACONF="$DATACONF\nRATE=$RATEKB"
			DATACONF="$DATACONF\nWEIGHT=$WEIGHTKB"
			DATACONF="$DATACONF\nPRIO=5"
			echo -e "$DATACONF" > $C_ZT_CONF_DIR/cbqconf/cbq-$NID.$USERNAME-$IP-$CLASS
			chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$NID.$USERNAME-$IP-$CLASS
			chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$NID.$USERNAME-$IP-$CLASS
			if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
				if ! [-d $C_ZT_DIR/tmp/cbqconf ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/cbqconf"
				fi
				echo -e "$DATACONF" > $C_ZT_DIR/tmp/cbqconf/cbq-$NID.$USERNAME-$IP-$CLASS
			fi
			echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$NID.$USERNAME-$IP-$CLASS
		fi
		if [ "$RATEU" != "open" ];then
			NID="$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME uidNumber | grep -e '^uidNumber: ' | sed 's/^uidNumber: //g')"
			MARK="5$NID"
			RATEU="$( echo "$RATEU*1024" | $C_ZT_BIN_DIR/bc | cut -d'.' -f1)"
			RATEKB="$(echo $RATEU""Kbit)"
			WEIGHT="$(echo "$RATEU/10" | $C_ZT_BIN_DIR/bc )"
			WEIGHTKB="$(echo $WEIGHT""Kbit)"
			DATACONF="# Bandwidth upload user: $USERNAME class: $CLASS"
			DATACONF="$DATACONF\nDEVICE=$INTERFACEWAN,1000Mbit,100Mbit"
			DATACONF="$DATACONF\nRATE=$RATEKB\nWEIGHT=$WEIGHTKB"
			DATACONF="$DATACONF\nPRIO=5\nMARK=$MARK"
			echo -e "$DATACONF" > $C_ZT_CONF_DIR/cbqconf/cbq-$MARK.$USERNAME-$IP-$CLASS-UP
			chown root:root $C_ZT_CONF_DIR/cbqconf/cbq-$MARK.$USERNAME-$IP-$CLASS-UP
			chmod 755 $C_ZT_CONF_DIR/cbqconf/cbq-$MARK.$USERNAME-$IP-$CLASS-UP
			if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
				if ! [-d $C_ZT_DIR/tmp/cbqconf ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/tmp/cbqconf"
				fi
				echo -e "$DATACONF" > $C_ZT_DIR/tmp/cbqconf/cbq-$MARK.$USERNAME-$IP-$CLASS-UP
			fi
			echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$MARK.$USERNAME-$IP-$CLASS-UP
			/usr/local/sbin/iptables --table mangle -D POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK
			/usr/local/sbin/iptables --table mangle -A POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK
		fi
		if [ -f $C_ZT_CONF_DIR/cbqconf/cbq.init ];then
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq.init" 2>/dev/null > /dev/null
		fi
		$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
	fi
else
	NUM_CLASS="$(cat $C_CLASSES_DIR/$CLASS/NumClass)"
	if [ -f  $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS ];then
		sed -i "/$IP/d" $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS 2>/dev/null > /dev/null
		if [ "$2" == "yes" ];then
			echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS
		fi
		CONTROL_SH="yes"
	fi
	NUM_CLASS=$(($NUM_CLASS+100))
	if [ -f  $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS ];then
		sed -i "/$IP/d" $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS 2>/dev/null > /dev/null
		INTERFACEWAN="$(route -n | grep '^0.0.0.0' | awk '{print $NF}')"
		MARK="$(cat $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS | grep  'MARK' | cut -d'=' -f2)"
		/usr/local/sbin/iptables --table mangle -D POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK
		if [ "$2" == "yes" ];then
			echo "RULE=$IP/32" >> $C_ZT_CONF_DIR/cbqconf/cbq-$NUM_CLASS.$CLASS
			/usr/local/sbin/iptables --table mangle -A POSTROUTING --out-interface $INTERFACEWAN -s $IP -j MARK --set-mark $MARK
		fi
		CONTROL_SH="yes"
	fi
	if [ -n "$CONTROL_SH" ];then
		if [ -f $C_ZT_CONF_DIR/cbqconf/cbq.init ];then
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_CONF_DIR/cbqconf/cbq.init" 2>/dev/null > /dev/null
		fi
		$C_ZT_SCRIPTS_DIR/cbq.sh restart 2>/dev/null > /dev/null
	fi
fi
