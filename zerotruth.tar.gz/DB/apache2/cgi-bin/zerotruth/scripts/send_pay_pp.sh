#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#************************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
PP_URL=$(cat $C_ZT_CONF_DIR/conf_pp | grep PAYMENT | awk '{print $2}') 
PP_RETURN=$(curl -k -v $PP_URL \
-H 'Content-Type:application/json' \
-H "Authorization:Bearer $C_PP_TOKEN" \
-d '{
  "intent":"sale",
  "redirect_urls":{
    "return_url":"http://zerotruth.org",
    "cancel_url":"http://zerotruth.org"
  },
  "payer":{
    "payment_method":"paypal"
  },
  "transactions":[
    {
      "amount":{
        "total":"xxxxx",
        "currency":"USD"
      },
      "description":"Zerotruth"
    }
  ]
}')

CC_URL=$(echo "$PP_RETURN" | awk '{split ($0, a, "GET");print a[2]}' | cut -d'"' -f5)
CC_PAY=$(echo "$PP_RETURN" | awk '{split ($0, a, "PAY-");print a[2]}' | cut -d'"' -f1)
$C_ZT_BIN_DIR/zt "Aggiungi" "P_RET PAY-$CC_PAY" "$C_ZT_DIR/tmp/Aaashb"

echo "<script language=\"JavaScript\" type=\"text/javascript\">

location.href=\"$CC_URL&useraction=commit\";

</SCRIPT>"
