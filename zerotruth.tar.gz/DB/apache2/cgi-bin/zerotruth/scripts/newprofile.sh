#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#***********************************************************************

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh


if [[ -f $C_SYSTEM/cp/Interface && $(cat $C_SYSTEM/cp/Enabled) == "yes" ]];then
	interfacecp=$(cat $C_SYSTEM/cp/Interface | awk '{print $1}')
	controlv=$(echo "$interfacecp" | cut -sd'.' -f2)
	if [ -n "$controlv" ];then
		interface=$(echo "$interfacecp" | cut -d'.' -f1)
		ipcp=$(cat $C_SYSTEM/net/interfaces/$interface/VLAN/$controlv/IP/00/IP)
		ln -f -s $C_SYSTEM/net/interfaces/$interface/VLAN/$controlv/IP/00/IP $C_SYSTEM/cp/Auth/Custom/IP
	else
		ipcp=$(cat $C_SYSTEM/net/interfaces/$interfacecp/IP/00/IP)
		ln -f -s $C_SYSTEM/net/interfaces/$interfacecp/IP/00/IP $C_SYSTEM/cp/Auth/Custom/IP
	fi
else
	echo "Zeroshell Captive Portal is not active"
	echo "Before you config zerotruth for new profile you have to activate it from zeroshell"
	echo ""
	echo "See you soon."
	echo " "
	exit
fi


cp -f /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf-save
ln -s -f $C_HTDOCS_CONF_DIR/httpd.conf /etc/httpd/conf/httpd.conf
cp -f /etc/httpd/conf/ssl.conf /etc/httpd/conf/ssl.conf-save
ln -s -f $C_HTDOCS_CONF_DIR/ssl.conf /etc/httpd/conf/ssl.conf
cp -f /root/kerbynet.cgi/template/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl-save
ln -s -f $C_HTDOCS_TEMPLATE_DIR/cp_clientctrl /root/kerbynet.cgi/template/cp_clientctrl
cp -f /root/kerbynet.cgi/scripts/cp_authorize_client /root/kerbynet.cgi/scripts/cp_authorize_client-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_authorize_client /root/kerbynet.cgi/scripts/cp_authorize_client
cp -f /root/kerbynet.cgi/scripts/cp_createticket /root/kerbynet.cgi/scripts/cp_createticket-save
ln -s -f $C_HTDOCS_SCRIPTS_DIR/cp_createticket /root/kerbynet.cgi/scripts/cp_createticket
cp -f /root/kerbynet.cgi/scripts/proxy_start /root/kerbynet.cgi/scripts/proxy_start-save
cp -f /etc/openldap/schema/inetorgperson.schema /etc/openldap/schema/inetorgperson.schema-save
ln -s -f $C_HTDOCS_CONF_DIR/inetorgperson.schema  /etc/openldap/schema/inetorgperson.schema
ln -s -f $C_HTDOCS_CONF_DIR/sysctl.conf /etc/sysctl.conf
echo "/DB/apache2/cgi-bin/zerotruth/lib" >> /etc/ld.so.conf

if [ ! -d $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron ];then
	mkdir $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron
	mkdir $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/cron
	echo "Cron ZTcontrol" > $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/Enabled
	echo "# Bash script: ZTcontrol-Cron" > $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/File
	echo "$ZT_BIN_DIR/zt Control" >> $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/File
	echo "5 m" > $C_CRON_SCRIPTS_DIR/ZTcontrol-Cron/cron/Step
	CONTROL_CRON="yes"
fi

if [ ! -d $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron ];then
	mkdir $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron
	mkdir $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron
	let HOUR=$RANDOM%23
	let MINUTE=$RANDOM%59
	echo "Cron ZTcontrolupdate" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt ControlUpdate" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/File
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/DoM
	echo "$HOUR" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/Hour
	echo "$MINUTE" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZTcontrolupdate-Cron/cron/Step
	CONTROL_CRON="yes"
fi

if [ ! -d $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron ];then
	mkdir $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron
	mkdir $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron
	echo "Cron ZTrestartored" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt RestartOreD" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/File
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/DoW
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/DoM
	echo "0" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/Hour
	echo "1" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZTrestartored-Cron/cron/Step
	CONTROL_CRON="yes"
fi

if [ ! -d $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron ];then
	mkdir $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron
	mkdir $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron
	echo "Cron ZTrestartorem" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/Description
	echo "yes" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/Enabled
	echo "$C_ZT_BIN_DIR/zt RestartOreM" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/File
	chmod 755 $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/File
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/DoW
	echo "1" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/DoM
	echo "0" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/Hour
	echo "1" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/Minute
	echo "*" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/Month
	echo "" > $C_CRON_SCRIPTS_DIR/ZTrestartorem-Cron/cron/Step
	CONTROL_CRON="yes"
fi

$C_ZT_BIN_DIR/zt "Esegui" "ldconfig"
$C_ZT_BIN_DIR/zt "Esegui" "/etc/init.d/httpd" "restart"
$C_ZT_BIN_DIR/zt "Esegui" "/etc/init.d/ldap" "restart"
$C_ZT_BIN_DIR/zt "Esegui" "useradd" "proxy"
$C_ZT_BIN_DIR/zt "Esegui" "sysctl" "-p"

if [ -n "$CONTROL_CRON" ];then
	echo "$C_ZT_SCRIPTS_DIR/ztpostboot.sh" >> $C_CRON_SCRIPTS_DIR/postboot/File
	echo "yes" > $C_CRON_SCRIPTS_DIR/postboot/Enabled
	$C_ZT_BIN_DIR/zt "RestartCron"
fi


if [ "$C_HAVP" == "on" ] || [ "$C_SQUID" == "on" ];then
	$C_ZT_BIN_DIR/zt "Proxy" "$C_SQUID-$C_HAVP"
fi

if [ -n "$C_SHAPER" ];then
	$C_ZT_BIN_DIR/zt "Cancella" $C_ZT_CONF_DIR/cbqconf/*
	$C_ZT_BIN_DIR/zt "Shaper" "on"
fi



exit
