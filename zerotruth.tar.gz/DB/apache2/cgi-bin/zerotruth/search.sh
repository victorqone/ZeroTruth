#!/bin/bash
#*******************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
source ./main.sh

NAME_SCRIPT=$(echo "$0" | sed 's/\// /g' | awk '{print $NF}')

if [ -n "$INVIA_S" ];then
	if [ -n "$PRINT" ];then
		[ -z "$C_FONT_TICKET" ] && C_FONT_TICKET=16
		[ -z "$C_FONT_TICKET_INFO" ] && C_FONT_TICKET_INFO=12
		echo "<div id=\"ticket\">"
		NC=1
		NS=1
		N_S=$(($N_S+1))
		if [ -z "$C_TICKETS_PAGE" ];then
			N_TICKETS_PAGE=4
		else
			N_TICKETS_PAGE=$(($C_TICKETS_PAGE/2+1))
		fi
		for i in $(seq 1 $N_S);do
			eval USERNAME=\$USER_S$i
			if [ -n "$USERNAME" ];then
				ldap_search_people "uid=$USERNAME"
				ldap_search_radius "$USERNAME"
				CREATED_YEAR=$(echo "$CREATED" | cut -c 1-4 )
				CREATED_MONTH=$(echo "$CREATED" | cut -c 5-6 )
				CREATED_DAY=$(echo "$CREATED" | cut -c 7-8 )
				if [ "$C_FORM_DATE" == "ita" ];then
					DATE_CREATED="$CREATED_DAY/$CREATED_MONTH/$CREATED_YEAR"
				else
					DATE_CREATED="$CREATED_YEAR/$CREATED_MONTH/$CREATED_DAY"
				fi
				if [ "$EXPIRE" == "24836" ];then
					EXPIRE=$(cat $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh | grep '^L_NO_LIMIT=' | cut -d'"' -f2)
				else
					if [ "$C_FORM_DATE" == "ita" ];then
						EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%d/%m/%Y)
					else
						EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%Y/%m/%d)
					fi
				fi
				limituser				
				if [ $i == 1 ];then
					source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
					echo "<table align=\"center\"><tr><td align=\"center\"><font color=\"blue\" size=\"5\">$L_USER_TICKET</font></td></tr>
					<tr><td align=\"center\"><p><img src=\"/images/barra.png\" alt=\"barra\"></td></tr></table><br>&nbsp;<br>"
					echo "<table width=\"920\" border=\"0\" align=\"center\">"
				fi
				source $C_ZT_DIR/language/$LANGUAGE_PRINT/$LANGUAGE_PRINT.sh
				NAME="$L_ANONYMOUS"
				LAST_NAME="$L_ANONYMOUS"
				INFO_TICKET=$(cat $C_ZT_CONF_DIR/infoTicket)
				if [ $NC == 2 ];then
					echo "</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;<br>"
				else
					echo "<tr><td>&nbsp;<br>"
				fi
				PASSWORD=$(echo "$PASSWORD" | cut -d'-' -f1)
				echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\" align=\"center\">
				<tr>
				<td colspan=\"2\"><img src=\"/images/imguser.png\" WIDTH=\"350px\" alt=\"imguser\"></td>
				</tr>
				<tr><td>
				<table  align=\"left\" width=\"350\" style=\"font: ${C_FONT_TICKET}px "Trebuchet MS",Arial,sans-serif;\">"
				if [ -n "$C_PRINT_QR" ];then
					$C_ZT_BIN_DIR/zt "QrCode" "$USERNAME" "$PASSWORD"
					echo "<tr><td colspan =\"2\" align=\"center\"><img src=\"$APACHE_BASEDIR/images/qrcode/${USERNAME}.png\"></td></tr>"
				fi
				echo "<tr><td width=\"130px\"><b>&nbsp;$L_USERNAME: </b></td>
				<td><b>$USERNAME</b></td></tr>
				<tr><td><b>&nbsp;$L_PASSWORD: </b></td>
				<td><b>$PASSWORD</b></td></tr>"
				if [ -n "$C_PRINT_NAME" ];then
					echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
					<tr><td>&nbsp;$L_LAST_NAME: </td><td>$( echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
				else
					if [ "$NAME" != "$L_ANONYMOUS" ];then
						echo "<tr><td>&nbsp;$L_NAME: </td><td>$(echo $NAME | sed '/\\/s///g')</td></tr>
						<tr><td>&nbsp;$L_LAST_NAME: </td><td>$( echo $LAST_NAME | sed '/\\/s///g')</td></tr>"
					fi
				fi
				if [ -n "$ROOM" ];then
					echo "<tr><td>&nbsp;$C_ROOM_NAME: </td><td>$ROOM</td></tr>"
				fi
				if [ -n "$C_PRINT_CLASS" ];then
					echo "<tr><td>&nbsp;$L_CLASS: </td><td>$CLASS</td></tr>"
				fi
				if [ -n "$EMAIL" ];then
					echo "<tr><td>&nbsp;$L_EMAIL: </td><td>$EMAIL</td></tr>"
				fi
				if [ -n "$PHONE" ];then
					echo "<tr><td>&nbsp;$L_TELEPHONE: </td><td>$PHONE</td></tr>"
				fi
				if [ -n "$C_PRINT_CREATED" ];then
					echo "<tr><td>&nbsp;$L_CREATED: </td><td>$DATE_CREATED</td></tr>"
				fi
				if [ -n  "$C_PRINT_EXP" ];then
					echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXPIRE</td></tr>"
				else
					if [ -n "$EXPIRE"  ];then
						echo "<tr><td>&nbsp;$L_ENDS: </td><td>$EXPIRE</td></tr>"
					fi
				fi
				if [[ -n "$DAYS_TICKET" && "$DAYS_TICKET" != "$L_ALL" ]];then
					echo "<tr><td>&nbsp;$L_DAYS: </td><td>$DAYS_TICKET</td></tr>"
				fi
				if [[ -n "$TIME"  && "$TIME" != "$L_ALL" ]];then
					echo "<tr><td>&nbsp;$L_TIME: </td><td>$TIME</td></tr>"
				fi
				if [ -n "$HOURSDAY" ];then
					echo "<tr><td>&nbsp;$L_DMAX_HOURS: </td><td>$HOURSDAY</td></tr>"
				fi
				if [ -n "$HOURSMONTH" ];then
					echo "<tr><td>&nbsp;$L_MMAX_HOURS: </td><td valign=\"button\">$HOURSMONTH</td></tr>"
				fi
				if [ -n "$MBDAY" ];then
					echo "<tr><td>&nbsp;$L_DMAX_MB: </td><td>$MBDAY</td></tr>"
				fi
				if [ -n "$MBMONTH" ];then
					echo "<tr><td>&nbsp;$L_MMAX_MB: </td><td>$MBMONTH</td></tr>"
				fi
				echo "</table>"
				if [ -n "$INFO_TICKET" ];then
					echo "<table width=\"350\" style=\"border-collapse: collapse ;border-color: #a0a0f0 ;\" border=\"1\">
					<tr><td colspan=\"2\" style=\"font: ${C_FONT_TICKET_INFO}px "Trebuchet MS",Arial,sans-serif;\">$INFO_TICKET</td></tr></table>"
				fi
				echo "</table><br>&nbsp;<br>"
				if [ $NC == 1 ];then
					NC=2
				else
					echo "</td></tr>"
					NC=1
					NS=$(($NS+1))
					if [ $NS == $N_TICKETS_PAGE ];then
						echo "</table><p><hr style=\"page-break-after:always\"><p><table align=\"center\" width=\"920\" border=\"0\">"
						NS=1
					fi
				fi
			fi
			DAYS_TICKET=""
		done
		echo "</table><p>"
		echo "</div><p>&nbsp;<br>&nbsp;<br>"
		source $C_ZT_DIR/language/$C_LANGUAGE/$C_LANGUAGE.sh
		echo "<p><input type=button name=\"PRINT\" class=\"bottonelinea\" value=\"$L_PRINT_TICKETS\" onClick=\"StampaTicket()\">
		<form method=\"get\" action=\"$NAME_SCRIPT\">
		<input type=\"hidden\" name=\"USERNAME_RIC\" value=\"$USERNAME_RIC\">
		<input type=\"hidden\" name=\"NAME_RIC\" value=\"$NAME_RIC\">
		<input type=\"hidden\" name=\"LAST_NAME_RIC\" value=\"$LAST_NAME_RIC\">
		<input type=\"hidden\" name=\"CLASS_RIC\" value=\"$CLASS_RIC\">
		<input type=\"hidden\" name=\"ROOM_RIC\" value=\"$ROOM_RIC\">
		<input type=\"hidden\" name=\"PHONE_RIC\" value=\"$PHONE_RIC\">
		<input type=\"hidden\" name=\"EMAIL_RIC\" value=\"$EMAIL_RIC\">
		<input type=\"hidden\" name=\"VALID_RIC\" value=\"$VALID_RIC\">
		<input type=\"hidden\" name=\"OWNER_RIC\" value=\"$OWNER_RIC\">
		<input type=\"submit\" class=\"bottonelineadue\" value=\"$L_GO_BACK\"></form><br>&nbsp;<br>"
		./footer.sh
		exit
	fi
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_REGISTERED_USERS</font><br>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>"
	wait "750"
	for i in $(seq 0 $N_S);do
		eval USERNAME=\$USER_S$i
		if [ -n "$USERNAME" ];then
			if [[ -n $DAY_EXPIRE && -n $MONTH_EXPIRE && -n $YEAR_EXPIRE ]];then
				SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE")
				ldap_modify_people "shadowExpire"
				ldap_search_people "uid=$USERNAME"
				ldap_search_radius "$USERNAME"
				if [ $(echo $PASSWORD | grep '-') ];then
					PASSWORD=$(echo $PASSWORD | cut -d'-' -f1)
				fi
				$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USERNAME" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE"
				$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME" "UPDATE"
			fi
			if [ -n "$NOLIMIT" ];then
				SHADOWEXPIRE=24836
				ldap_modify_people "shadowExpire"
				ldap_search_people "uid=$USERNAME"
				ldap_search_radius "$USERNAME"
				if [ $(echo $PASSWORD | grep '-') ];then
					PASSWORD=$(echo $PASSWORD | cut -d'-' -f1)
				fi
				$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USERNAME" "$YEAR_EXPIRE-$MONTH_EXPIRE-$DAY_EXPIRE"
				$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME" "UPDATE"		
			fi
			if [ "$ACTION" == "DELETE_S" ];then
				deleteuser "$USERNAME"
			fi
			if [ "$ACTION" == "LOCK_S" ];then
				lockuser "$USERLOCK" "yes"
			fi
			if [ "$ACTION" == "UNLOCK_S" ];then
				lockuser "$USERLOCK" "yes"
			fi
			if [ "$ACTION" == "DELETE_SESSIONS_S" ];then
				if [ -n "$USERNAME" ];then
					$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERNAME"
					SESSIONS="0"
					QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME validity)
					VALIDITY=$( echo "$QUERY" | grep -e '^validity: ' | sed 's/^validity: //g')
					if [[ "$VALIDITY" == "T" || "$VALIDITY" == "M" ]];then
						VALIDITY="yes"
					fi
					ldap_modify_people "sessions validity"
				fi
			fi
			if [ "$ACTION" == "DOWNLOAD_SESSIONS_S" ];then
				if [ -n "$USERNAME" ];then
					[ ! -d /tmp/usersSessions ] && $C_ZT_BIN_DIR/zt "CreaCartella" "/tmp/usersSessions"
					if [ -d $C_ACCT_DIR/entries/$USERNAME ];then
						$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERNAME" "/tmp/usersSessions"
					fi
				fi
			fi
			if [ -n "$CLASS_S" ];then
				CONNECTED=$(ls $C_CP_DIR/Connected )
				for IP in $CONNECTED;do
					if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERNAME" ];then
						$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
					fi
				done
				CLASS="$CLASS_S"
				ldap_modify_radius "radiusUserCategory"
				ldap_modify_people "class"
				$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
				$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
				if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
					$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "CHANGE CLASS $USERNAME"
				fi
			fi
			if [ -n "$OWNER_S" ];then
				OWNER="$OWNER_S"
				ldap_modify_people "ownerUser"
				if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
					$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "CHANGE OWNER $USERNAME"
				fi
			fi
			if [ "$ACTION" ==  "DISCONNECT_S" ];then
				disconnectuser "$USERNAME"
			fi
			if [ "$ACTION" ==  "HIDDEN_S" ];then
				HIDDEN="yes"
				ldap_modify_people "hidden"
				if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
					$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "Hidden All"
				fi
			fi
			if [ "$ACTION" ==  "PUBLIC_S" ];then
				HIDDEN="no"
				ldap_modify_people "hidden"
				if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
					$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "Public All"
				fi
			fi
		fi
	done
	if [ -d /tmp/usersSessions ];then
		$C_ZT_BIN_DIR/zt "DownloadSessions"
		LINK="yes"
	fi
	return_page "$NAME_SCRIPT?USERNAME_RIC=$USERNAME_RIC&NAME_RIC=$NAME_RIC&LAST_NAME_RIC=$LAST_NAME_RIC&CLASS_RIC=$CLASS_RIC&ROOM_RIC=$ROOM_RIC&PHONE_RIC=$PHONE_RIC&EMAIL_RIC=$EMAIL_RIC&VALID_RIC=$VALID_RIC&SEARCH=yes&ACTION_RIC=yes&LINK=$LINK"
	exit
fi
if [ -n "$DISCONNECT_ALL" ];then
	if [ -n "$LETTER" ];then
		LETTERD=$(echo "$LETTER" | tr A-Z a-z)
	fi
	NAME_CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -d'@' -f1)
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in $CONNECTED;do
		if [ -n $(cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1 | grep "^$LETTERD") ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		fi
	done
	if [[ "$C_CP_LOCAL_TYPE" == "Server" && -n $(cat $C_ZT_DIR/remote/remotelogin) ]];then
		RIGHE=$(cat $C_ZT_DIR/remote/remotelogin | wc -l )
		for r in $(seq 1 $RIGHE);do
			RIGA=$(cat $C_ZT_DIR/remote/remotelogin | sed -n "${r}p")
			NAS=$(echo "$RIGA" | awk '{print $2}')
			IP=$(echo "$RIGA" | awk '{print $3}')
			NUSER=$(cat $C_ZT_CONF_DIR/zt.config | grep $NAS | cut -d'=' -f1 | cut -sd'E' -f4)
			IP_REMOTE=C_CP_REMOTE_IP$NUSER
			eval IP_REMOTE=\$$IP_REMOTE
			PASS=C_CP_REMOTE_PASSWORD$NUSER
			eval PASS=\$$PASS
			curl http://$IP_REMOTE:8089/cgi-bin/remotecp.sh?NAS=Server+IP=$C_CP_LOCAL_IP+PASS=$PASS+ACTION=DisconnectUser+
		done
	fi
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DISCONNECT_ALL LETTER $LETTER"
	fi
fi
if [ -n "$LOCKTUTTI" ];then
	if [[ -n "$LETTER" && "$LETTER" != "$L_ALL" ]];then
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" "(&(cn=$LETTER*))" '(!(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	else
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(!(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	fi
	if [[ "$C_CP_LOCAL_TYPE" == "Server" && -n $(cat $C_ZT_DIR/remote/remotelogin) ]];then
		RIGHE=$(cat $C_ZT_DIR/remote/remotelogin | wc -l )
		for r in $(seq 1 $RIGHE);do
			RIGA=$(cat $C_ZT_DIR/remote/remotelogin | sed -n "${r}p")
			NAS=$(echo "$RIGA" | awk '{print $2}')
			IP=$(echo "$RIGA" | awk '{print $3}')
			NUSER=$(cat $C_ZT_CONF_DIR/zt.config | grep $NAS | cut -d'=' -f1 | cut -sd'E' -f4)
			IP_REMOTE=C_CP_REMOTE_IP$NUSER
			eval IP_REMOTE=\$$IP_REMOTE
			PASS=C_CP_REMOTE_PASSWORD$NUSER
			eval PASS=\$$PASS
			curl http://$IP_REMOTE:8089/cgi-bin/remotecp.sh?NAS=Server+IP=$C_CP_LOCAL_IP+PASS=$PASS+ACTION=DisconnectUser+OPTION=$IP
		done
	fi
	for USERL in $USERLOCK;do
		if [[ "$USERL" != "admin" && -n "$USERLOCK" ]];then
			OWNER=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERL ownerUser | sed -n '/ownerUser:/p' | awk '{ print $2 }')
			if [[ "$UTENTEC" == "$C_ADMIN" || -z "$C_THEIR_USERS" ]] || [[ -n "$C_THEIR_USERS" && "$OWNER" == "$UTENTEC" ]];then
				CONNECTED=$(ls $C_CP_DIR/Connected )
				for IP in $CONNECTED;do
					if [ $(cat $C_CP_DIR/Connected/$IP/User | cut -d"@" -f1) == "$USERL" ];then
						$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
					fi
				done
				RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERL sn)
				PASS=$( echo $RADIUS | awk '{print $NF}')
				if [ -z "$CONTROLLOCK" ] ;then
					PASSLOCK="$PASS-$RANDOM"
					DATA="dn: cn=$USERL,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
					echo -e "$DATA" | ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
				fi
			fi
		fi
	done
	if [[ -n "$C_LOG_USER" && -n "$USERLOCK" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_LOCK_ALL"
	fi
	USERLOCK=""
	USERL=""
fi
if [ -n "$UNLOCKTUTTI" ];then
	if [[ -n "$LETTER" && "$LETTER" != "$L_ALL" ]];then
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" "(&(cn=$LETTER*))" '(&(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	else
		USERLOCK=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" '(&(sn=*-*))' cn | sed -n '/cn:/p' | awk '{ print $2 }')
	fi
	for USERL in $USERLOCK;do
		OWNER=$(/usr/local/bin/ldapsearch -xLLL -b "ou=PEOPLE,$C_LDAPBASE"  uid=$USERL ownerUser | sed -n '/ownerUser:/p' | awk '{ print $2 }')
		if [[ "$UTENTEC" == "$C_ADMIN" || -z "$C_THEIR_USERS" ]] || [[ -n "$C_THEIR_USERS" && "$OWNER" == "$UTENTEC" ]];then
			if [[ "$USERL" != "admin" && -n "$USERLOCK" ]];then
				RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USERL sn)
				PASS=$( echo $RADIUS | awk '{print $NF}')
				PASS=$(echo "$PASS" | cut -d'-' -f1)
				DATA="dn: cn=$USERL,ou=Radius,$C_LDAPBASE\nsn: $PASS"
				echo -e "$DATA" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
			fi
		fi
	done
	if [[ -n "$C_LOG_USER" && -n "$USERLOCK" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UNLOCK_ALL"
	fi
	USERLOCK=""
	USERL=""
fi
if [ -n "$DELETEEXP" ];then
	if [ -n "$LETTER" ];then
		FILTERD="(&(uid=$LETTER*) (&(validity=no)))"
	else
		FILTERD="validity=no"
	fi
	EXPIRED=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$FILTERD" uid)
	USEREXPIRED=$(echo "$EXPIRED" | sed -n '/uid:/p' | awk '{ print $2 }')
	if [ -n "$USEREXPIRED" ];then
		for USER_EX in $USEREXPIRED;do
			if [ -d $C_CRON_SCRIPTS_DIR/ZT${USER_EX}START-Cron ];then
				$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USER_EX}START-Cron"
				$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USER_EX}STOP-Cron"
				CONTROL_CRON="yes"
			fi
			if [ -d $C_CRON_SCRIPTS_DIR/ZT${USER_EX}STARTSEC-Cron ];then
				$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USER_EX}STARTSEC-Cron"
				$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USER_EX}STOPSEC-Cron"
				CONTROL_CRON="yes"
			fi
			if [ -n "$CONTROL_CRON" ];then
				$C_ZT_BIN_DIR/zt "RestartCron"
			fi
			LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USER_EX givenName sn)
			NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g' | sed 's/ /_/g')
			LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g' | sed 's/ /_/g')
			TODAY=$(date +%d%m%Y)
			if [ -d $C_ACCT_DIR/entries/$USER_EX/sessions ];then
				if ! [ -d $C_ZT_DIR/deleted ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted"
				fi
				$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
				$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USER_EX" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
				$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USER_EX"
				if [ -f $C_ACCT_DIR/credits/$USER_EX/Credit ];then
					$C_ZT_BIN_DIR/zt "Copia" "$C_ACCT_DIR/credits/$USER_EX/Credit" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY/Credit"
				fi
			fi
			if [ -d $C_ZT_DIR/expired/$USER_EX ];then
				if ! [ -d $C_ZT_DIR/deleted/$USER_EX_$NAME_$LAST_NAME_$TODAY ];then
					$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY"
				fi
				$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ZT_DIR/expired/$USER_EX" "$C_ZT_DIR/deleted/$USER_EX-$NAME-$LAST_NAME-$TODAY/EXPIRED"
				$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USER_EX"
			fi
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USER_EX"
			/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USER_EX,ou=People,$C_LDAPBASE" > /dev/null
			/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USER_EX,ou=Radius,$C_LDAPBASE" > /dev/null
			$C_ZT_BIN_DIR/zt "DelK5" "$USER_EX"
		done
		if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETE_EXPIRED"
		fi
	fi
	EXPIRED=""
	USEREXPIRED=""
	USER_EX=""
fi
if [ -n "$USERLOCK" ];then
	if [ "$LOCK" != "no" ];then
		PASSLOCK="$PASSLOCK-$RANDOM"
	fi
	file="dn: cn=$USERLOCK,ou=Radius,$C_LDAPBASE\nsn: $PASSLOCK"
	echo -e "$file" | /usr/local/bin/ldapmodify -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT > /dev/null
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in $CONNECTED;do
		if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERLOCK" ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		fi
	done
	 if [[ "$C_CP_LOCAL_TYPE" == "Server" && -n $(cat $C_ZT_DIR/remote/remotelogin) ]];then
		USERL=$(cat $C_ZT_DIR/remote/remotelogin | grep $USERLOCK)
		if [ -n "$USERL" ];then
			USERLOCK=$(echo "$USERL" | awk '{print $1}')
			NASUSERLOCK=$(echo "$USERL" | awk '{print $2}')
			IPUSERLOCK=$(echo "$USERL" | awk '{print $3}')
			NUSERLOCK=$(cat $C_ZT_CONF_DIR/zt.config | grep $NASUSERLOCK | cut -d'=' -f1 | cut -sd'E' -f4)
			IP_REMOTE=C_CP_REMOTE_IP$NUSERLOCK
			eval IP_REMOTE=\$$IP_REMOTE
			PASS=C_CP_REMOTE_PASSWORD$NUSERLOCK
			eval PASS=\$$PASS
			curl http://$IP_REMOTE:8089/cgi-bin/remotecp.sh?NAS=Server+IP=$C_CP_LOCAL_IP+PASS=$PASS+ACTION=DisconnectUser+OPTION=$IPUSERLOCK
		fi
	fi
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		if [ "$LOCK" != "no" ];then
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_LOCK user $USERLOCK"
		else
			$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_UNLOCK user $USERLOCK"
		fi
	fi
fi
if [ -n "$USERDEL" ];then
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOP-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}START-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -d $C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOPSEC-Cron ];then
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STOPSEC-Cron"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_CRON_SCRIPTS_DIR/ZT${USERDEL}STARTSEC-Cron"
		CONTROL_CRON="yes"
	fi
	if [ -n "$CONTROL_CRON" ];then
		$C_ZT_BIN_DIR/zt "RestartCron"
	fi
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERDEL,ou=People,$C_LDAPBASE" > /dev/null
	/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "cn=$USERDEL,ou=Radius,$C_LDAPBASE" > /dev/null
	CONNECTED=$(ls $C_CP_DIR/Connected )
	for IP in "$CONNECTED";do
		if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERDEL" ];then
			$C_ZT_BIN_DIR/zt "Disconnetti" "$IP"
		fi
	done
	if [ -d $C_ACCT_DIR/entries/$USERDEL ];then
		NAME=$(echo "$NAME" | sed '/ /s///g' | sed 's/ /_/g')
		LAST_NAME=$(echo "$LAST_NAME" | sed '/ /s///g' | sed 's/ /_/g')
		TODAY=$(date +%d%m%Y)
		$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ACCT_DIR/entries/$USERDEL" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-$TODAY"
		$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/entries/$USERDEL"
		if [ -d $C_ZT_DIR/expired/$USERDEL ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_DIR/deleted/$NAME-$LAST_NAME-$TODAY/EXPIRED"
			$C_ZT_BIN_DIR/zt "CopiaTutto" "$C_ZT_DIR/expired/$USERDEL" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-CREDIT-$TODAY/EXPIRED"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/expired/$USERDEL"
		fi
		if [ -f $C_ACCT_DIR/credits/$USERDEL/Credit ];then
			$C_ZT_BIN_DIR/zt "Salva" "$(cat $C_ACCT_DIR/credits/$USERDEL/Credit)" "$C_ZT_DIR/deleted/$USERDEL-$NAME-$LAST_NAME-$TODAY/Credit"
		fi
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "$C_ACCT_DIR/credits/$USERDEL"
	$C_ZT_BIN_DIR/zt "DelK5" "$USERDEL"
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DELETED user $USERDEL"
	fi
	if [ "$C_NOT_SMS_DELETE_USER" == "on" ] && [ -n "$C_ADMIN_PHONE" ] && [ -n $C_SMS_ABIL ];then
		TEXT_SMS_ADMIN="$C_HOTSPOT_NAME: $L_DELETED_USER $USERDEL $L_BY $UTENTEC"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS_ADMIN"
	fi
	if [ -n "$C_NOT_EMAIL_DELETE_USER" ] && [ -n "$C_ADMIN_EMAIL" ] && [ -n $C_EMAIL_ABIL ];then
		TEXT_EMAIL_ADMIN="$(cat $C_ZT_CONF_DIR/emailh)\n"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n$L_DELETED_USER $USERDEL\n$L_BY $UTENTEC"
		TEXT_EMAIL_ADMIN="$TEXT_EMAIL_ADMIN\n\n$(cat $C_ZT_CONF_DIR/emailf)"
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL_ADMIN" "$C_ADMIN_EMAIL"
	fi
fi
if [ -n "$USERDIS" ];then
	if [ "$CONTROL_CON_REMOTE" == "ok" ];then
		for nu in $(seq 1 5);do
			NAME="C_CP_REMOTE_NAME$nu"
			eval NAME="\$$NAME"
			if [ "$NAME" == "$NAS" ];then
				IP_REMOTE="C_CP_REMOTE_IP$nu"
				eval IP_REMOTE="\$$IP_REMOTE"
				PASS="C_CP_REMOTE_PASSWORD$nu"
				eval PASS="\$$PASS"
			fi
		done
		curl http://$IP_REMOTE:8089/cgi-bin/remotecp.sh?NAS=Server+IP=$C_CP_LOCAL_IP+PASS=$PASS+ACTION=DisconnectUser+OPTION=$USERIP
	else
		[ "$C_CP_LOCAL_TYPE" == "Client" ] && REM="yes"
		USER_CONNECT="$(cat $C_CP_DIR/Connected/$USERIP/User | cut -sd'@' -f1)"
		$C_ZT_BIN_DIR/zt "Disconnetti" "$USERIP" "$REM"
	fi
	if [[ -n "$C_LOG_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		$C_ZT_BIN_DIR/zt "AddLog" "$UTENTEC" "$L_DISCONNECTED $USER_CONNECT $USERIP"
	fi
fi
if [ -z "$SEARCH" ];then
	echo "<br><font color=\"#0000FF\" size=\"5\">$L_REGISTERED_USERS</font>
	<p><img src=\"/images/barra.png\" alt=\"barra\">
	<p><font color=\"#0000FF\" size=\"3\">$L_SEARCH</font><p>
	<form method=\"POST\" action=\"$NAME_SCRIPT\">
	<p>&nbsp;<p><table class=\"naked\" width=\"55%\">
	<tr><td>$L_USERNAME: </td>
	<td><input name=\"USERNAME_RIC\" type=\"text\" value=\"\" size=\"15\"></td>
	<td>$L_CLASS: </td><td>
	<select name=\"CLASS_RIC\">"
	for class in $(ls $C_CLASSES_DIR);do
		if [ -d $C_CLASSES_DIR/$class ];then
			echo "<option value=\"$class\" selected>$class</option>"
		fi
	done
	echo "<option value=\"\" selected></option>
	</option></select></td></tr>
	<tr><td>$L_NAME:</td>
	<td><input name=\"NAME_RIC\" type=\"text\" value=\"\" size=\"15\"></td>
	<td>$L_LAST_NAME : </td>
	<td><input name=\"LAST_NAME_RIC\" type=\"text\" value=\"\" size=\"15\"></td></tr>
	<tr><td>$L_EMAIL:</td>
	<td><input name=\"EMAIL_RIC\" type=\"text\" value=\"\" size=\"15\"></td>
	<td>$L_PHONE: </td>
	<td><input name=\"PHONE_RIC\" type=\"text\" value=\"\" size=\"15\"></td></tr>
	<tr><td>$L_VALID:<td>
	<select name=\"VALID_RIC\">
	<option value=\"no\" >$L_NO</option>
	<option value=\"yes\">$L_YES</option>
	<option value=\"\" selected></option>
	</option></select></td>"
	if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
	[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
		ROOMS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" roomName | sed -n '/roomName:/p' | awk '{ print $2 }' | sed '/\?/d' | sort | uniq )
		echo "<td>$C_ROOM_NAME: </td><td>
		<select name=\"ROOM_RIC\">"
		for ST in $ROOMS;do
			if [ "$ST" != "?" ];then
				echo "<option value=\"$ST\" selected>$ST</option>"
			fi
		done
		echo "<option value=\"\" selected></option>
		</select></td>"
	else
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<td>$L_OWNER: </td><td>
			<select name=\"OWNER_RIC\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -z "$CONTROLOW" ];then
		if [[ -z "$C_THEIR_USERS" || "$UTENTEC" == "$C_ADMIN" ]];then
			echo "<tr><td>$L_OWNER:<td>
			<select name=\"OWNER_RIC\">"
			for OWNER_EX in $(ls -A ./conf/Manager/);do
				echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
			done
			echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
			echo "<option value=\"\" selected></option>
			</select></td>"
			CONTROLOW="ok"
		fi
	fi
	if [ -z "$CONTROLOW" ];then
		echo "<input type=\"hidden\" name=\"OWNER_RIC\" value=\"$UTENTEC\">"
	fi
	echo "</tr></table>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"submit\" name=\"SEARCH\" class=\"bottone\" value=\"$L_SEARCH\"></form><p>"
	./footer.sh
	exit
fi
echo "<br><font color=\"blue\" size=\"5\">$L_REGISTERED_USERS</font>"
search "$USERNAME_RIC" "$NAME_RIC" "$LAST_NAME_RIC" "$CLASS_RIC" "$ROOM_RIC" "$PHONE_RIC" "$EMAIL_RIC" "$VALID_RIC" "$OWNER_RIC"
	echo "<p><table border=\"0\" align=\"center\"><tr>
	<td><form action=\"$NAME_SCRIPT\" method=\"POST\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\">
	</form></td></tr></table><p>"
	echo "<form method=\"POST\" action=\"$NAME_SCRIPT\">"
	echo "<div style=\"font: 12$px Trebuchet MS,Arial,sans-serif;\">$L_USERNAME: <font color=\"blue\">$URIC</font>&nbsp;&nbsp; $L_NAME: <font color=\"blue\">$NRIC</font>
	&nbsp;&nbsp; $L_LAST_NAME: <font color=\"blue\">$CRIC</font> &nbsp;&nbsp;$L_CLASS: <font color=\"blue\">$PRIC</font>
	&nbsp;&nbsp;$L_OWNER: <font color=\"blue\">$OWRIC</font> &nbsp;&nbsp;$L_EMAIL: <font color=\"blue\">$ERIC</font>
	&nbsp;&nbsp;$L_PHONE: <font color=\"blue\">$PHRIC</font>&nbsp;&nbsp;
	$L_VALID: <font color=\"blue\">$SCRIC</font>"
	if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
    [[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
		echo "&nbsp;&nbsp;$C_ROOM_NAME: <font color=\"blue\">$SRIC</font>"
	fi
	echo "</div>"
	px="px"
	CS="no"
	if [ -z "$CSC" ];then
		CS="yes"
		CSC="yes"
	else
		CS="no"
		CSC=""
	fi
	[ -z "$C_FONT_SEARCH" ] && C_FONT_SEARCH=16
	echo "<table class=\"tabellauser\" style=\"font: $C_FONT_SEARCH$px Trebuchet MS,Arial,sans-serif;\" border=\"1\">
	<tr>
	<td class=\"intesta\" align=\"center\">N.</td>
	<td class=\"intesta\" align=\"center\">
	<a href=\"search.sh?USERNAME_RIC=$USERNAME_RIC&CLASS_RIC=$CLASS_RIC&NAME_RIC=$NAME_RIC&LAST_NAME_RIC=$LAST_NAME_RIC&EMAIL_RIC=$EMAIL_RIC&PHONE_RIC=$PHONE_RIC&VALID_RIC=$VALID_RIC&ROOM_RIC=$ROOM_RIC&OWNER_RIC=$OWNER_RIC&SEARCH=yes&SORT=sessions\">S.</a></td>
	<td class=\"intesta\" align=\"center\">
	<a href=\"search.sh?USERNAME_RIC=$USERNAME_RIC&CLASS_RIC=$CLASS_RIC&NAME_RIC=$NAME_RIC&LAST_NAME_RIC=$LAST_NAME_RIC&EMAIL_RIC=$EMAIL_RIC&PHONE_RIC=$PHONE_RIC&VALID_RIC=$VALID_RIC&ROOM_RIC=$ROOM_RIC&OWNER_RIC=$OWNER_RIC&SEARCH=yes&CSC=$CSC&SORT=$SORT\">C.</a>
	</td>"

if [[ -n "$C_ROOM" && -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" ]] || \
	[[ -n "$C_ROOM_NAME" && "$C_CP_LOCAL_TYPE" != "Server" && "$UTENTEC" == "$C_ADMIN" ]];then
	echo "<td class=\"intesta\">$C_ROOM_NAME</td>"
fi
if [ "$C_CP_LOCAL_TYPE" == "Server" ];then
	echo "<td class=\"intesta\">NAS</td>"
fi

echo "<td class=\"intesta\">$L_USERNAME</td>
<td class=\"intesta\">$L_NAME</td>
<td class=\"intesta\">$L_LAST_NAME</td>
<td class=\"intesta\">$L_CLASS</td>"
if [ "$UTENTEC" == "$C_ADMIN" ];then
	echo "<td class=\"intesta\">$L_OWNER</td>"
fi
echo "<td class=\"intesta\">$L_EMAIL</td>
<td class=\"intesta\">$L_TELEPHONE</td>
<td class=\"intesta\">$L_EXPIRY</td>"
echo "<td colspan=\"4\" class=\"intesta\">S.</td>"

echo "</tr>"
N=1
NR=0
PASSBLOCKED=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" sn=*-* cn | sed -n '/cn:/p' | awk '{ print $2 }' |  sed 's/^/-/g' | sed 's/ /-/g' | sed 's/$/-/g')
if [ "$(ls $C_CP_DIR/Connected/)" ];then
	CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -sd'@' -f1)
	CONNECTED=$(echo $CONNECTED |  sed 's/^/--/g' | sed 's/ /--/g' | sed 's/$/--/g')
fi
[ -z "$SORT" ] && SORT="uid"
PEOPLE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "$CONTROLLDAP" -S $SORT uid hidden givenName sn mail telephoneNumber shadowExpire validity gecos sessions class ownerUser roomName)
if [ -n "$(echo "$PEOPLE" | grep '^uid:')" ];then
	PEOPLE=$(echo "$PEOPLE" | sed '/^dn:/d'  | sed 's/^$/XXXXX/g')
	PEOPLE=$(echo "$PEOPLE" | \
	sed 's/sessions: /01--/g' | \
	sed 's/uid: /02--/g' | \
	sed 's/hidden: /03--/g' | \
	sed 's/givenName: /04--/g' | \
	sed 's/sn: /05--/g' | \
	sed 's/mail: /06--/g' | \
	sed 's/telephoneNumber: /07--/g' | \
	sed 's/shadowExpire: /08--/g' | \
	sed 's/validity: /09--/g' | \
	sed 's/gecos: /10--/g' | \
	sed 's/class: /11--/g' | \
	sed 's/ownerUser: /12--/g' | \
	sed 's/roomName: /13--/g' | \
	sed 's/ /+/g' )
	PEOPLE=$(echo $PEOPLE | sed 's/XXXXX/\n/g' | sed '/^dn/d' | sed 's/^ //g' | sed '/^$/d')
	NUSERS=$(echo "$PEOPLE" | grep '02--' | wc -l | awk '{print $1}')
	PEOPLE="$(echo "$PEOPLE" | $C_ZT_SCRIPTS_DIR/split.sh| sed 's/[0-9][0-9]--//g' | sed 's/\?/\&nbsp;/g' | sed 's/+/\&nbsp;/g')"
	echo "$PEOPLE" | awk -v NOLIMIT="$L_NO_LIMIT" -v LETTER="$LETTERVIEW" -v DELETE="$L_DELETE" \
	-v LOCK="$L_LOCK" -v UNLOCK="$L_UNLOCK" -v EDIT="$L_MODIFY" -v AVVLOCK="$L_ALERT_LOCKED" -v AVVDELETE="$L_ALERT_REMOVE" \
	-v AVVUNLOCK="$L_ALERT_UNLOCK" -v DISCONNECT="$L_DISCONNECT1"  -v AVVDISCONNECT="$L_ALERT_DISCONNECT" -v CROOM="$C_ROOM_NAME" \
	-v LOCKED="$PASSBLOCKED" -v CONNECTED="$CONNECTED" -v USERNAME_RIC="$USERNAME_RIC" -v NAME_RIC="$NAME_RIC" -v LAST_NAME_RIC="$LAST_NAME_RIC" \
	-v CLASS_RIC="$CLASS_RIC" -v ROOM_RIC="$ROOM_RIC" -v EMAIL_RIC="$EMAIL_RIC" -v VALID_RIC="$VALID_RIC" -v OWNER_RIC="$OWNER_RIC" \
	-v UC="$UTENTEC" -v ADMIN="$C_ADMIN" -v EDITUSERS="$C_EDIT_USERS"  -v UNLOCKLOCK="$C_UNLOCK_LOCK_USERS" -v DELETEUSER="$C_DELETE_USER" \
	-v DISCONNECTUSER="$C_DISCONNECT_USER" -v MBLIMITREACHED="$L_MB_LIMIT_REACHED" -v HOURLIMITREACHED="$L_HOUR_LIMIT_REACHED" \
	-v EXCEEDEDEXPIRYDATE="$L_EXCEEDED_EXPIRY_DATE" -v CREDITNOTAVAILABLE="$L_CREDIT_NOT_AVAILABLE" -v CS="$CS" -f $C_ZT_SCRIPTS_DIR/tablesearch.awk
	echo "</table><p>"
	echo "<p>"
	echo "$L_ACTIONS: <select name=\"ACTION\">"
	if [[ -n "$C_DELETE_USER" || "$UTENTEC" == "$C_ADMIN" ]];then
		echo "<option value=\"DELETE_S\">$L_DELETE</option>"
	fi
	if [[ -n "$C_DISCONNECT_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
		echo "<option value=\"DISCONNECT_S\">$L_DISCONNECT1</option>"
	fi
	if [[ -n "$C_LOCK_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
		echo "<option value=\"LOCK_S\">$L_LOCK</option>"
	fi
	if [[ -n "$C_UNLOCK_ALL" || "$UTENTEC" == "$C_ADMIN" ]];then
		echo "<option value=\"UNLOCK_S\">$L_UNLOCK</option>"
	fi
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<option value=\"HIDDEN_S\">$L_HIDDEN</option>
		<option value=\"PUBLIC_S\">$L_PUBLIC</option>"
	fi
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<option value=\"DOWNLOAD_SESSIONS_S\">Download $L_SESSIONS</option>"
	fi
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "<option value=\"DELETE_SESSIONS_S\">$L_DELETE_SESSIONS</option>"
	fi
	echo "<option value=\"\" selected=\"selected\"></option></select>"
	if [[ "$UTENTEC" == "$C_ADMIN" || -n $C_GES_CLASS ]];then
		echo "&nbsp;&nbsp;&nbsp;&nbsp;$L_CHANGE_CLASS: <select name=\"CLASS_S\">"
		for CL in $(ls $C_CLASSES_DIR);do
			if [[ -n "$(echo $C_CLASS_USER | grep "$CL")" || "$UTENTEC" == "$C_ADMIN" ]];then
				echo "<option value=\"$CL\" selected>$CL</option>"
			fi
		done
		echo "<option value=\"\" selected></option></select>"
	fi
	if [ "$UTENTEC" == "$C_ADMIN" ];then
		echo "&nbsp;&nbsp;&nbsp;&nbsp$L_CHANGE_OWNER:
		<select name=\"OWNER_S\">"
		for OWNER_EX in $(ls -A ./conf/Manager/);do
			echo "<option value=\"$OWNER_EX\" selected>$OWNER_EX</option>"
		done
		echo "<option value=\"$C_ADMIN\" selected>$C_ADMIN</option>"
		echo "<option value=\"\" selected></option>
		</select>"
	fi
	if [[ -n "$C_PRINT_TICKET"  || "$UTENTEC" == "$C_ADMIN" ]];then
		echo "&nbsp;&nbsp;&nbsp;&nbsp;$L_PRINT_TICKET:
		<input name=\"PRINT\" type=\"checkbox\">
		<select name=\"LANGUAGE_PRINT\">"
		for LANG in $(ls -A ./language/);do
			if [ "$LANG" != "$C_LANGUAGE" ] && [ "$LANG" != "index.html" ];then
				LANG1=$LANG
				[ "$LANG" == "espanol" ] && LANG1="espa&ntilde;ol"
				[ "$LANG" == "portugues" ] && LANG1="portugu&ecirc;s"
				[ "$LANG" == "francais" ] && LANG1="fran&ccedil;ais"
				echo "<option  value=\"$LANG\">$LANG1</option>"
			fi
		done
		LANGUAGE1=$C_LANGUAGE
		[ "$C_LANGUAGE" == "espanol" ] && LANGUAGE1="espa&ntilde;ol"
		[ "$C_LANGUAGE" == "portugues" ] && LANGUAGE1="portugu&ecirc;s"
		[ "$C_LANGUAGE" == "francais" ] && LANGUAGE1="fran&ccedil;ais"
		echo "<option value=\"$C_LANGUAGE\" selected=\"selected\">$LANGUAGE1</option></select>"
	fi
	YNOW=$(date +%Y)
	YEND=$(($YNOW+10))
	if [ -n "$C_EXPIRE" ] || [ "$UTENTEC" == "$C_ADMIN" ] ;then
		echo "<br>&nbsp;<br>"
		if [ "$C_FORM_DATE" == "ita" ];then
			echo "$L_EXPIRY:
			<select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\" selected>$L_DAY</option></select> 
			<select name=\"MONTH_EXPIRE\">"
			for M in $(seq 1 12);do
				echo "<option value=\"$M\" selected>$M</option>"
			done
			echo "<option value=\"\" selected>$L_MONTH</option></select>
			<select name=\"YEAR_EXPIRE\">"
			for A in $(seq $YNOW $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\" selected>$L_YEAR</option></select>"
			echo "&nbsp;&nbsp;$L_NO_LIMIT: <input name=\"NOLIMIT\" type=\"checkbox\">"
		else
			echo "$L_EXPIRY:
			<select name=\"YEAR_EXPIRE\">"
			for A in $(seq $YNOW $YEND);do
				echo "<option value=\"$A\" selected>$A</option>"
			done
			echo "<option value=\"\" selected>$L_YEAR</option></select>
			<select name=\"MONTH_EXPIRE\">"
			for M in $(seq 1 12);do
				echo "<option value=\"$M\" selected>$M</option>"
			done
			echo "<option value=\"\" selected>$L_MONTH</option></select>
			<select name=\"DAY_EXPIRE\">"
			for G in $(seq 1 31);do
				echo "<option value=\"$G\" selected>$G</option>"
			done
			echo "<option value=\"\" selected>$L_DAY</option></select>"
			echo "&nbsp;&nbsp;$L_NO_LIMIT: <input name=\"NOLIMIT\" type=\"checkbox\">"
		fi
	fi
	N_S=$(($N-1))
	echo "<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<input type=\"hidden\" name=\"N_S\" value=\"$NUSERS\">
	<input type=\"hidden\" name=\"USERNAME_RIC\" value=\"$USERNAME_RIC\">
	<input type=\"hidden\" name=\"NAME_RIC\" value=\"$NAME_RIC\">
	<input type=\"hidden\" name=\"LAST_NAME_RIC\" value=\"$LAST_NAME_RIC\">
	<input type=\"hidden\" name=\"CLASS_RIC\" value=\"$CLASS_RIC\">
	<input type=\"hidden\" name=\"ROOM_RIC\" value=\"$ROOM_RIC\">
	<input type=\"hidden\" name=\"PHONE_RIC\" value=\"$PHONE_RIC\">
	<input type=\"hidden\" name=\"EMAIL_RIC\" value=\"$EMAIL_RIC\">
	<input type=\"hidden\" name=\"VALID_RIC\" value=\"$VALID_RIC\">
	<input type=\"hidden\" name=\"OWNER_RIC\" value=\"$OWNER_RIC\">
	<input type=\"submit\" name=\"INVIA_S\" class=\"bottone\" value=\"$L_CONTINUE\";
	onClick=\"javascript:return confirm('$L_ALERT_CHANGES');\">
	</form><br>&nbsp;"
	if [ -n "$LINK" ];then
		FILE_DOWNLOAD=$(ls $C_HTDOCS_DIR/*.tgz | cut -d'/' -f5)
		echo "<script type=\"text/javascript\">window.location=\"/$FILE_DOWNLOAD\";</script>"
	else
		[ -n "$(ls $C_HTDOCS_DIR/*usersSessions.tgz)" ] && $C_ZT_BIN_DIR/zt "Cancella" "$C_HTDOCS_DIR/*usersSessions.tgz"
	fi
else
	echo "</table><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<p><font color=\"red\">$L_NO_RESULT</font><p>
	<p><img src=\"/images/barra.png\" alt=\"barra\"><p>
	<form action=\"$NAME_SCRIPT\" method=\"POST\">
	<input type=\"submit\" class=\"bottone\" value=\"$L_GO_BACK\"></form><p>&nbsp;<p>"
fi
./footer.sh
