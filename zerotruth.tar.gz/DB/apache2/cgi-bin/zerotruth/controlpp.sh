#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright	(C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh
POST=$(</dev/stdin)_id
if [ "$POST" != "" ];then
	n=$(($(echo $POST | grep -o "&" | wc -l)+1))
	for i in $(seq 1 $n);do
		NV=$(echo $POST | awk '{split ($0, a, "&*&");print a['$i']}')
		NAME_VAR=$(echo $NV | cut -d'=' -f1)
		VAL_VAR=$(echo $NV | sed '/'$NAME_VAR='/s///g')
		VAL_VAR=$($C_ZT_BIN_DIR/convplain "$VAL_VAR")
		eval $NAME_VAR=\"$VAL_VAR\"
	done
fi
$C_ZT_BIN_DIR/zt "Aggiungi" "PAYER_EMAI $payer_email" "$C_ZT_DIR/tmp/lock_pay_$custom"
$C_ZT_BIN_DIR/zt "Aggiungi" "TXN_ID $txn_id" "$C_ZT_DIR/tmp/lock_pay_$custom"
$C_ZT_BIN_DIR/zt "Aggiungi" "AMMOUNT $mc_gross" "$C_ZT_DIR/tmp/lock_pay_$custom"
PAYMENT_HOUR=$(echo "$payment_date" | cut -d' ' -f1)
$C_ZT_BIN_DIR/zt "Aggiungi" "PAYMENT_HOUR $PAYMENT_HOUR" "$C_ZT_DIR/tmp/lock_pay_$custom"
PAYMENT_DATE=$(echo "$payment_date" | sed "s/$PAYMENT_HOUR//g")
$C_ZT_BIN_DIR/zt "Aggiungi" "PAYMENT_DATE $PAYMENT_DATE" "$C_ZT_DIR/tmp/lock_pay_$custom"
$C_ZT_BIN_DIR/zt "Aggiungi" "PAYMENT_STATUS $payment_status" "$C_ZT_DIR/tmp/lock_pay_$custom"
exit
